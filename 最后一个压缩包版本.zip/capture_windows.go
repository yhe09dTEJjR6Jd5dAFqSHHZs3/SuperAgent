//go:build windows

package main

import (
	"fmt"
	"math"
	"runtime"
	"unsafe"
)

func captureWindow(hwnd uintptr) ([]byte, int, int, error) {
	var r RECT
	ok, _, _ := pGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
	if ok == 0 {
		return nil, 0, 0, fmt.Errorf("GetWindowRect 失败")
	}
	sw, sh := int(r.Right-r.Left), int(r.Bottom-r.Top)
	if sw < 80 || sh < 60 || sw > 20000 || sh > 20000 {
		return nil, 0, 0, fmt.Errorf("窗口尺寸无效：%dx%d", sw, sh)
	}
	scale := math.Min(1, math.Min(1000/float64(sw), 620/float64(sh)))
	w, h := int(float64(sw)*scale), int(float64(sh)*scale)
	if w < 80 || h < 60 {
		return nil, 0, 0, fmt.Errorf("缩放后窗口尺寸过小")
	}
	bmi := BITMAPINFO{Header: BITMAPINFOHEADER{Size: uint32(unsafe.Sizeof(BITMAPINFOHEADER{})), Width: int32(w), Height: int32(-h), Planes: 1, BitCount: 32, Compression: BI_RGB, SizeImage: uint32(w * h * 4)}}
	screenDC, _, _ := pGetDC.Call(0)
	if screenDC == 0 {
		return nil, 0, 0, fmt.Errorf("GetDC 失败")
	}
	defer pReleaseDC.Call(0, screenDC)
	memDC, _, _ := pCreateCompatibleDC.Call(screenDC)
	if memDC == 0 {
		return nil, 0, 0, fmt.Errorf("CreateCompatibleDC 失败")
	}
	defer pDeleteDC.Call(memDC)
	var bits uintptr
	bitmap, _, _ := pCreateDIBSection.Call(screenDC, uintptr(unsafe.Pointer(&bmi)), DIB_RGB_COLORS, uintptr(unsafe.Pointer(&bits)), 0, 0)
	if bitmap == 0 || bits == 0 {
		return nil, 0, 0, fmt.Errorf("CreateDIBSection 失败")
	}
	defer pDeleteObject.Call(bitmap)
	old, _, _ := pSelectObject.Call(memDC, bitmap)
	defer pSelectObject.Call(memDC, old)
	printed, _, _ := pPrintWindow.Call(hwnd, memDC, PW_RENDERFULLCONTENT)
	pix := make([]byte, w*h*4)
	pRtlMoveMemory.Call(uintptr(unsafe.Pointer(&pix[0])), bits, uintptr(len(pix)))
	if printed == 0 || mostlyBlack(pix) {
		pSetStretchBltMode.Call(memDC, HALFTONE)
		pStretchBlt.Call(memDC, 0, 0, uintptr(w), uintptr(h), screenDC, uintptr(r.Left), uintptr(r.Top), uintptr(sw), uintptr(sh), SRCCOPY|CAPTUREBLT)
		pRtlMoveMemory.Call(uintptr(unsafe.Pointer(&pix[0])), bits, uintptr(len(pix)))
	}
	runtime.KeepAlive(pix)
	return pix, w, h, nil
}

func mostlyBlack(p []byte) bool {
	if len(p) < 4 {
		return true
	}
	count, bright := 0, 0
	total := len(p) / 4
	stride := total/300 + 1
	for i := 0; i < total; i += stride {
		o := i * 4
		count++
		if int(p[o])+int(p[o+1])+int(p[o+2]) > 24 {
			bright++
		}
	}
	return count == 0 || bright*100/count < 1
}
