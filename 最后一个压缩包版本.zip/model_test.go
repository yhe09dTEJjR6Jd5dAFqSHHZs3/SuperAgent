package main

import (
	"encoding/json"
	"math"
	"path/filepath"
	"testing"
)

func TestModelUpdateAndFeedback(t *testing.T) {
	names := []string{"idle", "left"}
	m := newModel(names)
	m.update(10, 1, 11, 1)
	m.mu.Lock()
	before := m.Q[10][1]
	m.mu.Unlock()
	if before <= 0 {
		t.Fatalf("expected positive Q value, got %f", before)
	}
	if !m.applyFeedback(10, 1, -2) {
		t.Fatal("feedback should apply")
	}
	m.mu.Lock()
	after := m.Q[10][1]
	m.mu.Unlock()
	if after >= before {
		t.Fatalf("negative feedback should reduce Q value: before=%f after=%f", before, after)
	}
	if m.applyFeedback(10, 99, 1) {
		t.Fatal("invalid action feedback should be rejected")
	}
}

func TestVisitCountAndIntrinsicReward(t *testing.T) {
	m := newModel([]string{"idle"})
	first := intrinsicReward(7, 0.1, m)
	m.markVisited(7)
	second := intrinsicReward(7, 0.1, m)
	if first <= second {
		t.Fatalf("novel state should receive more reward: first=%f second=%f", first, second)
	}
}

func TestDecodeLegacyModelMigratesToExpandedActionSet(t *testing.T) {
	legacy := ModelDisk{Version: 1, Q: map[uint64][]float64{42: {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}}, Visits: map[uint64]uint32{42: 3}}
	data, err := json.Marshal(legacy)
	if err != nil {
		t.Fatal(err)
	}
	current := actionNames(defaultActions())
	m, err := decodeModel(data, current)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Q[42]) != len(current) {
		t.Fatalf("migrated Q length=%d, want %d", len(m.Q[42]), len(current))
	}
	if m.Q[42][10] != 10 {
		t.Fatalf("legacy action value not preserved: %f", m.Q[42][10])
	}
	if m.Q[42][11] != 0 {
		t.Fatalf("new action should start at zero: %f", m.Q[42][11])
	}
	if m.Visits[42] != 3 {
		t.Fatalf("visit count = %d", m.Visits[42])
	}
}

func TestDecodeRejectsMalformedQTable(t *testing.T) {
	d := ModelDisk{Version: modelVersion, Actions: []string{"idle", "left"}, Q: map[uint64][]float64{1: {0}}}
	data, _ := json.Marshal(d)
	if _, err := decodeModel(data, []string{"idle", "left"}); err == nil {
		t.Fatal("expected malformed Q vector to be rejected")
	}
	d.Q = map[uint64][]float64{1: {0, math.NaN()}}
	data = []byte(`{"version":2,"actions":["idle","left"],"q":{"1":[0,NaN]}}`)
	if _, err := decodeModel(data, []string{"idle", "left"}); err == nil {
		t.Fatal("expected invalid JSON number to be rejected")
	}
}

func TestModelSaveLoadRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "agent_model.json")
	m := newModel([]string{"idle", "left"})
	m.update(1, 1, 2, 0.75)
	m.markVisited(1)
	if err := m.save(path); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadModel(path, []string{"idle", "left", "right"})
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Q[1]) != 3 {
		t.Fatalf("loaded Q length=%d", len(loaded.Q[1]))
	}
	if loaded.Q[1][1] <= 0 {
		t.Fatalf("expected saved Q value, got %f", loaded.Q[1][1])
	}
	if loaded.Q[1][2] != 0 {
		t.Fatalf("new action value should be zero, got %f", loaded.Q[1][2])
	}
}
