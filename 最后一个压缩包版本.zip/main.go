//go:build windows

package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

type WindowInfo struct {
	Hwnd    uintptr
	Title   string
	PID     uint32
	ExePath string
}

type StopKeyOption struct {
	Name string
	VK   uint16
}

type App struct {
	hwnd              uintptr
	folder            string
	target            uintptr
	targetPID         uint32
	targetTitle       string
	targetExePath     string
	profileDir        string
	modelPath         string
	profileName       string
	windows           []WindowInfo
	actions           []Action
	model             *Model
	active            atomic.Bool
	stopRequested     atomic.Bool
	mode              string
	stopVK            uint16
	stopName          string
	mu                sync.Mutex
	frame             []byte
	frameW, frameH    int
	status            string
	events            []string
	steps             uint64
	lastAction        string
	lastReward        float64
	lastState         uint64
	lastActionIndex   int
	hasLastAction     bool
	feedbackUp        uint64
	feedbackDown      uint64
	folderEdit        uintptr
	windowCombo       uintptr
	stopCombo         uintptr
	statusLabel       uintptr
	hintLabel         uintptr
	folderButton      uintptr
	refreshButton     uintptr
	playButton        uintptr
	watchButton       uintptr
	trainButton       uintptr
	blackboxButton    uintptr
	feedbackUpBtn     uintptr
	feedbackDnBtn     uintptr
	stopKeys          []StopKeyOption
	feedbackHotkeys   bool
	blackboxHotkey    bool
	lastSaveError     string
	lastRecoveryError string
}

var app *App

func recordEvent(s string) {
	if app == nil {
		return
	}
	if len(s) > 600 {
		s = s[:600]
	}
	app.mu.Lock()
	app.events = append(app.events, time.Now().Format("15:04:05.000")+" "+s)
	if len(app.events) > 6000 {
		app.events = append([]string(nil), app.events[len(app.events)-6000:]...)
	}
	app.mu.Unlock()
}

func postStatus(s string) {
	if app == nil {
		return
	}
	app.mu.Lock()
	app.status = s
	app.mu.Unlock()
	if app.hwnd != 0 {
		pPostMessageW.Call(app.hwnd, WM_APP_UPDATE, 0, 0)
	}
}

func postFrame(frame []byte, w, h int) {
	app.mu.Lock()
	app.frame = append(app.frame[:0], frame...)
	app.frameW, app.frameH = w, h
	app.mu.Unlock()
	if app.hwnd != 0 {
		pPostMessageW.Call(app.hwnd, WM_APP_FRAME, 0, 0)
	}
}

func updateStatusUI() {
	app.mu.Lock()
	s := app.status
	app.mu.Unlock()
	if app.statusLabel != 0 {
		setText(app.statusLabel, s)
	}
}

func updateHintUI() {
	if app.hintLabel == 0 {
		return
	}
	app.mu.Lock()
	steps, action, reward := app.steps, app.lastAction, app.lastReward
	up, down := app.feedbackUp, app.feedbackDown
	app.mu.Unlock()
	states := 0
	if app.model != nil {
		states = app.model.stateCount()
	}
	setText(app.hintLabel, fmt.Sprintf("动作：%d  |  学习状态：%d  |  最近动作：%s  |  内在奖励：%.3f  |  用户反馈 +%d/-%d", steps, states, action, reward, up, down))
}

func createControls(hwnd uintptr) {
	font, _, _ := pGetStockObject.Call(17)
	mk := func(class, title string, style uint32, x, y, w, h int32, id uintptr) uintptr {
		handle := callCreate(class, title, WS_CHILD|WS_VISIBLE|style, x, y, w, h, hwnd, id)
		if handle != 0 {
			sendMsg(handle, 0x0030, font, 1)
		}
		return handle
	}
	mk("STATIC", "纯本地游戏智能体 · 无云端服务 · 无第三方 AI 模型", 0, 20, 14, 900, 26, 0)
	mk("STATIC", "工作目录：", 0, 20, 50, 90, 24, 0)
	app.folderEdit = mk("EDIT", "", WS_BORDER|ES_READONLY|ES_AUTOHSCROLL, 112, 47, 650, 28, ID_FOLDER_EDIT)
	app.folderButton = mk("BUTTON", "选择文件夹…", BS_PUSHBUTTON|WS_TABSTOP, 775, 47, 155, 28, ID_FOLDER_BTN)
	mk("STATIC", "目标游戏窗口：", 0, 20, 91, 100, 24, 0)
	app.windowCombo = mk("COMBOBOX", "", CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP, 112, 87, 650, 240, ID_WINDOW_COMBO)
	app.refreshButton = mk("BUTTON", "刷新窗口", BS_PUSHBUTTON|WS_TABSTOP, 775, 87, 155, 28, ID_REFRESH_BTN)
	mk("STATIC", "停止键：", 0, 20, 132, 80, 24, 0)
	app.stopCombo = mk("COMBOBOX", "", CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP, 112, 128, 180, 260, ID_STOP_COMBO)
	mk("STATIC", "运行期间全局生效；停止键不会发送给游戏。", 0, 310, 131, 590, 24, 0)
	app.playButton = mk("BUTTON", "玩游戏", BS_PUSHBUTTON|WS_TABSTOP, 20, 174, 165, 40, ID_PLAY_BTN)
	app.watchButton = mk("BUTTON", "看 Agent 玩游戏", BS_PUSHBUTTON|WS_TABSTOP, 198, 174, 190, 40, ID_WATCH_BTN)
	app.trainButton = mk("BUTTON", "Agent 闭关修炼", BS_PUSHBUTTON|WS_TABSTOP, 401, 174, 190, 40, ID_TRAIN_BTN)
	app.blackboxButton = mk("BUTTON", "生成桌面黑匣子", BS_PUSHBUTTON|WS_TABSTOP, 604, 174, 190, 40, ID_BLACKBOX_BTN)
	app.feedbackUpBtn = mk("BUTTON", "反馈：这次有帮助 +", BS_PUSHBUTTON|WS_TABSTOP, 20, 226, 220, 34, ID_FEEDBACK_UP)
	app.feedbackDnBtn = mk("BUTTON", "反馈：这次不对 −", BS_PUSHBUTTON|WS_TABSTOP, 250, 226, 220, 34, ID_FEEDBACK_DN)
	mk("STATIC", "运行中 Ctrl+Alt+PageUp/Down 反馈，Ctrl+Alt+B 生成黑匣子。", 0, 490, 231, 440, 24, 0)
	app.statusLabel = mk("STATIC", "先选择工作目录，再刷新并手动选择游戏窗口。", WS_BORDER, 20, 273, 910, 30, ID_STATUS)
	app.hintLabel = mk("STATIC", "动作：0 | 学习状态：0 | 最近动作：无", 0, 20, 311, 910, 24, ID_HINT)
	mk("STATIC", "游戏画面预览（仅“看 Agent 玩游戏”模式显示）", 0, 20, 346, 500, 20, 0)
	mk("STATIC", "安全说明：只有确认目标窗口位于前台时才会发送输入；焦点不正确时会等待，不会向其他程序发送按键。", 0, 20, 632, 910, 24, 0)

	app.stopKeys = buildStopKeyOptions()
	for _, k := range app.stopKeys {
		addCombo(app.stopCombo, k.Name)
	}
	sendMsg(app.stopCombo, CB_SETCURSEL, 0, 0)
	app.stopVK, app.stopName = VK_ESCAPE, "ESC"
	pEnableWindow.Call(app.feedbackUpBtn, 0)
	pEnableWindow.Call(app.feedbackDnBtn, 0)
}

func buildStopKeyOptions() []StopKeyOption {
	keys := []StopKeyOption{{"ESC（默认）", VK_ESCAPE}, {"BACKSPACE", 0x08}, {"CAPS LOCK", 0x14}, {"PRINT SCREEN", 0x2C}, {"NUM LOCK", 0x90}}
	for i := 1; i <= 24; i++ {
		keys = append(keys, StopKeyOption{fmt.Sprintf("F%d", i), uint16(0x6F + i)})
	}
	for c := 'A'; c <= 'Z'; c++ {
		keys = append(keys, StopKeyOption{string(c), uint16(c)})
	}
	for c := '0'; c <= '9'; c++ {
		keys = append(keys, StopKeyOption{string(c), uint16(c)})
	}
	keys = append(keys,
		StopKeyOption{"左方向键", 0x25}, StopKeyOption{"上方向键", 0x26}, StopKeyOption{"右方向键", 0x27}, StopKeyOption{"下方向键", 0x28},
		StopKeyOption{"空格", 0x20}, StopKeyOption{"回车", 0x0D}, StopKeyOption{"TAB", 0x09},
		StopKeyOption{"PAUSE", VK_PAUSE}, StopKeyOption{"SCROLL LOCK", VK_SCROLL}, StopKeyOption{"INSERT", VK_INSERT},
		StopKeyOption{"DELETE", VK_DELETE}, StopKeyOption{"HOME", VK_HOME}, StopKeyOption{"END", VK_END},
		StopKeyOption{"PAGE UP", VK_PRIOR}, StopKeyOption{"PAGE DOWN", VK_NEXT},
		StopKeyOption{"NUMPAD 0", 0x60}, StopKeyOption{"NUMPAD 1", 0x61}, StopKeyOption{"NUMPAD 2", 0x62},
		StopKeyOption{"NUMPAD 3", 0x63}, StopKeyOption{"NUMPAD 4", 0x64}, StopKeyOption{"NUMPAD 5", 0x65},
		StopKeyOption{"NUMPAD 6", 0x66}, StopKeyOption{"NUMPAD 7", 0x67}, StopKeyOption{"NUMPAD 8", 0x68},
		StopKeyOption{"NUMPAD 9", 0x69}, StopKeyOption{"NUMPAD *", 0x6A}, StopKeyOption{"NUMPAD +", 0x6B},
		StopKeyOption{"NUMPAD -", 0x6D}, StopKeyOption{"NUMPAD .", 0x6E}, StopKeyOption{"NUMPAD /", 0x6F}, StopKeyOption{"NUMPAD SEPARATOR", 0x6C},
		StopKeyOption{"OEM ;", 0xBA}, StopKeyOption{"OEM =", 0xBB}, StopKeyOption{"OEM ,", 0xBC},
		StopKeyOption{"OEM -", 0xBD}, StopKeyOption{"OEM .", 0xBE}, StopKeyOption{"OEM /", 0xBF},
		StopKeyOption{"OEM `", 0xC0}, StopKeyOption{"OEM [", 0xDB}, StopKeyOption{"OEM \\", 0xDC},
		StopKeyOption{"OEM ]", 0xDD}, StopKeyOption{"OEM '", 0xDE}, StopKeyOption{"OEM_8", 0xDF})
	return keys
}

func chooseFolder() {
	var display [260]uint16
	title := utf16("请选择 Agent 数据存放目录（模型、配置和运行数据只写入此目录）")
	bi := BROWSEINFO{HwndOwner: app.hwnd, DisplayName: &display[0], Title: title, Flags: 0x0001 | 0x0040}
	cb := syscall.NewCallback(func(hwnd, msg, lp, data uintptr) uintptr { return 0 })
	bi.Callback = cb
	pidl, _, _ := pSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&bi)))
	runtime.KeepAlive(title)
	runtime.KeepAlive(display)
	runtime.KeepAlive(cb)
	if pidl == 0 {
		return
	}
	var path [260]uint16
	ok, _, _ := pSHGetPathFromIDListW.Call(pidl, uintptr(unsafe.Pointer(&path[0])))
	pCoTaskMemFree.Call(pidl)
	if ok == 0 {
		messageBox(app.hwnd, "无法读取所选目录。", appTitle, 0x10)
		return
	}
	folder := syscall.UTF16ToString(path[:])
	if folder == "" {
		return
	}
	if err := os.MkdirAll(folder, 0700); err != nil {
		messageBox(app.hwnd, "无法访问所选目录："+err.Error(), appTitle, 0x10)
		return
	}
	app.folder = folder
	app.model = nil
	setText(app.folderEdit, folder)
	postStatus("工作目录已就绪。模型将在选择游戏并启动时加载到独立游戏档案。")
	recordEvent("选择工作目录")
}

func enumerateWindows() []WindowInfo {
	wins := make([]WindowInfo, 0, 32)
	cb := syscall.NewCallback(func(hwnd, lParam uintptr) uintptr {
		if hwnd == app.hwnd {
			return 1
		}
		visible, _, _ := pIsWindowVisible.Call(hwnd)
		if visible == 0 {
			return 1
		}
		length, _, _ := pGetWindowTextLen.Call(hwnd)
		if length == 0 || length > 500 {
			return 1
		}
		buf := make([]uint16, length+1)
		got, _, _ := pGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		if got == 0 {
			return 1
		}
		pid := targetPID(hwnd)
		title := syscall.UTF16ToString(buf)
		if strings.TrimSpace(title) == "" || title == appTitle {
			return 1
		}
		wins = append(wins, WindowInfo{Hwnd: hwnd, Title: title, PID: pid})
		return 1
	})
	pEnumWindows.Call(cb, 0)
	runtime.KeepAlive(cb)
	return wins
}

func refreshWindows() {
	app.windows = enumerateWindows()
	sendMsg(app.windowCombo, CB_RESETCONTENT, 0, 0)
	for _, w := range app.windows {
		addCombo(app.windowCombo, fmt.Sprintf("[%d] %s", w.PID, w.Title))
	}
	// Deliberately do not select the first window: user confirmation is required.
	sendMsg(app.windowCombo, CB_SETCURSEL, ^uintptr(0), 0)
	app.target, app.targetPID, app.targetTitle, app.targetExePath = 0, 0, "", ""
	if len(app.windows) > 0 {
		postStatus(fmt.Sprintf("发现 %d 个可见窗口；请从列表中手动选择目标游戏窗口。", len(app.windows)))
	} else {
		postStatus("未发现可见窗口。请先打开游戏，再刷新窗口列表。")
	}
}

func selectWindowFromCombo() {
	idx := int(sendMsg(app.windowCombo, CB_GETCURSEL, 0, 0))
	if idx < 0 || idx >= len(app.windows) {
		return
	}
	w := app.windows[idx]
	if !pIsWindowResult(w.Hwnd) || targetPID(w.Hwnd) != w.PID {
		postStatus("窗口已失效，请刷新窗口列表。")
		return
	}
	w.ExePath = processImagePath(w.PID)
	app.windows[idx] = w
	app.target, app.targetPID, app.targetTitle, app.targetExePath = w.Hwnd, w.PID, w.Title, w.ExePath
	if w.ExePath != "" {
		postStatus("目标已选择：" + w.Title + " | " + filepath.Base(w.ExePath))
	} else {
		postStatus("目标已选择：" + w.Title + " | 无法读取进程路径，将使用窗口标题建立档案")
	}
	recordEvent("选择目标窗口：" + w.Title)
}

func selectStopKey() {
	idx := int(sendMsg(app.stopCombo, CB_GETCURSEL, 0, 0))
	if idx >= 0 && idx < len(app.stopKeys) {
		app.stopVK, app.stopName = app.stopKeys[idx].VK, strings.TrimSuffix(app.stopKeys[idx].Name, "（默认）")
	}
}

func profileDirectory(folder, exePath, title string) (string, string) {
	identity := strings.ToLower(strings.TrimSpace(exePath))
	base := "game"
	if exePath != "" {
		base = strings.TrimSuffix(filepath.Base(exePath), filepath.Ext(exePath))
	} else {
		identity = "window-title:" + strings.ToLower(strings.TrimSpace(title))
		base = title
	}
	if identity == "" {
		identity = "unknown-game"
	}
	var safe strings.Builder
	for _, r := range strings.ToLower(base) {
		if r >= 'a' && r <= 'z' || r >= '0' && r <= '9' || r == '-' || r == '_' {
			safe.WriteRune(r)
		} else if r > 127 {
			safe.WriteByte('_')
		}
		if safe.Len() >= 24 {
			break
		}
	}
	name := strings.Trim(safe.String(), "_")
	if name == "" {
		name = "game"
	}
	sum := sha256.Sum256([]byte(identity))
	profile := name + "_" + hex.EncodeToString(sum[:6])
	return filepath.Join(folder, "models", profile), profile
}

func quarantineFile(path string) string {
	if _, err := os.Stat(path); err != nil {
		return ""
	}
	backup := path + ".corrupt_" + time.Now().Format("20060102_150405_000000000")
	if err := os.Rename(path, backup); err != nil {
		return ""
	}
	return backup
}

func loadProfileModel(profileDir, folder string, names []string) (*Model, string, error) {
	path := filepath.Join(profileDir, "agent_model.json")
	model, err := loadModel(path, names)
	if err == nil {
		return model, path, nil
	}
	var notes []string
	if !os.IsNotExist(err) {
		if moved := quarantineFile(path); moved != "" {
			notes = append(notes, "损坏模型已隔离备份")
		} else if _, statErr := os.Stat(path); statErr == nil {
			return nil, path, fmt.Errorf("模型文件损坏且无法隔离；为避免覆盖原文件，已取消启动")
		}
	}

	// Recover the last known-good snapshot if the current file is missing or invalid.
	backupPath := path + ".bak"
	backupModel, backupErr := loadModel(backupPath, names)
	if backupErr == nil {
		restoreErr := backupModel.save(path)
		message := "已从 .bak 恢复模型"
		if restoreErr != nil {
			message += "，但恢复写入失败：" + restoreErr.Error()
		}
		if len(notes) > 0 {
			message += "；" + strings.Join(notes, "；")
		}
		return backupModel, path, fmt.Errorf("%s", message)
	}
	if _, statErr := os.Stat(backupPath); statErr == nil && backupErr != nil {
		if moved := quarantineFile(backupPath); moved != "" {
			notes = append(notes, "损坏备份已隔离")
		} else if _, stillExists := os.Stat(backupPath); stillExists == nil {
			return nil, path, fmt.Errorf("模型备份损坏且无法隔离；为避免覆盖原文件，已取消启动")
		}
	}

	// One-time import of the original shared model. It is copied into this game's
	// profile and is never used by subsequent games.
	legacyPath := filepath.Join(folder, "agent_model.json")
	if legacy, legacyErr := loadModel(legacyPath, names); legacyErr == nil {
		saveErr := legacy.save(path)
		message := "已将旧版共享模型迁移到当前游戏独立档案"
		if saveErr != nil {
			message += "，但迁移写入失败：" + saveErr.Error()
		}
		if len(notes) > 0 {
			message += "；" + strings.Join(notes, "；")
		}
		return legacy, path, fmt.Errorf("%s", message)
	} else if !os.IsNotExist(legacyErr) {
		if moved := quarantineFile(legacyPath); moved != "" {
			notes = append(notes, "旧版损坏模型已隔离")
		} else if _, stillExists := os.Stat(legacyPath); stillExists == nil {
			notes = append(notes, "旧版损坏模型无法隔离，已保留原文件")
		}
	}
	if len(notes) > 0 {
		return newModel(names), path, fmt.Errorf("%s；已初始化新模型", strings.Join(notes, "；"))
	}
	return newModel(names), path, nil
}

func startAgent(mode string) {
	if app.active.Load() {
		return
	}
	if app.folder == "" {
		messageBox(app.hwnd, "请先选择工作目录。", appTitle, 0x30)
		return
	}
	if app.target == 0 || !pIsWindowResult(app.target) || targetPID(app.target) != app.targetPID {
		messageBox(app.hwnd, "请先刷新并手动选择一个有效的游戏窗口。", appTitle, 0x30)
		return
	}
	selectStopKey()
	ok, _, _ := pRegisterHotKey.Call(app.hwnd, STOP_HOTKEY_ID, MOD_NOREPEAT, uintptr(app.stopVK))
	if ok == 0 {
		messageBox(app.hwnd, "无法注册停止键 "+app.stopName+"。该按键可能被系统或其他程序占用，请换一个按键。", appTitle, 0x10)
		return
	}
	upOK, _, _ := pRegisterHotKey.Call(app.hwnd, FEEDBACK_UP_HOTKEY_ID, MOD_CONTROL|MOD_ALT|MOD_NOREPEAT, uintptr(VK_PRIOR))
	downOK, _, _ := pRegisterHotKey.Call(app.hwnd, FEEDBACK_DN_HOTKEY_ID, MOD_CONTROL|MOD_ALT|MOD_NOREPEAT, uintptr(VK_NEXT))
	app.feedbackHotkeys = upOK != 0 && downOK != 0
	if !app.feedbackHotkeys {
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_UP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_DN_HOTKEY_ID)
	}
	bbOK, _, _ := pRegisterHotKey.Call(app.hwnd, BLACKBOX_HOTKEY_ID, MOD_CONTROL|MOD_ALT|MOD_NOREPEAT, uintptr('B'))
	app.blackboxHotkey = bbOK != 0
	profileDir, profileName := profileDirectory(app.folder, app.targetExePath, app.targetTitle)
	if err := os.MkdirAll(profileDir, 0700); err != nil {
		pUnregisterHotKey.Call(app.hwnd, STOP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_UP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_DN_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, BLACKBOX_HOTKEY_ID)
		messageBox(app.hwnd, "无法创建游戏档案目录："+err.Error(), appTitle, 0x10)
		return
	}
	actions, created, actionErr := loadActions(actionConfigPath(profileDir), app.stopVK)
	if actionErr != nil {
		pUnregisterHotKey.Call(app.hwnd, STOP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_UP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_DN_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, BLACKBOX_HOTKEY_ID)
		messageBox(app.hwnd, "动作配置无效，未启动 Agent：\n"+actionErr.Error()+"\n\n可删除该游戏档案中的 actions.json 以重新生成默认配置。", appTitle, 0x10)
		return
	}
	model, modelPath, modelNote := loadProfileModel(profileDir, app.folder, actionNames(actions))
	if model == nil {
		pUnregisterHotKey.Call(app.hwnd, STOP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_UP_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, FEEDBACK_DN_HOTKEY_ID)
		pUnregisterHotKey.Call(app.hwnd, BLACKBOX_HOTKEY_ID)
		messageBox(app.hwnd, "无法安全加载游戏模型：\n"+modelNote.Error(), appTitle, 0x10)
		return
	}
	app.profileDir, app.profileName, app.modelPath = profileDir, profileName, modelPath
	app.actions, app.model = actions, model
	if created {
		recordEvent("已生成默认 actions.json")
	}
	if modelNote != nil {
		recordEvent(modelNote.Error())
	}
	app.stopRequested.Store(false)
	app.mode = mode
	app.steps = 0
	app.mu.Lock()
	app.lastAction, app.lastReward = "无", 0
	app.lastSaveError = ""
	app.lastRecoveryError = ""
	app.hasLastAction = false
	app.feedbackUp, app.feedbackDown = 0, 0
	app.mu.Unlock()
	app.active.Store(true)
	setControlsEnabled(false)
	status := "正在运行：" + modeName(mode) + "。按 " + app.stopName + " 停止；Ctrl+Alt+PageUp/Down 反馈，Ctrl+Alt+B 生成黑匣子。"
	if !app.feedbackHotkeys {
		status += "（反馈全局热键不可用，可尝试点击反馈按钮）"
	}
	if !app.blackboxHotkey {
		status += "（黑匣子全局热键不可用，可尝试点击按钮）"
	}
	if modelNote != nil {
		status += "（" + modelNote.Error() + "）"
	}
	postStatus(status)
	recordEvent("开始模式：" + mode + "；停止键：" + app.stopName + "；档案：" + profileName)
	go runAgent(mode, app.target, app.targetPID, app.modelPath)
}

func setControlsEnabled(enabled bool) {
	for _, h := range []uintptr{app.folderEdit, app.windowCombo, app.stopCombo, app.folderButton, app.refreshButton, app.playButton, app.watchButton, app.trainButton} {
		if h != 0 {
			pEnableWindow.Call(h, boolToUintptr(enabled))
		}
	}
	if app.blackboxButton != 0 {
		pEnableWindow.Call(app.blackboxButton, 1)
	}
	if app.feedbackUpBtn != 0 {
		pEnableWindow.Call(app.feedbackUpBtn, boolToUintptr(!enabled))
	}
	if app.feedbackDnBtn != 0 {
		pEnableWindow.Call(app.feedbackDnBtn, boolToUintptr(!enabled))
	}
	menu, _, _ := pGetSystemMenu.Call(app.hwnd, 0)
	flag := uintptr(MF_ENABLED)
	if !enabled {
		flag = MF_GRAYED
	}
	pEnableMenuItem.Call(menu, SC_CLOSE, flag|MF_BYCOMMAND)
	pDrawMenuBar.Call(app.hwnd)
}

func boolToUintptr(v bool) uintptr {
	if v {
		return 1
	}
	return 0
}
func pIsWindowResult(hwnd uintptr) bool { r, _, _ := pIsWindow.Call(hwnd); return r != 0 }

func runAgent(mode string, target uintptr, pid uint32, modelPath string) {
	defer func() {
		releaseAllInputs()
		if recovered := recover(); recovered != nil {
			recordEvent(fmt.Sprintf("Agent 可恢复异常：%v", recovered))
			app.mu.Lock()
			app.lastRecoveryError = fmt.Sprint(recovered)
			app.mu.Unlock()
			saveModelSafely(modelPath)
			if !app.stopRequested.Load() {
				postStatus("检测到可恢复内部异常；已释放输入、保存模型并准备继续运行。按 " + app.stopName + " 可停止。")
				_ = sleepWithStop(500*time.Millisecond, &app.stopRequested)
				if !app.stopRequested.Load() {
					go runAgent(mode, target, pid, modelPath)
					return
				}
			}
		}
		pPostMessageW.Call(app.hwnd, WM_APP_FINISH, 0, 0)
	}()
	rng := rand.New(rand.NewSource(time.Now().UnixNano()))
	epsilon := 0.10
	if mode == "watch" {
		epsilon = 0.16
	}
	if mode == "train" {
		epsilon = 0.78
	}
	var previousFeature []byte
	var pendingState uint64
	var pendingAction int
	pending := false
	lastSave := time.Now()
	for !app.stopRequested.Load() {
		if !pIsWindowResult(target) || targetPID(target) != pid {
			postStatus("目标窗口暂不可用或身份已变化；Agent 持续等待，不会向其他窗口发送输入。按 " + app.stopName + " 停止。")
			_ = sleepWithStop(500*time.Millisecond, &app.stopRequested)
			continue
		}
		if iconic, _, _ := pIsIconic.Call(target); iconic != 0 {
			pShowWindow.Call(target, SW_RESTORE)
		}
		if !focusTarget(target, pid, &app.stopRequested) {
			if app.stopRequested.Load() {
				break
			}
			postStatus("游戏窗口未能取得前台焦点；本轮不会发送任何输入，正在重试。按 " + app.stopName + " 停止。")
			_ = sleepWithStop(250*time.Millisecond, &app.stopRequested)
			continue
		}
		frame, fw, fh, err := captureWindow(target)
		if err != nil {
			postStatus("读取游戏画面失败；Agent 持续重试，不会盲目发送按键。按 " + app.stopName + " 停止。")
			recordEvent("画面读取失败：" + err.Error())
			_ = sleepWithStop(300*time.Millisecond, &app.stopRequested)
			continue
		}
		if app.stopRequested.Load() {
			break
		}
		feature, change := visualFeature(frame, fw, fh, previousFeature)
		state := featureHash(feature)
		if pending {
			reward := intrinsicReward(state, change, app.model)
			app.model.update(pendingState, pendingAction, state, reward)
			app.mu.Lock()
			app.lastReward = reward
			app.mu.Unlock()
			pending = false
		}
		actionIndex := app.model.choose(state, epsilon, rng)
		if actionIndex < 0 || actionIndex >= len(app.actions) {
			actionIndex = 0
		}
		if mode == "watch" {
			postFrame(frame, fw, fh)
		}
		if err := performAction(target, pid, app.actions[actionIndex], &app.stopRequested); err != nil {
			if app.stopRequested.Load() {
				break
			}
			recordEvent("动作未执行：" + err.Error())
			postStatus(err.Error() + "；正在等待并重试。按 " + app.stopName + " 停止。")
			previousFeature = feature
			_ = sleepWithStop(180*time.Millisecond, &app.stopRequested)
			continue
		}
		pendingState, pendingAction, pending = state, actionIndex, true
		app.model.markVisited(state)
		previousFeature = feature
		app.mu.Lock()
		app.steps++
		step := app.steps
		app.lastAction = app.actions[actionIndex].Name
		app.lastState, app.lastActionIndex, app.hasLastAction = state, actionIndex, true
		app.mu.Unlock()
		if step%5 == 0 {
			postStatus(fmt.Sprintf("运行中：%s | 步数 %d | 最近动作 %s | 按 %s 停止", modeName(mode), step, app.actions[actionIndex].Name, app.stopName))
			pPostMessageW.Call(app.hwnd, WM_APP_UPDATE, 0, 0)
		}
		if step%25 == 0 || time.Since(lastSave) > 15*time.Second {
			saveModelSafely(modelPath)
			lastSave = time.Now()
		}
	}
	saveModelSafely(modelPath)
	recordEvent("用户停止模式：" + mode)
}

func saveModelSafely(path string) {
	if app == nil || app.model == nil {
		return
	}
	err := app.model.save(path)
	app.mu.Lock()
	if err != nil {
		app.lastSaveError = err.Error()
	} else {
		app.lastSaveError = ""
	}
	app.mu.Unlock()
	if err != nil {
		recordEvent("模型保存失败：" + err.Error())
	}
}

func modeName(mode string) string {
	switch mode {
	case "play":
		return "玩游戏"
	case "watch":
		return "看 Agent 玩游戏"
	case "train":
		return "Agent 闭关修炼"
	}
	return mode
}

func giveFeedback(positive bool) {
	if !app.active.Load() || app.model == nil {
		return
	}
	app.mu.Lock()
	state, action, ok := app.lastState, app.lastActionIndex, app.hasLastAction
	if ok {
		if positive {
			app.feedbackUp++
		} else {
			app.feedbackDown++
		}
	}
	app.mu.Unlock()
	if !ok {
		postStatus("尚无已执行动作；请等待 Agent 完成至少一个动作后再反馈。")
		return
	}
	reward := -2.0
	label := "负向"
	if positive {
		reward, label = 2.0, "正向"
	}
	if !app.model.applyFeedback(state, action, reward) {
		postStatus("反馈未能应用。")
		return
	}
	recordEvent(fmt.Sprintf("用户给出%s反馈：%s", label, app.actions[action].Name))
	postStatus("已应用" + label + "反馈；学习值已更新。")
	pPostMessageW.Call(app.hwnd, WM_APP_UPDATE, 0, 0)
}

func finishAgent() {
	releaseAllInputs()
	app.active.Store(false)
	pUnregisterHotKey.Call(app.hwnd, STOP_HOTKEY_ID)
	pUnregisterHotKey.Call(app.hwnd, FEEDBACK_UP_HOTKEY_ID)
	pUnregisterHotKey.Call(app.hwnd, FEEDBACK_DN_HOTKEY_ID)
	pUnregisterHotKey.Call(app.hwnd, BLACKBOX_HOTKEY_ID)
	app.feedbackHotkeys = false
	app.blackboxHotkey = false
	setControlsEnabled(true)
	app.mu.Lock()
	saveErr := app.lastSaveError
	app.mu.Unlock()
	if saveErr != "" {
		postStatus("已停止，但模型保存失败：" + saveErr)
	} else {
		postStatus("已停止。当前游戏模型已保存到所选工作目录的独立档案。")
	}
	updateHintUI()
}

func createBlackbox() {
	desktop := desktopPath()
	if desktop == "" {
		messageBox(app.hwnd, "无法定位 Windows 桌面目录；未在其他位置创建文件。", appTitle, 0x10)
		return
	}
	app.mu.Lock()
	events := append([]string(nil), app.events...)
	steps, action, status, reward := app.steps, app.lastAction, app.status, app.lastReward
	up, down := app.feedbackUp, app.feedbackDown
	saveErr, runErr := app.lastSaveError, app.lastRecoveryError
	app.mu.Unlock()
	states := 0
	if app.model != nil {
		states = app.model.stateCount()
	}
	payload := map[string]any{
		"format": "LocalGameAgent-BlackBox-v2", "created_at": time.Now().Format(time.RFC3339Nano),
		"mode": modeName(app.mode), "target_window": app.targetTitle, "target_process": app.targetExePath,
		"game_profile": app.profileName, "steps": steps, "learned_states": states,
		"last_action": action, "last_intrinsic_reward": reward, "positive_feedback": up,
		"negative_feedback": down, "status": status, "last_save_error": saveErr, "last_recovery_error": runErr, "actions": actionNames(app.actions),
	}
	var data []byte
	for len(events) > 0 {
		payload["events"] = events
		data, _ = json.Marshal(payload)
		if len(data) <= MAX_BLACKBOX_BYTES {
			break
		}
		drop := len(events)/8 + 1
		events = events[drop:]
	}
	if len(events) == 0 {
		payload["events"] = []string{}
		data, _ = json.Marshal(payload)
	}
	if len(data) > MAX_BLACKBOX_BYTES {
		payload = map[string]any{"format": "LocalGameAgent-BlackBox-v2", "created_at": time.Now().Format(time.RFC3339Nano), "steps": steps, "learned_states": states, "note": "event log truncated to enforce size limit"}
		data, _ = json.Marshal(payload)
	}
	if len(data) > MAX_BLACKBOX_BYTES {
		messageBox(app.hwnd, "黑匣子超过 900 KiB 限制，已取消写入。", appTitle, 0x10)
		return
	}
	name := "GameAgent_BlackBox_" + time.Now().Format("20060102_150405_000000000") + ".json"
	path := filepath.Join(desktop, name)
	if err := writeBlackboxFile(path, data); err != nil {
		messageBox(app.hwnd, "创建黑匣子失败："+err.Error(), appTitle, 0x10)
		return
	}
	info, err := os.Stat(path)
	if err != nil || info.Size() > MAX_BLACKBOX_BYTES {
		_ = os.Remove(path)
		messageBox(app.hwnd, "黑匣子大小校验失败，已撤销文件。", appTitle, 0x10)
		return
	}
	recordEvent("生成黑匣子：" + path)
	messageBox(app.hwnd, fmt.Sprintf("黑匣子已生成：\n%s\n大小：%d 字节（不超过 900 KiB）", path, info.Size()), appTitle, 0x40)
}

func writeBlackboxFile(path string, data []byte) error {
	if len(data) > MAX_BLACKBOX_BYTES {
		return fmt.Errorf("黑匣子超过 900 KiB 限制")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	n, writeErr := f.Write(data)
	if writeErr == nil {
		writeErr = f.Sync()
	}
	closeErr := f.Close()
	if writeErr != nil {
		_ = os.Remove(path)
		return writeErr
	}
	if closeErr != nil {
		_ = os.Remove(path)
		return closeErr
	}
	if n != len(data) {
		_ = os.Remove(path)
		return fmt.Errorf("黑匣子写入不完整")
	}
	info, err := os.Stat(path)
	if err != nil {
		_ = os.Remove(path)
		return err
	}
	if info.Size() > MAX_BLACKBOX_BYTES {
		_ = os.Remove(path)
		return fmt.Errorf("黑匣子大小超过限制")
	}
	return nil
}

func desktopPath() string {
	var buf [260]uint16
	r, _, _ := pSHGetFolderPathW.Call(0, 0x10, 0, 0, uintptr(unsafe.Pointer(&buf[0])))
	if r != 0 {
		return ""
	}
	return syscall.UTF16ToString(buf[:])
}

func drawPreview(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	defer pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	panel := RECT{Left: 20, Top: 371, Right: 930, Bottom: 620}
	brush, _, _ := pGetStockObject.Call(1)
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&panel)), brush)
	pRectangle.Call(hdc, uintptr(panel.Left), uintptr(panel.Top), uintptr(panel.Right), uintptr(panel.Bottom))
	app.mu.Lock()
	frame := append([]byte(nil), app.frame...)
	fw, fh, mode := app.frameW, app.frameH, app.mode
	app.mu.Unlock()
	if mode == "watch" && len(frame) >= 4 && fw > 0 && fh > 0 {
		bmi := BITMAPINFO{Header: BITMAPINFOHEADER{Size: uint32(unsafe.Sizeof(BITMAPINFOHEADER{})), Width: int32(fw), Height: int32(-fh), Planes: 1, BitCount: 32, Compression: BI_RGB, SizeImage: uint32(fw * fh * 4)}}
		pSetStretchBltMode.Call(hdc, HALFTONE)
		pStretchDIBits.Call(hdc, 22, 373, 906, 245, 0, 0, uintptr(fw), uintptr(fh), uintptr(unsafe.Pointer(&frame[0])), uintptr(unsafe.Pointer(&bmi)), DIB_RGB_COLORS, SRCCOPY)
		runtime.KeepAlive(frame)
	} else {
		msg := "等待画面…\n选择“看 Agent 玩游戏”后，这里会显示目标窗口画面。"
		pSetBkMode.Call(hdc, 1)
		pSetTextColor.Call(hdc, 0x505050)
		t := utf16(msg)
		textRect := RECT{Left: 35, Top: 450, Right: 915, Bottom: 540}
		pDrawTextW.Call(hdc, uintptr(unsafe.Pointer(t)), ^uintptr(0), uintptr(unsafe.Pointer(&textRect)), 0x00000001|0x00000004)
		runtime.KeepAlive(t)
	}
}

func wndProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		app.hwnd = hwnd
		createControls(hwnd)
		refreshWindows()
		return 0
	case WM_COMMAND:
		id := int(wp & 0xFFFF)
		code := int((wp >> 16) & 0xFFFF)
		switch id {
		case ID_FOLDER_BTN:
			if code == BN_CLICKED {
				chooseFolder()
			}
		case ID_REFRESH_BTN:
			if code == BN_CLICKED {
				refreshWindows()
			}
		case ID_WINDOW_COMBO:
			if code == CBN_SELCHANGE {
				selectWindowFromCombo()
			}
		case ID_STOP_COMBO:
			if code == CBN_SELCHANGE {
				selectStopKey()
				postStatus("停止键已设置为 " + app.stopName + "。")
			}
		case ID_PLAY_BTN:
			if code == BN_CLICKED {
				startAgent("play")
			}
		case ID_WATCH_BTN:
			if code == BN_CLICKED {
				startAgent("watch")
			}
		case ID_TRAIN_BTN:
			if code == BN_CLICKED {
				startAgent("train")
			}
		case ID_BLACKBOX_BTN:
			if code == BN_CLICKED {
				createBlackbox()
			}
		case ID_FEEDBACK_UP:
			if code == BN_CLICKED {
				giveFeedback(true)
			}
		case ID_FEEDBACK_DN:
			if code == BN_CLICKED {
				giveFeedback(false)
			}
		}
		return 0
	case WM_HOTKEY:
		if app.active.Load() {
			switch wp {
			case STOP_HOTKEY_ID:
				app.stopRequested.Store(true)
				postStatus("已收到 " + app.stopName + " 停止指令；正在释放所有按键/鼠标并保存模型…")
				recordEvent("用户按下停止键：" + app.stopName)
			case FEEDBACK_UP_HOTKEY_ID:
				giveFeedback(true)
			case FEEDBACK_DN_HOTKEY_ID:
				giveFeedback(false)
			case BLACKBOX_HOTKEY_ID:
				createBlackbox()
			}
		}
		return 0
	case WM_APP_UPDATE:
		updateStatusUI()
		updateHintUI()
		return 0
	case WM_APP_FRAME:
		var r RECT = RECT{Left: 20, Top: 371, Right: 930, Bottom: 620}
		pInvalidateRect.Call(hwnd, uintptr(unsafe.Pointer(&r)), 0)
		return 0
	case WM_APP_FINISH:
		finishAgent()
		pInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case WM_PAINT:
		drawPreview(hwnd)
		return 0
	case WM_SYSCOMMAND:
		if (wp&0xFFF0) == SC_CLOSE && app.active.Load() {
			postStatus("Agent 正在运行；请按 " + app.stopName + " 停止后再关闭窗口。")
			return 0
		}
	case WM_CLOSE:
		if app.active.Load() {
			postStatus("Agent 正在运行；请按 " + app.stopName + " 停止后再关闭窗口。")
			return 0
		}
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		if app.active.Load() {
			return 0
		}
		pUnregisterHotKey.Call(hwnd, STOP_HOTKEY_ID)
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func main() {
	runtime.LockOSThread()
	coInit, _, _ := pCoInitializeEx.Call(0, 0x2)
	if coInit == 0 || coInit == 1 {
		defer pCoUninitialize.Call()
	}
	app = &App{stopVK: VK_ESCAPE, stopName: "ESC", status: "先选择工作目录，再刷新并手动选择游戏窗口。"}
	instance := getInstance()
	cn := utf16(className)
	cursor, _, _ := pLoadCursorW.Call(0, 32512)
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), Style: 0x0002 | 0x0001, WndProc: syscall.NewCallback(wndProc), Instance: instance, Cursor: syscall.Handle(cursor), Background: syscall.Handle(6), ClassName: cn}
	if r, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		messageBox(0, "窗口类注册失败。", appTitle, 0x10)
		return
	}
	caption := utf16(appTitle + " · Windows 11 x64")
	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cn)), uintptr(unsafe.Pointer(caption)), WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX, 100, 60, 970, 710, 0, 0, uintptr(instance), 0)
	runtime.KeepAlive(cn)
	runtime.KeepAlive(caption)
	runtime.KeepAlive(wc)
	if hwnd == 0 {
		messageBox(0, "主窗口创建失败。", appTitle, 0x10)
		return
	}
	pShowWindow.Call(hwnd, SW_SHOW)
	pUpdateWindow.Call(hwnd)
	var msg MSG
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}
