//go:build windows

package main

import (
	"fmt"
	"runtime"
	"sync"
	"time"
	"unsafe"
)

const (
	inputKeyboard  = 1
	inputMouse     = 0
	keyUpFlag      = 0x0002
	mouseMove      = 0x0001
	mouseLeftDown  = 0x0002
	mouseLeftUp    = 0x0004
	mouseRightDown = 0x0008
	mouseRightUp   = 0x0010
	mouseWheel     = 0x0800
)

var inputState = struct {
	sync.Mutex
	keys  map[uint16]bool
	mouse map[uint32]bool
}{keys: make(map[uint16]bool), mouse: make(map[uint32]bool)}

func sendKeyInput(vk uint16, up bool) error {
	flags := uint32(0)
	if up {
		flags = keyUpFlag
	}
	in := INPUT{Type: inputKeyboard}
	ki := KEYBDINPUT{Vk: vk, Flags: flags}
	*(*KEYBDINPUT)(unsafe.Pointer(&in.Data[0])) = ki
	count, _, callErr := pSendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
	runtime.KeepAlive(in)
	if count != 1 {
		if callErr != nil {
			return callErr
		}
		return fmt.Errorf("SendInput 键盘输入失败（返回 %d）", count)
	}
	inputState.Lock()
	if up {
		delete(inputState.keys, vk)
	} else {
		inputState.keys[vk] = true
	}
	inputState.Unlock()
	return nil
}

func sendMouseInput(flags, data uint32) error {
	in := INPUT{Type: inputMouse}
	mi := MOUSEINPUT{MouseData: data, Flags: flags}
	*(*MOUSEINPUT)(unsafe.Pointer(&in.Data[0])) = mi
	count, _, callErr := pSendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
	runtime.KeepAlive(in)
	if count != 1 {
		if callErr != nil {
			return callErr
		}
		return fmt.Errorf("SendInput 鼠标输入失败（返回 %d）", count)
	}
	inputState.Lock()
	switch flags {
	case mouseLeftDown:
		inputState.mouse[mouseLeftUp] = true
	case mouseLeftUp:
		delete(inputState.mouse, mouseLeftUp)
	case mouseRightDown:
		inputState.mouse[mouseRightUp] = true
	case mouseRightUp:
		delete(inputState.mouse, mouseRightUp)
	}
	inputState.Unlock()
	return nil
}

func releaseAllInputs() {
	inputState.Lock()
	keys := make([]uint16, 0, len(inputState.keys))
	for vk := range inputState.keys {
		keys = append(keys, vk)
	}
	buttons := make([]uint32, 0, len(inputState.mouse))
	for flag := range inputState.mouse {
		buttons = append(buttons, flag)
	}
	inputState.Unlock()
	for _, vk := range keys {
		_ = sendKeyInput(vk, true)
	}
	for _, flag := range buttons {
		_ = sendMouseInput(flag, 0)
	}
}

func focusTarget(target uintptr, pid uint32, stop atomicBool) bool {
	for attempt := 0; attempt < 3 && !stop.Load(); attempt++ {
		if !pIsWindowResult(target) || targetPID(target) != pid {
			return false
		}
		pSetForegroundWindow.Call(target)
		if sleepWithStop(35*time.Millisecond, stop) && targetIsForeground(target, pid) {
			return true
		}
	}
	return false
}

// atomicBool is a tiny adapter so the input layer does not depend on App.
type atomicBool interface{ Load() bool }

func performAction(target uintptr, pid uint32, action Action, stop atomicBool) error {
	if stop.Load() {
		return nil
	}
	if !focusTarget(target, pid, stop) {
		if stop.Load() {
			return nil
		}
		return fmt.Errorf("目标窗口未获得前台焦点；为防止误操作，未发送输入")
	}
	if action.Mouse != "" {
		if err := performMouseAction(target, pid, action, stop); err != nil {
			return err
		}
	}
	if len(action.Keys) > 0 {
		pressed := make([]uint16, 0, len(action.Keys))
		defer func() {
			for i := len(pressed) - 1; i >= 0; i-- {
				_ = sendKeyInput(pressed[i], true)
			}
		}()
		for _, vk := range action.Keys {
			if stop.Load() {
				return nil
			}
			if !targetIsForeground(target, pid) {
				return fmt.Errorf("输入期间游戏窗口失去焦点；已释放按键")
			}
			if err := sendKeyInput(vk, false); err != nil {
				return err
			}
			pressed = append(pressed, vk)
		}
		if !sleepWithTarget(time.Duration(action.DurationMS)*time.Millisecond, target, pid, stop) {
			if stop.Load() {
				return nil
			}
			return fmt.Errorf("输入期间游戏窗口失去前台焦点；已释放按键")
		}
	}
	if len(action.Keys) == 0 && action.Mouse == "" {
		_ = sleepWithStop(time.Duration(action.DurationMS)*time.Millisecond, stop)
	}
	return nil
}

func performMouseAction(target uintptr, pid uint32, action Action, stop atomicBool) error {
	var client RECT
	ok, _, _ := pGetClientRect.Call(target, uintptr(unsafe.Pointer(&client)))
	if ok == 0 {
		return fmt.Errorf("无法读取游戏客户区")
	}
	width, height := int(client.Right-client.Left), int(client.Bottom-client.Top)
	if width < 1 || height < 1 {
		return fmt.Errorf("游戏客户区尺寸无效")
	}
	pt := POINT{X: int32(float64(width-1) * action.X), Y: int32(float64(height-1) * action.Y)}
	ok, _, _ = pClientToScreen.Call(target, uintptr(unsafe.Pointer(&pt)))
	if ok == 0 {
		return fmt.Errorf("无法转换鼠标坐标")
	}
	if !targetIsForeground(target, pid) {
		return fmt.Errorf("游戏窗口失去焦点；未执行鼠标操作")
	}
	if action.Mouse == "move" || action.Mouse == "left" || action.Mouse == "right" || action.Mouse == "wheel_up" || action.Mouse == "wheel_down" {
		ok, _, _ = pSetCursorPos.Call(uintptr(pt.X), uintptr(pt.Y))
		if ok == 0 {
			return fmt.Errorf("设置鼠标位置失败")
		}
	}
	if action.Mouse == "move" {
		return nil
	}
	if !targetIsForeground(target, pid) {
		return fmt.Errorf("鼠标操作前游戏窗口失去焦点")
	}
	switch action.Mouse {
	case "left":
		if err := sendMouseInput(mouseLeftDown, 0); err != nil {
			return err
		}
		defer func() { _ = sendMouseInput(mouseLeftUp, 0) }()
		if !sleepWithTarget(time.Duration(action.DurationMS)*time.Millisecond, target, pid, stop) {
			if stop.Load() {
				return nil
			}
			return fmt.Errorf("鼠标按住期间游戏窗口失去前台焦点；已释放鼠标键")
		}
	case "right":
		if err := sendMouseInput(mouseRightDown, 0); err != nil {
			return err
		}
		defer func() { _ = sendMouseInput(mouseRightUp, 0) }()
		if !sleepWithTarget(time.Duration(action.DurationMS)*time.Millisecond, target, pid, stop) {
			if stop.Load() {
				return nil
			}
			return fmt.Errorf("鼠标按住期间游戏窗口失去前台焦点；已释放鼠标键")
		}
	case "wheel_up":
		return sendMouseInput(mouseWheel, 120)
	case "wheel_down":
		return sendMouseInput(mouseWheel, 0xFFFFFF88)
	}
	return nil
}

func sleepWithStop(duration time.Duration, stop atomicBool) bool {
	deadline := time.Now().Add(duration)
	for time.Now().Before(deadline) {
		if stop.Load() {
			return false
		}
		remaining := time.Until(deadline)
		if remaining > 10*time.Millisecond {
			remaining = 10 * time.Millisecond
		}
		time.Sleep(remaining)
	}
	return !stop.Load()
}

func sleepWithTarget(duration time.Duration, target uintptr, pid uint32, stop atomicBool) bool {
	deadline := time.Now().Add(duration)
	for time.Now().Before(deadline) {
		if stop.Load() || !targetIsForeground(target, pid) {
			return false
		}
		remaining := time.Until(deadline)
		if remaining > 10*time.Millisecond {
			remaining = 10 * time.Millisecond
		}
		time.Sleep(remaining)
	}
	return !stop.Load() && targetIsForeground(target, pid)
}
