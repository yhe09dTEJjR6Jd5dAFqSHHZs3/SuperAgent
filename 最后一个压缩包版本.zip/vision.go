package main

import "hash/fnv"

// visualFeature converts a BGRA frame into a compact, model-friendly descriptor.
// It averages each region instead of sampling a single pixel, and combines
// luminance, saturation, local edges, and temporal change.
func visualFeature(frame []byte, w, h int, previous []byte) ([]byte, float64) {
	const gridW, gridH = 12, 9
	const cellCount = gridW * gridH
	feature := make([]byte, cellCount*4)
	if w <= 0 || h <= 0 || len(frame) < w*h*4 {
		return feature, 0
	}
	luma := make([]int, cellCount)
	saturation := make([]int, cellCount)
	for gy := 0; gy < gridH; gy++ {
		y0 := gy * h / gridH
		y1 := (gy + 1) * h / gridH
		if y1 <= y0 {
			y1 = y0 + 1
		}
		for gx := 0; gx < gridW; gx++ {
			x0 := gx * w / gridW
			x1 := (gx + 1) * w / gridW
			if x1 <= x0 {
				x1 = x0 + 1
			}
			var sumR, sumG, sumB, samples int
			stepX := (x1 - x0) / 6
			stepY := (y1 - y0) / 6
			if stepX < 1 {
				stepX = 1
			}
			if stepY < 1 {
				stepY = 1
			}
			for y := y0; y < y1; y += stepY {
				for x := x0; x < x1; x += stepX {
					o := (y*w + x) * 4
					if o+2 >= len(frame) {
						continue
					}
					sumB += int(frame[o])
					sumG += int(frame[o+1])
					sumR += int(frame[o+2])
					samples++
				}
			}
			if samples == 0 {
				continue
			}
			r := sumR / samples
			g := sumG / samples
			b := sumB / samples
			maxC, minC := r, r
			if g > maxC {
				maxC = g
			}
			if b > maxC {
				maxC = b
			}
			if g < minC {
				minC = g
			}
			if b < minC {
				minC = b
			}
			gray := (r*3 + g*6 + b) / 10
			idx := gy*gridW + gx
			luma[idx] = gray / 32 // 0..7
			if maxC > 0 {
				saturation[idx] = (maxC - minC) * 3 / maxC
			}
		}
	}
	var totalChange float64
	for gy := 0; gy < gridH; gy++ {
		for gx := 0; gx < gridW; gx++ {
			idx := gy*gridW + gx
			left, right, up, down := luma[idx], luma[idx], luma[idx], luma[idx]
			if gx > 0 {
				left = luma[idx-1]
			}
			if gx+1 < gridW {
				right = luma[idx+1]
			}
			if gy > 0 {
				up = luma[idx-gridW]
			}
			if gy+1 < gridH {
				down = luma[idx+gridW]
			}
			dx := right - left
			if dx < 0 {
				dx = -dx
			}
			dy := down - up
			if dy < 0 {
				dy = -dy
			}
			edge := dx + dy
			if edge > 3 {
				edge = 3
			}
			motion := 0
			if len(previous) == len(feature) {
				old := int(previous[idx*4])
				d := luma[idx] - old
				if d < 0 {
					d = -d
				}
				motion = d
				if motion > 3 {
					motion = 3
				}
				totalChange += float64(d) / 7.0
			}
			feature[idx*4] = byte(luma[idx])
			feature[idx*4+1] = byte(saturation[idx])
			feature[idx*4+2] = byte(edge)
			feature[idx*4+3] = byte(motion)
		}
	}
	if len(previous) != len(feature) {
		return feature, 0
	}
	return feature, totalChange / float64(cellCount)
}

func featureHash(feature []byte) uint64 {
	h := fnv.New64a()
	_, _ = h.Write(feature)
	return h.Sum64()
}
