package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"sync"
)

const (
	modelVersion       = 2
	maxModelStates     = 50000
	maxModelFileBytes  = 64 * 1024 * 1024
	maxQValue          = 1e6
	learningRate       = 0.12
	discountFactor     = 0.92
	maxRewardMagnitude = 5.0
)

var legacyActionNames = []string{"不操作", "←", "→", "↑", "↓", "A", "D", "W", "S", "空格", "回车"}

type ModelDisk struct {
	Version int                  `json:"version"`
	Actions []string             `json:"actions,omitempty"`
	Q       map[uint64][]float64 `json:"q"`
	Visits  map[uint64]uint32    `json:"visits,omitempty"`
}

type Model struct {
	mu          sync.Mutex
	Q           map[uint64][]float64
	Visits      map[uint64]uint32
	ActionNames []string
}

func newModel(names []string) *Model {
	copyNames := append([]string(nil), names...)
	return &Model{Q: make(map[uint64][]float64), Visits: make(map[uint64]uint32), ActionNames: copyNames}
}

func (m *Model) ensureLocked(state uint64) []float64 {
	q := m.Q[state]
	if q == nil {
		q = make([]float64, len(m.ActionNames))
		m.Q[state] = q
	}
	return q
}

func (m *Model) choose(state uint64, epsilon float64, rng interface {
	Float64() float64
	Intn(int) int
}) int {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.ActionNames) == 0 {
		return 0
	}
	q := m.ensureLocked(state)
	if epsilon < 0 {
		epsilon = 0
	}
	if epsilon > 1 {
		epsilon = 1
	}
	if rng.Float64() < epsilon {
		return rng.Intn(len(q))
	}
	best := 0
	for i := 1; i < len(q); i++ {
		if q[i] > q[best] {
			best = i
		}
	}
	return best
}

func (m *Model) update(state uint64, action int, next uint64, reward float64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if action < 0 || action >= len(m.ActionNames) {
		return
	}
	reward = clamp(reward, -maxRewardMagnitude, maxRewardMagnitude)
	q := m.ensureLocked(state)
	nextQ := m.ensureLocked(next)
	maxNext := 0.0
	if len(nextQ) > 0 {
		maxNext = nextQ[0]
		for _, v := range nextQ[1:] {
			if v > maxNext {
				maxNext = v
			}
		}
	}
	q[action] += learningRate * (reward + discountFactor*maxNext - q[action])
	m.evictLocked(state, next)
}

func (m *Model) markVisited(state uint64) {
	m.mu.Lock()
	if m.Visits[state] < ^uint32(0) {
		m.Visits[state]++
	}
	m.evictLocked(state, state)
	m.mu.Unlock()
}

func (m *Model) applyFeedback(state uint64, action int, reward float64) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	if action < 0 || action >= len(m.ActionNames) {
		return false
	}
	q := m.ensureLocked(state)
	reward = clamp(reward, -maxRewardMagnitude, maxRewardMagnitude)
	q[action] += learningRate * (reward - q[action])
	m.evictLocked(state, state)
	return true
}

func (m *Model) evictLocked(keepA, keepB uint64) {
	if len(m.Q) <= maxModelStates {
		return
	}
	type item struct {
		state  uint64
		visits uint32
	}
	items := make([]item, 0, len(m.Q))
	for state := range m.Q {
		if state == keepA || state == keepB {
			continue
		}
		items = append(items, item{state: state, visits: m.Visits[state]})
	}
	sort.Slice(items, func(i, j int) bool {
		if items[i].visits == items[j].visits {
			return items[i].state < items[j].state
		}
		return items[i].visits < items[j].visits
	})
	target := maxModelStates * 9 / 10
	for _, it := range items {
		if len(m.Q) <= target {
			break
		}
		delete(m.Q, it.state)
		delete(m.Visits, it.state)
	}
}

func (m *Model) visitCount(state uint64) uint32 {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.Visits[state]
}

func (m *Model) stateCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.Q)
}

func (m *Model) save(path string) error {
	m.mu.Lock()
	d := ModelDisk{
		Version: modelVersion,
		Actions: append([]string(nil), m.ActionNames...),
		Q:       make(map[uint64][]float64, len(m.Q)),
		Visits:  make(map[uint64]uint32, len(m.Visits)),
	}
	for k, v := range m.Q {
		d.Q[k] = append([]float64(nil), v...)
	}
	for k, v := range m.Visits {
		d.Visits[k] = v
	}
	m.mu.Unlock()
	data, err := json.Marshal(d)
	if err != nil {
		return err
	}
	if len(data) > maxModelFileBytes {
		return fmt.Errorf("模型序列化后超过 %d MB 限制", maxModelFileBytes/(1024*1024))
	}
	return atomicWriteFile(path, data, 0600)
}

func loadModel(path string, currentActions []string) (*Model, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if info.Size() <= 0 || info.Size() > maxModelFileBytes {
		return nil, fmt.Errorf("模型文件大小无效：%d 字节", info.Size())
	}
	data, err := readBoundedFile(path, maxModelFileBytes)
	if err != nil {
		return nil, err
	}
	return decodeModel(data, currentActions)
}

func decodeModel(data []byte, currentActions []string) (*Model, error) {
	if len(data) == 0 || len(data) > maxModelFileBytes {
		return nil, fmt.Errorf("模型数据大小无效")
	}
	var d ModelDisk
	if err := json.Unmarshal(data, &d); err != nil {
		return nil, fmt.Errorf("模型 JSON 无效：%w", err)
	}
	if d.Q == nil {
		return nil, fmt.Errorf("模型缺少 Q 表")
	}
	if len(d.Q) > maxModelStates {
		return nil, fmt.Errorf("模型状态数超过上限")
	}
	storedNames := d.Actions
	if d.Version == 1 {
		storedNames = legacyActionNames
	} else if d.Version != modelVersion {
		return nil, fmt.Errorf("不支持的模型版本：%d", d.Version)
	}
	if len(storedNames) == 0 || len(storedNames) > maxActions {
		return nil, fmt.Errorf("模型动作定义无效")
	}
	if len(currentActions) == 0 || len(currentActions) > maxActions {
		return nil, fmt.Errorf("当前动作定义无效")
	}
	storedIndex := make(map[string]int, len(storedNames))
	for i, name := range storedNames {
		if name == "" {
			return nil, fmt.Errorf("模型动作名称为空")
		}
		if _, exists := storedIndex[name]; exists {
			return nil, fmt.Errorf("模型动作名称重复：%s", name)
		}
		storedIndex[name] = i
	}
	currentIndex := make([]int, len(currentActions))
	for i, name := range currentActions {
		if name == "" {
			return nil, fmt.Errorf("当前动作名称为空")
		}
		if idx, ok := storedIndex[name]; ok {
			currentIndex[i] = idx
		} else {
			currentIndex[i] = -1
		}
	}
	matched := 0
	for _, idx := range currentIndex {
		if idx >= 0 {
			matched++
		}
	}
	if matched == 0 {
		return nil, fmt.Errorf("模型与当前动作集没有可迁移的共同动作")
	}
	if len(d.Visits) > maxModelStates {
		return nil, fmt.Errorf("模型访问计数超过上限")
	}
	m := newModel(currentActions)
	for state, values := range d.Q {
		if len(values) != len(storedNames) {
			return nil, fmt.Errorf("状态 %d 的 Q 值长度错误：%d，预期 %d", state, len(values), len(storedNames))
		}
		for _, value := range values {
			if math.IsNaN(value) || math.IsInf(value, 0) || math.Abs(value) > maxQValue {
				return nil, fmt.Errorf("状态 %d 包含非法 Q 值", state)
			}
		}
		converted := make([]float64, len(currentActions))
		for i, oldIdx := range currentIndex {
			if oldIdx >= 0 {
				converted[i] = values[oldIdx]
			}
		}
		m.Q[state] = converted
	}
	for state, count := range d.Visits {
		if _, exists := m.Q[state]; !exists {
			return nil, fmt.Errorf("访问计数引用了不存在的状态 %d", state)
		}
		m.Visits[state] = count
	}
	return m, nil
}

func intrinsicReward(state uint64, visualChange float64, model *Model) float64 {
	visits := model.visitCount(state)
	reward := -0.025
	switch {
	case visits == 0:
		reward += 0.85
	case visits < 4:
		reward += 0.12
	default:
		reward -= math.Min(float64(visits)*0.0005, 0.08)
	}
	if visualChange < 0 {
		visualChange = 0
	}
	if visualChange > 1 {
		visualChange = 1
	}
	reward += math.Min(visualChange*0.18, 0.18)
	return clamp(reward, -1, 1.2)
}

func clamp(v, minValue, maxValue float64) float64 {
	if v < minValue {
		return minValue
	}
	if v > maxValue {
		return maxValue
	}
	return v
}
