$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

$go = Get-Command go -ErrorAction SilentlyContinue
if (-not $go) {
    throw 'Go 1.22 or newer is required to rebuild this project. The delivered GameAgent.exe does not require Go.'
}

Write-Host 'Running unit tests...' -ForegroundColor Cyan
& go test ./...
if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed.' }

Write-Host 'Running go vet...' -ForegroundColor Cyan
& go vet ./...
if ($LASTEXITCODE -ne 0) { throw 'go vet failed.' }

$env:GOOS = 'windows'
$env:GOARCH = 'amd64'
$env:CGO_ENABLED = '0'

Write-Host 'Building Windows amd64 GUI executable...' -ForegroundColor Cyan
& go build -trimpath -ldflags='-s -w -H=windowsgui' -o GameAgent.exe .
if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }

$hash = Get-FileHash -Algorithm SHA256 .\GameAgent.exe
"$($hash.Hash.ToLower())  GameAgent.exe" | Set-Content -Encoding ascii .\SHA256SUMS.txt
Write-Host "Build completed: GameAgent.exe (Windows x64 GUI)" -ForegroundColor Green
Write-Host "SHA256: $($hash.Hash)" -ForegroundColor Green
