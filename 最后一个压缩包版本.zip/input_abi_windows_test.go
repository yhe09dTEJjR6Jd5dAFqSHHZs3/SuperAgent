//go:build windows && amd64

package main

import (
	"testing"
	"unsafe"
)

func TestWindowsInputABISizes(t *testing.T) {
	if got := unsafe.Sizeof(INPUT{}); got != 40 {
		t.Fatalf("INPUT size=%d, want 40 on Windows amd64", got)
	}
	if got := unsafe.Sizeof(KEYBDINPUT{}); got != 24 {
		t.Fatalf("KEYBDINPUT size=%d, want 24 on Windows amd64", got)
	}
	if got := unsafe.Sizeof(MOUSEINPUT{}); got != 32 {
		t.Fatalf("MOUSEINPUT size=%d, want 32 on Windows amd64", got)
	}
}
