package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultActionsValidate(t *testing.T) {
	cfg := defaultActionConfig()
	actions, err := validateActionConfig(cfg, 0x1B)
	if err != nil {
		t.Fatalf("default actions should validate: %v", err)
	}
	if len(actions) != 24 {
		t.Fatalf("got %d actions, want 24", len(actions))
	}
	if actions[0].Name != "不操作" {
		t.Fatalf("first action = %q", actions[0].Name)
	}
}

func TestActionConfigRejectsStopKeyCollision(t *testing.T) {
	cfg := defaultActionConfig()
	cfg.Actions[5].Keys = []string{"A"}
	if _, err := validateActionConfig(cfg, 'A'); err == nil {
		t.Fatal("expected stop-key collision to be rejected")
	}
}

func TestActionConfigRejectsUnsafeKeysAndBounds(t *testing.T) {
	cfg := defaultActionConfig()
	cfg.Actions[1].Keys = []string{"ALT", "F4"}
	if _, err := validateActionConfig(cfg, 0x1B); err == nil {
		t.Fatal("expected unsafe key to be rejected")
	}
	cfg = defaultActionConfig()
	bad := 1.5
	cfg.Actions[15].X = &bad
	if _, err := validateActionConfig(cfg, 0x1B); err == nil {
		t.Fatal("expected out-of-range mouse coordinate to be rejected")
	}
}

func TestLoadActionsCreatesProfileConfig(t *testing.T) {
	path := filepath.Join(t.TempDir(), "models", "game", "actions.json")
	actions, created, err := loadActions(path, 0x1B)
	if err != nil {
		t.Fatal(err)
	}
	if !created {
		t.Fatal("expected default config to be created")
	}
	if len(actions) != 24 {
		t.Fatalf("got %d actions", len(actions))
	}
	if _, err := os.Stat(path); err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var cfg ActionConfig
	if err := json.Unmarshal(data, &cfg); err != nil {
		t.Fatal(err)
	}
	if cfg.Version != 1 {
		t.Fatalf("config version = %d", cfg.Version)
	}
}
