@echo off
chcp 65001 >nul
setlocal DisableDelayedExpansion
set "bootstrap=%~dp0启动引导.ps1"
if not exist "%bootstrap%" (
  echo 缺少启动引导文件。
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%bootstrap%"
exit /b %errorlevel%
