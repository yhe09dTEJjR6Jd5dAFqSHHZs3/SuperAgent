﻿$ErrorActionPreference = 'Stop'
$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$agent = Join-Path $base '通用游戏Agent.py'
$runtime = Join-Path (Join-Path $env:LOCALAPPDATA '通用游戏Agent') 'Python312'
$runtimePython = Join-Path $runtime 'python.exe'
$validation = 'import sys,tkinter; sys.exit(0 if sys.version_info >= (3,10) and sys.maxsize > 2**32 else 1)'
function CheckPython([string]$exe, [string[]]$prefix) {
    if (-not $exe -or -not (Test-Path -LiteralPath $exe -PathType Leaf)) { return $false }
    try {
        $null = & $exe @prefix -c $validation 2>$null
        return $LASTEXITCODE -eq 0
    } catch { return $false }
}
function FindPython {
    $choices = @()
    $choices += @{ Exe = $runtimePython; Prefix = @() }
    $choices += @{ Exe = (Join-Path (Join-Path $base 'runtime') 'python.exe'); Prefix = @() }
    foreach ($name in @('py.exe', 'python.exe')) {
        $command = Get-Command $name -ErrorAction SilentlyContinue
        if ($command) {
            if ($name -eq 'py.exe') {
                $choices += @{ Exe = $command.Source; Prefix = @('-3') }
            } else {
                $choices += @{ Exe = $command.Source; Prefix = @() }
            }
        }
    }
    foreach ($choice in $choices) {
        $exe = [string]$choice.Exe
        $prefix = [string[]]$choice.Prefix
        if (CheckPython $exe $prefix) { return @{ Exe=$exe; Prefix=$prefix } }
    }
    return $null
}
function InstallRuntime {
    if (-not $env:LOCALAPPDATA) { throw '系统没有提供可写入的用户运行时目录。' }
    $parent = Split-Path -Parent $runtime
    New-Item -Path $parent -ItemType Directory -Force | Out-Null
    $installer = Join-Path ([IO.Path]::GetTempPath()) ('agent-python-' + [guid]::NewGuid().ToString('N') + '.exe')
    $sources = @(
        'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe',
        'https://mirrors.huaweicloud.com/python/3.12.10/python-3.12.10-amd64.exe',
        'https://mirrors.aliyun.com/python/3.12.10/python-3.12.10-amd64.exe'
    )
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        foreach ($source in $sources) {
            try {
                Write-Host '正在准备本地 Python 运行环境…'
                Invoke-WebRequest -UseBasicParsing -Uri $source -OutFile $installer -TimeoutSec 90
                $signature = Get-AuthenticodeSignature -LiteralPath $installer
                if ($signature.Status -ne 'Valid' -or -not $signature.SignerCertificate -or
                    $signature.SignerCertificate.Subject -notmatch 'Python Software Foundation') {
                    throw '下载文件没有通过 Python Software Foundation 数字签名验证。'
                }
                $arguments = @('/quiet','InstallAllUsers=0',
                               ('TargetDir="' + $runtime + '"'),
                               'Include_launcher=0','Include_pip=1','Include_tcltk=1',
                               'Include_test=0','PrependPath=0','AssociateFiles=0',
                               'Shortcuts=0','CompileAll=0')
                $process = Start-Process -FilePath $installer -ArgumentList $arguments -Wait -PassThru
                if ($process.ExitCode -eq 0 -and (CheckPython $runtimePython @())) { return }
                throw ('运行时安装未成功，退出码：' + $process.ExitCode)
            } catch {
                if (Test-Path -LiteralPath $installer) { Remove-Item -LiteralPath $installer -Force }
            }
        }
        throw '首次运行需要 Windows x64 Python 3.10+ 和 tkinter。联网自动准备失败；可以安装 Python，或将完整 Windows Python 运行时放入压缩包的 runtime 文件夹。'
    } finally {
        if (Test-Path -LiteralPath $installer) { Remove-Item -LiteralPath $installer -Force }
    }
}
try {
    if (-not (Test-Path -LiteralPath $agent -PathType Leaf)) { throw '找不到 Agent 主程序。' }
    $choice = FindPython
    if (-not $choice) {
        InstallRuntime
        $choice = FindPython
    }
    if (-not $choice) { throw 'Python 运行时验证失败。' }
    $exe = $choice.Exe
    $arguments = @($choice.Prefix) + @($agent)
    if ([IO.Path]::GetFileName($exe).ToLowerInvariant() -eq 'py.exe') {
        $w = Join-Path (Split-Path -Parent $exe) 'pyw.exe'
    } else {
        $w = Join-Path (Split-Path -Parent $exe) 'pythonw.exe'
    }
    if (Test-Path -LiteralPath $w -PathType Leaf) {
        $exe = $w
    } else {
        Write-Host '未找到无控制台运行器，使用标准 Python 启动。'
    }
    $escaped = @($arguments | ForEach-Object { '"' + ($_ -replace '"','\"') + '"' })
    Start-Process -FilePath $exe -ArgumentList $escaped -WorkingDirectory $base -ErrorAction Stop | Out-Null
} catch {
    $message = [string]$_.Exception.Message
    try {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show($message, '通用游戏 Agent · 启动失败', 'OK', 'Error') | Out-Null
    } catch {
        Write-Host $message
    }
    exit 1
}
