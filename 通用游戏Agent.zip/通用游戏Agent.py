import ctypes
import gzip
import hashlib
import importlib
import json
import math
import os
import pathlib
import random
import shutil
import socket
import sqlite3
import struct
import subprocess
import sys
sys.dont_write_bytecode = True
import sysconfig
import tempfile
import threading
import time
import traceback
import uuid
import urllib.parse
import urllib.request
import zipfile
import zlib
from collections import OrderedDict, deque

W, H, GW, GH, FEATURE_COUNT = 320, 180, 20, 12, 512
LEGACY_FEATURE_COUNT, MODEL_FORMAT, MODEL_HIDDEN_SIZE = 384, 8, 128
DW, DH = 960, 540
WM_APP_STATUS, WM_APP_READY, WM_APP_STOPPED, WM_APP_CHOOSE, WM_APP_RELEASED, WM_APP_STOP_REQUESTED = 0x8001, 0x8002, 0x8003, 0x8004, 0x8005, 0x8006
WM_CLOSE, WM_DESTROY, WM_COMMAND, WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0010, 0x0002, 0x0111, 0x0100, 0x0101, 0x0104, 0x0105
WM_QUIT, WM_SETFONT, WM_HOTKEY, WM_INPUT = 0x0012, 0x0030, 0x0312, 0x00FF
MOUSEEVENTF_MOVE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0001, 0x0002, 0x0004
MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP = 0x0008, 0x0010, 0x0020, 0x0040
MOUSEEVENTF_WHEEL, MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_VIRTUALDESK = 0x0800, 0x8000, 0x4000
KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP, KEYEVENTF_SCANCODE = 0x0001, 0x0002, 0x0008
SRCCOPY, CAPTUREBLT, DIB_RGB_COLORS = 0x00CC0020, 0x40000000, 0
DISCOUNT = 0.92
N_STEP = 3
GLYPH_ROWS = {
    '0': ('01110', '10001', '10011', '10101', '11001', '10001', '01110'),
    '1': ('00100', '01100', '00100', '00100', '00100', '00100', '01110'),
    '2': ('01110', '10001', '00001', '00010', '00100', '01000', '11111'),
    '3': ('11110', '00001', '00001', '01110', '00001', '00001', '11110'),
    '4': ('00010', '00110', '01010', '10010', '11111', '00010', '00010'),
    '5': ('11111', '10000', '10000', '11110', '00001', '00001', '11110'),
    '6': ('01110', '10000', '10000', '11110', '10001', '10001', '01110'),
    '7': ('11111', '00001', '00010', '00100', '01000', '01000', '01000'),
    '8': ('01110', '10001', '10001', '01110', '10001', '10001', '01110'),
    '9': ('01110', '10001', '10001', '01111', '00001', '00001', '01110'),
    'A': ('01110', '10001', '10001', '11111', '10001', '10001', '10001'),
    'B': ('11110', '10001', '10001', '11110', '10001', '10001', '11110'),
    'H': ('10001', '10001', '10001', '11111', '10001', '10001', '10001'),
    'J': ('00111', '00010', '00010', '00010', '10010', '10010', '01100'),
    'K': ('10001', '10010', '10100', '11000', '10100', '10010', '10001'),
    'P': ('11110', '10001', '10001', '11110', '10000', '10000', '10000'),
    'Q': ('01110', '10001', '10001', '10001', '10101', '10010', '01101'),
    'X': ('10001', '10001', '01010', '00100', '01010', '10001', '10001'),
    'Z': ('11111', '00001', '00010', '00100', '01000', '10000', '11111'),
    'C': ('01111', '10000', '10000', '10000', '10000', '10000', '01111'),
    'D': ('11110', '10001', '10001', '10001', '10001', '10001', '11110'),
    'E': ('11111', '10000', '10000', '11110', '10000', '10000', '11111'),
    'F': ('11111', '10000', '10000', '11110', '10000', '10000', '10000'),
    'G': ('01111', '10000', '10000', '10111', '10001', '10001', '01110'),
    'I': ('11111', '00100', '00100', '00100', '00100', '00100', '11111'),
    'L': ('10000', '10000', '10000', '10000', '10000', '10000', '11111'),
    'M': ('10001', '11011', '10101', '10101', '10001', '10001', '10001'),
    'N': ('10001', '11001', '10101', '10011', '10001', '10001', '10001'),
    'O': ('01110', '10001', '10001', '10001', '10001', '10001', '01110'),
    'R': ('11110', '10001', '10001', '11110', '10100', '10010', '10001'),
    'S': ('01111', '10000', '10000', '01110', '00001', '00001', '11110'),
    'T': ('11111', '00100', '00100', '00100', '00100', '00100', '00100'),
    'U': ('10001', '10001', '10001', '10001', '10001', '10001', '01110'),
    'V': ('10001', '10001', '10001', '10001', '10001', '01010', '00100'),
    'W': ('10001', '10001', '10001', '10101', '10101', '10101', '01010'),
    'Y': ('10001', '10001', '01010', '00100', '00100', '00100', '00100'),
}


class LocalGlyphTemplates:
    def __init__(self):
        self.templates = {}
        if os.name != 'nt':
            return
        gdi = ctypes.WinDLL('gdi32', use_last_error=True)
        gdi.CreateFontW.argtypes = [ctypes.c_int] * 13 + [ctypes.c_wchar_p]
        gdi.CreateFontW.restype = HWND
        gdi.TextOutW.argtypes = [HWND, ctypes.c_int, ctypes.c_int, ctypes.c_wchar_p, ctypes.c_int]
        gdi.TextOutW.restype = ctypes.c_int
        gdi.SetTextColor.argtypes = [HWND, ctypes.c_ulong]
        gdi.SetTextColor.restype = ctypes.c_ulong
        gdi.SetBkMode.argtypes = [HWND, ctypes.c_int]
        gdi.SetBkMode.restype = ctypes.c_int
        gdi.CreateCompatibleDC.argtypes = [HWND]
        gdi.CreateCompatibleDC.restype = HWND
        gdi.DeleteDC.argtypes = [HWND]
        gdi.DeleteDC.restype = ctypes.c_int
        gdi.CreateDIBSection.argtypes = [HWND, ctypes.POINTER(BITMAPINFO), ctypes.c_uint, ctypes.POINTER(HWND), HWND, ctypes.c_ulong]
        gdi.CreateDIBSection.restype = HWND
        gdi.SelectObject.argtypes = [HWND, HWND]
        gdi.SelectObject.restype = HWND
        gdi.DeleteObject.argtypes = [HWND]
        gdi.DeleteObject.restype = ctypes.c_int
        dc = gdi.CreateCompatibleDC(None)
        if not dc:
            return
        dib = BITMAPINFO()
        dib.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        dib.bmiHeader.biWidth = 40
        dib.bmiHeader.biHeight = -40
        dib.bmiHeader.biPlanes = 1
        dib.bmiHeader.biBitCount = 32
        pointer = HWND()
        bitmap = gdi.CreateDIBSection(dc, ctypes.byref(dib), 0, ctypes.byref(pointer), None, 0)
        if not bitmap or not pointer.value:
            if bitmap:
                gdi.DeleteObject(bitmap)
            gdi.DeleteDC(dc)
            return
        old_bitmap = gdi.SelectObject(dc, bitmap)
        gdi.SetBkMode(dc, 1)
        gdi.SetTextColor(dc, 0xFFFFFF)
        chars = '胜利失败通关成功任务完成获游戏结束恭喜挑战胜负已达标'
        try:
            for face in ('Microsoft YaHei UI', 'SimSun'):
                for height in (15, 20, 27, 32):
                    font = gdi.CreateFontW(height, 0, 0, 0, 650, 0, 0, 0, 1, 0, 0, 5, 0, face)
                    if not font:
                        continue
                    old_font = gdi.SelectObject(dc, font)
                    try:
                        for char in set(chars):
                            ctypes.memset(pointer.value, 0, 40 * 40 * 4)
                            if not gdi.TextOutW(dc, 2, 1, char, 1):
                                continue
                            bitmap_data = ctypes.string_at(pointer.value, 40 * 40 * 4)
                            positions = [(i % 40, i // 40) for i in range(40 * 40) if bitmap_data[i * 4] >= 95]
                            if not positions:
                                continue
                            left, top = min(x for x, y in positions), min(y for x, y in positions)
                            right, bottom = max(x for x, y in positions), max(y for x, y in positions)
                            occupied = set(positions)
                            mask = set()
                            for y in range(12):
                                sy = top + min(bottom - top, int((y + 0.5) * (bottom - top + 1) / 12))
                                for x in range(10):
                                    sx = left + min(right - left, int((x + 0.5) * (right - left + 1) / 10))
                                    if (sx, sy) in occupied:
                                        mask.add(y * 10 + x)
                            if len(mask) >= 14:
                                self.templates.setdefault(char, []).append(mask)
                    finally:
                        gdi.SelectObject(dc, old_font)
                        gdi.DeleteObject(font)
        finally:
            gdi.SelectObject(dc, old_bitmap)
            gdi.DeleteObject(bitmap)
            gdi.DeleteDC(dc)

    def best(self, sampled):
        result = (0.0, '')
        second = 0.0
        for symbol, variants in self.templates.items():
            score = max(2.0 * len(sampled & shape) / max(1, len(sampled) + len(shape)) for shape in variants)
            if score > result[0]:
                second = result[0]
                result = (score, symbol)
            else:
                second = max(second, score)
        return result if result[0] >= 0.87 and result[0] - second >= 0.065 else (0.0, '')

CAPTURE_OWNER_LOCK = threading.Lock()
HWND = ctypes.c_void_p
LRESULT = ctypes.c_ssize_t
WPARAM = ctypes.c_size_t
LPARAM = ctypes.c_ssize_t
WINPROC = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(LRESULT, HWND, ctypes.c_uint, WPARAM, LPARAM)
HOOKPROC = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(LRESULT, ctypes.c_int, WPARAM, LPARAM)
WNDENUMPROC = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(ctypes.c_int, HWND, LPARAM)


def luminance_bgr(blue, green, red):
    return (blue * 0.114 + green * 0.587 + red * 0.299) / 255.0


class POINT(ctypes.Structure):
    _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long), ('right', ctypes.c_long), ('bottom', ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [('hwnd', HWND), ('message', ctypes.c_uint), ('wParam', WPARAM), ('lParam', LPARAM), ('time', ctypes.c_ulong), ('pt', POINT), ('lPrivate', ctypes.c_ulong)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [('style', ctypes.c_uint), ('lpfnWndProc', WINPROC), ('cbClsExtra', ctypes.c_int), ('cbWndExtra', ctypes.c_int), ('hInstance', HWND), ('hIcon', HWND), ('hCursor', HWND), ('hbrBackground', HWND), ('lpszMenuName', ctypes.c_wchar_p), ('lpszClassName', ctypes.c_wchar_p)]


class BROWSEINFOW(ctypes.Structure):
    _fields_ = [('hwndOwner', HWND), ('pidlRoot', HWND), ('pszDisplayName', ctypes.c_wchar_p), ('lpszTitle', ctypes.c_wchar_p), ('ulFlags', ctypes.c_uint), ('lpfn', HWND), ('lParam', LPARAM), ('iImage', ctypes.c_int)]


class GUID(ctypes.Structure):
    _fields_ = [('Data1', ctypes.c_ulong), ('Data2', ctypes.c_ushort), ('Data3', ctypes.c_ushort), ('Data4', ctypes.c_ubyte * 8)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [('biSize', ctypes.c_ulong), ('biWidth', ctypes.c_long), ('biHeight', ctypes.c_long), ('biPlanes', ctypes.c_ushort), ('biBitCount', ctypes.c_ushort), ('biCompression', ctypes.c_ulong), ('biSizeImage', ctypes.c_ulong), ('biXPelsPerMeter', ctypes.c_long), ('biYPelsPerMeter', ctypes.c_long), ('biClrUsed', ctypes.c_ulong), ('biClrImportant', ctypes.c_ulong)]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [('bmiHeader', BITMAPINFOHEADER), ('bmiColors', ctypes.c_ulong * 3)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong), ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamL', ctypes.c_ushort), ('wParamH', ctypes.c_ushort)]


class INPUTUNION(ctypes.Union):
    _fields_ = [('mi', MOUSEINPUT), ('ki', KEYBDINPUT), ('hi', HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('value', INPUTUNION)]


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [('vkCode', ctypes.c_ulong), ('scanCode', ctypes.c_ulong), ('flags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class RAWINPUTDEVICE(ctypes.Structure):
    _fields_ = [('usUsagePage', ctypes.c_ushort), ('usUsage', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong), ('hwndTarget', HWND)]


class RAWINPUTHEADER(ctypes.Structure):
    _fields_ = [('dwType', ctypes.c_ulong), ('dwSize', ctypes.c_ulong), ('hDevice', HWND), ('wParam', WPARAM)]


class RAWKEYBOARD(ctypes.Structure):
    _fields_ = [('MakeCode', ctypes.c_ushort), ('Flags', ctypes.c_ushort), ('Reserved', ctypes.c_ushort), ('VKey', ctypes.c_ushort), ('Message', ctypes.c_uint), ('ExtraInformation', ctypes.c_ulong)]


class RAWKEYINPUT(ctypes.Structure):
    _fields_ = [('header', RAWINPUTHEADER), ('keyboard', RAWKEYBOARD)]


class POINTERINFO(ctypes.Structure):
    _fields_ = [('pointerType', ctypes.c_uint), ('pointerId', ctypes.c_uint), ('frameId', ctypes.c_uint), ('pointerFlags', ctypes.c_uint), ('sourceDevice', HWND), ('hwndTarget', HWND), ('ptPixelLocation', POINT), ('ptHimetricLocation', POINT), ('ptPixelLocationRaw', POINT), ('ptHimetricLocationRaw', POINT), ('dwTime', ctypes.c_ulong), ('historyCount', ctypes.c_uint), ('InputData', ctypes.c_int), ('dwKeyStates', ctypes.c_ulong), ('PerformanceCount', ctypes.c_ulonglong), ('ButtonChangeType', ctypes.c_uint)]


class POINTERTOUCHINFO(ctypes.Structure):
    _fields_ = [('pointerInfo', POINTERINFO), ('touchFlags', ctypes.c_ulong), ('touchMask', ctypes.c_ulong), ('rcContact', RECT), ('rcContactRaw', RECT), ('orientation', ctypes.c_uint), ('pressure', ctypes.c_uint)]


class Native:
    def __init__(self):
        self.user = ctypes.WinDLL('user32', use_last_error=True)
        self.gdi = ctypes.WinDLL('gdi32', use_last_error=True)
        self.shell = ctypes.WinDLL('shell32', use_last_error=True)
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.ole = ctypes.WinDLL('ole32', use_last_error=True)
        self.ole.CoInitializeEx.argtypes = [HWND, ctypes.c_ulong]
        self.ole.CoInitializeEx.restype = ctypes.c_long
        self.ole.CoUninitialize.argtypes = []
        self.ole.CoUninitialize.restype = None
        self.com_initialized = self.ole.CoInitializeEx(None, 2) in (0, 1)
        specs = [
            (self.user, 'RegisterClassW', [ctypes.POINTER(WNDCLASSW)], ctypes.c_ushort),
            (self.user, 'CreateWindowExW', [ctypes.c_ulong, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, HWND, HWND, HWND, HWND], HWND),
            (self.user, 'DefWindowProcW', [HWND, ctypes.c_uint, WPARAM, LPARAM], LRESULT),
            (self.user, 'GetMessageW', [ctypes.POINTER(MSG), HWND, ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'PeekMessageW', [ctypes.POINTER(MSG), HWND, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'TranslateMessage', [ctypes.POINTER(MSG)], ctypes.c_int),
            (self.user, 'DispatchMessageW', [ctypes.POINTER(MSG)], LRESULT),
            (self.user, 'PostMessageW', [HWND, ctypes.c_uint, WPARAM, LPARAM], ctypes.c_int),
            (self.user, 'PostThreadMessageW', [ctypes.c_ulong, ctypes.c_uint, WPARAM, LPARAM], ctypes.c_int),
            (self.user, 'SendMessageW', [HWND, ctypes.c_uint, WPARAM, LPARAM], LRESULT),
            (self.user, 'ShowWindow', [HWND, ctypes.c_int], ctypes.c_int),
            (self.user, 'UpdateWindow', [HWND], ctypes.c_int),
            (self.user, 'SetWindowTextW', [HWND, ctypes.c_wchar_p], ctypes.c_int),
            (self.user, 'EnableWindow', [HWND, ctypes.c_int], ctypes.c_int),
            (self.user, 'DestroyWindow', [HWND], ctypes.c_int),
            (self.user, 'LoadCursorW', [HWND, HWND], HWND),
            (self.user, 'GetSystemMetrics', [ctypes.c_int], ctypes.c_int),
            (self.user, 'GetForegroundWindow', [], HWND),
            (self.user, 'EnumWindows', [WNDENUMPROC, LPARAM], ctypes.c_int),
            (self.user, 'GetWindow', [HWND, ctypes.c_uint], HWND),
            (self.user, 'GetWindowRect', [HWND, ctypes.POINTER(RECT)], ctypes.c_int),
            (self.user, 'IsWindowVisible', [HWND], ctypes.c_int),
            (self.user, 'GetClassNameW', [HWND, ctypes.c_wchar_p, ctypes.c_int], ctypes.c_int),
            (self.user, 'GetWindowTextW', [HWND, ctypes.c_wchar_p, ctypes.c_int], ctypes.c_int),
            (self.user, 'GetClientRect', [HWND, ctypes.POINTER(RECT)], ctypes.c_int),
            (self.user, 'ClientToScreen', [HWND, ctypes.POINTER(POINT)], ctypes.c_int),
            (self.user, 'IsWindow', [HWND], ctypes.c_int),
            (self.user, 'IsIconic', [HWND], ctypes.c_int),
            (self.user, 'SetForegroundWindow', [HWND], ctypes.c_int),
            (self.user, 'GetDC', [HWND], HWND),
            (self.user, 'ReleaseDC', [HWND, HWND], ctypes.c_int),
            (self.user, 'GetAsyncKeyState', [ctypes.c_int], ctypes.c_short),
            (self.user, 'SendInput', [ctypes.c_uint, ctypes.POINTER(INPUT), ctypes.c_int], ctypes.c_uint),
            (self.user, 'MapVirtualKeyW', [ctypes.c_uint, ctypes.c_uint], ctypes.c_uint),
            (self.user, 'SetWindowsHookExW', [ctypes.c_int, HOOKPROC, HWND, ctypes.c_ulong], HWND),
            (self.user, 'CallNextHookEx', [HWND, ctypes.c_int, WPARAM, LPARAM], LRESULT),
            (self.user, 'UnhookWindowsHookEx', [HWND], ctypes.c_int),
            (self.user, 'RegisterHotKey', [HWND, ctypes.c_int, ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'UnregisterHotKey', [HWND, ctypes.c_int], ctypes.c_int),
            (self.user, 'RegisterRawInputDevices', [ctypes.POINTER(RAWINPUTDEVICE), ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'GetRawInputData', [HWND, ctypes.c_uint, HWND, ctypes.POINTER(ctypes.c_uint), ctypes.c_uint], ctypes.c_uint),
            (self.user, 'UnregisterClassW', [ctypes.c_wchar_p, HWND], ctypes.c_int),
            (self.user, 'GetWindowThreadProcessId', [HWND, ctypes.POINTER(ctypes.c_ulong)], ctypes.c_ulong),
            (self.gdi, 'CreateCompatibleDC', [HWND], HWND),
            (self.gdi, 'DeleteDC', [HWND], ctypes.c_int),
            (self.gdi, 'CreateDIBSection', [HWND, ctypes.POINTER(BITMAPINFO), ctypes.c_uint, ctypes.POINTER(HWND), HWND, ctypes.c_ulong], HWND),
            (self.gdi, 'SelectObject', [HWND, HWND], HWND),
            (self.gdi, 'DeleteObject', [HWND], ctypes.c_int),
            (self.gdi, 'SetStretchBltMode', [HWND, ctypes.c_int], ctypes.c_int),
            (self.gdi, 'StretchBlt', [HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong], ctypes.c_int),
            (self.shell, 'SHBrowseForFolderW', [ctypes.POINTER(BROWSEINFOW)], HWND),
            (self.shell, 'SHGetPathFromIDListW', [HWND, ctypes.c_wchar_p], ctypes.c_int),
            (self.shell, 'SHGetKnownFolderPath', [ctypes.POINTER(GUID), ctypes.c_ulong, HWND, ctypes.POINTER(HWND)], ctypes.c_long),
            (self.ole, 'CoTaskMemFree', [HWND], None),
            (self.kernel, 'GetModuleHandleW', [ctypes.c_wchar_p], HWND),
            (self.kernel, 'OpenProcess', [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong], HWND),
            (self.kernel, 'QueryFullProcessImageNameW', [HWND, ctypes.c_ulong, ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_ulong)], ctypes.c_int),
            (self.kernel, 'CloseHandle', [HWND], ctypes.c_int),
            (self.kernel, 'GetCurrentThreadId', [], ctypes.c_ulong),
            (self.kernel, 'GetDriveTypeW', [ctypes.c_wchar_p], ctypes.c_uint),
            (self.gdi, 'GetStockObject', [ctypes.c_int], HWND),
        ]
        for lib, name, args, result in specs:
            proc = getattr(lib, name)
            proc.argtypes = args
            proc.restype = result
        try:
            self.user.SetProcessDpiAwarenessContext.argtypes = [HWND]
            self.user.SetProcessDpiAwarenessContext.restype = ctypes.c_int
            self.user.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:
            try:
                self.user.SetProcessDPIAware()
            except Exception:
                pass

    def folder(self, owner):
        name = ctypes.create_unicode_buffer(512)
        browse = BROWSEINFOW()
        browse.hwndOwner = owner
        browse.pszDisplayName = ctypes.cast(name, ctypes.c_wchar_p)
        browse.lpszTitle = '选择用于保存游戏 Agent 数据的文件夹'
        browse.ulFlags = 0x0001 | (0x0040 if self.com_initialized else 0)
        pidl = self.shell.SHBrowseForFolderW(ctypes.byref(browse))
        if not pidl:
            return None
        try:
            path = ctypes.create_unicode_buffer(32768)
            if self.shell.SHGetPathFromIDListW(pidl, path):
                return pathlib.Path(path.value)
        finally:
            self.ole.CoTaskMemFree(pidl)
        return None

    def desktop(self):
        guid = GUID(0xB4BFCC3A, 0xDB2C, 0x424C, (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
        output = HWND()
        if self.shell.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(output)) == 0 and output.value:
            try:
                return pathlib.Path(ctypes.wstring_at(output.value))
            finally:
                self.ole.CoTaskMemFree(output)
        return pathlib.Path.home() / 'Desktop'


def canonical_game_key(key):
    key = str(key or 'desktop')[:50]
    base, separator, number = key.rpartition(':')
    return base if separator and number.isdecimal() and base else key


def stop_equivalent(a, b):
    if a == b:
        return True
    for generic, left, right in ((16, 160, 161), (17, 162, 163), (18, 164, 165)):
        if b == generic:
            return a in (generic, left, right)
        if b == left:
            return a in (generic, left)
        if b == right:
            return a == right
    return False


def physical_virtual_key(vk, scan, flags):
    if vk in (16, 160, 161):
        return 161 if scan == 0x36 or vk == 161 else 160
    if vk in (17, 162, 163):
        return 163 if flags & 0x01 or vk == 163 else 162
    if vk in (18, 164, 165):
        return 165 if flags & 0x01 or vk == 165 else 164
    return vk

class StopKeyGate:
    def __init__(self, native, vk, stop_event):
        self.native, self.vk, self.stop_event = native, vk, stop_event
        self.lock = threading.Lock()
        self.injected_down = False
        self.injected_release_grace_until = 0.0
        self.poll_stops = 0
        self.poll_accessible = True
        self.on_stop = None
        try:
            self.armed = not bool(native.user.GetAsyncKeyState(vk) & 0x8000)
        except Exception:
            self.armed = False

    def observe(self, pressed, physical=True):
        callback = None
        with self.lock:
            if not physical:
                return False
            if not pressed:
                self.armed = True
                return False
            if not self.armed or self.stop_event.is_set():
                return False
            self.armed = False
            self.stop_event.set()
            callback = self.on_stop
        if callback is not None:
            try:
                callback()
            except Exception:
                pass
        return True

    def note_injected(self, pressed):
        with self.lock:
            self.injected_down = bool(pressed)
            if not pressed:
                self.injected_release_grace_until = time.monotonic() + 0.12

    def injected_blocked(self):
        with self.lock:
            return self.injected_down or time.monotonic() < self.injected_release_grace_until

    def poll(self, allow_press=True):
        try:
            state = int(self.native.user.GetAsyncKeyState(self.vk)) & 0xFFFF
            pressed = bool(state & 0x8000)
            tapped = bool(state & 0x0001)
        except Exception:
            self.poll_accessible = False
            return self.stop_event.is_set()
        self.poll_accessible = True
        if not pressed:
            with self.lock:
                if self.injected_down:
                    self.injected_down = False
                    self.injected_release_grace_until = time.monotonic() + 0.12
            self.observe(False)
            if allow_press and tapped and not self.injected_blocked() and self.observe(True):
                self.poll_stops += 1
        elif allow_press and not self.injected_blocked() and self.observe(True):
            self.poll_stops += 1
        return self.stop_event.is_set()


class StopListener:
    def __init__(self, native, stop_vk, stop_event, gate=None):
        self.native = native
        self.stop_vk = stop_vk
        self.stop_event = stop_event
        self.gate = gate if gate is not None else StopKeyGate(native, stop_vk, stop_event)
        self.ending = threading.Event()
        self.thread_id = 0
        self.mode = 'initializing'
        self.callback = None
        self.window_callback = None
        self.window = None
        self.ready = threading.Event()
        self.last_tick = time.monotonic()
        self.last_poll_tick = time.monotonic()
        self.poll_ready = threading.Event()
        self.poll_failures = 0
        self.loop_failures = 0
        self.raw_events = 0
        self.hook_events = 0
        self.hotkey_events = 0
        self.registered_channels = {'hook': False, 'raw': False, 'hotkey': False}
        self.registration_error = None
        self.thread = threading.Thread(target=self.run, name='StopKey', daemon=True)
        self.poll_thread = threading.Thread(target=self.poll_loop, name='StopKeyBackup', daemon=True)

    def start(self):
        self.poll_thread.start()
        self.thread.start()
        self.poll_ready.wait(2.0)
        self.ready.wait(2.0)
        if not self.healthy():
            self.close()
            raise OSError('停止键事件监听与独立轮询均未通过健康检查')

    def alive(self):
        return self.thread.is_alive() or self.poll_thread.is_alive()

    def event_healthy(self):
        return (self.thread.is_alive() and self.ready.is_set()
                and any(self.registered_channels.values())
                and time.monotonic() - self.last_tick < 1.5 and not self.ending.is_set())

    def poll_healthy(self):
        return (self.poll_thread.is_alive() and self.poll_ready.is_set() and self.gate.poll_accessible
                and time.monotonic() - self.last_poll_tick < 1.5 and not self.ending.is_set())

    def healthy(self):
        return self.event_healthy() or self.poll_healthy()

    def poll_loop(self):
        while not self.ending.is_set() and not self.stop_event.is_set():
            try:
                self.gate.poll(allow_press=True)
            except Exception:
                self.poll_failures += 1
            finally:
                self.last_poll_tick = time.monotonic()
                self.poll_ready.set()
            self.ending.wait(0.008)

    def run(self):
        self.thread_id = self.native.kernel.GetCurrentThreadId()
        hook = None
        registered = False
        raw_registered = False
        registered_class = False
        class_name = f'OpenGameAgentStopRaw_{os.getpid()}_{id(self)}'
        instance = self.native.kernel.GetModuleHandleW(None)
        try:
            def keyboard(code, wp, lp):
                try:
                    if code >= 0:
                        info = ctypes.cast(lp, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                        physical_vk = physical_virtual_key(info.vkCode, info.scanCode, info.flags)
                        if stop_equivalent(physical_vk, self.stop_vk):
                            if info.flags & 0x10:
                                self.gate.note_injected(wp in (WM_KEYDOWN, WM_SYSKEYDOWN))
                                return self.native.user.CallNextHookEx(hook, code, wp, lp)
                            self.hook_events += 1
                            if wp in (WM_KEYUP, WM_SYSKEYUP):
                                self.gate.observe(False)
                                return 1
                            if wp in (WM_KEYDOWN, WM_SYSKEYDOWN):
                                self.gate.observe(True)
                                return 1
                except Exception:
                    pass
                return self.native.user.CallNextHookEx(hook, code, wp, lp)

            def raw_window(hwnd, msg, wp, lp):
                if msg == WM_INPUT:
                    try:
                        length = ctypes.c_uint(0)
                        header_size = ctypes.sizeof(RAWINPUTHEADER)
                        result = self.native.user.GetRawInputData(HWND(lp), 0x10000003, None, ctypes.byref(length), header_size)
                        if result != 0xFFFFFFFF and header_size + ctypes.sizeof(RAWKEYBOARD) <= length.value <= 65536:
                            buffer = ctypes.create_string_buffer(length.value)
                            copied = self.native.user.GetRawInputData(HWND(lp), 0x10000003, ctypes.cast(buffer, HWND), ctypes.byref(length), header_size)
                            if copied != 0xFFFFFFFF and copied >= header_size + ctypes.sizeof(RAWKEYBOARD):
                                data = ctypes.cast(buffer, ctypes.POINTER(RAWKEYINPUT)).contents
                                if data.header.dwType == 1:
                                    keyboard_input = data.keyboard
                                    vk = physical_virtual_key(int(keyboard_input.VKey), int(keyboard_input.MakeCode), int(keyboard_input.Flags >> 1) & 1)
                                    if stop_equivalent(vk, self.stop_vk):
                                        self.raw_events += 1
                                        self.gate.observe(not bool(keyboard_input.Flags & 1))
                    except Exception:
                        self.loop_failures += 1
                    if wp & 0xFF == 0:
                        self.native.user.DefWindowProcW(hwnd, msg, wp, lp)
                    return 0
                return self.native.user.DefWindowProcW(hwnd, msg, wp, lp)

            self.callback = HOOKPROC(keyboard)
            hook = self.native.user.SetWindowsHookExW(13, self.callback, None, 0)
            self.window_callback = WINPROC(raw_window)
            wc = WNDCLASSW()
            wc.lpfnWndProc = self.window_callback
            wc.hInstance = instance
            wc.lpszClassName = class_name
            if self.native.user.RegisterClassW(ctypes.byref(wc)):
                registered_class = True
                self.window = self.native.user.CreateWindowExW(0, class_name, '', 0, 0, 0, 0, 0,
                                                                HWND(-3), None, instance, None)
                if self.window:
                    device = RAWINPUTDEVICE(1, 6, 0x100, self.window)
                    raw_registered = bool(self.native.user.RegisterRawInputDevices(ctypes.byref(device), 1, ctypes.sizeof(RAWINPUTDEVICE)))
            registered = bool(self.native.user.RegisterHotKey(None, 8915, 0x4000, self.stop_vk))
            self.registered_channels = {'raw': raw_registered, 'hook': bool(hook), 'hotkey': registered}
            channels = [name for name, enabled in self.registered_channels.items() if enabled]
            self.mode = '+'.join(channels) if channels else 'poll'
            if not channels:
                self.registration_error = '键盘钩子、Raw Input 与系统热键均不可用，已启用独立键盘状态轮询'
            self.ready.set()
            msg = MSG()
            while not self.ending.is_set() and not self.stop_event.is_set():
                self.last_tick = time.monotonic()
                try:
                    self.gate.poll(allow_press=True)
                    while self.native.user.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                        if msg.message == WM_QUIT:
                            self.ending.set()
                            break
                        if msg.message == WM_HOTKEY and msg.wParam == 8915:
                            self.hotkey_events += 1
                            if not self.gate.injected_blocked():
                                self.gate.observe(True)
                            continue
                        self.native.user.TranslateMessage(ctypes.byref(msg))
                        self.native.user.DispatchMessageW(ctypes.byref(msg))
                except Exception:
                    self.loop_failures += 1
                    self.ending.set()
                self.ending.wait(0.009)
        except Exception as exc:
            self.registration_error = f'{type(exc).__name__}: {str(exc)[:180]}'
            self.mode = 'poll'
            self.ready.set()
        finally:
            self.registered_channels = {'hook': False, 'raw': False, 'hotkey': False}
            if raw_registered:
                try:
                    removal = RAWINPUTDEVICE(1, 6, 0x00000001, None)
                    self.native.user.RegisterRawInputDevices(ctypes.byref(removal), 1, ctypes.sizeof(RAWINPUTDEVICE))
                except Exception:
                    pass
            if hook:
                try:
                    self.native.user.UnhookWindowsHookEx(hook)
                except Exception:
                    pass
            if registered:
                try:
                    self.native.user.UnregisterHotKey(None, 8915)
                except Exception:
                    pass
            if self.window:
                try:
                    self.native.user.DestroyWindow(self.window)
                except Exception:
                    pass
                self.window = None
            if registered_class:
                try:
                    self.native.user.UnregisterClassW(class_name, instance)
                except Exception:
                    pass

    def close(self):
        self.ending.set()
        if self.thread_id:
            try:
                self.native.user.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
            except Exception:
                pass
        if self.thread.ident is not None and self.thread is not threading.current_thread():
            self.thread.join(timeout=1.0)
        if self.poll_thread.ident is not None and self.poll_thread is not threading.current_thread():
            self.poll_thread.join(timeout=0.6)


class DXGIOutputDescription(ctypes.Structure):
    _fields_ = [('DeviceName', ctypes.c_wchar * 32), ('DesktopCoordinates', RECT), ('AttachedToDesktop', ctypes.c_int), ('Rotation', ctypes.c_uint), ('Monitor', HWND)]


class DXGIFrameInfo(ctypes.Structure):
    _fields_ = [('LastPresentTime', ctypes.c_longlong), ('LastMouseUpdateTime', ctypes.c_longlong), ('AccumulatedFrames', ctypes.c_uint), ('RectsCoalesced', ctypes.c_int), ('ProtectedContentMaskedOut', ctypes.c_int), ('PointerPosition', POINT), ('PointerVisible', ctypes.c_int), ('TotalMetadataBufferSize', ctypes.c_uint), ('PointerShapeBufferSize', ctypes.c_uint)]


class D3DTextureDescription(ctypes.Structure):
    _fields_ = [('Width', ctypes.c_uint), ('Height', ctypes.c_uint), ('MipLevels', ctypes.c_uint), ('ArraySize', ctypes.c_uint), ('Format', ctypes.c_uint), ('SampleCount', ctypes.c_uint), ('SampleQuality', ctypes.c_uint), ('Usage', ctypes.c_uint), ('BindFlags', ctypes.c_uint), ('CPUAccessFlags', ctypes.c_uint), ('MiscFlags', ctypes.c_uint)]


class D3DMappedResource(ctypes.Structure):
    _fields_ = [('pData', HWND), ('RowPitch', ctypes.c_uint), ('DepthPitch', ctypes.c_uint)]


class NativeDXGI:
    def __init__(self, np_module=None):
        if os.name != 'nt' or ctypes.sizeof(HWND) != 8:
            raise OSError('原生 DXGI 采集要求 Windows 11 x64')
        self.np = np_module
        self.device = HWND()
        self.context = HWND()
        self.outputs = []
        self.duplication = HWND()
        self.staging = HWND()
        self.active = None
        self.buffer = None
        self.pitch = 0
        self.buffer_width = 0
        self.buffer_height = 0
        self.frame_protected = False
        try:
            library = ctypes.WinDLL('d3d11.dll')
            create = library.D3D11CreateDevice
            create.argtypes = [HWND, ctypes.c_uint, HWND, ctypes.c_uint, HWND, ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(HWND), ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(HWND)]
            create.restype = ctypes.c_long
            level = ctypes.c_uint()
            result = create(None, 1, None, 0x20, None, 0, 7, ctypes.byref(self.device), ctypes.byref(level), ctypes.byref(self.context))
            if result < 0 or not self.device.value or not self.context.value:
                raise OSError('D3D11 硬件设备初始化失败')
            dxgi = self.query(self.device, '54ec77fa-1377-44e6-8c32-88fd5f44c84c')
            adapter = HWND()
            try:
                self.invoke(dxgi, 7, ctypes.c_long, ctypes.POINTER(HWND))(dxgi, ctypes.byref(adapter))
                if not adapter.value:
                    raise OSError('无法获取 DXGI 显示适配器')
                index = 0
                while index < 16:
                    output = HWND()
                    status = self.invoke(adapter, 7, ctypes.c_long, ctypes.c_uint, ctypes.POINTER(HWND))(adapter, index, ctypes.byref(output))
                    if status < 0 or not output.value:
                        break
                    try:
                        desc = DXGIOutputDescription()
                        status = self.invoke(output, 7, ctypes.c_long, ctypes.POINTER(DXGIOutputDescription))(output, ctypes.byref(desc))
                        if status < 0 or not desc.AttachedToDesktop or desc.Rotation != 1:
                            continue
                        rect = desc.DesktopCoordinates
                        if rect.right <= rect.left or rect.bottom <= rect.top:
                            continue
                        output1 = self.query(output, '00cddea8-939b-4b83-a340-a685226666cc')
                        self.outputs.append(((rect.left, rect.top, rect.right, rect.bottom), output1))
                    except OSError:
                        pass
                    finally:
                        self.release(output)
                        index += 1
            finally:
                self.release(adapter)
                self.release(dxgi)
            if not self.outputs:
                raise OSError('没有可用的 DXGI 桌面输出')
        except Exception:
            self.close()
            raise

    @staticmethod
    def invoke(pointer, slot, result, *arguments):
        vtable = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(HWND))).contents
        address = vtable[slot]
        if not address:
            raise OSError('DirectX COM 方法不可用')
        return ctypes.WINFUNCTYPE(result, HWND, *arguments)(ctypes.cast(address, HWND).value)

    @classmethod
    def release(cls, pointer):
        if pointer is not None and pointer.value:
            cls.invoke(pointer, 2, ctypes.c_ulong)(pointer)
            pointer.value = None

    @classmethod
    def query(cls, pointer, guid):
        iid = GUID.from_buffer_copy(uuid.UUID(guid).bytes_le)
        output = HWND()
        result = cls.invoke(pointer, 0, ctypes.c_long, ctypes.POINTER(GUID), ctypes.POINTER(HWND))(pointer, ctypes.byref(iid), ctypes.byref(output))
        if result < 0 or not output.value:
            raise OSError(f'DXGI 接口不可用：{guid}')
        return output

    def _reset(self):
        self.release(self.staging)
        self.release(self.duplication)
        self.active = None
        self.buffer = None
        self.pitch = 0
        self.frame_protected = False

    def _select(self, rect):
        x, y, width, height = rect
        for index, (bounds, _) in enumerate(self.outputs):
            left, top, right, bottom = bounds
            if x >= left and y >= top and x + width <= right and y + height <= bottom:
                return index
        return None

    def _connect(self, index):
        if self.active == index and self.duplication.value:
            return
        self._reset()
        output = self.outputs[index][1]
        result = self.invoke(output, 22, ctypes.c_long, HWND, ctypes.POINTER(HWND))(output, self.device, ctypes.byref(self.duplication))
        if result < 0 or not self.duplication.value:
            raise OSError(f'桌面复制接口不可用：0x{result & 0xffffffff:08x}')
        self.active = index

    def _stage(self, width, height):
        if self.staging.value and self.buffer_width == width and self.buffer_height == height:
            return
        self.release(self.staging)
        desc = D3DTextureDescription(width, height, 1, 1, 87, 1, 0, 3, 0, 0x20000, 0)
        result = self.invoke(self.device, 5, ctypes.c_long, ctypes.POINTER(D3DTextureDescription), HWND, ctypes.POINTER(HWND))(self.device, ctypes.byref(desc), None, ctypes.byref(self.staging))
        if result < 0 or not self.staging.value:
            raise OSError('无法创建 DirectX CPU 读取纹理')
        self.buffer_width, self.buffer_height = width, height

    def _capture(self, index):
        bounds = self.outputs[index][0]
        width, height = bounds[2] - bounds[0], bounds[3] - bounds[1]
        info = DXGIFrameInfo()
        resource = HWND()
        status = self.invoke(self.duplication, 8, ctypes.c_long, ctypes.c_uint, ctypes.POINTER(DXGIFrameInfo), ctypes.POINTER(HWND))(self.duplication, 24, ctypes.byref(info), ctypes.byref(resource))
        if status == ctypes.c_long(0x887a0027).value:
            return self.buffer is not None
        if status < 0:
            self._reset()
            raise OSError(f'DXGI 获取屏幕帧失败：0x{status & 0xffffffff:08x}')
        texture = HWND()
        mapped_ok = False
        try:
            self.frame_protected = bool(info.ProtectedContentMaskedOut)
            texture = self.query(resource, '6f15aaf2-d208-4e89-9ab4-489535d34f9c')
            incoming = D3DTextureDescription()
            self.invoke(texture, 10, None, ctypes.POINTER(D3DTextureDescription))(texture, ctypes.byref(incoming))
            if incoming.Format != 87 or incoming.Width != width or incoming.Height != height:
                return False
            self._stage(width, height)
            self.invoke(self.context, 47, None, HWND, HWND)(self.context, self.staging, texture)
            mapped = D3DMappedResource()
            result = self.invoke(self.context, 14, ctypes.c_long, HWND, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(D3DMappedResource))(self.context, self.staging, 0, 1, 0, ctypes.byref(mapped))
            if result < 0 or not mapped.pData or mapped.RowPitch < width * 4:
                raise OSError('DirectX 帧映射失败')
            mapped_ok = True
            self.pitch = int(mapped.RowPitch)
            self.buffer = ctypes.string_at(mapped.pData, self.pitch * height)
            return True
        finally:
            if mapped_ok:
                self.invoke(self.context, 15, None, HWND, ctypes.c_uint)(self.context, self.staging, 0)
            self.release(texture)
            self.release(resource)
            if self.duplication.value:
                self.invoke(self.duplication, 14, ctypes.c_long)(self.duplication)

    def grab(self, rect, width, height):
        index = self._select(rect)
        if index is None:
            return None
        self._connect(index)
        if not self._capture(index) or self.frame_protected:
            return None
        left, top, right, bottom = self.outputs[index][0]
        sx, sy = rect[0] - left, rect[1] - top
        rw, rh = rect[2], rect[3]
        if self.np is not None:
            np = self.np
            image = np.frombuffer(self.buffer, dtype=np.uint8).reshape(self.buffer_height, self.pitch)
            xs = sx + np.minimum(rw - 1, np.arange(width, dtype=np.int32) * rw // width)
            ys = sy + np.minimum(rh - 1, np.arange(height, dtype=np.int32) * rh // height)
            image = image[:, :self.buffer_width * 4].reshape(self.buffer_height, self.buffer_width, 4)
            return np.ascontiguousarray(image[ys[:, None], xs[None, :]]).tobytes()
        raw = self.buffer
        result = bytearray(width * height * 4)
        xs = [sx + min(rw - 1, c * rw // width) for c in range(width)]
        for row in range(height):
            source = (sy + min(rh - 1, row * rh // height)) * self.pitch
            destination = row * width * 4
            for col, x in enumerate(xs):
                pos = source + x * 4
                result[destination + col * 4:destination + col * 4 + 4] = raw[pos:pos + 4]
        return bytes(result)

    def close(self):
        self._reset()
        for _, output in self.outputs:
            self.release(output)
        self.outputs.clear()
        self.release(self.context)
        self.release(self.device)


class WorkspaceLease:
    def __init__(self, selected):
        self.selected = pathlib.Path(selected).resolve()
        self.selected.mkdir(parents=True, exist_ok=True)
        self.stream = None
        self.folder = None
        import msvcrt
        for attempt in range(2):
            folder = self.selected if attempt == 0 else self.selected / '并行运行数据' / (time.strftime('%Y%m%d_%H%M%S') + '_' + str(os.getpid()) + '_' + uuid.uuid4().hex[:8])
            folder.mkdir(parents=True, exist_ok=True)
            stream = (folder / '.agent_workspace.lock').open('a+b')
            try:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                stream.close()
                if attempt == 0:
                    continue
                raise
            self.folder = folder
            self.stream = stream
            return
        raise OSError('无法锁定选定的数据目录')

    def close(self):
        if self.stream is None:
            return
        stream, self.stream = self.stream, None
        try:
            import msvcrt
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        finally:
            stream.close()


class Capture:
    def __init__(self, native, mode, own_hwnd):
        self.n = native
        self.mode = mode
        self.own_hwnd = own_hwnd
        self.target = None
        self.target_signature = None
        self.target_pid = None
        self.target_candidate = None
        self.target_candidate_count = 0
        self.target_candidate_since = 0.0
        self.target_last_focus_attempt = 0.0
        self.target_rank = 0
        self.target_candidate_frame = None
        self.target_candidate_motion = 0.0
        self.target_candidate_last_probe = 0.0
        self.capture_lock = threading.RLock()
        self.identity_base = None
        self.identity_title = ''
        self.identity_candidate = ''
        self.identity_count = 0
        self.low_information_frames = 0
        self.last_backend_probe = 0.0
        self.base = None
        self.detail = None
        self.dx = None
        self.native_dx = None
        self.cv_np = None
        self.backend_error = None
        try:
            self.cv_np = importlib.import_module('numpy')
        except ImportError:
            pass
        self._initialize_fast_capture()
        try:
            self.base = self._surface(W, H)
            self.detail = self._surface(DW, DH)
        except Exception:
            self.close()
            raise

    @property
    def backend(self):
        if self.native_dx is not None:
            return 'native_dxgi'
        if self.dx is not None:
            return 'dxcam'
        return 'gdi'

    def _initialize_fast_capture(self):
        if self.native_dx is None:
            try:
                self.native_dx = NativeDXGI(self.cv_np)
                self.backend_error = None
            except Exception as exc:
                self.backend_error = f'原生 DXGI 采集未启用：{type(exc).__name__}: {exc}'
        if self.native_dx is None and self.dx is None and self.cv_np is not None:
            try:
                library = importlib.import_module('dxcam')
                self.dx = library.create(output_idx=0, output_color='BGRA')
            except Exception as exc:
                self.backend_error = f'{self.backend_error or ""}; dxcam 不可用：{type(exc).__name__}: {exc}'

    def _surface(self, width, height):
        dc = self.n.gdi.CreateCompatibleDC(None)
        if not dc:
            raise OSError('无法创建图像采集内存设备')
        bitmap = None
        try:
            bmi = BITMAPINFO()
            bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bmi.bmiHeader.biWidth = width
            bmi.bmiHeader.biHeight = -height
            bmi.bmiHeader.biPlanes = 1
            bmi.bmiHeader.biBitCount = 32
            bmi.bmiHeader.biCompression = 0
            bmi.bmiHeader.biSizeImage = width * height * 4
            bits = HWND()
            bitmap = self.n.gdi.CreateDIBSection(dc, ctypes.byref(bmi), DIB_RGB_COLORS, ctypes.byref(bits), None, 0)
            if not bitmap or not bits.value:
                raise OSError('无法创建图像采集缓冲区')
            previous = self.n.gdi.SelectObject(dc, bitmap)
            if not previous:
                raise OSError('无法选取图像采集缓冲区')
            self.n.gdi.SetStretchBltMode(dc, 3)
            return (dc, bitmap, previous, bits.value, width, height)
        except Exception:
            if bitmap:
                self.n.gdi.DeleteObject(bitmap)
            self.n.gdi.DeleteDC(dc)
            raise

    def game_identity(self):
        hwnd = self.target if self.mode == '窗口' and self.target else self.n.user.GetForegroundWindow()
        if not hwnd or hwnd == self.own_hwnd or not self.n.user.IsWindow(hwnd):
            return 'desktop'
        try:
            pid = ctypes.c_ulong()
            self.n.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            exe = ''
            if pid.value:
                process = self.n.kernel.OpenProcess(0x1000, 0, pid.value)
                if process:
                    try:
                        buffer = ctypes.create_unicode_buffer(32768)
                        size = ctypes.c_ulong(len(buffer))
                        if self.n.kernel.QueryFullProcessImageNameW(process, 0, buffer, ctypes.byref(size)):
                            exe = pathlib.PureWindowsPath(buffer.value).name.lower()
                    finally:
                        self.n.kernel.CloseHandle(process)
            label = ctypes.create_unicode_buffer(260)
            self.n.user.GetClassNameW(hwnd, label, len(label))
            basis = '|'.join((exe or f'pid:{pid.value}', label.value.lower()))
            if exe in ('chrome.exe', 'msedge.exe', 'firefox.exe', 'brave.exe', 'opera.exe'):
                title = ctypes.create_unicode_buffer(512)
                self.n.user.GetWindowTextW(hwnd, title, len(title))
                clean = ''.join('#' if c.isdigit() else c for c in title.value.lower().strip()).split(' - ')[0][:75]
                if self.identity_base != basis:
                    self.identity_base = basis
                    self.identity_title = clean
                    self.identity_candidate = clean
                    self.identity_count = 0
                elif clean != self.identity_title:
                    if clean == self.identity_candidate:
                        self.identity_count += 1
                    else:
                        self.identity_candidate = clean
                        self.identity_count = 1
                    if self.identity_count >= 90 and clean:
                        self.identity_title = clean
                        self.identity_count = 0
                basis += '|' + self.identity_title
            else:
                self.identity_base = basis
                self.identity_title = ''
            return hashlib.blake2b(basis.encode('utf-8'), digest_size=10).hexdigest()
        except Exception:
            return 'desktop'

    def _window_identity(self, hwnd):
        if not hwnd or hwnd == self.own_hwnd or not self.n.user.IsWindow(hwnd):
            return None
        pid = ctypes.c_ulong()
        self.n.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value or pid.value == os.getpid():
            return None
        label = ctypes.create_unicode_buffer(256)
        self.n.user.GetClassNameW(hwnd, label, len(label))
        executable = ''
        process = self.n.kernel.OpenProcess(0x1000, 0, pid.value)
        if process:
            try:
                path = ctypes.create_unicode_buffer(32768)
                length = ctypes.c_ulong(len(path))
                if self.n.kernel.QueryFullProcessImageNameW(process, 0, path, ctypes.byref(length)):
                    executable = str(path.value).casefold()
            finally:
                self.n.kernel.CloseHandle(process)
        if label.value.casefold() in ('progman', 'workerw', 'shell_traywnd'):
            return None
        title_buffer = ctypes.create_unicode_buffer(512)
        self.n.user.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
        stable_title = ''.join('#' if char.isdecimal() else char for char in title_buffer.value.strip().casefold())[:120]
        return (int(pid.value), label.value.casefold(), executable, stable_title)

    def _same_target(self, hwnd):
        record = self._window_identity(hwnd)
        if record is None or self.target_signature is None:
            return False
        if record[1] != self.target_signature[0]:
            return False
        if record[0] == self.target_pid:
            return not self.target_signature[1] or record[2] == self.target_signature[1]
        if not self.target_signature[1] or record[2] != self.target_signature[1]:
            return False
        if len(self.target_signature) > 2 and self.target_signature[2] and record[3] != self.target_signature[2]:
            return False
        if self.n.user.GetForegroundWindow() != hwnd:
            return False
        old_process = self.n.kernel.OpenProcess(0x1000, 0, self.target_pid or 0)
        if old_process:
            try:
                return False
            finally:
                self.n.kernel.CloseHandle(old_process)
        return getattr(ctypes, 'get_last_error', lambda: 0)() == 87

    def _window_rank(self, hwnd, identity, width, height, foreground):
        if identity is None or width < 80 or height < 80:
            return None
        executable = pathlib.PureWindowsPath(identity[2]).name.casefold()
        window_class = identity[1].casefold()
        if executable in ('explorer.exe', 'taskmgr.exe', 'searchhost.exe', 'startmenuexperiencehost.exe', 'shellexperiencehost.exe', 'systemsettings.exe', 'control.exe', 'gamebar.exe', 'steam.exe'):
            return None
        if window_class in ('cabinetwclass', 'explorewclass', 'progman', 'workerw', 'shell_traywnd', 'windows.ui.core.corewindow'):
            return None
        if self.n.user.GetWindow(hwnd, 4):
            return None
        area = width * height
        screen_area = max(1, self.n.user.GetSystemMetrics(0) * self.n.user.GetSystemMetrics(1))
        recognized = any(token in window_class or token in executable for token in ('unitywndclass', 'unrealwindow', 'sdl_app', 'glfw', 'godot', 'game', 'pygame', 'roblox', 'steam', 'rpg', 'emulator', 'retroarch'))
        return (min(15000000, area) + (45000000 if hwnd == foreground else 0)
                + (2500000 if area >= screen_area * 0.70 else 0)
                + (8000000 if recognized else 0))

    def _candidate_is_game_like(self, selected):
        if selected is None:
            return False
        identity = selected[2]
        name = (identity[1] + ' ' + pathlib.PureWindowsPath(identity[2]).name).casefold()
        return any(token in name for token in ('unitywndclass', 'unrealwindow', 'sdl_app', 'glfw', 'godot', 'game', 'pygame', 'roblox', 'steam', 'rpg', 'emulator', 'retroarch'))

    def _candidate_visual_evidence(self, hwnd):
        rect = RECT()
        origin = POINT()
        if not self.n.user.GetClientRect(hwnd, ctypes.byref(rect)) or not self.n.user.ClientToScreen(hwnd, ctypes.byref(origin)):
            return False
        width, height = rect.right - rect.left, rect.bottom - rect.top
        if width < 80 or height < 80:
            return False
        now = time.monotonic()
        if now - self.target_candidate_last_probe < 0.18:
            return self.target_candidate_motion >= 0.012
        self.target_candidate_last_probe = now
        frame = self._grab(self.base, (origin.x, origin.y, width, height))
        old = self.target_candidate_frame
        self.target_candidate_frame = frame
        if old is not None and len(old) == len(frame):
            step = max(4, len(frame) // 2000 // 4 * 4)
            indices = range(0, len(frame), step)
            changed = sum(abs(old[i] - frame[i]) for i in indices) / max(1, len(indices) * 255)
            self.target_candidate_motion = max(changed, self.target_candidate_motion * 0.92)
        return self.target_candidate_motion >= 0.012

    def _candidates(self, previously_bound=False):
        visible = []
        foreground = self.n.user.GetForegroundWindow()
        def visit(hwnd, unused):
            try:
                identity = self._window_identity(hwnd)
                if identity is None or not self.n.user.IsWindowVisible(hwnd) or self.n.user.IsIconic(hwnd):
                    return 1
                if previously_bound and not self._same_target(hwnd):
                    return 1
                rect = RECT()
                if not self.n.user.GetClientRect(hwnd, ctypes.byref(rect)):
                    return 1
                width, height = rect.right - rect.left, rect.bottom - rect.top
                score = self._window_rank(hwnd, identity, width, height, foreground)
                if score is None:
                    return 1
                if previously_bound and identity[0] == self.target_pid:
                    score += 16000000
                if self.target and hwnd == self.target:
                    score += 32000000
                visible.append((score, int(hwnd), identity))
            except (OSError, ValueError, TypeError):
                pass
            return 1
        callback = WNDENUMPROC(visit)
        self.n.user.EnumWindows(callback, 0)
        visible.sort(reverse=True)
        return visible

    def _stable_window_candidate(self, selected, seconds):
        candidate = (selected[1], selected[2]) if selected is not None else None
        if candidate is None:
            self.target_candidate = None
            self.target_candidate_count = 0
            self.target_candidate_since = 0.0
            self.target_candidate_frame = None
            self.target_candidate_motion = 0.0
            return False
        if candidate != self.target_candidate:
            self.target_candidate = candidate
            self.target_candidate_count = 1
            self.target_candidate_since = time.monotonic()
            self.target_candidate_frame = None
            self.target_candidate_motion = 0.0
            self.target_candidate_last_probe = 0.0
        else:
            self.target_candidate_count += 1
        stable_for = time.monotonic() - self.target_candidate_since
        if self.target_candidate_count < 4 or stable_for < seconds:
            return False
        if self._candidate_is_game_like(selected):
            return True
        if stable_for >= 6.0:
            return True
        return self._candidate_visual_evidence(selected[1]) and stable_for >= 0.8

    def _bind_window(self, selected):
        self.target = selected[1]
        self.target_signature = selected[2][1:]
        self.target_pid = selected[2][0]
        self.target_rank = selected[0]
        self.target_candidate = None
        self.target_candidate_count = 0
        self.target_candidate_since = 0.0
        self.target_candidate_frame = None
        self.target_candidate_motion = 0.0

    def is_target_focused(self):
        if self.mode != '窗口':
            return True
        return bool(self.target and self.n.user.IsWindow(self.target)
                    and not self.n.user.IsIconic(self.target)
                    and self._same_target(self.target)
                    and self.n.user.GetForegroundWindow() == self.target)

    def bounds(self):
        if self.mode == '窗口':
            foreground = self.n.user.GetForegroundWindow()
            if self.target_signature is None:
                options = self._candidates()
                selected = next((item for item in options if item[1] == foreground), None)
                if self._stable_window_candidate(selected, 0.45):
                    self._bind_window(selected)
            elif not self.target or not self.n.user.IsWindow(self.target) or not self._same_target(self.target):
                self.target = None
                options = self._candidates(previously_bound=True)
                selected = next((item for item in options if item[1] == foreground), None)
                if selected is None and len(options) == 1 and options[0][2][0] == self.target_pid:
                    selected = options[0]
                if self._stable_window_candidate(selected, 0.80):
                    self._bind_window(selected)
            else:
                self.target_candidate = None
                self.target_candidate_count = 0
                self.target_candidate_since = 0.0
            if self.target and self.n.user.IsWindow(self.target) and self._same_target(self.target):
                if self.n.user.IsIconic(self.target):
                    self.n.user.ShowWindow(self.target, 9)
                rect = RECT()
                origin = POINT()
                if self.n.user.GetClientRect(self.target, ctypes.byref(rect)) and self.n.user.ClientToScreen(self.target, ctypes.byref(origin)):
                    width, height = rect.right - rect.left, rect.bottom - rect.top
                    if width >= 80 and height >= 80:
                        if not self.is_target_focused() and time.monotonic() - self.target_last_focus_attempt >= 0.28:
                            self.target_last_focus_attempt = time.monotonic()
                            self.n.user.SetForegroundWindow(self.target)
                        if not self.is_target_focused():
                            raise OSError('原游戏窗口尚未获得输入焦点，正持续尝试恢复')
                        return (origin.x, origin.y, width, height)
            raise OSError('等待有效前台游戏窗口；仅允许稳定绑定或恢复原程序窗口，不切换到无关窗口')
        return (
            self.n.user.GetSystemMetrics(76),
            self.n.user.GetSystemMetrics(77),
            max(1, self.n.user.GetSystemMetrics(78)),
            max(1, self.n.user.GetSystemMetrics(79)),
        )

    def review_frame_quality(self, quality):
        if quality.get('low_information'):
            self.low_information_frames += 1
        else:
            self.low_information_frames = 0
        if self.low_information_frames < 12:
            return
        now = time.monotonic()
        if now - self.last_backend_probe < 25.0:
            return
        self.last_backend_probe = now
        if self.native_dx is not None:
            self.native_dx.close()
            self.native_dx = None
        elif self.dx is not None:
            camera = self.dx
            self.dx = None
            try:
                camera.stop()
                camera.release()
            except Exception:
                pass
        else:
            self._initialize_fast_capture()
        self.low_information_frames = 0

    def _grab(self, surface, rect):
        dc, _, _, bits, width, height = surface
        if self.native_dx is not None:
            try:
                frame = self.native_dx.grab(rect, width, height)
                if frame is not None and len(frame) == width * height * 4:
                    return frame
            except Exception as exc:
                self.backend_error = f'DXGI 采集失败：{type(exc).__name__}: {exc}'
                self.native_dx.close()
                self.native_dx = None
        if self.dx is not None and self.cv_np is not None:
            try:
                x, y, rw, rh = rect
                frame = self.dx.grab(region=(x, y, x + rw, y + rh), new_frame_only=False)
                if frame is not None and len(frame.shape) == 3 and frame.shape[2] == 4:
                    sy = self.cv_np.minimum(rh - 1, (self.cv_np.arange(height) * rh // height))
                    sx = self.cv_np.minimum(rw - 1, (self.cv_np.arange(width) * rw // width))
                    return self.cv_np.ascontiguousarray(frame[sy[:, None], sx[None, :]]).tobytes()
            except Exception:
                camera = self.dx
                self.dx = None
                if camera is not None:
                    try:
                        camera.stop()
                    except Exception:
                        pass
                    try:
                        camera.release()
                    except Exception:
                        pass
        desktop = self.n.user.GetDC(None)
        if not desktop:
            raise OSError('屏幕采集源不可用')
        try:
            ok = self.n.gdi.StretchBlt(dc, 0, 0, width, height, desktop, rect[0], rect[1], rect[2], rect[3], SRCCOPY | CAPTUREBLT)
            if not ok:
                raise OSError('屏幕采集失败')
            return ctypes.string_at(bits, width * height * 4)
        finally:
            self.n.user.ReleaseDC(None, desktop)

    def grab(self):
        with self.capture_lock:
            rect = self.bounds()
            return self._grab(self.base, rect), rect

    def grab_detail(self, rect, u, v):
        rw = min(rect[2], max(96, int(rect[2] * 0.38)))
        rh = min(rect[3], max(96, int(rect[3] * 0.38)))
        ox = rect[0] + max(0, min(rect[2] - rw, int(u * rect[2] - rw * 0.5)))
        oy = rect[1] + max(0, min(rect[3] - rh, int(v * rect[3] - rh * 0.5)))
        with self.capture_lock:
            return self._grab(self.detail, (ox, oy, rw, rh))

    def close(self):
        if self.native_dx is not None:
            try:
                self.native_dx.close()
            except Exception:
                pass
            self.native_dx = None
        if self.dx is not None:
            try:
                self.dx.stop()
            except Exception:
                pass
            try:
                self.dx.release()
            except Exception:
                pass
            self.dx = None
        for name in ('base', 'detail'):
            surface = getattr(self, name, None)
            if surface is None:
                continue
            dc, bitmap, previous, _, _, _ = surface
            try:
                self.n.gdi.SelectObject(dc, previous)
            finally:
                try:
                    self.n.gdi.DeleteObject(bitmap)
                finally:
                    self.n.gdi.DeleteDC(dc)
            setattr(self, name, None)


class Controller:
    def __init__(self, native, stop_vk, stopped):
        self.n = native
        self.stop_vk = stop_vk
        self.stopped = stopped
        self.down = set()
        self.mouse_down = set()
        self.successful_inputs = 0
        self.last_successful_input = None
        self.last_action_detail = None
        self.guard = None
        self.stop_gate = None
        self.releasing = False
        self.feedback_break = False
        self.interruption_reason = None
        self.monitor = None
        self.monitor_interval = 0.045
        self.touch_points = []
        self.touch_available = False
        try:
            self.n.user.InitializeTouchInjection.argtypes = [ctypes.c_uint, ctypes.c_ulong]
            self.n.user.InitializeTouchInjection.restype = ctypes.c_int
            self.n.user.InjectTouchInput.argtypes = [ctypes.c_uint, ctypes.POINTER(POINTERTOUCHINFO)]
            self.n.user.InjectTouchInput.restype = ctypes.c_int
            self.touch_available = bool(self.n.user.InitializeTouchInjection(10, 3))
        except Exception:
            self.touch_available = False

    def touch(self, locations, phase, rect):
        if not self.touch_available and phase != 'up':
            return False
        if phase == 'up' and not self.touch_points:
            return True
        if phase != 'up':
            if self.stop_gate is not None:
                self.stop_gate.poll(allow_press=True)
            if self.stopped.is_set():
                return False
            if self.guard is not None and not self.guard():
                raise OSError('触摸输入焦点不属于已绑定的游戏窗口')
        infos = (POINTERTOUCHINFO * len(locations))()
        flags = {'down': 0x10006, 'update': 0x20006, 'up': 0x40000}[phase]
        for i, (u, v) in enumerate(locations):
            x = rect[0] + round(min(1.0, max(0.0, u)) * max(0, rect[2] - 1))
            y = rect[1] + round(min(1.0, max(0.0, v)) * max(0, rect[3] - 1))
            infos[i].pointerInfo.pointerType = 2
            infos[i].pointerInfo.pointerId = i
            infos[i].pointerInfo.pointerFlags = flags
            infos[i].pointerInfo.ptPixelLocation = POINT(x, y)
            infos[i].touchMask = 7
            infos[i].rcContact = RECT(x - 3, y - 3, x + 3, y + 3)
            infos[i].orientation = 90
            infos[i].pressure = 512
        if not self.n.user.InjectTouchInput(len(locations), infos):
            if phase != 'up':
                self.touch_available = False
            raise OSError('Windows 触摸注入失败，触摸释放状态保留以便重试')
        self.touch_points = [(locations, rect)] if phase != 'up' else []
        self.successful_inputs += 1
        self.last_successful_input = time.monotonic()
        return True

    def send(self, inp):
        release_input = (inp.type == 1 and bool(inp.value.ki.dwFlags & KEYEVENTF_KEYUP)) or (inp.type == 0 and bool(inp.value.mi.dwFlags & (MOUSEEVENTF_LEFTUP | MOUSEEVENTF_RIGHTUP | MOUSEEVENTF_MIDDLEUP)))
        if inp.type == 1:
            code = int(inp.value.ki.wVk)
            scan = int(inp.value.ki.wScan)
            flags = int(inp.value.ki.dwFlags)
            if scan and not code:
                code = int(self.n.user.MapVirtualKeyW(scan | (0xE000 if flags & KEYEVENTF_EXTENDEDKEY else 0), 3))
            if stop_equivalent(physical_virtual_key(code, scan, 1 if flags & KEYEVENTF_EXTENDEDKEY else 0), self.stop_vk):
                return False
        if not self.releasing and not release_input:
            if self.stop_gate is not None:
                self.stop_gate.poll(allow_press=True)
            if self.stopped.is_set():
                return False
            if self.guard is not None and not self.guard():
                raise OSError('当前输入焦点不属于已绑定的游戏窗口')
            if self.stopped.is_set():
                return False
        sent = self.n.user.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        if sent != 1:
            code = getattr(ctypes, 'get_last_error', lambda: 0)()
            raise OSError(code, f'SendInput 失败：{sent}/1，可能受到进程权限或输入保护的阻止')
        self.successful_inputs += 1
        self.last_successful_input = time.monotonic()
        return True

    def key(self, vk, pressed):
        if stop_equivalent(vk, self.stop_vk):
            return False
        scan = self.n.user.MapVirtualKeyW(vk, 0)
        extended = vk in (33, 34, 35, 36, 37, 38, 39, 40, 45, 46, 91, 92, 93, 111, 163, 165)
        flags = (KEYEVENTF_SCANCODE if scan else 0) | (KEYEVENTF_EXTENDEDKEY if extended else 0) | (0 if pressed else KEYEVENTF_KEYUP)
        data = INPUT()
        data.type = 1
        data.value.ki = KEYBDINPUT(0 if scan else vk, scan, flags, 0, 0)
        if not self.send(data):
            return False
        if pressed:
            self.down.add(vk)
        else:
            self.down.discard(vk)
        return True

    def mouse(self, flags, wheel=0, x=0, y=0):
        data = INPUT()
        data.type = 0
        data.value.mi = MOUSEINPUT(x, y, wheel & 0xFFFFFFFF, flags, 0, 0)
        if not self.send(data):
            return False
        for bit in (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_MIDDLEDOWN):
            if flags & bit:
                self.mouse_down.add(bit)
        for down, up in ((MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP), (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP), (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP)):
            if flags & up:
                self.mouse_down.discard(down)

    def move(self, u, v, rect):
        x = rect[0] + round(min(1.0, max(0.0, u)) * max(0, rect[2] - 1))
        y = rect[1] + round(min(1.0, max(0.0, v)) * max(0, rect[3] - 1))
        sx, sy = self.n.user.GetSystemMetrics(76), self.n.user.GetSystemMetrics(77)
        sw, sh = max(1, self.n.user.GetSystemMetrics(78) - 1), max(1, self.n.user.GetSystemMetrics(79) - 1)
        px = max(0, min(65535, round((x - sx) * 65535 / sw)))
        py = max(0, min(65535, round((y - sy) * 65535 / sh)))
        self.mouse(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK, x=px, y=py)

    def delay(self, seconds):
        deadline = time.monotonic() + max(0.0, seconds)
        while not self.stopped.is_set() and not self.feedback_break:
            if self.stop_gate is not None and self.stop_gate.poll(allow_press=True):
                return False
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return True
            if self.stopped.wait(min(self.monitor_interval, remaining)):
                return False
            if self.monitor is not None:
                monitor_result = self.monitor()
                if monitor_result is not True:
                    self.feedback_break = True
                    self.interruption_reason = monitor_result if isinstance(monitor_result, str) else 'visual_change'
                    return False
        return False

    def release(self, preserve_keys=(), preserve_mouse=(), retries=4):
        keep_keys = set(preserve_keys)
        keep_mouse = set(preserve_mouse)
        mapping = {MOUSEEVENTF_LEFTDOWN: MOUSEEVENTF_LEFTUP,
                   MOUSEEVENTF_RIGHTDOWN: MOUSEEVENTF_RIGHTUP,
                   MOUSEEVENTF_MIDDLEDOWN: MOUSEEVENTF_MIDDLEUP}
        failure = None
        self.releasing = True
        try:
            for attempt in range(max(1, int(retries))):
                for vk in tuple(self.down):
                    if vk not in keep_keys:
                        try:
                            if not self.key(vk, False):
                                failure = OSError('输入释放被拒绝')
                        except Exception as exc:
                            failure = exc
                for pressed in tuple(self.mouse_down):
                    if pressed not in keep_mouse:
                        try:
                            self.mouse(mapping[pressed])
                        except Exception as exc:
                            failure = exc
                for locations, rect in tuple(self.touch_points):
                    try:
                        if not self.touch(locations, 'up', rect):
                            failure = OSError('触摸释放未成功')
                    except Exception as exc:
                        failure = exc
                pending = bool(self.down - keep_keys or self.mouse_down - keep_mouse or self.touch_points)
                if not pending:
                    return True
                if attempt + 1 < retries:
                    time.sleep(0.035)
            raise OSError('仍存在未确认释放的按键、鼠标或触摸输入') from failure
        finally:
            self.releasing = False

    def _focus_point(self, obs):
        ranked = sorted(range(GW * GH), key=lambda i: obs.salience[i] + 0.025 * (1 - abs((i % GW + 0.5) / GW - 0.5)) + random.random() * 0.065, reverse=True)
        if obs.attention_points and random.random() < 0.55:
            x, y, _ = random.choice(obs.attention_points[:min(18, len(obs.attention_points))])
            return x, y
        chosen = random.choice(ranked[:min(10, len(ranked))])
        return ((chosen % GW + random.random()) / GW, (chosen // GW + random.random()) / GH)

    def _refine_point(self, x, y, obs, stagnation):
        cx = max(0, min(GW - 1, int(x * GW)))
        cy = max(0, min(GH - 1, int(y * GH)))
        radius = 2 if stagnation >= 14 else 1
        candidates = [r * GW + c for r in range(max(0, cy - radius), min(GH, cy + radius + 1)) for c in range(max(0, cx - radius), min(GW, cx + radius + 1))]
        best = max(candidates, key=lambda i: obs.salience[i] - 0.045 * ((i % GW - cx) ** 2 + (i // GW - cy) ** 2) + random.random() * 0.012)
        strength = min(0.7, max(0.0, obs.salience[best] * 1.4))
        u = x * (1 - strength) + ((best % GW + 0.5) / GW) * strength
        v = y * (1 - strength) + ((best // GW + 0.5) / GH) * strength
        jitter = 0.012 if stagnation < 12 else 0.025
        return max(0.0, min(1.0, u + random.uniform(-jitter, jitter))), max(0.0, min(1.0, v + random.uniform(-jitter, jitter)))

    def execute(self, action, observation, rect, stagnation, parameters=None, monitor=None, feedback_delay=0.09):
        if self.stopped.is_set():
            return False
        kind, a, b, x, y = action.kind, action.a, action.b, action.x, action.y
        requested_duration = parameters[2] if parameters is not None else action.duration
        extent = max(0.5, min(1.5, float(parameters[3]))) if parameters is not None and len(parameters) > 3 else 1.0
        tempo = max(0.42, min(1.30, 0.11 / max(0.035, feedback_delay)))
        if kind not in ('hold', 'pair_hold', 'move_fire', 'combat', 'aim', 'look', 'key', 'chord', 'swipe', 'right_swipe', 'touch_swipe'):
            tempo = 1.0
        activity = max(0.55, 1.0 - min(0.40, observation.change * 0.75))
        requested_duration = float(requested_duration)
        if not math.isfinite(requested_duration) or requested_duration < 0.0:
            requested_duration = action.duration
        duration = max(0.025, requested_duration * tempo * activity * (1.0 + min(18, stagnation) / 25.0))
        self.monitor = monitor
        self.monitor_interval = min(0.065, max(0.012, feedback_delay * (0.24 if kind in ('combat', 'aim', 'look') else 0.46)))
        self.feedback_break = False
        self.interruption_reason = None
        initial_x, initial_y = x, y
        self.last_action_detail = None
        emitted_before = self.successful_inputs
        emitted_during_action = 0
        planned_wait = 0.0
        actual_wait = 0.0
        finished = False
        primary_input_sent = False
        down_was_held = kind == 'hold' and a in self.down
        def pause(seconds):
            nonlocal planned_wait, actual_wait
            seconds = max(0.0, float(seconds))
            planned_wait += seconds
            start = time.monotonic()
            result = self.delay(seconds)
            actual_wait += min(seconds, time.monotonic() - start)
            return result
        def glide(x0, y0, x1, y1, seconds):
            distance = math.hypot((x1 - x0) * rect[2], (y1 - y0) * rect[3])
            frames = max(4, min(48, int(max(distance / 15.0, seconds / 0.018))))
            for j in range(1, frames + 1):
                if self.stopped.is_set() or self.feedback_break:
                    return False
                fraction = j / frames
                eased = fraction * fraction * (3.0 - 2.0 * fraction)
                self.move(x0 + (x1 - x0) * eased, y0 + (y1 - y0) * eased, rect)
                if not pause(seconds / frames):
                    return False
            return True
        try:
            self.release(preserve_keys=(a,) if kind == 'hold' else ())
            emitted_before = self.successful_inputs
            if kind in ('key', 'hold'):
                if down_was_held or self.key(a, True):
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind == 'chord':
                if self.key(a, True) and self.key(b, True):
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind == 'pair_hold':
                if self.key(a, True) and self.key(b, True):
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind == 'move_fire':
                if self.key(a, True):
                    self.mouse(MOUSEEVENTF_LEFTDOWN)
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press'):
                if parameters is not None:
                    x, y = self._refine_point(parameters[0], parameters[1], observation, stagnation)
                elif kind.startswith('focus_') or kind == 'press':
                    x, y = self._focus_point(observation)
                else:
                    x, y = self._refine_point(x, y, observation, stagnation)
                initial_x, initial_y = x, y
                self.move(x, y, rect)
                if pause(0.016):
                    if kind in ('right', 'focus_right'):
                        down, up = MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP
                    elif kind == 'middle':
                        down, up = MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP
                    else:
                        down, up = MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP
                    finished = True
                    for _ in range(2 if kind in ('double', 'focus_double') else 1):
                        if self.stopped.is_set() or self.feedback_break:
                            finished = False
                            break
                        self.mouse(down)
                        primary_input_sent = True
                        held = pause(duration if kind == 'press' else max(0.028, min(0.14, duration * 0.36)))
                        self.mouse(up)
                        if not held or not pause(0.045):
                            finished = False
                            break
            elif kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch'):
                x, y = parameters[:2] if parameters is not None else self._focus_point(observation)
                x, y = self._refine_point(x, y, observation, stagnation)
                initial_x, initial_y = x, y
                if self.touch_available:
                    if kind == 'dual_touch':
                        x, y = min(0.42, max(0.08, x)), min(0.93, max(0.55, y))
                        positions = [(x, y), (0.82, 0.74)]
                    else:
                        positions = [(max(0.02, x - 0.14), y), (min(0.98, x + 0.14), y)] if kind == 'pinch' else [(x, y)]
                    finished = self.touch(positions, 'down', rect)
                    primary_input_sent = bool(finished)
                    frames = max(6, min(40, int(duration / 0.024))) if kind != 'touch_tap' else 1
                    for j in range(frames):
                        if self.stopped.is_set() or self.feedback_break or not finished:
                            finished = False
                            break
                        if kind == 'pinch':
                            offset = 0.14 + (j + 1) * a * 0.018 * extent
                            positions = [(max(0.02, x - offset), y), (min(0.98, x + offset), y)]
                        elif kind == 'touch_swipe':
                            positions = [(max(0.02, min(0.98, x + a * (j + 1) * 0.045 * extent)), max(0.02, min(0.98, y + b * (j + 1) * 0.045 * extent)))]
                        elif kind == 'dual_touch':
                            phase = (j + 1) / frames
                            positions = [(max(0.08, min(0.45, x + a * 0.13 * extent * phase)),
                                          max(0.55, min(0.94, y + b * 0.13 * extent * phase))),
                                         (max(0.64, min(0.96, 0.82 + a * 0.10 * extent * phase)),
                                          max(0.55, min(0.94, 0.74 + b * 0.10 * extent * phase)))]
                        if not self.touch(positions, 'update', rect) or not pause(duration / frames):
                            finished = False
                            break
                    self.touch(positions, 'up', rect)
                else:
                    self.move(x, y, rect)
                    self.mouse(MOUSEEVENTF_LEFTDOWN)
                    primary_input_sent = True
                    finished = True
                    if kind in ('touch_swipe', 'dual_touch'):
                        finished = glide(x, y, x + a * 0.36 * extent, y + b * 0.36 * extent, duration)
                    elif kind == 'pinch':
                        finished = pause(0.06)
                        if finished:
                            self.mouse(MOUSEEVENTF_WHEEL, (1 if a > 0 else -1) * 120)
                    else:
                        finished = pause(duration)
                    self.mouse(MOUSEEVENTF_LEFTUP)
            elif kind == 'move':
                x, y = parameters[:2] if parameters is not None else self._focus_point(observation)
                x, y = self._refine_point(x, y, observation, stagnation)
                initial_x, initial_y = x, y
                self.move(x, y, rect)
                primary_input_sent = True
                finished = pause(max(0.02, min(0.18, duration * 0.30)))
            elif kind in ('swipe', 'right_swipe'):
                x, y = parameters[:2] if parameters is not None else self._focus_point(observation)
                dx = a * extent * min(0.5, 0.25 + stagnation * 0.008)
                dy = b * extent * min(0.5, 0.25 + stagnation * 0.008)
                x, y = min(1.0, max(0.0, x - dx * 0.5)), min(1.0, max(0.0, y - dy * 0.5))
                initial_x, initial_y = x, y
                self.move(x, y, rect)
                self.mouse(MOUSEEVENTF_RIGHTDOWN if kind == 'right_swipe' else MOUSEEVENTF_LEFTDOWN)
                primary_input_sent = True
                finished = True
                target_x, target_y = min(1.0, max(0.0, x + dx)), min(1.0, max(0.0, y + dy))
                finished = glide(x, y, target_x, target_y, duration)
                x, y = target_x, target_y
            elif kind == 'look':
                finished = True
                for _ in range(8):
                    if self.stopped.is_set() or self.feedback_break:
                        finished = False
                        break
                    self.mouse(MOUSEEVENTF_MOVE, x=int(a * extent * max(2, rect[2] * 0.01)), y=int(b * extent * max(2, rect[3] * 0.01)))
                    primary_input_sent = True
                    if not pause(duration / 8):
                        finished = False
                        break
            elif kind == 'wheel':
                self.mouse(MOUSEEVENTF_WHEEL, a * 120)
                primary_input_sent = True
                finished = pause(0.05)
            elif kind in ('combat', 'aim'):
                if not a or self.key(a, True):
                    self.mouse(MOUSEEVENTF_LEFTDOWN)
                    primary_input_sent = True
                    finished = pause(duration * 0.45)
                    if finished and kind == 'aim':
                        for j in range(3):
                            if self.stopped.is_set() or self.feedback_break:
                                finished = False
                                break
                            self.mouse(MOUSEEVENTF_MOVE, x=int(b * 8 * extent), y=int((j - 1) * 5 * extent))
                            if not pause(duration * 0.12):
                                finished = False
                                break
                    elif finished:
                        finished = pause(duration * 0.55)
        finally:
            emitted_during_action = self.successful_inputs - emitted_before
            self.monitor = None
            if kind == 'hold' and finished and not self.stopped.is_set() and not self.feedback_break:
                self.release(preserve_keys=(a,))
            else:
                self.release()
            emitted = emitted_during_action + int(down_was_held)
            interrupted = bool(self.stopped.is_set() or self.feedback_break or not finished)
            if emitted > 0 and primary_input_sent:
                self.last_action_detail = {
                    'kind': kind, 'a': int(a), 'b': int(b), 'x': float(x), 'y': float(y),
                    'start_x': float(initial_x), 'start_y': float(initial_y),
                    'duration': float(actual_wait), 'requested_duration': float(requested_duration), 'extent': float(extent),
                    'scheduled_duration': float(duration),
                    'completion_ratio': (max(0.0, min(1.0 if finished else 0.85, actual_wait / planned_wait)) if planned_wait else (1.0 if finished else 0.0)),
                    'interrupted': interrupted, 'finished': bool(finished and not interrupted),
                    'interruption_reason': 'stop_key' if self.stopped.is_set() else self.interruption_reason if self.feedback_break else 'incomplete_action' if not finished else None,
                    'input_sent': True, 'sent_events': int(emitted),
                    'emulated_touch': bool(kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch') and not self.touch_available),
                    'actual_touch_points': (2 if kind in ('pinch', 'dual_touch') else 1) if self.touch_available and kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch') else 0,
                    'spatial': kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch'),
                }
        return bool(self.last_action_detail and not self.stopped.is_set())

class Action:
    __slots__ = ('id', 'kind', 'a', 'b', 'x', 'y', 'prior', 'duration', 'category')

    def __init__(self, id, kind, a=0, b=0, x=0.0, y=0.0, prior=1.0, duration=0.15, category='explore'):
        self.id, self.kind, self.a, self.b = id, kind, a, b
        self.x, self.y, self.prior, self.duration, self.category = x, y, prior, duration, category


def actions_for(stop_vk):
    common = {ord(c) for c in 'WASDQERFGTZXCVBIJKLNM1234567890'} | {13, 9, 32, 37, 38, 39, 40, 16, 17, 18, 27, 8}
    actions = []
    for vk in range(8, 255):
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'key:{vk}', 'key', a=vk, prior=4.5 if vk in common else 0.025, duration=0.11, category='interact'))
    for vk in list(map(ord, 'WASDQERFGTZXCVBIJKLNM1234567890')) + [32, 37, 38, 39, 40, 16, 17, 18, 9, 13, 8]:
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'hold:{vk}', 'hold', a=vk, prior=3.1 if vk in (87, 65, 83, 68) else 1.0, duration=0.35, category='navigate'))
    for modifier in (16, 17, 18):
        if stop_equivalent(modifier, stop_vk):
            continue
        for vk in list(map(ord, 'WASDQERFGTZXCVBIJKLNM1234567890')) + [32, 37, 38, 39, 40, 9, 13]:
            if not stop_equivalent(vk, stop_vk):
                actions.append(Action(f'chord:{modifier}:{vk}', 'chord', a=modifier, b=vk, prior=0.9, duration=0.2, category='combat'))
    for first, second in ((87, 65), (87, 68), (83, 65), (83, 68), (38, 37), (38, 39), (40, 37), (40, 39)):
        if not stop_equivalent(first, stop_vk) and not stop_equivalent(second, stop_vk):
            actions.append(Action(f'pair_hold:{first}:{second}', 'pair_hold', a=first, b=second, prior=1.15, duration=0.42, category='navigate'))
    for vk in (87, 65, 83, 68, 32):
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'move_fire:{vk}', 'move_fire', a=vk, prior=1.2, duration=0.38, category='combat'))
    for kind, prior in (('click', 4.0), ('right', 1.3), ('double', 1.5), ('move', 0.8), ('middle', 0.4), ('focus_click', 2.0), ('focus_right', 0.8), ('focus_double', 0.9), ('press', 1.5)):
        actions.append(Action(kind, kind, x=0.5, y=0.5, prior=prior, duration=0.48 if kind == 'press' else 0.15, category='interact'))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)):
        for kind, prior in (('swipe', 1.4), ('right_swipe', 0.6), ('look', 1.5)):
            actions.append(Action(f'{kind}:{dx}:{dy}', kind, a=dx, b=dy, prior=prior, duration=0.25, category='navigate'))
    actions.append(Action('touch_tap', 'touch_tap', prior=1.4, duration=0.09, category='interact'))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        actions.append(Action(f'touch_swipe:{dx}:{dy}', 'touch_swipe', a=dx, b=dy, prior=0.8, duration=0.45, category='navigate'))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)):
        actions.append(Action(f'dual_touch:{dx}:{dy}', 'dual_touch', a=dx, b=dy, prior=0.85, duration=0.45, category='combat'))
    for direction in (-1, 1):
        actions.append(Action(f'pinch:{direction}', 'pinch', a=direction, prior=0.35, duration=0.5, category='navigate'))
        actions.append(Action(f'wheel:{direction}', 'wheel', a=direction, prior=1.1, category='interact'))
    for vk in (87, 65, 83, 68, 32, 0):
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'combat:{vk}', 'combat', a=vk, prior=1.1, duration=0.45, category='combat'))
    for dx in (-1, 1):
        actions.append(Action(f'aim:{dx}', 'aim', b=dx, prior=1.0, duration=0.32, category='combat'))
    return actions


class Observation:
    __slots__ = ('lum', 'rgb', 'salience', 'motion', 'edges', 'features', 'signature', 'change', 'novelty', 'rect', 'raw', 'hud', 'game', 'valid', 'quality', 'frame_uid', 'region_signals', 'scene_key', 'attention_points', 'hud_readouts', 'ui_text', 'ui_numbers', 'hud_meters')

    def __init__(self, lum, rgb, salience, motion, edges, features, signature, change, novelty, rect, raw, hud, game, valid=True, quality=None):
        self.lum, self.rgb, self.salience, self.motion, self.edges = lum, rgb, salience, motion, edges
        self.valid = valid
        self.quality = quality or {}
        self.features, self.signature, self.change, self.novelty = features, signature, change, novelty
        self.rect, self.raw, self.hud, self.game = rect, raw, hud, game
        self.frame_uid = uuid.uuid4().hex
        self.region_signals = []
        self.scene_key = game
        self.attention_points = []
        self.hud_readouts = []
        self.ui_text = []
        self.ui_numbers = []
        self.hud_meters = {}



def quarantine_corrupt_store(folder, failure):
    words = ('malformed', 'not a database', '完整性检查失败', 'database disk image', 'file is not a database')
    if not isinstance(failure, sqlite3.DatabaseError) or not any(word in str(failure).lower() for word in words):
        return False
    stamp = str(time.time_ns())
    moved = False
    for suffix in ('', '-wal', '-shm'):
        source = folder / ('experience.sqlite3' + suffix)
        if source.exists():
            source.replace(folder / ('experience.sqlite3' + suffix + '.corrupt.' + stamp))
            moved = True
    return moved


class ReplayStore:
    def __init__(self, folder):
        self.db = sqlite3.connect(str(folder / 'experience.sqlite3'), timeout=12)
        try:
            self.db.execute('PRAGMA journal_mode=WAL')
            self.db.execute('PRAGMA synchronous=FULL')
            integrity = self.db.execute('PRAGMA quick_check(1)').fetchone()
            if not integrity or integrity[0] != 'ok':
                raise sqlite3.DatabaseError('数据库完整性检查失败')
            self.db.execute("CREATE TABLE IF NOT EXISTS transitions (id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL, game TEXT NOT NULL, action TEXT NOT NULL, reward REAL NOT NULL, before BLOB NOT NULL, after BLOB NOT NULL, change REAL NOT NULL, done INTEGER NOT NULL DEFAULT 0, horizon INTEGER NOT NULL DEFAULT 1, priority REAL NOT NULL DEFAULT 0.1, confidence REAL NOT NULL DEFAULT 0, action_detail TEXT NOT NULL DEFAULT '{}', uid TEXT NOT NULL UNIQUE)")
            present = {column[1] for column in self.db.execute('PRAGMA table_info(transitions)')}
            for name, column_type, default in (('done', 'INTEGER', '0'), ('horizon', 'INTEGER', '1'), ('priority', 'REAL', '0.1'), ('confidence', 'REAL', '0'), ('action_detail', 'TEXT', "'{}'")):
                if name not in present:
                    self.db.execute(f'ALTER TABLE transitions ADD COLUMN {name} {column_type} NOT NULL DEFAULT {default}')
            if 'uid' not in present:
                self.db.execute('ALTER TABLE transitions ADD COLUMN uid TEXT')
                previous_ids = self.db.execute('SELECT id FROM transitions').fetchall()
                if previous_ids:
                    self.db.executemany('UPDATE transitions SET uid=? WHERE id=?', ((uuid.uuid4().hex, entry[0]) for entry in previous_ids))
            self.db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_transitions_uid ON transitions(uid)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_transitions_game ON transitions(game, id)')
            self.db.execute('CREATE TABLE IF NOT EXISTS keyframes (id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL, game TEXT NOT NULL, step INTEGER NOT NULL, action TEXT NOT NULL, signature TEXT NOT NULL, valid INTEGER NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL, frame BLOB NOT NULL)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_frames_game_step ON keyframes(game, step)')
            if 'uid' not in {col[1] for col in self.db.execute('PRAGMA table_info(keyframes)')}:
                self.db.execute('ALTER TABLE keyframes ADD COLUMN uid TEXT')
            self.db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_keyframes_uid ON keyframes(uid)')
            self.db.execute('CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, started REAL NOT NULL, python TEXT NOT NULL)')
            for table in ('transitions', 'keyframes'):
                for (identity,) in self.db.execute(f'SELECT DISTINCT game FROM {table}').fetchall():
                    normalized = canonical_game_key(identity)
                    if normalized != identity:
                        self.db.execute(f'UPDATE {table} SET game=? WHERE game=?', (normalized, identity))
            self.db.execute('INSERT INTO sessions(started,python) VALUES (?,?)', (time.time(), sys.version.split()[0]))
            self.db.commit()
            self.pending = 0
            self.last_commit = time.monotonic()
            self.frame_step = {}
            self.frames_saved = 0
            self.start_frame_count = int(self.db.execute('SELECT COUNT(*) FROM keyframes').fetchone()[0])
            self.total_transitions = int(self.db.execute('SELECT COUNT(*) FROM transitions').fetchone()[0])
            self.first_commit_verified = self.total_transitions > 0
        except Exception:
            self.db.close()
            raise

    @staticmethod
    def pack(values):
        if len(values) != FEATURE_COUNT:
            raise ValueError('经验样本特征长度不正确')
        return struct.pack('<' + 'f' * FEATURE_COUNT, *values)

    @staticmethod
    def unpack(raw):
        if len(raw) not in (LEGACY_FEATURE_COUNT * 4, FEATURE_COUNT * 4):
            raise ValueError('经验样本特征长度不正确')
        count = len(raw) // 4
        values = list(struct.unpack('<' + 'f' * count, raw))
        return values + [0.0] * (FEATURE_COUNT - count)

    def verify_roundtrip(self):
        before = [float(i % 13) / 13.0 for i in range(FEATURE_COUNT)]
        after = [float((i + 1) % 13) / 13.0 for i in range(FEATURE_COUNT)]
        marker = 'preflight:' + hashlib.sha256(os.urandom(16)).hexdigest()
        self.db.execute('SAVEPOINT agent_verify')
        try:
            self.db.execute('INSERT INTO transitions(at,game,action,reward,before,after,change,done,horizon,priority,confidence,action_detail,uid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)', (time.time(), marker, 'preflight', 0.1, sqlite3.Binary(self.pack(before)), sqlite3.Binary(self.pack(after)), 0.01, 0, 1, 0.1, 1.0, '{}', uuid.uuid4().hex))
            row = self.db.execute('SELECT before,after,action_detail FROM transitions WHERE game=? ORDER BY id DESC LIMIT 1', (marker,)).fetchone()
            if row is None or bytes(row[0]) != self.pack(before) or bytes(row[1]) != self.pack(after) or row[2] != '{}':
                raise sqlite3.DatabaseError('经验库写入及回读验证失败')
        finally:
            self.db.execute('ROLLBACK TO agent_verify')
            self.db.execute('RELEASE agent_verify')
        if self.db.execute('SELECT COUNT(*) FROM transitions WHERE game=?', (marker,)).fetchone()[0]:
            raise sqlite3.DatabaseError('经验库测试事务回滚失败')
        return True

    def add_many(self, rows):
        if not rows:
            return 0
        timestamp = time.time()
        entries = []
        for row in rows:
            game, action, reward, before, after, change, done, horizon, priority, confidence = row[:10]
            detail = row[10].copy() if len(row) > 10 and isinstance(row[10], dict) else {}
            uid = detail.get('uid')
            if not isinstance(uid, str) or not (12 <= len(uid) <= 80):
                uid = uuid.uuid4().hex
                detail['uid'] = uid
            encoded = json.dumps(detail, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            entries.append((timestamp, canonical_game_key(game), action, float(reward), sqlite3.Binary(self.pack(before)), sqlite3.Binary(self.pack(after)), float(change), int(done), int(horizon), max(0.01, float(priority)), max(0.0, min(1.0, float(confidence))), encoded, uid))
        try:
            cursor = self.db.executemany('INSERT INTO transitions(at,game,action,reward,before,after,change,done,horizon,priority,confidence,action_detail,uid) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO NOTHING', entries)
            inserted = cursor.rowcount
            if inserted < 0 or inserted > len(entries):
                raise sqlite3.DatabaseError('经验批量写入结果异常')
            if not self.first_commit_verified and inserted:
                verified = False
                for expected in reversed(entries):
                    sample = self.db.execute('SELECT action,before,after,action_detail FROM transitions WHERE uid=?', (expected[12],)).fetchone()
                    if (sample is not None and sample[0] == expected[2] and bytes(sample[1]) == bytes(expected[4])
                            and bytes(sample[2]) == bytes(expected[5]) and sample[3] == expected[11]):
                        verified = True
                        break
                if not verified:
                    raise sqlite3.DatabaseError('首次经验写入后回读校验失败')
            self.db.commit()
            if inserted:
                self.first_commit_verified = True
        except Exception:
            self.db.rollback()
            raise
        self.total_transitions += inserted
        self.pending = 0
        self.last_commit = time.monotonic()
        return inserted

    def frame(self, game, step, action, obs, force=False):
        last = self.frame_step.get(game, -10000)
        if not force and step - last < (8 if obs.novelty > 0.9 else 28):
            return False
        if obs.raw is None or len(obs.raw) != W * H * 4:
            return False
        compressed = zlib.compress(obs.raw, 4)
        uid = str(getattr(obs, 'frame_uid', '')) or hashlib.sha256(compressed + str(game).encode() + str(step).encode() + str(action).encode()).hexdigest()
        result = self.db.execute('INSERT INTO keyframes(at,game,step,action,signature,valid,width,height,frame,uid) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO NOTHING', (time.time(), canonical_game_key(game), int(step), action, obs.signature, int(obs.valid), W, H, sqlite3.Binary(compressed), uid))
        self.frame_step[game] = step
        if result.rowcount:
            self.frames_saved += 1
            self.pending += 1
        return bool(result.rowcount)

    def recent(self, indices, limit=1000):
        limit = max(1, min(10000, int(limit)))
        take_latest = max(1, int(limit * 0.82))
        rows = self.db.execute('SELECT game,action,reward,before,after,priority,done,horizon,confidence,action_detail FROM transitions ORDER BY id DESC LIMIT ?', (take_latest,)).fetchall()
        if self.total_transitions > take_latest:
            max_id = int(self.db.execute('SELECT COALESCE(MAX(id),0) FROM transitions').fetchone()[0])
            for _ in range(min(limit - take_latest, 320)):
                location = random.randint(1, max_id)
                row = self.db.execute('SELECT game,action,reward,before,after,priority,done,horizon,confidence,action_detail FROM transitions WHERE id>=? ORDER BY id LIMIT 1', (location,)).fetchone()
                if row is not None:
                    rows.append(row)
        output = []
        for game, action, reward, before, after, priority, done, horizon, confidence, detail in reversed(rows):
            if action not in indices:
                continue
            try:
                params = json.loads(detail) if detail else {}
                if not isinstance(params, dict):
                    params = {}
                output.append([canonical_game_key(game), self.unpack(before), indices[action], float(reward), self.unpack(after), max(0.02, float(priority)), bool(done), max(1, int(horizon)), max(0.0, min(1.0, float(confidence))), params])
            except (ValueError, struct.error, TypeError, json.JSONDecodeError):
                continue
        return output

    def mark_terminal_uid(self, uid):
        result = self.db.execute('UPDATE transitions SET done=1 WHERE uid=? AND horizon=1', (uid,))
        self.db.commit()
        self.last_commit = time.monotonic()
        self.pending = 0
        return result.rowcount > 0

    def flush(self):
        if self.pending:
            self.db.commit()
            self.pending = 0
            self.last_commit = time.monotonic()

    def close(self):
        try:
            self.flush()
        finally:
            self.db.close()



class GameData:
    def __init__(self, count, hidden, np_module):
        self.np = np_module
        scale = 0.03 / math.sqrt(hidden)
        if self.np is not None:
            self.q = self.np.asarray([[random.uniform(-scale, scale) for _ in range(hidden)] for _ in range(count)], dtype=self.np.float32)
            self.bias = self.np.zeros(count, dtype=self.np.float32)
        else:
            self.q = [[random.uniform(-scale, scale) for _ in range(hidden)] for _ in range(count)]
            self.bias = [0.0] * count
        self.counts = [0] * count
        self.action_effect = [0.0] * count
        self.action_effect_samples = [0] * count
        self.visits = OrderedDict()
        self.scene_centers = OrderedDict()
        self.world = OrderedDict()
        self.targets = OrderedDict()
        self.candidate_events = OrderedDict()
        self.skills = {}
        self.trajectories = OrderedDict()
        self.recent = deque(maxlen=6)
        self.exemplars = deque(maxlen=48)
        self.game_steps = 0
        self.total_reward = 0.0
        self.baseline_change = 0.0
        self.passive_change = 0.0
        self.passive_samples = 0
        self.stagnation = 0
        self.category_score = {}
        self.family_score = {}
        self.feedback_delay = 0.09
        self.parameter_stats = OrderedDict()
        self.duration_stats = {}
        self.parameter_heads = {}
        self.goal_landmarks = OrderedDict()
        self.hud_trends = OrderedDict()
        self.goal_evidence = deque(maxlen=24)
        self.screen_outcomes = {'win': 0, 'loss': 0, 'task': 0}
        self.plan_success = [0, 0]
        self.result_streak = 0
        self.result_label = None
        self.result_scene = None
        self.result_active = False
        self.result_misses = 0
        self.result_appeared = False
        self.result_position = None
        self.numeric_recent = deque(maxlen=24)
        self.confirmed_results = OrderedDict()
        self.focus_recent = deque(maxlen=14)
        self.scene_history = deque(maxlen=18)
        self.target_q = self.q.copy() if self.np is not None else [row[:] for row in self.q]
        self.target_bias = self.bias.copy() if self.np is not None else self.bias[:]

    def ensure_parameter_head(self, kind, hidden):
        if kind not in self.parameter_heads:
            if self.np is not None:
                weights = self.np.zeros((4, hidden), dtype=self.np.float32)
                bias = self.np.zeros(4, dtype=self.np.float32)
            else:
                weights = [[0.0] * hidden for _ in range(4)]
                bias = [0.0] * 4
            self.parameter_heads[kind] = {'w': weights, 'b': bias, 'samples': 0}
        return self.parameter_heads[kind]

    def sync_target(self):
        self.target_q = self.q.copy() if self.np is not None else [row[:] for row in self.q]
        self.target_bias = self.bias.copy() if self.np is not None else self.bias[:]

    def merge(self, other):
        self_steps = self.game_steps
        other_steps = other.game_steps
        for i in range(len(self.counts)):
            left, right = self.counts[i], other.counts[i]
            if right > 0:
                if left > 0:
                    blend = right / (left + right)
                    self.q[i] = self.q[i] * (1.0 - blend) + other.q[i] * blend if self.np is not None else [a * (1.0 - blend) + b * blend for a, b in zip(self.q[i], other.q[i])]
                    self.bias[i] = self.bias[i] * (1.0 - blend) + other.bias[i] * blend
                else:
                    self.q[i] = other.q[i].copy() if self.np is not None else other.q[i][:]
                    self.bias[i] = other.bias[i]
                self.counts[i] += right
            left_effect, right_effect = self.action_effect_samples[i], other.action_effect_samples[i]
            if right_effect:
                self.action_effect[i] = (self.action_effect[i] * left_effect + other.action_effect[i] * right_effect) / (left_effect + right_effect)
                self.action_effect_samples[i] += right_effect
        for name, limit in (('visits', 15000), ('trajectories', 12000)):
            a, b = getattr(self, name), getattr(other, name)
            for key, value in b.items():
                a[key] = a.get(key, 0) + value
                a.move_to_end(key)
            while len(a) > limit:
                a.popitem(last=False)
        for name, limit in (('scene_centers', 2400), ('world', 12500), ('targets', 720), ('candidate_events', 350), ('goal_landmarks', 800), ('hud_trends', 160), ('parameter_stats', 3200)):
            a, b = getattr(self, name), getattr(other, name)
            for key, value in b.items():
                if key not in a:
                    a[key] = value
                    a.move_to_end(key)
            while len(a) > limit:
                a.popitem(last=False)
        for name in ('category_score', 'family_score', 'duration_stats'):
            a = getattr(self, name)
            for key, value in getattr(other, name).items():
                if key in a:
                    total = max(1, a[key][0] + value[0]) if name != 'duration_stats' else max(1, a[key][1] + value[1])
                    if name == 'duration_stats':
                        a[key] = [(a[key][0] * a[key][1] + value[0] * value[1]) / total, total]
                    else:
                        a[key] = [total, (a[key][1] * a[key][0] + value[1] * value[0]) / total]
                else:
                    a[key] = value
        for kind, source in other.parameter_heads.items():
            destination = self.parameter_heads.get(kind)
            if destination is None:
                self.parameter_heads[kind] = {
                    'w': source['w'].copy() if self.np is not None else [row[:] for row in source['w']],
                    'b': source['b'].copy() if self.np is not None else source['b'][:],
                    'samples': int(source.get('samples', 0)),
                }
            else:
                old_count, add_count = int(destination.get('samples', 0)), int(source.get('samples', 0))
                if add_count:
                    factor = add_count / max(1, old_count + add_count)
                    if self.np is not None:
                        destination['w'] = destination['w'] * (1.0 - factor) + source['w'] * factor
                        destination['b'] = destination['b'] * (1.0 - factor) + source['b'] * factor
                    else:
                        destination['w'] = [[a * (1.0 - factor) + b * factor for a, b in zip(row, other_row)] for row, other_row in zip(destination['w'], source['w'])]
                        destination['b'] = [a * (1.0 - factor) + b * factor for a, b in zip(destination['b'], source['b'])]
                    destination['samples'] = old_count + add_count
        for key, value in other.skills.items():
            if key not in self.skills or float(value.get('quality', 0.0)) > float(self.skills[key].get('quality', 0.0)):
                self.skills[key] = value
        for exemplar in other.exemplars:
            sample = exemplar[:]
            sample[0] = canonical_game_key(sample[0])
            self.exemplars.append(sample)
        self.game_steps += other_steps
        self.total_reward += other.total_reward
        weighted = max(1, self_steps + other_steps)
        for name in ('baseline_change', 'passive_change', 'feedback_delay'):
            setattr(self, name, (getattr(self, name) * self_steps + getattr(other, name) * other_steps) / weighted)
        self.passive_samples += other.passive_samples
        self.stagnation = min(self.stagnation, other.stagnation)
        self.plan_success = [a + b for a, b in zip(self.plan_success, other.plan_success)]
        for outcome in self.screen_outcomes:
            self.screen_outcomes[outcome] += other.screen_outcomes.get(outcome, 0)
        for key, result in other.confirmed_results.items():
            self.confirmed_results[key] = result
        while len(self.confirmed_results) > 96:
            self.confirmed_results.popitem(last=False)
        self.sync_target()

    def export(self):
        return {
            'q': self.q.tolist() if self.np is not None else self.q,
            'bias': self.bias.tolist() if self.np is not None else self.bias,
            'counts': self.counts,
            'action_effect': self.action_effect,
            'action_effect_samples': self.action_effect_samples,
            'visits': list(self.visits.items()),
            'scene_centers': list(self.scene_centers.items()),
            'world': {str(k): v for k, v in self.world.items()},
            'targets': dict(self.targets),
            'candidate_events': dict(self.candidate_events),
            'skills': self.skills,
            'exemplars': list(self.exemplars),
            'trajectories': list(self.trajectories.items())[-5000:],
            'game_steps': self.game_steps,
            'total_reward': self.total_reward,
            'baseline_change': self.baseline_change,
            'passive_change': self.passive_change,
            'passive_samples': self.passive_samples,
            'stagnation': self.stagnation,
            'category_score': self.category_score,
            'family_score': self.family_score,
            'feedback_delay': self.feedback_delay,
            'parameter_stats': list(self.parameter_stats.items()),
            'duration_stats': self.duration_stats,
            'parameter_heads': {kind: {'w': head['w'].tolist() if self.np is not None else head['w'],
                                       'b': head['b'].tolist() if self.np is not None else head['b'],
                                       'samples': head['samples']} for kind, head in self.parameter_heads.items()},
            'goal_landmarks': list(self.goal_landmarks.items())[-800:],
            'hud_trends': list(self.hud_trends.items())[-160:],
            'plan_success': self.plan_success,
            'screen_outcomes': self.screen_outcomes,
            'confirmed_results': list(self.confirmed_results.items())[-96:],
            'result_active': self.result_active,
        }


class Brain:

    def __init__(self, folder, stop_vk, numpy_module):
        self.folder = folder
        self.stop_vk = stop_vk
        self.np = numpy_module
        self.cv_np = importlib.import_module('numpy') if numpy_module is not None and getattr(numpy_module, '__name__', '') == 'cupy' else numpy_module
        self.actions = actions_for(stop_vk)
        try:
            self.local_glyphs = LocalGlyphTemplates()
        except Exception:
            self.local_glyphs = None
        self.action_index = {a.id: i for i, a in enumerate(self.actions)}
        self.priors = [a.prior for a in self.actions]
        self.action_groups = {}
        self.action_families = {}
        self.action_kinds = {}
        self.family_for_action = []
        for i, action in enumerate(self.actions):
            self.action_groups.setdefault(action.category, []).append(i)
            family = ('keyboard' if action.kind in ('key', 'hold', 'pair_hold', 'chord') else
                      'pointer' if action.kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'touch_tap') else
                      'navigation' if action.kind in ('move', 'swipe', 'right_swipe', 'look', 'wheel', 'touch_swipe', 'pinch', 'dual_touch') else 'combat')
            self.family_for_action.append(family)
            self.action_families.setdefault(family, []).append(i)
            self.action_kinds.setdefault((family, action.kind), []).append(i)
        self.action_kinds_for_parameter = {action.kind for action in self.actions}
        self.hidden_size = MODEL_HIDDEN_SIZE
        self.rng = random.Random()
        self.encoder = [[self.rng.uniform(-0.035, 0.035) for _ in range(FEATURE_COUNT)] for _ in range(self.hidden_size)]
        self.encoder_bias = [0.0] * self.hidden_size
        if self.np is not None:
            self.encoder = self.np.asarray(self.encoder, dtype=self.np.float32)
            self.encoder_bias = self.np.zeros(self.hidden_size, dtype=self.np.float32)
        self.target_encoder = None
        self.target_encoder_bias = None
        self.games = {}
        self.game_key = 'desktop'
        self.last_skill_source = None
        self.last_plan_parameters = []
        self.last_plan_predictions = []
        self.visual_routes = {}
        self.visual_active_base = None
        self.visual_active_key = None
        self.visual_candidate = None
        self.visual_candidate_vector = None
        self.visual_candidate_count = 0
        self.visual_candidate_diversity = 0
        self.last_attention_tracks = []
        self.previous_lum = None
        self.previous_motion = None
        self.temporal_luma = deque(maxlen=4)
        self.last_change = 0.0
        self.last_frame = None
        self.last_detail = [0.0] * 24
        self.last_detail_focus = (0.5, 0.5)
        self.checkpoint_verified = False
        self.checkpoint_migrated = False
        self.checkpoint_serial = 0
        self.last_checkpoint_summary = {}
        self.checkpoint_compressed_bytes = 0
        self.delta_base_step = None
        self.dirty_games = set()
        self.dirty_sequence = 0
        self.store_roundtrip_verified = False
        self.db_preflight_verified = False
        self.step = 0
        self.backend_generation = 0
        self.backend_recoveries = 0
        self.updates = 0
        self.td_error_ema = 0.0
        self.total_reward = 0.0
        self.last_save = 0.0
        self.keyframes_this_session = 0
        self.valid_transitions = 0
        self.low_information_observations = 0
        self.invalid_observations = 0
        self.persisted_transitions = 0
        self.dropped_unpersisted = 0
        self.spilled_transitions = 0
        self.spool_recovered = 0
        self.journaled_transitions = 0
        self.journal_failures = 0
        self.journal_unwritten = OrderedDict()
        self.spool_path = self.folder / 'experience_overflow.jsonl'
        self.persist_backlog = deque()
        self.frame_backlog = deque()
        self.terminal_updates = deque()
        self.initial_frames = OrderedDict()
        self.initial_frame_games = set()
        self.persist_last_batch = time.monotonic()
        self.store_reconnect_at = 0.0
        self.store_failures = 0
        self.db_transitions_last_known = 0
        self.nstep_generated = 0
        self.reward_info = {}
        self.lock = threading.RLock()
        self.storage_condition = threading.Condition(self.lock)
        self.storage_stop = threading.Event()
        self.storage_force = False
        self.checkpoint_sequence = 0
        self.keyframes_skipped = 0
        self.checkpoint_requested = False
        self.storage_problem = None
        self.storage_failures = 0
        self.spool_lock = threading.Lock()
        self.training_condition = threading.Condition(self.lock)
        self.training_stop = threading.Event()
        self.training_queue = deque(maxlen=4096)
        self.pending_n = deque()
        self.training_problem = None
        self.training_failures = 0
        self.training_last_tick = time.monotonic()
        self.storage_last_tick = time.monotonic()
        self.training_retried = 0
        self.training_stale_batches = 0
        self.training_queue_evictions = 0
        self.terminal_credit_samples = 0
        self.memory = deque(maxlen=16000 if self.np is not None else 3500)
        self.store = None
        self.store_problem = None
        self.restore()
        self.set_game('desktop')
        self.sync_target()
        self._connect_store()
        if self.store is not None:
            try:
                for _ in range(8):
                    if not self.spool_path.exists() or not self.spool_path.stat().st_size:
                        break
                    self._drain_spool()
                self.memory.extend(self.store.recent(self.action_index, limit=3500 if self.np is not None else 900))
                for transition in list(self.memory)[-min(96, len(self.memory)):]:
                    self.training_queue.append(transition)
            except Exception as exc:
                self._store_failure(exc)
            finally:
                if self.store is not None:
                    self.store.close()
                    self.store = None
        self.storage_thread = threading.Thread(target=self.storage_loop, name='AgentStorage', daemon=True)
        self.storage_thread.start()
        self.trainer = threading.Thread(target=self.training_loop, name='AgentLearner', daemon=True)
        self.trainer.start()

    @property
    def game(self):
        return self.games[self.game_key]

    @property
    def stagnation(self):
        return self.game.stagnation

    @property
    def visits(self):
        return self.game.visits


    def set_game(self, key):
        key = canonical_game_key(key)
        with self.lock:
            if key not in self.games:
                self.games[key] = GameData(len(self.actions), self.hidden_size, self.np)
                self.dirty_games.add(key)
                self.dirty_sequence += 1
            if self.game_key != key:
                self.flush_pending(done=True)
                self.previous_lum = None
                self.previous_motion = None
                self.temporal_luma.clear()
                self.last_change = 0.0
                self.last_detail = [0.0] * 24
                self.last_detail_focus = (0.5, 0.5)
                self.last_attention_tracks = []
            self.game_key = key
            self.last_skill_source = None
            self.last_plan_parameters = []
            self.last_plan_predictions = []

    def record_passive_change(self, before, after):
        pixels_a = self.rgb_blocks(before)
        pixels_b = self.rgb_blocks(after)
        difference = sum(abs(a[k] - b[k]) for a, b in zip(pixels_a, pixels_b) for k in range(3)) / (GW * GH * 3 * 255.0)
        game = self.game
        rate = min(0.22, 1.0 / (game.passive_samples + 1))
        game.passive_change = game.passive_change * (1.0 - rate) + rate * difference
        game.passive_samples += 1
        return difference

    def identify_game(self, base_key, raw):
        base = str(base_key or 'desktop')[:35]
        rgb = self.rgb_blocks(raw)
        vector = []
        for row in range(4):
            for col in range(4):
                cells = [rgb[r * GW + c] for r in range(row * 3, row * 3 + 3) for c in range(col * 5, col * 5 + 5)]
                vector.extend(sum(pixel[channel] for pixel in cells) / (255.0 * len(cells)) for channel in range(3))
                values = [luminance_bgr(*pixel) for pixel in cells]
                vector.append(sum(abs(values[k] - values[k - 1]) for k in range(1, len(values))) / max(1, len(values) - 1))
        def distance(a, b):
            return sum(abs(x - y) for x, y in zip(a, b)) / 64.0
        with self.lock:
            profiles = self.visual_routes.setdefault(base, [])
            if self.visual_active_base != base:
                self.visual_active_base = base
                self.visual_active_key = base
                self.visual_candidate = None
                self.visual_candidate_vector = None
                self.visual_candidate_count = 0
                self.visual_candidate_diversity = 0
            if not profiles:
                profiles.append({'key': base, 'anchors': [vector], 'samples': 1})
                self.visual_active_key = base
                self.dirty_sequence += 1
                return base
            current = next((item for item in profiles if item['key'] == self.visual_active_key), None)
            best = min(profiles, key=lambda item: min(distance(vector, anchor) for anchor in item['anchors']))
            best_distance = min(distance(vector, anchor) for anchor in best['anchors'])
            current_distance = min(distance(vector, anchor) for anchor in current['anchors']) if current is not None else 1.0
            if current is not None and current_distance < 0.16:
                current['samples'] = min(1000000000, int(current.get('samples', 1)) + 1)
                if current_distance > 0.045 and current['samples'] % 17 == 0:
                    if len(current['anchors']) >= 24:
                        current['anchors'].pop(1)
                    current['anchors'].append(vector)
                self.visual_candidate = None
                self.visual_candidate_vector = None
                self.visual_candidate_count = 0
                self.visual_candidate_diversity = 0
            else:
                proposed = best['key'] if best_distance < 0.12 else 'new_profile'
                gap = distance(vector, self.visual_candidate_vector) if self.visual_candidate_vector is not None else 1.0
                if proposed == self.visual_candidate and gap < 0.16:
                    self.visual_candidate_count += 1
                    if gap > 0.012:
                        self.visual_candidate_diversity += 1
                else:
                    self.visual_candidate = proposed
                    self.visual_candidate_count = 1
                    self.visual_candidate_diversity = 0
                self.visual_candidate_vector = vector
                if proposed != 'new_profile' and self.visual_candidate_count >= 10:
                    self.visual_active_key = proposed
                    self.visual_candidate = None
                    self.visual_candidate_count = 0
                elif (proposed == 'new_profile' and self.visual_candidate_count >= 48
                      and self.visual_candidate_diversity >= 3 and len(profiles) < 12):
                    existing = {item['key'] for item in profiles}
                    suffix = 1
                    while f'{base}~g{suffix}' in existing:
                        suffix += 1
                    key = f'{base}~g{suffix}'
                    profiles.append({'key': key, 'anchors': [vector], 'samples': 1})
                    self.visual_active_key = key
                    self.visual_candidate = None
                    self.visual_candidate_count = 0
                    self.visual_candidate_diversity = 0
                    self.dirty_sequence += 1
            return self.visual_active_key

    def detail_focus(self, obs, detail=None):
        if detail and detail.get('spatial') and self.step % 3 != 2:
            point = (max(0.0, min(1.0, float(detail.get('start_x', detail.get('x', 0.5))))), max(0.0, min(1.0, float(detail.get('start_y', detail.get('y', 0.5))))))
        elif self.last_attention_tracks and self.step % 4 != 0:
            point = max(self.last_attention_tracks[:18], key=lambda item: item[2])[0:2]
        elif obs.attention_points and self.step % 5 != 0:
            positions = obs.attention_points[:min(20, len(obs.attention_points))]
            candidate = self.rng.choice(positions)
            point = (candidate[0], candidate[1])
        else:
            choices = sorted(range(GW * GH), key=lambda i: obs.salience[i] * 0.64 + obs.edges[i] * 0.22 + obs.motion[i] * 0.14, reverse=True)[:min(28, GW * GH)]
            cell = self.rng.choice(choices) if self.step % 5 else self.rng.randrange(GW * GH)
            point = ((cell % GW + 0.5) / GW, (cell // GW + 0.5) / GH)
        self.last_detail_focus = point
        return point

    def attention_proposals(self, raw, detail, rect, obs):
        candidates = []
        def scan(data, width, height, left, top, span_x, span_y, weight):
            game = self.game
            stride = 12 if width > 700 else 8
            for cy in range(4, height - 4, stride):
                for cx in range(4, width - 4, stride):
                    pos = (cy * width + cx) * 4
                    right = pos + 16
                    leftward = pos - 16
                    below = pos + width * 16
                    above = pos - width * 16
                    base = luminance_bgr(data[pos], data[pos + 1], data[pos + 2])
                    horizontal = abs(luminance_bgr(data[right], data[right + 1], data[right + 2]) - luminance_bgr(data[leftward], data[leftward + 1], data[leftward + 2]))
                    vertical = abs(luminance_bgr(data[below], data[below + 1], data[below + 2]) - luminance_bgr(data[above], data[above + 1], data[above + 2]))
                    edge = 0.55 * (horizontal + vertical) + 0.35 * (abs(base - luminance_bgr(data[right], data[right + 1], data[right + 2])) + abs(base - luminance_bgr(data[below], data[below + 1], data[below + 2])))
                    corner = min(horizontal, vertical)
                    color = (max(data[pos], data[pos + 1], data[pos + 2]) - min(data[pos], data[pos + 1], data[pos + 2])) / 255.0
                    u, v = left + span_x * cx / width, top + span_y * cy / height
                    j = min(GH - 1, int(v * GH)) * GW + min(GW - 1, int(u * GW))
                    target = game.targets.get(f'{j % GW}:{j // GW}')
                    useful = max(0.0, float(target[0])) * min(1.0, float(target[1]) / 6.0) if target else 0.0
                    value = weight * (min(1.0, edge * 0.55) + corner * 0.23 + color * 0.11 + obs.salience[j] * 0.27 + useful * 0.16)
                    if value > 0.12:
                        candidates.append((u, v, value))
        scan(raw, W, H, 0.0, 0.0, 1.0, 1.0, 1.0)
        if detail is not None and len(detail) == DW * DH * 4:
            rw = min(rect[2], max(96, int(rect[2] * 0.38)))
            rh = min(rect[3], max(96, int(rect[3] * 0.38)))
            fx, fy = self.last_detail_focus
            ox = max(0, min(rect[2] - rw, int(fx * rect[2] - rw * 0.5)))
            oy = max(0, min(rect[3] - rh, int(fy * rect[3] - rh * 0.5)))
            scan(detail, DW, DH, ox / rect[2], oy / rect[3], rw / rect[2], rh / rect[3], 1.3)
        candidates.sort(key=lambda entry: entry[2], reverse=True)
        retained = []
        for item in candidates:
            if all(abs(item[0] - prior[0]) > 0.023 or abs(item[1] - prior[1]) > 0.032 for prior in retained):
                retained.append(item)
            if len(retained) >= 48:
                break
        return retained

    def rgb_blocks(self, raw):
        if len(raw) != W * H * 4:
            raise ValueError(f'屏幕图像长度错误：{len(raw)}')
        if self.cv_np is not None:
            pixels = self.cv_np.frombuffer(raw, dtype=self.cv_np.uint8).reshape(GH, H // GH, GW, W // GW, 4)
            return pixels[:, 2::4, :, 2::4, :3].mean(axis=(1, 3)).reshape(GH * GW, 3).tolist()
        cells = []
        cell_width, cell_height = W // GW, H // GH
        for row in range(GH):
            for col in range(GW):
                blue = green = red = 0
                for dy in (2, 6, 10, 14):
                    for dx in (2, 6, 10, 14):
                        index = ((row * cell_height + dy) * W + col * cell_width + dx) * 4
                        blue += raw[index]
                        green += raw[index + 1]
                        red += raw[index + 2]
                cells.append([blue / 16.0, green / 16.0, red / 16.0])
        return cells

    def detail_features(self, raw):
        if raw is not None:
            if len(raw) != DW * DH * 4:
                raise ValueError('精细采集图像长度错误')
            samples = []
            texture = []
            color = []
            for row in range(4):
                for col in range(4):
                    mean = grad = chroma = 0.0
                    n = 0
                    for dy in range(4, DH // 4 - 4, 10):
                        for dx in range(4, DW // 4 - 4, 10):
                            cy = row * (DH // 4) + dy
                            cx = col * (DW // 4) + dx
                            pos = (cy * DW + cx) * 4
                            right = pos + 4 * 3
                            below = pos + DW * 4 * 3
                            v = luminance_bgr(raw[pos], raw[pos + 1], raw[pos + 2])
                            mean += v
                            grad += abs(v - luminance_bgr(raw[right], raw[right + 1], raw[right + 2]))
                            grad += abs(v - luminance_bgr(raw[below], raw[below + 1], raw[below + 2]))
                            chroma += (max(raw[pos], raw[pos + 1], raw[pos + 2]) - min(raw[pos], raw[pos + 1], raw[pos + 2])) / 255.0
                            n += 1
                    samples.append(mean / max(1, n))
                    texture.append(grad / max(1, 2 * n))
                    color.append(chroma / max(1, n))
            sections = []
            for row in range(2):
                for col in range(2):
                    ids = [(row * 2 + ry) * 4 + col * 2 + cx for ry in range(2) for cx in range(2)]
                    sections.extend((sum(texture[i] for i in ids) / 4, sum(color[i] for i in ids) / 4))
            self.last_detail = samples + sections
        return self.last_detail

    def read_ui_symbols(self, raw):
        width, height = W, H
        visible = bytearray(width * height)
        zones = ((0, min(42, height)), (max(0, height // 2 - 30), min(height, height // 2 + 30)), (max(0, height - 42), height))
        for top, bottom in zones:
            for y in range(top, bottom):
                offset = y * width
                for x in range(width):
                    pos = (offset + x) * 4
                    blue, green, red = raw[pos], raw[pos + 1], raw[pos + 2]
                    bright_text = (min(red, green, blue) >= 177 and max(red, green, blue) - min(red, green, blue) <= 56) or (red > 218 and green > 189 and blue < 146)
                    dark_text = False
                    if not bright_text and max(red, green, blue) <= 87:
                        for nx, ny in ((x - 6, y), (x + 6, y), (x, y - 4), (x, y + 4)):
                            if 0 <= nx < width and top <= ny < bottom:
                                other = (ny * width + nx) * 4
                                if min(raw[other], raw[other + 1], raw[other + 2]) >= 163:
                                    dark_text = True
                                    break
                    if bright_text:
                        visible[offset + x] = 1
                    elif dark_text:
                        visible[offset + x] = 3
        glyphs = []
        templates = {}
        for symbol, rows in GLYPH_ROWS.items():
            columns = [x for x in range(5) if any(row[x] == '1' for row in rows)]
            left, right = min(columns), max(columns)
            bits = set()
            for y in range(7):
                for x in range(5):
                    rx = left + min(right - left, int((x + 0.5) * (right - left + 1) / 5))
                    if rows[y][rx] == '1':
                        bits.add(y * 5 + x)
            templates[symbol] = bits
        for polarity in (1, 3):
            for top, bottom in zones:
                for y in range(top, bottom):
                    for x in range(width):
                        index = y * width + x
                        if visible[index] != polarity:
                            continue
                        pending = [index]
                        visible[index] = polarity + 1
                        x0 = x1 = x
                        y0 = y1 = y
                        points = []
                        for pixel in pending:
                            py, px = divmod(pixel, width)
                            points.append(pixel)
                            x0, x1 = min(x0, px), max(x1, px)
                            y0, y1 = min(y0, py), max(y1, py)
                            for ny in range(max(top, py - 1), min(bottom, py + 2)):
                                for nx in range(max(0, px - 1), min(width, px + 2)):
                                    target = ny * width + nx
                                    if visible[target] == polarity:
                                        visible[target] = polarity + 1
                                        pending.append(target)
                        cw, ch = x1 - x0 + 1, y1 - y0 + 1
                        if not (2 <= cw <= 22 and 6 <= ch <= 28 and 7 <= len(points) <= 290 and 0.18 <= cw / ch <= 1.9):
                            continue
                        covered = set(points)
                        sampled = set()
                        for gy in range(7):
                            sy = y0 + min(ch - 1, int((gy + 0.5) * ch / 7))
                            for gx in range(5):
                                sx = x0 + min(cw - 1, int((gx + 0.5) * cw / 5))
                                if sy * width + sx in covered:
                                    sampled.add(gy * 5 + gx)
                        if len(sampled) < 6:
                            continue
                        scores = sorted(((2 * len(sampled & template) / max(1, len(sampled) + len(template)), symbol)
                                         for symbol, template in templates.items()), reverse=True)
                        score, char = scores[0]
                        if score >= 0.79 and (score - scores[1][0] >= 0.035 or score >= 0.96):
                            glyphs.append((x0, y0, x1, y1, char, score))
                        elif getattr(self, 'local_glyphs', None) is not None and self.local_glyphs.templates and 0.48 <= cw / ch <= 1.35:
                            high_resolution = set()
                            for gy in range(12):
                                sy = y0 + min(ch - 1, int((gy + 0.5) * ch / 12))
                                for gx in range(10):
                                    sx = x0 + min(cw - 1, int((gx + 0.5) * cw / 10))
                                    if sy * width + sx in covered:
                                        high_resolution.add(gy * 10 + gx)
                            if len(high_resolution) >= 14:
                                result_score, result_char = self.local_glyphs.best(high_resolution)
                                if result_char:
                                    glyphs.append((x0, y0, x1, y1, result_char, result_score))
        glyphs.sort(key=lambda item: (item[1] // 8, item[0]))
        lines = []
        for glyph in glyphs:
            x0, y0, x1, y1, char, score = glyph
            options = [line for line in lines if x0 >= line['right'] and x0 - line['right'] <= max(12, (y1 - y0 + 1) * 1.4)
                       and abs((y0 + y1) / 2 - line['center']) <= max(4, (y1 - y0 + 1) * 0.4)]
            if options:
                line = min(options, key=lambda item: (x0 - item['right']) + abs((y0 + y1) / 2 - item['center']))
                line['text'] += char
                line['confidence'] = min(line['confidence'], score)
                line['right'] = x1
                line['center'] = ((y0 + y1) / 2 + line['center']) / 2
            else:
                lines.append({'text': char, 'confidence': score, 'x': x0 / width, 'y': y0 / height,
                              'right': x1, 'center': (y0 + y1) / 2})
        result = []
        for line in lines:
            content = line['text']
            if len(content) >= 2 and line['confidence'] >= 0.79:
                result.append({'text': content[:24], 'confidence': round(line['confidence'], 3),
                               'x': round(line['x'], 3), 'y': round(line['y'], 3)})
        return result[:30]

    def detect_hud_meters(self, raw):
        meter_rows = tuple(range(3, 36, 3)) + tuple(range(H - 36, H - 2, 3))
        runs = {}
        for y in meter_rows:
            current, start = None, 0
            for x in range(W + 1):
                tone = None
                if x < W:
                    pos = (y * W + x) * 4
                    b, g, r = raw[pos], raw[pos + 1], raw[pos + 2]
                    if g >= 105 and g >= r * 1.38 and g >= b * 1.26:
                        tone = 'green'
                    elif r >= 112 and r >= g * 1.40 and r >= b * 1.26:
                        tone = 'red'
                    elif b >= 110 and b >= r * 1.4 and b >= g * 1.30:
                        tone = 'blue'
                if tone != current:
                    size = x - start
                    if current is not None and size >= 18 and size <= W * 0.65:
                        key = ('top' if y < H // 2 else 'bottom', start // 12, current)
                        record = runs.setdefault(key, [])
                        record.append((size / W, y))
                    current, start = tone, x
        return {f'{part}:{x}:{tone}': round(sum(length for length, _ in values) / len(values), 4)
                for (part, x, tone), values in runs.items() if len(values) >= 2}

    def observe(self, raw, rect, detail=None):
        try:
            rgb = self.rgb_blocks(raw)
        except Exception:
            self.invalid_observations += 1
            raise
        if detail is not None and len(detail) != DW * DH * 4:
            self.invalid_observations += 1
            detail = None
        count = GW * GH
        lum = [luminance_bgr(b, g, r) for b, g, r in rgb]
        motion = [abs(v - p) for v, p in zip(lum, self.previous_lum)] if self.previous_lum is not None else [0.0] * count
        prior_motion = self.previous_motion if self.previous_motion is not None else [0.0] * count
        two_frames_ago = self.temporal_luma[-2] if len(self.temporal_luma) >= 2 else self.previous_lum
        long_motion = [abs(v - p) for v, p in zip(lum, two_frames_ago)] if two_frames_ago is not None else [0.0] * count
        change = sum(motion) / count
        edges = []
        salience = []
        saturation = []
        for row in range(GH):
            for col in range(GW):
                i = row * GW + col
                edge = 0.0
                if col:
                    edge += abs(lum[i] - lum[i - 1])
                if row:
                    edge += abs(lum[i] - lum[i - GW])
                edge *= 0.5
                edges.append(edge)
                salience.append(min(1.0, motion[i] * 1.3 + edge * 0.85))
                saturation.append((max(rgb[i]) - min(rgb[i])) / 255.0)
        avg = sum(lum) / count
        variance = math.sqrt(sum((v - avg) ** 2 for v in lum) / count)
        mean_rgb = [sum(pixel[k] for pixel in rgb) / (255.0 * count) for k in range(3)]
        bright = sum(v > 0.78 for v in lum) / count
        dark = sum(v < 0.22 for v in lum) / count
        max_s = max(range(count), key=salience.__getitem__)
        weighted_motion = sum(motion) + 1e-9
        weighted_salience = sum(salience) + 1e-9
        motion_x = sum((i % GW + 0.5) / GW * motion[i] for i in range(count)) / weighted_motion
        motion_y = sum((i // GW + 0.5) / GH * motion[i] for i in range(count)) / weighted_motion
        salience_x = sum((i % GW + 0.5) / GW * salience[i] for i in range(count)) / weighted_salience
        salience_y = sum((i // GW + 0.5) / GH * salience[i] for i in range(count)) / weighted_salience
        game = self.game
        fingerprint = []
        for row in range(4):
            for col in range(5):
                ids = [r * GW + c for r in range(row * 3, (row + 1) * 3) for c in range(col * 4, (col + 1) * 4)]
                fingerprint.append(min(11, int(12 * sum(lum[i] for i in ids) / len(ids))))
        signature = hashlib.blake2b(bytes(fingerprint), digest_size=8).hexdigest()
        with self.lock:
            nearest = None
            distance = 1000.0
            for old_signature, (center, _) in list(game.scene_centers.items())[-96:]:
                gap = sum(abs(x - y) for x, y in zip(fingerprint, center)) / 20.0
                if gap < distance:
                    distance, nearest = gap, old_signature
            if nearest is not None and distance < 0.34:
                signature = nearest
            count_seen = game.visits.get(signature, 0)
            game.visits[signature] = count_seen + 1
            game.visits.move_to_end(signature)
            scene_record = game.scene_centers.get(signature)
            if scene_record is None:
                game.scene_centers[signature] = [[float(x) for x in fingerprint], 1]
            else:
                center, previous = scene_record
                rate = 1.0 / min(30, previous + 1)
                for i, value in enumerate(fingerprint):
                    center[i] += rate * (value - center[i])
                scene_record[1] = previous + 1
                game.scene_centers.move_to_end(signature)
            game.scene_history.append(signature)
            if len(game.visits) > 15000:
                game.visits.popitem(last=False)
            if len(game.scene_centers) > 2400:
                game.scene_centers.popitem(last=False)
        novelty = 1.0 / math.sqrt(1 + count_seen)
        features = [
            1.0, avg, variance * 1.7, mean_rgb[0], mean_rgb[1], mean_rgb[2],
            change * 2.0, sum(edges) / count * 2.0, sum(saturation) / count,
            bright, dark, novelty, min(1.0, game.stagnation / 35.0),
            self.last_change * 2.0, motion_x, motion_y, salience_x, salience_y,
        ]
        for row in range(3):
            for col in range(4):
                ids = [r * GW + c for r in range(row * 4, (row + 1) * 4) for c in range(col * 5, (col + 1) * 5)]
                reciprocal = 1.0 / len(ids)
                features.extend((
                    sum(lum[i] for i in ids) * reciprocal,
                    sum(rgb[i][0] for i in ids) * reciprocal / 255.0,
                    sum(rgb[i][1] for i in ids) * reciprocal / 255.0,
                    sum(rgb[i][2] for i in ids) * reciprocal / 255.0,
                    sum(motion[i] for i in ids) * reciprocal * 2.0,
                    sum(edges[i] for i in ids) * reciprocal * 2.0,
                    sum(saturation[i] for i in ids) * reciprocal,
                ))
        for row in range(4):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                ids = [r * GW + c for r in range(row * 3, (row + 1) * 3) for c in range(x0, x1)]
                features.append(sum(lum[i] for i in ids) / max(1, len(ids)))
        features.extend(self.detail_features(detail))
        features.extend(((max_s % GW + 0.5) / GW, (max_s // GW + 0.5) / GH))
        for row in range(4):
            for col in range(8):
                ids = [r * GW + c for r in range(row * 3, (row + 1) * 3) for c in range(col * GW // 8, (col + 1) * GW // 8)]
                scale = 1.0 / len(ids)
                features.extend((sum(motion[i] for i in ids) * scale, sum(edges[i] for i in ids) * scale, sum(saturation[i] for i in ids) * scale))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cells = [r * GW + c for r in range(y0, y1) for c in range(x0, x1)]
                features.append(sum(lum[i] for i in cells) / len(cells))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cells = [r * GW + c for r in range(y0, y1) for c in range(x0, x1)]
                features.append(sum(0.32 * motion[i] + 0.25 * prior_motion[i] + 0.23 * long_motion[i] + 0.20 * edges[i] for i in cells) / len(cells))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cells = [r * GW + c for r in range(y0, y1) for c in range(x0, x1)]
                features.append(sum((rgb[i][2] - rgb[i][0]) / 255.0 for i in cells) / len(cells))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cx, cy = (x0 + x1) / (2 * GW), (y0 + y1) / (2 * GH)
                tracked = sum(max(0.0, min(1.0, weight)) * max(0.0, 1.0 - abs(x + vx - cx) * 6.0 - abs(y + vy - cy) * 6.0)
                              for x, y, weight, vx, vy in self.last_attention_tracks[:30])
                features.append(min(1.0, tracked))
        if len(features) != FEATURE_COUNT:
            raise ValueError(f'视觉特征数量错误：{len(features)}')
        hud_ids = [r * GW + c for r in list(range(2)) + list(range(GH - 2, GH)) for c in range(GW)]
        hud = sum((saturation[i] * 0.4 + edges[i] * 0.6) for i in hud_ids) / len(hud_ids)
        identical = self.previous_lum is not None and change < 0.0001
        self.temporal_luma.append(lum[:])
        self.previous_lum = lum
        self.previous_motion = motion
        self.last_change = change
        self.last_frame = raw
        blank = variance < 0.006 and (avg < 0.012 or avg > 0.988)
        color_deviation = math.sqrt(sum((pixel[channel] / 255.0 - mean_rgb[channel]) ** 2 for pixel in rgb for channel in range(3)) / (count * 3))
        uniform = color_deviation < 0.006
        low_information = bool(blank or uniform)
        confidence = 0.16 if low_information else 0.62 if identical else 1.0
        if low_information:
            self.low_information_observations += 1
        quality = {'blank': bool(blank), 'uniform': bool(uniform), 'low_information': low_information, 'trainable': not low_information, 'confidence': confidence, 'variance': round(variance, 5), 'same_as_previous': bool(identical), 'temporal_frames': len(self.temporal_luma), 'scene': 'blank' if low_information else 'changing' if change > 0.16 else 'active' if change > 0.012 else 'steady', 'capture_integrity': True}
        observation = Observation(lum, rgb, salience, motion, edges, features, signature, change, novelty, rect, raw, hud, self.game_key, True, quality)
        regions = []
        for r0, r1, c0, c1 in ((0, 2, 0, 10), (0, 2, 10, 20), (10, 12, 0, 10), (10, 12, 10, 20), (2, 10, 0, 5), (2, 10, 5, 15), (2, 10, 15, 20)):
            ids = [r * GW + c for r in range(r0, r1) for c in range(c0, c1)]
            regions.append((sum(lum[i] for i in ids) / len(ids), sum(saturation[i] for i in ids) / len(ids), sum(edges[i] for i in ids) / len(ids)))
        observation.region_signals = regions
        hud_readouts = []
        for row_first in (0, GH - 2):
            for segment in range(6):
                indices = [r * GW + c for r in range(row_first, row_first + 2) for c in range(segment * GW // 6, (segment + 1) * GW // 6)]
                hud_readouts.extend((
                    sum(saturation[i] > 0.23 and lum[i] > 0.12 for i in indices) / len(indices),
                    sum(rgb[i][1] > rgb[i][0] * 1.22 and rgb[i][1] > rgb[i][2] * 1.22 for i in indices) / len(indices),
                    sum(rgb[i][2] > rgb[i][0] * 1.28 and rgb[i][2] > rgb[i][1] * 1.28 for i in indices) / len(indices),
                    sum(lum[i] > 0.70 for i in indices) / len(indices),
                ))
        observation.hud_readouts = hud_readouts
        observation.hud_meters = self.detect_hud_meters(raw) if not low_information else {}
        observation.ui_text = self.read_ui_symbols(raw) if not low_information else []
        if not low_information and detail is not None:
            def detail_patch(left, top, width, height):
                small = bytearray(W * H * 4)
                for y in range(H):
                    source_y = min(DH - 1, top + y * height // H)
                    output = y * W * 4
                    input_row = source_y * DW * 4
                    for x in range(W):
                        sample = input_row + min(DW - 1, left + x * width // W) * 4
                        small[output + x * 4:output + x * 4 + 4] = detail[sample:sample + 4]
                return bytes(small)
            region_width = min(rect[2], max(96, int(rect[2] * 0.38)))
            region_height = min(rect[3], max(96, int(rect[3] * 0.38)))
            fx, fy = self.last_detail_focus
            offset_x = max(0, min(rect[2] - region_width, int(fx * rect[2] - region_width * 0.5)))
            offset_y = max(0, min(rect[3] - region_height, int(fy * rect[3] - region_height * 0.5)))
            crops = [(0, 0, DW, DH)]
            if self.step % 3 == 0:
                crops.append((DW // 4, DH // 4, DW // 2, DH // 2))
            for left, top, width, height in crops:
                for item in self.read_ui_symbols(detail_patch(left, top, width, height)):
                    u = (left + item['x'] * width) / DW
                    v = (top + item['y'] * height) / DH
                    absolute_x = (offset_x + u * region_width) / max(1, rect[2])
                    absolute_y = (offset_y + v * region_height) / max(1, rect[3])
                    if not any(existing['text'] == item['text'] and abs(existing['x'] - absolute_x) < 0.025 and abs(existing['y'] - absolute_y) < 0.025 for existing in observation.ui_text):
                        observation.ui_text.append({**item, 'x': absolute_x, 'y': absolute_y, 'source': 'detail'})
            observation.ui_text.sort(key=lambda item: item['confidence'], reverse=True)
            observation.ui_text = observation.ui_text[:36]
        observation.ui_numbers = [entry for entry in observation.ui_text if entry['text'].isdigit() and len(entry['text']) <= 8]
        proposed = self.attention_proposals(raw, detail, rect, observation)
        predicted = []
        for x, y, confidence, vx, vy in self.last_attention_tracks:
            matches = [point for point in proposed[:35] if abs(point[0] - x) < 0.095 and abs(point[1] - y) < 0.12]
            if matches:
                nx, ny, weight = min(matches, key=lambda point: abs(point[0] - x) + abs(point[1] - y))
                tracked_x = max(0.01, min(0.99, nx + (nx - x + vx) * 0.28))
                tracked_y = max(0.01, min(0.99, ny + (ny - y + vy) * 0.28))
                predicted.append((tracked_x, tracked_y, min(2.0, weight * 1.18 + confidence * 0.10)))
        proposed = sorted(proposed + predicted, key=lambda point: point[2], reverse=True)
        observation.attention_points = []
        for point in proposed:
            if all(abs(point[0] - old_point[0]) > 0.016 or abs(point[1] - old_point[1]) > 0.024
                   for old_point in observation.attention_points):
                observation.attention_points.append(point)
            if len(observation.attention_points) >= 48:
                break
        tracks = []
        for x, y, weight in observation.attention_points[:30]:
            matched = min(self.last_attention_tracks, key=lambda item: abs(item[0] - x) + abs(item[1] - y)) if self.last_attention_tracks else None
            if matched is not None and abs(matched[0] - x) < 0.12 and abs(matched[1] - y) < 0.16:
                vx = max(-0.10, min(0.10, 0.65 * (x - matched[0]) + 0.35 * matched[3]))
                vy = max(-0.10, min(0.10, 0.65 * (y - matched[1]) + 0.35 * matched[4]))
                tracks.append((x, y, weight, vx, vy))
            else:
                tracks.append((x, y, weight, 0.0, 0.0))
        self.last_attention_tracks = tracks
        observation.scene_key = self.game_key
        return observation

    def _encode(self, features, target=False):
        matrix = self.target_encoder if target else self.encoder
        bias = self.target_encoder_bias if target else self.encoder_bias
        if self.np is not None:
            x = self.np.asarray(features, dtype=self.np.float32)
            return self.np.tanh(matrix @ x + bias)
        return [math.tanh(sum(weight * value for weight, value in zip(row, features)) + bias[j]) for j, row in enumerate(matrix)]

    def _values(self, features, game, target=False, include_hidden=False):
        hidden = self._encode(features, target)
        matrix = game.target_q if target else game.q
        bias = game.target_bias if target else game.bias
        if self.np is not None:
            scores = matrix @ hidden + bias
            return (scores, hidden) if include_hidden else scores
        scores = [sum(w * h for w, h in zip(row, hidden)) + bias[i] for i, row in enumerate(matrix)]
        return (scores, hidden) if include_hidden else scores


    def _world_key(self, index, obs):
        features = obs.features if hasattr(obs, 'features') else obs
        blocks = [features[18 + 7 * i] for i in range(12)]
        regions = ((0, 1, 4, 5), (2, 3, 6, 7), (4, 5, 8, 9), (6, 7, 10, 11))
        tokens = [str(max(0, min(3, int(sum(blocks[i] for i in cells))))) for cells in regions]
        tokens.append(str(min(3, max(0, int(features[8] * 4)))))
        tokens.append(str(min(3, max(0, int(features[2] * 6)))))
        scene_identity = getattr(obs, 'scene_key', None) or self.visual_active_key or self.game_key
        scene = str(scene_identity).rsplit(':', 1)[-1][:8]
        return str(index) + '@' + scene + ':' + ''.join(tokens)

    def scores(self, obs, spatial=True):
        with self.lock:
            game = self.game
            values = self._values(obs.features, game)
            values = values.tolist() if self.np is not None else values
            if spatial:
                if game.recent:
                    recent = list(game.recent)[-6:]
                    for action_id, previous_features, achieved, signature, detail in recent:
                        if signature == obs.signature:
                            similarity = sum(abs(a - b) for a, b in zip(previous_features, obs.features[:18])) / 18.0
                            if achieved <= 0.025 and similarity < 0.08:
                                values[action_id] -= min(0.18, 0.028 + max(0.0, -achieved) * 0.25)
                    if len(recent) >= 3:
                        tail = recent[-3:]
                        if len({record[3] for record in tail}) == 1 and tail[-1][3] == obs.signature:
                            for action_id, _, achieved, _, _ in tail:
                                if achieved < 0.04:
                                    values[action_id] -= 0.035
                bonus = math.log(game.game_steps + 2)
                for i, action in enumerate(self.actions):
                    values[i] += 0.085 * math.sqrt(bonus / (1.0 + game.counts[i])) + 0.028 * math.log1p(action.prior)
                    statistics = game.category_score.get(action.category)
                    if statistics:
                        values[i] += 0.05 * statistics[1]
                    if game.action_effect_samples[i]:
                        certainty = min(1.0, game.action_effect_samples[i] / 12.0)
                        values[i] += 0.11 * certainty * game.action_effect[i]
                    if action.kind in ('click', 'double', 'right', 'middle', 'move'):
                        col = min(GW - 1, max(0, int(action.x * GW)))
                        row = min(GH - 1, max(0, int(action.y * GH)))
                        values[i] += 0.115 * obs.salience[row * GW + col]
                        target = game.targets.get(f'{col}:{row}')
                        if target:
                            values[i] += 0.075 * max(0.0, float(target[0])) * min(1.0, float(target[1]) / 8.0)
                    world = game.world.get(self._world_key(i, obs)) or game.world.get(i)
                    if world and world[1] >= 4:
                        reliability = min(1.0, world[1] / 25.0) / (1.0 + world[2] * 8.0)
                        expected_effect = max(-0.7, min(0.7, game.action_effect[i]))
                        values[i] += 0.055 * reliability * expected_effect - 0.025 * min(1.0, world[2] * 4.0)
            return values

    def choose(self, obs):
        with self.lock:
            game = self.game
            uncertainty = min(1.0, max(0.0, self.td_error_ema) * 3.0)
            epsilon = max(0.012, min(0.88, 0.76 / math.sqrt(1 + game.game_steps / 160.0)
                                      + 0.15 * min(1.0, game.stagnation / 28.0) + 0.08 * uncertainty))
            if self.rng.random() < epsilon:
                families = list(self.action_families)
                family_weights = []
                for family in families:
                    indices = self.action_families[family]
                    trials = sum(game.counts[i] for i in indices)
                    effectiveness = game.family_score.get(family, (0, 0.0))[1]
                    family_weights.append(max(0.15, 1.0 + effectiveness * 3.0) * (1.0 + math.log1p(len(indices))) / (1.0 + trials / len(indices)) ** 0.55)
                family = self.rng.choices(families, weights=family_weights, k=1)[0]
                kinds = [kind for fam, kind in self.action_kinds if fam == family]
                kind_weights = []
                for kind in kinds:
                    indices = self.action_kinds[(family, kind)]
                    attempts = sum(game.counts[i] for i in indices)
                    effective = sum(game.action_effect[i] for i in indices if game.action_effect_samples[i]) / max(1, sum(bool(game.action_effect_samples[i]) for i in indices))
                    kind_weights.append(max(0.1, 1.0 + effective * 3.0) * (1.0 + math.log1p(len(indices))) / (1.0 + attempts / len(indices)) ** 0.5)
                kind = self.rng.choices(kinds, weights=kind_weights, k=1)[0]
                indices = self.action_kinds[(family, kind)]
                weights = []
                for i in indices:
                    action = self.actions[i]
                    factor = 1.0
                    if action.kind in ('click', 'double', 'right', 'middle', 'move'):
                        col = min(GW - 1, max(0, int(action.x * GW)))
                        row = min(GH - 1, max(0, int(action.y * GH)))
                        factor += 2.5 * obs.salience[row * GW + col]
                    effect = max(-0.25, min(0.5, game.action_effect[i]))
                    weights.append(max(0.001, action.prior * factor * (1.0 + 2.0 * effect) / math.sqrt(1.0 + game.counts[i] * 0.20)))
                return self.rng.choices(indices, weights=weights, k=1)[0]
            values = self.scores(obs)
            if game.world:
                candidates = sorted(range(len(values)), key=values.__getitem__, reverse=True)[:6]
                baseline = max(values)
                for index in candidates:
                    model = game.world.get(self._world_key(index, obs)) or game.world.get(index)
                    if model is None or model[1] < 6:
                        continue
                    next_state = obs.features[:]
                    for k, adjustment in enumerate(model[0]):
                        next_state[k] = max(-2.0, min(2.0, next_state[k] + adjustment))
                    future = self._values(next_state, game)
                    best_future = float(self.np.max(future)) if self.np is not None else max(future)
                    confidence = min(1.0, model[1] / 35.0) / (1.0 + model[2] * 7.0)
                    values[index] += 0.07 * confidence * max(-1.0, min(1.0, best_future - baseline))
            family_scores = {}
            for family, indices in self.action_families.items():
                kinds = [kind for fam, kind in self.action_kinds if fam == family]
                kind_peaks = [max(values[i] for i in self.action_kinds[(family, kind)]) for kind in kinds]
                family_scores[family] = max(kind_peaks) + 0.012 * sum(kind_peaks) / len(kind_peaks)
            winner = max(family_scores.values())
            families = [key for key, value in family_scores.items() if value >= winner - 0.045]
            family = self.rng.choice(families)
            kind_scores = {}
            for fam, kind in self.action_kinds:
                if fam == family:
                    indices = self.action_kinds[(family, kind)]
                    kind_scores[kind] = max(values[i] for i in indices) + 0.01 / math.sqrt(1 + sum(game.counts[i] for i in indices) / len(indices))
            winner = max(kind_scores.values())
            kinds = [kind for kind, score in kind_scores.items() if score >= winner - 0.025]
            kind = self.rng.choice(kinds)
            indices = self.action_kinds[(family, kind)]
            top = max(values[i] for i in indices)
            options = [i for i in indices if values[i] >= top - 0.018]
            return self.rng.choice(options)

    def predicted_parameters(self, game, kind, features):
        head = game.ensure_parameter_head(kind, self.hidden_size)
        if head['samples'] < 8:
            return None
        hidden = self._encode(features)
        if self.np is not None:
            output = (0.5 + 0.5 * self.np.tanh(head['w'] @ hidden + head['b'])).tolist()
        else:
            output = [0.5 + 0.5 * math.tanh(sum(a * b for a, b in zip(row, hidden)) + head['b'][i]) for i, row in enumerate(head['w'])]
        return [min(1.0, max(0.0, float(value))) for value in output]

    def blend_action_parameters(self, game, action, features, proposed):
        prediction = self.predicted_parameters(game, action.kind, features)
        if prediction is None or self.rng.random() < 0.12:
            return (*proposed[:3], 1.0)
        head = game.parameter_heads[action.kind]
        influence = min(0.72, max(0.0, (head['samples'] - 7) / 130.0))
        learned_duration = 0.04 + 1.46 * prediction[2]
        x = max(0.01, min(0.99, proposed[0] * (1.0 - influence) + prediction[0] * influence))
        y = max(0.01, min(0.99, proposed[1] * (1.0 - influence) + prediction[1] * influence))
        duration = max(0.025, proposed[2] * (1.0 - influence) + learned_duration * influence)
        extent = 1.0 - influence * 0.5 + influence * prediction[3]
        return (x, y, duration, max(0.5, min(1.5, extent)))

    def recommend_action_parameters(self, index, obs):
        with self.lock:
            game = self.game
            action = self.actions[index]
            spatial_kinds = ('click', 'right', 'double', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch')
            durations = (0.065, 0.12, 0.24, 0.48, 0.9, 1.45) if action.kind in ('key', 'hold', 'pair_hold', 'chord') else (0.12, 0.28, 0.55, 0.95, 1.4) if action.kind in ('press', 'swipe', 'right_swipe', 'combat', 'move_fire', 'aim', 'look', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch') else (action.duration,)
            ranked = []
            for duration in durations:
                label = f'{action.kind}:{action.a}:{action.b}:{round(duration, 3)}'
                score, count = game.duration_stats.get(label, (0.0, 0))
                explore = 0.11 / math.sqrt(1 + count)
                ranked.append(score * min(1.0, count / 7.0) + explore + self.rng.random() * (0.12 if game.game_steps < 300 else 0.045))
            duration = durations[max(range(len(durations)), key=ranked.__getitem__)]
            if action.kind not in spatial_kinds:
                return self.blend_action_parameters(game, action, obs.features, (action.x, action.y, duration))
            ranked_cells = sorted(range(GW * GH), key=lambda i: obs.salience[i] + 0.035 * obs.edges[i], reverse=True)
            candidates = ranked_cells[:40] + self.rng.sample(range(GW * GH), 24)
            candidates.extend(min(GW - 1, int(u * GW)) + GW * min(GH - 1, int(v * GH)) for u, v, _ in obs.attention_points[:24])
            for key, entry in list(game.parameter_stats.items())[-350:]:
                parts = str(key).split(':')
                if len(parts) == 3 and parts[0] == action.kind and entry[1] >= 2:
                    try:
                        col, row = int(parts[1]), int(parts[2])
                        if 0 <= col < GW and 0 <= row < GH:
                            candidates.append(row * GW + col)
                    except ValueError:
                        continue
            best_cell = None
            best_score = -1e10
            for cell in set(candidates):
                col, row = cell % GW, cell // GW
                key = f'{action.kind}:{col}:{row}'
                record = game.parameter_stats.get(key, (0.0, 0, 0.0))
                count = record[1]
                score = 0.43 * obs.salience[cell] + 0.17 * obs.edges[cell] + 0.08 * obs.motion[cell]
                score += 0.52 * record[0] * min(1.0, count / 6.0) + 0.12 * record[2] * min(1.0, count / 5.0)
                score += 0.13 / math.sqrt(1 + count)
                score -= 0.11 * sum(recent == cell for recent in game.focus_recent)
                score += self.rng.random() * (0.26 if game.game_steps < 250 else 0.08)
                if score > best_score:
                    best_score, best_cell = score, cell
            if best_cell is None:
                return self.blend_action_parameters(game, action, obs.features, (0.5, 0.5, duration))
            game.focus_recent.append(best_cell)
            col, row = best_cell % GW, best_cell // GW
            nearby = [(u, v, salience) for u, v, salience in obs.attention_points if int(u * GW) == col and int(v * GH) == row]
            if nearby and self.rng.random() < 0.72:
                u, v, _ = max(nearby, key=lambda entry: entry[2])
                return self.blend_action_parameters(game, action, obs.features, (u, v, duration))
            return self.blend_action_parameters(game, action, obs.features, ((col + 0.5) / GW, (row + 0.5) / GH, duration))

    def choose_plan(self, obs):
        with self.lock:
            game = self.game
            if self.rng.random() >= (0.58 if game.game_steps > 70 else 0.18):
                self.last_skill_source = None
                self.last_plan_parameters = []
                self.last_plan_predictions = []
                return [self.choose(obs)]
            candidates = []
            pools = [(self.game_key, game, 1.0)]
            pools.extend((key, other, 0.45) for key, other in self.games.items() if key != self.game_key and other.game_steps >= 100)
            for source_key, source, transfer_discount in pools:
                for key, info in source.skills.items():
                    ids = [self.action_index.get(a) for a in key.split('|')]
                    if len(ids) < 2 or any(index is None for index in ids):
                        continue
                    quality = max(0.0, float(info.get('quality', 0.0)))
                    if quality <= 0.01:
                        continue
                    context = info.get('context', [])
                    goal_features = info.get('goal_features', [])
                    if len(context) != 18 or info.get('goal_signature') == obs.signature:
                        continue
                    if len(goal_features) == 18:
                        goal_distance = sum((a - b) ** 2 for a, b in zip(goal_features, obs.features[:18])) / 18
                        if goal_distance < 0.002:
                            continue
                    distance = sum((a - b) ** 2 for a, b in zip(context, obs.features[:18])) / 18
                    if distance >= (0.016 if source is game else 0.009):
                        continue
                    attempts = max(0, int(info.get('attempts', 0)))
                    successes = max(0, min(attempts, int(info.get('successes', 0))))
                    confidence = (successes + 1.5) / (attempts + 3)
                    if source is not game and (attempts < 10 or confidence < 0.72):
                        continue
                    score = quality * confidence * transfer_discount / (1.0 + distance * 30.0)
                    details = info.get('parameters', [])
                    params = []
                    if source is game and isinstance(details, list) and len(details) == len(ids):
                        for detail in details:
                            if isinstance(detail, dict):
                                try:
                                    values = [float(detail.get('start_x', detail.get('x', 0.5))), float(detail.get('start_y', detail.get('y', 0.5))), float(detail.get('requested_duration', detail.get('duration', 0.2))), float(detail.get('extent', 1.0))]
                                except (TypeError, ValueError):
                                    values = []
                                params.append(tuple(values) if len(values) == 4 and all(math.isfinite(value) for value in values) else None)
                            else:
                                params.append(None)
                    candidates.append((max(0.001, score), ids, source_key, params))
            if candidates:
                indices, source_key, params = self.rng.choices([(ids, key, params) for _, ids, key, params in candidates], weights=[score for score, _, _, _ in candidates], k=1)[0]
                self.last_skill_source = source_key
                self.last_plan_parameters = params
                self.last_plan_predictions = []
                return indices
            self.last_skill_source = None
            self.last_plan_parameters = []
            plan, predictions = self.plan_with_world_model(obs)
            self.last_plan_predictions = predictions
            return plan

    def plan_with_world_model(self, obs):
        game = self.game
        estimates = self.scores(obs)
        initial = sorted(range(len(estimates)), key=estimates.__getitem__, reverse=True)[:30]
        reliable = []
        for index in initial:
            record = game.world.get(self._world_key(index, obs)) or game.world.get(index)
            if record is not None and record[1] >= 7 and record[2] < 0.20:
                reliable.append(index)
        if len(reliable) < 2:
            return [self.choose(obs)], []
        horizon = 4 if self.np is not None else 3
        beam = [(0.0, [], obs.features[:], [], 1.0)]
        candidates = []
        for depth in range(horizon):
            advanced = []
            for utility, path, features, predicted, trust in beam:
                values = self._values(features, game)
                if self.np is not None:
                    values = values.tolist()
                ranks = sorted(reliable, key=lambda i: values[i] + 0.16 * game.action_effect[i]
                               - (0.08 if path and path[-1] == i else 0.0), reverse=True)[:7]
                for index in ranks:
                    record = game.world.get(self._world_key(index, features)) or game.world.get(index)
                    if record is None or record[1] < 6 or record[2] > 0.20:
                        continue
                    changed = features[:]
                    for k, difference in enumerate(record[0][:32]):
                        changed[k] = max(-2.0, min(2.0, changed[k] + difference))
                    confidence = min(1.0, record[1] / 28.0) / (1.0 + record[2] * 7.0)
                    effect = max(-0.30, min(0.75, game.action_effect[index]))
                    repetition = 0.15 if len(path) > 1 and path[-1] == path[-2] == index else 0.055 if path and path[-1] == index else 0.0
                    risk = 0.12 * max(0.0, record[2] - 0.04) + 0.025 * max(0.0, 0.5 - confidence)
                    score = utility + (DISCOUNT ** depth) * (max(-0.3, min(0.3, values[index])) * 0.5 + effect * 0.18 + confidence * 0.055 - repetition - risk)
                    path2 = path + [index]
                    future_states = predicted + [changed[:32]]
                    confidence2 = trust * max(0.25, confidence)
                    advanced.append((score, path2, changed, future_states, confidence2))
            if not advanced:
                break
            advanced.sort(key=lambda item: item[0] + 0.11 * item[4], reverse=True)
            beam = advanced[:4]
            candidates.extend(beam)
        candidates = [row for row in candidates if len(row[1]) >= 2 and row[4] >= 0.045]
        if not candidates:
            return [self.choose(obs)], []
        best = max(candidates, key=lambda item: item[0] / max(1.0, len(item[1]) ** 0.65) + 0.06 * item[4])
        return best[1], best[3]

    def mark_plan_result(self, indices, finish, feedback=None):
        if len(indices) < 2:
            return
        key = '|'.join(self.actions[i].id for i in indices)
        with self.lock:
            game = self.game
            source = self.games.get(self.last_skill_source or self.game_key, game)
            info = source.skills.get(key)
            if info is None:
                return
            info['attempts'] = info.get('attempts', 0) + 1
            goal = info.get('goal_features', [])
            succeeded = info.get('goal_signature') == finish.signature
            if not succeeded and len(goal) == 18:
                distance = sum((a - b) ** 2 for a, b in zip(goal, finish.features[:18])) / 18
                succeeded = distance < 0.0025 and finish.quality.get('trainable', False)
            evidence = feedback if isinstance(feedback, dict) else self.reward_info
            succeeded = succeeded and evidence.get('screen_result_confirmation') in ('win', 'task')
            game.plan_success[0] += 1
            if succeeded:
                info['successes'] = info.get('successes', 0) + 1
                game.plan_success[1] += 1
                info['quality'] = min(2.0, float(info.get('quality', 0.0)) * 0.92 + 0.08)
            elif info['attempts'] >= 3:
                info['quality'] = max(0.0, float(info.get('quality', 0.0)) * 0.985)

    def _update_world(self, game, key, differences):
        record = game.world.get(key)
        if record is None:
            error = sum(abs(v) for v in differences) / len(differences)
            game.world[key] = [differences[:], 1, error]
            progress = 0.0
        else:
            average, count, last_error = record
            error = sum(abs(v - avg) for v, avg in zip(differences, average)) / len(differences)
            progress = max(0.0, last_error - error) if count >= 3 else 0.0
            rate = 1.0 / min(45, count + 1)
            for i, value in enumerate(differences):
                average[i] = average[i] * (1 - rate) + value * rate
            record[1] += 1
            record[2] = last_error * 0.94 + error * 0.06
            game.world.move_to_end(key)
        while len(game.world) > 12500:
            game.world.popitem(last=False)
        return error, progress

    def objective_signal(self, game, old, new, causal, persistence, stability, semantic=None, confirmed=None):
        if len(old.hud_readouts) != 48 or len(new.hud_readouts) != 48:
            return 0.0, []
        reliable = causal * persistence * stability
        if reliable < 0.24:
            return 0.0, []
        weighted = []
        detected = []
        for index, (a, b) in enumerate(zip(old.hud_readouts, new.hud_readouts)):
            change = b - a
            if abs(change) < 0.12:
                continue
            key = str(index)
            record = game.hud_trends.get(key, [0, 0.0, 0.0, 0.0])
            count, up, down, confidence = record
            total = up + down
            if count >= 3 and total > 0.5:
                dominant = 1 if up > down else -1
                agreement = abs(up - down) / total
                if agreement >= 0.52:
                    confidence_weight = min(1.0, count / 8.0) * agreement * reliable
                    weighted.append(max(-0.085, min(0.085, change * dominant * confidence_weight * 0.30)))
            if confirmed in ('win', 'task', 'loss') and reliable > 0.24:
                evidence = reliable * (1.0 if confirmed != 'loss' else 0.75)
                desirable = change if confirmed != 'loss' else -change
                record[0] = min(1000000, int(count) + 1)
                record[1] = up + (evidence if desirable > 0 else 0.0)
                record[2] = down + (evidence if desirable < 0 else 0.0)
                record[3] = min(1.0, confidence * 0.9 + evidence * 0.1)
                game.hud_trends[key] = record
                game.hud_trends.move_to_end(key)
                detected.append({'region': index // 4, 'channel': ('colored', 'green', 'red', 'bright')[index % 4], 'direction': 'up' if change > 0 else 'down', 'delta': round(change, 4), 'examples': record[0]})
        for item in (semantic or {}).get('numeric_readout_changes', []):
            delta = int(item.get('delta', 0))
            if not delta or abs(delta) > 10000:
                continue
            key = f"number:{min(15, max(0, int(item['x'] * 16)))}:{min(9, max(0, int(item['y'] * 10)))}"
            direction = 1 if delta > 0 else -1
            record = game.hud_trends.get(key, [0, 0.0, 0.0, 0.0])
            count, up, down, trust = record
            if count >= 4 and up + down > 0.7:
                dominant = 1 if up > down else -1
                agreement = abs(up - down) / max(0.01, up + down)
                if agreement >= 0.62:
                    weighted.append(0.055 * direction * dominant * agreement * reliable * min(1.0, count / 12.0))
            if reliable >= 0.32:
                game.numeric_recent.append((key, direction, self.step))
        if confirmed in ('win', 'task', 'loss'):
            for key, direction, step in game.numeric_recent:
                age = max(0, self.step - step)
                evidence = max(0.05, 0.95 ** age) * reliable * (1.0 if confirmed != 'loss' else 0.7)
                if confirmed == 'loss':
                    direction = -direction
                record = game.hud_trends.get(key, [0, 0.0, 0.0, 0.0])
                record[0] = min(1000000, int(record[0]) + 1)
                record[1 if direction > 0 else 2] += evidence
                record[3] = min(1.0, float(record[3]) * 0.88 + evidence * 0.12)
                game.hud_trends[key] = record
                game.hud_trends.move_to_end(key)
            game.numeric_recent.clear()
        while len(game.hud_trends) > 160:
            game.hud_trends.popitem(last=False)
        return max(-0.16, min(0.16, sum(weighted))), detected[:12]

    def progress_evidence(self, old, new, causal, persistence, stability):
        reliability = max(0.0, min(1.0, causal * persistence * stability))
        changes = []
        for key, previous in old.hud_meters.items():
            current = new.hud_meters.get(key)
            if current is None or previous < 0.055 or abs(current - previous) < 0.012:
                continue
            movement = max(-1.0, min(1.0, (current - previous) / max(0.07, previous)))
            changes.append({'region': key, 'relative_delta': round(movement, 3)})
        observed_results = [item for item in new.ui_text if item['confidence'] >= 0.84]
        win_words = ('VICTORY', 'YOUWIN', 'WIN', 'WON', '获胜', '胜利', '通关')
        loss_words = ('DEFEAT', 'FAILED', 'GAMEOVER', 'YOULOSE', 'LOSE', 'LOSS', '失败', '战败', '游戏结束')
        task_words = ('SUCCESS', 'CLEAR', '任务完成', '完成任务', '挑战成功', '达标', '成功')
        result = None
        result_confidence = 0.0
        result_text = None
        def matched(text, words):
            return any((word in text if not word.isascii() else text == word or (len(word) >= 5 and text.endswith(word) and len(text) <= len(word) + 4)) for word in words)
        for item in observed_results:
            label = ''.join(c for c in item['text'].upper() if c.isalnum())
            candidate = None
            if matched(label, loss_words):
                candidate = 'loss_candidate'
            elif matched(label, win_words):
                candidate = 'win_candidate'
            elif matched(label, task_words):
                candidate = 'task_candidate'
            if candidate and item['confidence'] > result_confidence:
                result, result_confidence, result_text = candidate, item['confidence'], item['text']
        number_changes = []
        for item in new.ui_numbers:
            if item['confidence'] < 0.86:
                continue
            old_match = next((prior for prior in old.ui_numbers if prior['confidence'] >= 0.86
                              and abs(prior['x'] - item['x']) < 0.025 and abs(prior['y'] - item['y']) < 0.025), None)
            if old_match is None:
                continue
            difference = int(item['text']) - int(old_match['text'])
            if difference and abs(difference) < 100000:
                number_changes.append({'x': item['x'], 'y': item['y'], 'delta': difference})
        return 0.0, {
            'meter_changes': changes[:10], 'numeric_readout_changes': number_changes[:10],
            'result_text_candidate': result, 'result_text_confidence': round(result_confidence, 3), 'result_text': result_text,
            'recognized_text_candidates': [item['text'] for item in observed_results[:8]],
            'semantic_confidence': round(reliability, 3),
        }

    def reward_for(self, old, new, idx, effect=None, feedback=None):
        with self.lock:
            game = self.game
            self.dirty_games.add(self.game_key)
            self.dirty_sequence += 1
            delta = sum(abs(a - b) for a, b in zip(old.lum, new.lum)) / (GW * GH)
            low_information = bool(old.quality.get('low_information') or new.quality.get('low_information'))
            if not old.valid or not new.valid or old.game != new.game or low_information:
                self.reward_info = {'proxy_reward': 0.0, 'reward_basis': 'insufficient_visual_information' if low_information else 'capture_integrity_failed', 'visual_change': round(delta, 5), 'verified_win': None, 'verified_task_progress': None, 'input_effect_is_causal': None}
                return 0.0, delta
            signals = feedback or {}
            samples = [float(value) for value in signals.get('frame_deltas', []) if isinstance(value, (int, float)) and math.isfinite(value)]
            peak = max([delta] + samples)
            settled = float(signals.get('settled_change', delta))
            passive = game.passive_change if game.passive_samples else 0.0
            background = max(passive * 1.45, game.baseline_change * 0.28, 0.0025)
            effective = max(0.0, peak - background)
            causal = max(0.0, min(1.0, effective / max(0.012, peak)))
            causal *= max(0.0, min(1.0, peak / 0.045))
            if game.passive_samples == 0:
                causal *= 0.65
            persistence = max(0.0, min(1.0, settled / max(0.015, peak)))
            causal *= 0.7 + 0.3 * persistence
            game.baseline_change = game.baseline_change * 0.975 + delta * 0.025
            differences = [new.features[k] - old.features[k] for k in range(32)]
            prediction_error, first_progress = self._update_world(game, idx, differences)
            conditional_error, conditional_progress = self._update_world(game, self._world_key(idx, old), differences)
            learning_progress = max(first_progress * 0.5, conditional_progress)
            if effective < max(0.008, passive * 0.4):
                game.stagnation += 1
            else:
                game.stagnation = max(0, game.stagnation - 2)
            trajectory = f'{old.signature}:{idx}:{new.signature}'
            seen = game.trajectories.get(trajectory, 0)
            game.trajectories[trajectory] = seen + 1
            game.trajectories.move_to_end(trajectory)
            if len(game.trajectories) > 12000:
                game.trajectories.popitem(last=False)
            hud_indices = [r * GW + c for r in (0, 1, GH - 2, GH - 1) for c in range(GW)]
            center_indices = [r * GW + c for r in range(3, GH - 3) for c in range(GW)]
            hud_change = sum(abs(old.lum[i] - new.lum[i]) for i in hud_indices) / len(hud_indices)
            center_change = sum(abs(old.lum[i] - new.lum[i]) for i in center_indices) / max(1, len(center_indices))
            event = None
            event_strength = 0.0
            stable_hud = float(signals.get('hud_stability', 1.0))
            stable_scene = max(0.0, min(1.0, float(signals.get('frame_stability', 0.0))))
            if hud_change > background + 0.038 and hud_change > center_change * 1.35 and causal > 0.28 and stable_hud > 0.55 and stable_scene > 0.55 and len(samples) >= 3:
                sections = []
                for rows in ((0, 1), (GH - 2, GH - 1)):
                    for left in (0, GW // 2):
                        indices = [r * GW + c for r in rows for c in range(left, left + GW // 2)]
                        sections.append(min(9, int(sum(abs(old.lum[i] - new.lum[i]) for i in indices) * 28 / len(indices))))
                signature = ':'.join(map(str, sections))
                record = game.candidate_events.get(signature, [0, 0.0])
                record[0] += 1
                record[1] = record[1] * 0.82 + causal * stable_hud * 0.18
                game.candidate_events[signature] = record
                game.candidate_events.move_to_end(signature)
                while len(game.candidate_events) > 350:
                    game.candidate_events.popitem(last=False)
                event = 'persistent_action_correlated_hud_change'
                event_strength = min(1.0, hud_change * 3.5) * min(0.80, 0.12 + 0.06 * record[0]) * record[1] * stable_scene
            discovery = min(1.0, effective * 9.0) * max(0.0, new.novelty - 0.20) * causal
            mastery = min(1.0, learning_progress * 7.0) * (0.3 + 0.7 * causal)
            no_effect = effective < 0.008 or causal < 0.06
            loop_count = sum(1 for signature in game.scene_history if signature == new.signature)
            repeated = min(0.115, 0.022 * math.log1p(seen) + 0.012 * max(0, loop_count - 2))
            meaningful_event = event_strength * min(1.0, persistence * 1.4) * max(0.0, 1.0 - min(0.85, seen * 0.16))
            new_scene_persistent = new.signature != old.signature and settled >= max(0.025, peak * 0.6) and causal > 0.25 and stable_scene > 0.65
            scene_progress = min(1.0, persistence * 1.2) * new.novelty * causal * stable_scene if new_scene_persistent and loop_count < 3 else 0.0
            goal_candidate = max(meaningful_event * 0.65, scene_progress * 0.14)
            progress_landmark = 0.0
            landmark = old.signature + '>' + new.signature
            if old.signature != new.signature and causal > 0.40 and stable_scene > 0.62 and persistence > 0.42 and loop_count <= 3:
                item = game.goal_landmarks.get(landmark, [0, 0.0, 0.0])
                item[0] += 1
                item[1] = item[1] * 0.84 + 0.16 * causal * stable_scene
                item[2] = item[2] * 0.84 + 0.16 * persistence
                game.goal_landmarks[landmark] = item
                game.goal_landmarks.move_to_end(landmark)
                while len(game.goal_landmarks) > 800:
                    game.goal_landmarks.popitem(last=False)
                progress_landmark = min(0.12, 0.04 * item[1] * item[2] / math.sqrt(max(1, item[0])))
            explicit_proxy, semantic_evidence = self.progress_evidence(old, new, causal, persistence, stable_scene)
            result_label = semantic_evidence['result_text_candidate']
            result_confidence = float(semantic_evidence['result_text_confidence'])
            result_key = new.signature + ':' + str(result_label) + ':' + str(self.step)
            if result_label and result_confidence >= 0.86:
                game.result_misses = 0
                previous_labels = {''.join(c for c in item['text'].upper() if c.isalnum()) for item in old.ui_text if item.get('confidence', 0) >= 0.84}
                new_result_words = semantic_evidence.get('result_text') or ''
                normalized_result = ''.join(c for c in new_result_words.upper() if c.isalnum())
                appeared = bool(normalized_result and normalized_result not in previous_labels)
                result_item = next((item for item in new.ui_text if item.get('text') == new_result_words), None)
                point = (float(result_item['x']), float(result_item['y'])) if result_item else None
                aligned = bool(point and game.result_position and abs(point[0] - game.result_position[0]) < 0.045
                               and abs(point[1] - game.result_position[1]) < 0.05)
                if game.result_label == result_label and game.result_scene == new.signature and aligned:
                    game.result_streak += 1
                else:
                    if game.result_label is not None and game.result_label != result_label:
                        game.result_active = False
                    game.result_label, game.result_scene, game.result_streak = result_label, new.signature, 1
                    game.result_appeared = appeared
                    game.result_position = point
            else:
                game.result_misses += 1
                game.result_streak = 0
                if game.result_misses >= 3:
                    game.result_label = None
                    game.result_scene = None
                    game.result_active = False
                    game.result_appeared = False
                    game.result_position = None
            confirmed_result = None
            if (game.result_streak >= 3 and game.result_appeared and not game.result_active and result_confidence >= 0.89
                    and stable_scene >= 0.58 and len(samples) >= 2 and persistence >= 0.60
                    and old.frame_uid != new.frame_uid and new.quality.get('trainable', False)):
                confirmed_result = 'loss' if result_label == 'loss_candidate' else 'win' if result_label == 'win_candidate' else 'task'
                game.result_active = True
                game.confirmed_results[result_key] = confirmed_result
                game.confirmed_results.move_to_end(result_key)
                while len(game.confirmed_results) > 96:
                    game.confirmed_results.popitem(last=False)
                game.screen_outcomes[confirmed_result] += 1
                explicit_proxy += (-0.92 if confirmed_result == 'loss' else 0.90 if confirmed_result == 'win' else 0.72) * result_confidence
            semantic_evidence['result_streak'] = game.result_streak
            semantic_evidence['result_first_appeared_after_action'] = game.result_appeared
            semantic_evidence['screen_result_confirmed'] = confirmed_result
            semantic_evidence['screen_result_is_game_truth'] = False
            goal_candidate = max(goal_candidate * 0.55, max(0.0, explicit_proxy))
            task_signal, hud_signals = self.objective_signal(game, old, new, causal, persistence, stable_scene,
                                                            semantic_evidence, confirmed_result)
            game.goal_evidence.append((new.signature, goal_candidate, causal))
            discovery *= min(1.0, persistence * 1.7) if peak > 0.02 else 0.0
            mastery *= causal if not no_effect else 0.0
            intrinsic_reward = (0.010 * discovery + 0.008 * mastery) * (0.15 if explicit_proxy < -0.02 else 1.0)
            objective_proxy = max(-0.12, min(0.12, task_signal)) + explicit_proxy
            proxy_exploration = min(0.018, 0.010 * meaningful_event + 0.008 * progress_landmark)
            recurring_without_progress = (loop_count >= 3 and confirmed_result is None
                                           and max(0.0, task_signal) < 0.008 and meaningful_event < 0.03)
            if recurring_without_progress:
                intrinsic_reward *= 0.30
                proxy_exploration *= 0.20
            repetition_penalty = repeated * (0.60 if recurring_without_progress else 0.35)
            reward = (intrinsic_reward + objective_proxy + proxy_exploration - repetition_penalty
                      - (0.018 if no_effect else 0.0) - (0.012 if game.stagnation > 24 else 0.0))
            if new.signature == old.signature and causal < 0.24:
                reward -= 0.025
            if loop_count >= 4 and meaningful_event < 0.03 and new.novelty < 0.36:
                reward -= min(0.055, 0.012 * (loop_count - 3))
            if confirmed_result == 'win':
                reward = 0.92 + min(0.04, max(-0.04, reward * 0.05))
            elif confirmed_result == 'task':
                reward = 0.74 + min(0.04, max(-0.04, reward * 0.05))
            elif confirmed_result == 'loss':
                reward = -0.94 + min(0.04, max(-0.04, reward * 0.05))
            quality = min(float(old.quality.get('confidence', 1.0)), float(new.quality.get('confidence', 1.0)))
            reward = max(-1.0, min(1.0, reward * quality))
            terminal_confidence = (causal * stable_scene * min(1.0, persistence * 1.2)
                                   * min(1.0, (hud_change + center_change) * 3.2)
                                   * min(1.0, delta * 4.0)) if new_scene_persistent else 0.0
            result_boundary = bool(confirmed_result)
            episode_boundary = bool(result_boundary)
            measured_effect = max(-0.30, min(1.0, effective * 6.0 * causal - (0.12 if no_effect else 0.0)
                                              + min(0.22, explicit_proxy * 1.4)))
            prior_samples = game.action_effect_samples[idx]
            rate = 1.0 / min(24, prior_samples + 1)
            game.action_effect[idx] += (measured_effect - game.action_effect[idx]) * rate
            game.action_effect_samples[idx] = prior_samples + 1
            family = self.family_for_action[idx]
            family_stats = game.family_score.setdefault(family, [0, 0.0])
            family_stats[0] += 1
            family_stats[1] = family_stats[1] * 0.93 + measured_effect * 0.07
            if effect is not None and effect.get('spatial'):
                u, v = float(effect.get('start_x', effect.get('x', 0.5))), float(effect.get('start_y', effect.get('y', 0.5)))
                key = f'{min(GW - 1, max(0, int(u * GW)))}:{min(GH - 1, max(0, int(v * GH)))}'
                target = game.targets.get(key, [0.0, 0])
                target[0] = target[0] * 0.87 + max(0.0, measured_effect) * 0.13
                target[1] += 1
                game.targets[key] = target
                game.targets.move_to_end(key)
                while len(game.targets) > 720:
                    game.targets.popitem(last=False)
            early = samples[0] if samples else delta
            if len(samples) > 1:
                desired = 0.16 if samples[-1] > early * 1.4 and samples[-1] > 0.015 else 0.065
                game.feedback_delay = min(0.3, max(0.035, game.feedback_delay * 0.94 + desired * 0.06))
            self.reward_info = {
                'proxy_reward': round(reward, 5),
                'reward_basis': 'persistent_screen_result_unverified_by_game' if confirmed_result else 'weak_exploration_and_outcome_calibrated_hud_signals_not_verified',
                'visual_change': round(delta, 5),
                'passive_visual_change': round(passive, 5),
                'peak_action_visual_change': round(peak, 5),
                'estimated_action_effect': round(effective, 5),
                'causal_confidence': round(causal, 4),
                'feedback_samples': len(samples),
                'feedback_latency': round(game.feedback_delay, 4),
                'novelty': round(new.novelty, 4),
                'visual_discovery': round(discovery, 5),
                'hud_proxy': round(new.hud - old.hud, 5),
                'hud_visual_change': round(hud_change, 5),
                'candidate_event': event,
                'goal_progress_candidate': round(goal_candidate, 5),
                'recurring_without_confirmed_progress': recurring_without_progress,
                'objective_evidence': semantic_evidence,
                'intrinsic_reward_component': round(intrinsic_reward * quality, 5),
                'objective_reward_proxy': round(objective_proxy * quality, 5),
                'learned_hud_trend_signal': round(task_signal * quality, 5),
                'hud_readout_changes': hud_signals,
                'task_reward_basis': 'hud_patterns_calibrated_only_from_confirmed_screen_outcomes_not_game_verified',
                'persistent_landmark_evidence': round(progress_landmark, 5),
                'learned_landmark_count': len(game.goal_landmarks),
                'goal_evidence': 'unverified_persistent_hud_or_scene_change' if goal_candidate > 0.025 else 'no_verifiable_goal_signal',
                'reward_components': {'exploration': round(intrinsic_reward + proxy_exploration, 5), 'persistent_hud_proxy': 0.0, 'scene_proxy': round(proxy_exploration, 5), 'visual_semantic_proxy': round(explicit_proxy, 5), 'learned_hud_trend': round(task_signal, 5), 'repetition_penalty': round(repetition_penalty, 5)},
                'scene_stability': round(stable_scene, 4),
                'episode_boundary_candidate_confidence': round(terminal_confidence, 4),
                'episode_boundary': episode_boundary,
                'episode_boundary_reason': 'persistent_locally_recognized_result_text_not_game_verified' if result_boundary else None,
                'scene_before': old.quality.get('scene'),
                'scene_after': new.quality.get('scene'),
                'scene_loop_visits': loop_count,
                'persistent_visual_change': round(persistence, 5),
                'prediction_error': round(prediction_error, 5),
                'conditional_prediction_error': round(conditional_error, 5),
                'learning_progress': round(learning_progress, 5),
                'repeated_transition': seen,
                'observation_confidence': round(quality, 3),
                'verified_win': None,
                'screen_outcome_totals': dict(game.screen_outcomes),
                'screen_result_confirmation': confirmed_result,
                'verified_task_progress': None,
                'input_effect_is_causal': None,
                'input_effect_causality_proxy': round(causal, 4),
            }
            return reward, delta

    def record_action_result(self, index, detail, reward):
        if not detail:
            return
        action = self.actions[index]
        game = self.game
        if detail.get('input_sent') and (detail.get('spatial') or action.kind in ('key', 'hold', 'chord', 'combat', 'aim', 'look', 'wheel')):
            game.ensure_parameter_head(action.kind, self.hidden_size)
        duration = float(detail.get('requested_duration', action.duration))
        if detail.get('finished', True) and math.isfinite(duration) and math.isfinite(reward):
            choices = (0.065, 0.12, 0.24, 0.48, 0.9, 1.45) if action.kind in ('key', 'hold', 'pair_hold', 'chord') else (0.12, 0.28, 0.55, 0.95, 1.4) if action.kind in ('press', 'swipe', 'right_swipe', 'combat', 'move_fire', 'aim', 'look', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch') else (action.duration,)
            selected = min(choices, key=lambda value: abs(value - duration))
            label = f'{action.kind}:{action.a}:{action.b}:{round(selected, 3)}'
            prior = game.duration_stats.get(label, [0.0, 0])
            count = int(prior[1]) + 1
            prior[0] += (max(-1.0, min(1.0, reward)) - prior[0]) / min(24, count)
            prior[1] = count
            game.duration_stats[label] = prior
        if not detail.get('spatial'):
            return
        x = float(detail.get('start_x', detail.get('x', 0.5)))
        y = float(detail.get('start_y', detail.get('y', 0.5)))
        duration = float(detail.get('duration', action.duration))
        if not all(map(math.isfinite, (x, y, duration, reward))):
            return
        col = min(GW - 1, max(0, int(x * GW)))
        row = min(GH - 1, max(0, int(y * GH)))
        key = f'{action.kind}:{col}:{row}'
        old = game.parameter_stats.get(key, [0.0, 0, 0.0])
        count = int(old[1]) + 1
        rate = 1.0 / min(24, count)
        quality = 0.3 if detail.get('interrupted') else 1.0
        old[0] += (max(-1.0, min(1.0, reward)) - old[0]) * rate * quality
        old[2] += (max(0.0, float(self.reward_info.get('causal_confidence', 0.0))) - old[2]) * rate
        old[1] = count
        game.parameter_stats[key] = old
        game.parameter_stats.move_to_end(key)
        while len(game.parameter_stats) > 3200:
            game.parameter_stats.popitem(last=False)
    def recover_backend(self):
        with self.lock:
            previous = self.np
            if previous is None:
                return False
            target = None
            if getattr(previous, '__name__', '') == 'cupy':
                try:
                    cpu = importlib.import_module('numpy')
                    if validate_learning_backend(cpu):
                        target = cpu
                except Exception:
                    target = None
            def convert(value):
                if getattr(value, 'get', None) is not None:
                    value = value.get()
                if hasattr(value, 'tolist'):
                    value = value.tolist()
                return target.asarray(value, dtype=target.float32) if target is not None else value
            encoder = convert(self.encoder)
            encoder_bias = convert(self.encoder_bias)
            target_encoder = convert(self.target_encoder)
            target_encoder_bias = convert(self.target_encoder_bias)
            converted = {}
            for key, game in self.games.items():
                converted[key] = (convert(game.q), convert(game.bias), convert(game.target_q), convert(game.target_bias),
                                  {kind: (convert(head['w']), convert(head['b']), head['samples']) for kind, head in game.parameter_heads.items()})
            self.np = target
            try:
                self.cv_np = importlib.import_module('numpy') if target is None else target
            except ImportError:
                self.cv_np = None
            self.encoder, self.encoder_bias = encoder, encoder_bias
            self.target_encoder, self.target_encoder_bias = target_encoder, target_encoder_bias
            for key, values in converted.items():
                game = self.games[key]
                game.np = target
                game.q, game.bias, game.target_q, game.target_bias = values[:4]
                game.parameter_heads = {kind: {'w': w, 'b': b, 'samples': samples} for kind, (w, b, samples) in values[4].items()}
            self.backend_generation += 1
            self.backend_recoveries += 1
            self.dirty_games.update(self.games)
            self.dirty_sequence += 1
            self.training_problem = None
            self.training_failures = 0
            return True

    def ensure_workers(self):
        if not self.storage_stop.is_set() and not self.storage_thread.is_alive():
            self.storage_thread = threading.Thread(target=self.storage_loop, name='AgentStorage', daemon=True)
            self.storage_thread.start()
            with self.storage_condition:
                self.storage_force = True
                self.storage_condition.notify_all()
        if not self.training_stop.is_set() and not self.trainer.is_alive():
            self.trainer = threading.Thread(target=self.training_loop, name='AgentLearner', daemon=True)
            self.trainer.start()

    def _training_snapshot(self, samples):
        snapshot = {
            'backend_generation': self.backend_generation,
            'encoder': self.encoder.copy() if self.np is not None else [row[:] for row in self.encoder],
            'encoder_bias': self.encoder_bias.copy() if self.np is not None else self.encoder_bias[:],
            'target_encoder': self.target_encoder,
            'target_encoder_bias': self.target_encoder_bias,
            'games': {},
        }
        for sample in samples:
            if len(sample) > 9 and isinstance(sample[9], dict) and sample[9].get('input_sent'):
                owner = self.games.get(sample[0])
                if owner is not None and isinstance(sample[2], int) and 0 <= sample[2] < len(self.actions):
                    owner.ensure_parameter_head(self.actions[sample[2]].kind, self.hidden_size)
        for key in {sample[0] for sample in samples}:
            game = self.games.get(key)
            if game is None:
                continue
            snapshot['games'][key] = {
                'q': game.q.copy() if self.np is not None else [row[:] for row in game.q],
                'bias': game.bias.copy() if self.np is not None else game.bias[:],
                'target_q': game.target_q,
                'target_bias': game.target_bias,
                'counts': game.counts[:],
                'parameter_heads': {kind: {'w': head['w'].copy() if self.np is not None else [row[:] for row in head['w']],
                                           'b': head['b'].copy() if self.np is not None else head['b'][:],
                                           'samples': int(head.get('samples', 0))} for kind, head in game.parameter_heads.items()},
            }
        return snapshot

    def _training_values(self, features, snapshot, game, target=False, include_hidden=False):
        encoder = snapshot['target_encoder'] if target else snapshot['encoder']
        encoder_bias = snapshot['target_encoder_bias'] if target else snapshot['encoder_bias']
        matrix = game['target_q'] if target else game['q']
        bias = game['target_bias'] if target else game['bias']
        if self.np is not None:
            x = self.np.asarray(features, dtype=self.np.float32)
            hidden = self.np.tanh(encoder @ x + encoder_bias)
            values = matrix @ hidden + bias
        else:
            hidden = [math.tanh(sum(w * x for w, x in zip(row, features)) + encoder_bias[j]) for j, row in enumerate(encoder)]
            values = [sum(w * value for w, value in zip(row, hidden)) + bias[i] for i, row in enumerate(matrix)]
        return (values, hidden) if include_hidden else values

    def _train_parameter(self, transition, snapshot, game):
        if len(transition) < 10 or not isinstance(transition[9], dict):
            return
        detail = transition[9]
        if not detail.get('input_sent') or not detail.get('finished') or detail.get('interrupted'):
            return
        reward = float(transition[3])
        confidence = max(0.0, min(1.0, float(transition[8]))) if len(transition) > 8 else 0.65
        if not math.isfinite(reward) or reward <= 0.008 or confidence < 0.25:
            return
        kind = self.actions[transition[2]].kind if 0 <= transition[2] < len(self.actions) else None
        head = game['parameter_heads'].get(kind)
        if head is None:
            return
        try:
            x = float(detail.get('start_x', detail.get('x', 0.5)))
            y = float(detail.get('start_y', detail.get('y', 0.5)))
            duration = float(detail.get('requested_duration', detail.get('duration', 0.2)))
            extent = float(detail.get('extent', 1.0))
        except (ValueError, TypeError):
            return
        if not all(math.isfinite(v) for v in (x, y, duration, extent)):
            return
        target = [min(1.0, max(0.0, x)), min(1.0, max(0.0, y)),
                  min(1.0, max(0.0, (duration - 0.04) / 1.46)),
                  min(1.0, max(0.0, extent - 0.5))]
        spatial = bool(detail.get('spatial'))
        moving = kind in ('swipe', 'right_swipe', 'look', 'touch_swipe', 'pinch', 'dual_touch')
        mask = [spatial, spatial, True, moving]
        force = min(1.0, reward * 4.0) * confidence
        if self.np is not None:
            before = self.np.asarray(transition[1], dtype=self.np.float32)
            hidden = self.np.tanh(snapshot['encoder'] @ before + snapshot['encoder_bias'])
            output = 0.5 + 0.5 * self.np.tanh(head['w'] @ hidden + head['b'])
            residual = (self.np.asarray(target, dtype=self.np.float32) - output) * self.np.asarray(mask, dtype=self.np.float32)
            old_logits = self.np.clip(2.0 * output - 1.0, -0.99, 0.99)
            update = residual * (1.0 - old_logits * old_logits) * (0.10 * force)
            head['w'] += self.np.outer(update, hidden)
            head['b'] += update
            self.np.clip(head['w'], -1.5, 1.5, out=head['w'])
            self.np.clip(head['b'], -3.0, 3.0, out=head['b'])
        else:
            hidden = [math.tanh(sum(weight * v for weight, v in zip(row, transition[1])) + snapshot['encoder_bias'][i]) for i, row in enumerate(snapshot['encoder'])]
            for i in range(4):
                if not mask[i]:
                    continue
                projected = sum(w * v for w, v in zip(head['w'][i], hidden)) + head['b'][i]
                tanh_value = math.tanh(projected)
                update = (target[i] - 0.5 - 0.5 * tanh_value) * (1.0 - tanh_value * tanh_value) * 0.10 * force
                for j, value in enumerate(hidden):
                    head['w'][i][j] = max(-1.5, min(1.5, head['w'][i][j] + update * value))
                head['b'][i] = max(-3.0, min(3.0, head['b'][i] + update))
        head['samples'] = min(10000000, head['samples'] + 1)

    def _train_one(self, transition, snapshot):
        game_key, before, index, reward, after, _, done, horizon = transition[:8]
        confidence = max(0.0, min(1.0, float(transition[8]))) if len(transition) > 8 else 0.65
        game = snapshot['games'].get(game_key)
        if game is None:
            return None
        future = 0.0
        if not done:
            online_future = self._training_values(after, snapshot, game)
            if self.np is not None:
                best = int(self.np.argmax(online_future))
                future = float(self._training_values(after, snapshot, game, target=True)[best])
            else:
                best = max(range(len(online_future)), key=online_future.__getitem__)
                future = self._training_values(after, snapshot, game, target=True)[best]
        target_value = max(-3.0, min(3.0, reward + (DISCOUNT ** horizon) * future))
        prediction, hidden = self._training_values(before, snapshot, game, include_hidden=True)
        error = max(-1.5, min(1.5, target_value - float(prediction[index])))
        learn_rate = 0.018 * (0.22 + 0.78 * confidence) / (1.0 + game['counts'][index] / 14000.0)
        encoder_rate = 0.00085 * (0.22 + 0.78 * confidence)
        encoder = snapshot['encoder']
        encoder_bias = snapshot['encoder_bias']
        if self.np is not None:
            old_head = game['q'][index].copy()
            game['q'][index] += hidden * (learn_rate * error)
            game['bias'][index] += learn_rate * error
            gradient = old_head * (1.0 - hidden * hidden) * error
            encoder += encoder_rate * self.np.outer(gradient, self.np.asarray(before, dtype=self.np.float32))
            encoder_bias += encoder_rate * gradient
            self.np.clip(game['q'][index], -2.5, 2.5, out=game['q'][index])
            self.np.clip(encoder, -1.2, 1.2, out=encoder)
        else:
            old_head = game['q'][index][:]
            for j, value in enumerate(hidden):
                game['q'][index][j] = max(-2.5, min(2.5, old_head[j] + learn_rate * error * value))
            game['bias'][index] = max(-3.0, min(3.0, game['bias'][index] + learn_rate * error))
            for j, value in enumerate(hidden):
                derivative = encoder_rate * old_head[j] * (1 - value * value) * error
                if abs(derivative) < 1e-10:
                    continue
                row = encoder[j]
                for k, feature in enumerate(before):
                    row[k] = max(-1.2, min(1.2, row[k] + derivative * feature))
                encoder_bias[j] = max(-1.2, min(1.2, encoder_bias[j] + derivative))
        self._train_parameter(transition, snapshot, game)
        return abs(error)

    def _train_batch(self, samples, snapshot):
        if self.np is None:
            return [(transition, error) for transition in samples if (error := self._train_one(transition, snapshot)) is not None]
        np = self.np
        grouped = {}
        for transition in samples:
            if transition[0] in snapshot['games']:
                grouped.setdefault(transition[0], []).append(transition)
        results = []
        for game_key, batch in grouped.items():
            game = snapshot['games'][game_key]
            before = np.asarray([item[1] for item in batch], dtype=np.float32)
            after = np.asarray([item[4] for item in batch], dtype=np.float32)
            actions = np.asarray([item[2] for item in batch], dtype=np.int32)
            rewards = np.asarray([item[3] for item in batch], dtype=np.float32)
            horizons = np.asarray([item[7] for item in batch], dtype=np.float32)
            dones = np.asarray([bool(item[6]) for item in batch], dtype=np.float32)
            confidence = np.asarray([max(0.0, min(1.0, float(item[8]) if len(item) > 8 else 0.65)) for item in batch], dtype=np.float32)
            priorities = np.asarray([max(0.025, float(item[5])) for item in batch], dtype=np.float32)
            hidden = np.tanh(before @ snapshot['encoder'].T + snapshot['encoder_bias'])
            next_online = np.tanh(after @ snapshot['encoder'].T + snapshot['encoder_bias'])
            best = np.argmax(next_online @ game['q'].T + game['bias'], axis=1)
            next_target = np.tanh(after @ snapshot['target_encoder'].T + snapshot['target_encoder_bias'])
            future = np.sum(next_target * game['target_q'][best], axis=1) + game['target_bias'][best]
            discounted = np.power(np.float32(DISCOUNT), horizons)
            targets = np.clip(rewards + (1.0 - dones) * discounted * future, -3.0, 3.0)
            old_head = game['q'][actions].copy()
            predicted = np.sum(hidden * old_head, axis=1) + game['bias'][actions]
            errors = np.clip(targets - predicted, -1.5, 1.5)
            weights = np.clip(np.sqrt(0.14 / priorities), 0.35, 1.5) * (0.22 + 0.78 * confidence)
            count = np.asarray([game['counts'][item[2]] for item in batch], dtype=np.float32)
            rates = np.float32(0.018) * weights / (1.0 + count / 14000.0)
            corrections = rates * errors / max(1.0, math.sqrt(len(batch) / 4.0))
            np.add.at(game['q'], actions, corrections[:, None] * hidden)
            np.add.at(game['bias'], actions, corrections)
            derivative = (old_head * (1.0 - hidden * hidden)) * (errors * weights)[:, None]
            scale = np.float32(0.00085 / max(1.0, len(batch)))
            snapshot['encoder'] += scale * (derivative.T @ before)
            snapshot['encoder_bias'] += scale * np.sum(derivative, axis=0)
            np.clip(game['q'], -2.5, 2.5, out=game['q'])
            np.clip(game['bias'], -3.0, 3.0, out=game['bias'])
            np.clip(snapshot['encoder'], -1.2, 1.2, out=snapshot['encoder'])
            np.clip(snapshot['encoder_bias'], -1.2, 1.2, out=snapshot['encoder_bias'])
            for transition in batch:
                self._train_parameter(transition, snapshot, game)
            error_values = np.asnumpy(np.abs(errors)).tolist() if getattr(np, '__name__', '') == 'cupy' else np.abs(errors).tolist()
            results.extend((item, float(error)) for item, error in zip(batch, error_values))
        return results

    def _commit_training(self, snapshot, results):
        with self.lock:
            if snapshot.get('backend_generation', self.backend_generation) != self.backend_generation:
                self.training_stale_batches += 1
                return False
            arrays = [snapshot['encoder'], snapshot['encoder_bias']]
            for state in snapshot['games'].values():
                arrays.extend((state['q'], state['bias']))
                for head in state['parameter_heads'].values():
                    arrays.extend((head['w'], head['b']))
            if self.np is not None:
                if not all(bool(self.np.all(self.np.isfinite(array))) for array in arrays):
                    raise ArithmeticError('学习批次出现非有限参数，拒绝提交模型')
            else:
                for array in arrays:
                    if not all(math.isfinite(float(value)) for entry in array for value in (entry if isinstance(entry, list) else (entry,))):
                        raise ArithmeticError('学习批次出现非有限参数，拒绝提交模型')
            self.encoder = snapshot['encoder']
            self.encoder_bias = snapshot['encoder_bias']
            for key, state in snapshot['games'].items():
                game = self.games.get(key)
                if game is not None:
                    game.q = state['q']
                    game.bias = state['bias']
                    game.parameter_heads = state['parameter_heads']
                    self.dirty_games.add(key)
                    self.dirty_sequence += 1
            prior = self.updates // 160
            for transition, error in results:
                if isinstance(transition, list):
                    transition[5] = max(0.025, min(2.5, error + 0.04))
                self.updates += 1
                self.td_error_ema = 0.975 * self.td_error_ema + 0.025 * error
            if self.updates // 160 != prior:
                self.sync_target()
            return True

    def enqueue_training(self, transition):
        self.memory.append(transition)
        if len(self.training_queue) >= self.training_queue.maxlen:
            self.training_queue_evictions += 1
        self.training_queue.append(transition)
        self.training_condition.notify()

    def _connect_store(self):
        if self.store is not None:
            return True
        if time.monotonic() < self.store_reconnect_at:
            return False
        try:
            self.store = ReplayStore(self.folder)
            self.db_preflight_verified = self.store.verify_roundtrip()
            self.store_failures = 0
            self.store_reconnect_at = 0.0
            self.db_transitions_last_known = self.store.total_transitions
            self.store_roundtrip_verified = self.store.first_commit_verified
            return True
        except Exception as exc:
            if self.store is not None:
                try:
                    self.store.close()
                except Exception:
                    try:
                        self.store.db.close()
                    except Exception:
                        pass
                self.store = None
            if quarantine_corrupt_store(self.folder, exc):
                try:
                    self.store = ReplayStore(self.folder)
                    self.db_preflight_verified = self.store.verify_roundtrip()
                    self.store_problem = '已隔离损坏的经验数据库，原数据文件保存在工作目录内'
                    self.store_failures = 0
                    self.store_reconnect_at = 0.0
                    self.db_transitions_last_known = self.store.total_transitions
                    self.store_roundtrip_verified = self.store.first_commit_verified
                    return True
                except Exception as recovery:
                    exc = recovery
            self.store_failures += 1
            self.store_reconnect_at = time.monotonic() + min(60.0, 2.0 ** min(self.store_failures, 6))
            self.store_problem = f'经验数据库初始化或重连失败：{type(exc).__name__}: {exc}'
            if self.store is not None:
                try:
                    self.store.close()
                except Exception:
                    pass
                self.store = None
            return False

    def _store_failure(self, exc):
        self.store_problem = f'经验数据库写入失败，将重试：{type(exc).__name__}: {exc}'
        self.store_failures += 1
        self.store_reconnect_at = time.monotonic() + min(60.0, 2.0 ** min(self.store_failures, 6))
        if self.store is not None:
            self.db_transitions_last_known = self.store.total_transitions
            try:
                self.store.db.rollback()
                self.store.db.close()
            except Exception:
                pass
            self.store = None

    def _journal_event(self, entry, identity=None):
        try:
            encoded = (json.dumps(entry, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
            with self.spool_lock:
                with self.spool_path.open('ab') as stream:
                    stream.write(encoded)
                    stream.flush()
                    os.fsync(stream.fileno())
                if identity is not None:
                    self.journal_unwritten.pop(identity, None)
                self.journaled_transitions += int(isinstance(entry, (tuple, list)))
            return True
        except (OSError, ValueError, TypeError, OverflowError) as exc:
            with self.spool_lock:
                if identity is not None:
                    self.journal_unwritten[identity] = entry
                self.journal_failures += 1
            self.store_problem = f'经验日志落盘失败，内存队列保留并等待重试：{type(exc).__name__}: {exc}'
            return False

    def _retry_journal(self):
        with self.storage_condition:
            pending = list(self.journal_unwritten.items())[:160]
            for identity, entry in pending:
                self._journal_event(entry, identity)

    def _append_persist(self, transition, change=0.0):
        detail = transition[9].copy() if len(transition) > 9 and isinstance(transition[9], dict) else {}
        if not isinstance(detail.get('uid'), str):
            detail['uid'] = uuid.uuid4().hex
        if len(transition) > 9 and isinstance(transition[9], dict):
            transition[9]['uid'] = detail['uid']
        row = (canonical_game_key(transition[0]), self.actions[transition[2]].id, float(transition[3]), transition[1][:], transition[4][:], float(change), bool(transition[6]), int(transition[7]), float(transition[5]), float(transition[8]) if len(transition) > 8 else 0.65, detail)
        self._journal_event(row, detail['uid'])
        while len(self.persist_backlog) >= 12000:
            oldest = self.persist_backlog[0]
            old_uid = oldest[10].get('uid')
            if old_uid in self.journal_unwritten:
                self._journal_event(oldest, old_uid)
            if old_uid in self.journal_unwritten:
                self.journal_unwritten.pop(old_uid, None)
                self.dropped_unpersisted += 1
                self.store_problem = '经验日志所在磁盘不可写，达到内存上限后有未落盘记录被丢弃；请检查工作目录磁盘空间和权限'
            else:
                self.spilled_transitions += 1
            self.persist_backlog.popleft()
        self.persist_backlog.append(row)

    def _drain_spool(self):
        with self.spool_lock:
            if not self.spool_path.exists() or self.spool_path.stat().st_size == 0:
                return
            temp = self.folder / 'experience_overflow.jsonl.tmp'
            valid_rows = []
            terminal_rows = []
            invalid = []
            with self.spool_path.open('rb') as source:
                for _ in range(128):
                    data = source.readline()
                    if not data:
                        break
                    try:
                        row = json.loads(data)
                        if (isinstance(row, list) and len(row) == 11 and isinstance(row[0], str)
                                and row[1] in self.action_index and isinstance(row[3], list) and isinstance(row[4], list)
                                and len(row[3]) in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)
                                and len(row[4]) in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)):
                            row[0] = canonical_game_key(row[0])
                            row[3] = row[3][:FEATURE_COUNT] + [0.0] * max(0, FEATURE_COUNT - len(row[3]))
                            row[4] = row[4][:FEATURE_COUNT] + [0.0] * max(0, FEATURE_COUNT - len(row[4]))
                            valid_rows.append(row)
                        elif isinstance(row, dict) and isinstance(row.get('terminal_uid'), str) and 12 <= len(row['terminal_uid']) <= 80:
                            terminal_rows.append(row)
                        else:
                            invalid.append(data)
                    except (json.JSONDecodeError, UnicodeDecodeError, TypeError, ValueError):
                        invalid.append(data)
                if valid_rows:
                    inserted = self.store.add_many(valid_rows)
                    self.spool_recovered += inserted
                    self.persisted_transitions += inserted
                    self.db_transitions_last_known = self.store.total_transitions
                    self.store_roundtrip_verified = self.store.first_commit_verified
                unresolved = [row for row in terminal_rows if not self.store.mark_terminal_uid(row['terminal_uid'])]
                with temp.open('wb') as destination:
                    shutil.copyfileobj(source, destination, length=1024 * 1024)
                    for item in unresolved:
                        destination.write((json.dumps(item, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
                    destination.flush()
                    os.fsync(destination.fileno())
            if invalid:
                corrupt = self.folder / 'experience_journal_corrupt.jsonl'
                with corrupt.open('ab') as destination:
                    destination.writelines(invalid)
                    destination.flush()
                    os.fsync(destination.fileno())
            if temp.stat().st_size:
                os.replace(temp, self.spool_path)
            else:
                temp.unlink(missing_ok=True)
                self.spool_path.unlink(missing_ok=True)
            if invalid:
                self.store_problem = f'经验日志存在 {len(invalid)} 条无法解码的记录，已保留到损坏日志文件'

    def persist_initial_frame(self, obs):
        if not obs.valid or obs.quality.get('low_information') or obs.game in self.initial_frame_games:
            return
        with self.lock:
            if obs.game not in self.initial_frame_games:
                self.initial_frame_games.add(obs.game)
                self.initial_frames[obs.game] = (self.games[obs.game].game_steps, obs)
            self._drain_persist(force=True)

    def _drain_persist(self, frame=None, force=False):
        with self.storage_condition:
            if frame is not None:
                if len(self.frame_backlog) >= 96:
                    self.frame_backlog.popleft()
                    self.keyframes_skipped += 1
                self.frame_backlog.append(frame)
            if force:
                self.storage_force = True
            self.storage_condition.notify_all()

    def storage_loop(self):
        ending_since = None
        try:
            while True:
                self.storage_last_tick = time.monotonic()
                self._retry_journal()
                with self.storage_condition:
                    stopping = self.storage_stop.is_set()
                    if stopping and ending_since is None:
                        ending_since = time.monotonic()
                    force = self.storage_force or stopping
                    pending = bool(self.initial_frames or self.frame_backlog or self.persist_backlog or self.terminal_updates or self.journal_unwritten)
                    checkpoint = self.checkpoint_requested or (stopping and not self.checkpoint_verified)
                    if not pending and not checkpoint and not force:
                        self.storage_condition.wait(0.45)
                        continue
                    initial = list(self.initial_frames.items())[:10]
                    frames = list(self.frame_backlog)[:12]
                    should_write = (force or self.persisted_transitions == 0 or len(self.persist_backlog) >= 16
                                    or time.monotonic() - self.persist_last_batch >= 2.0)
                    batch = list(self.persist_backlog)[:160] if should_write else []
                    terminal = list(self.terminal_updates)[:64]
                    sequence = self.checkpoint_sequence
                    if pending and not (initial or frames or batch or terminal or checkpoint or force):
                        self.storage_condition.wait(0.35)
                        continue
                try:
                    connected = self._connect_store() if (pending or force) else self.store is not None
                    if connected:
                        self._drain_spool()
                        for key, (step, observation) in initial:
                            self.store.frame(key, step, 'initial', observation, force=True)
                        for frame in frames:
                            game_key, step, index, observation = frame
                            self.store.frame(game_key, step + 1, self.actions[index].id, observation)
                        inserted = self.store.add_many(batch) if batch else 0
                        unresolved = False
                        resolved_terminal = []
                        for uid in terminal:
                            if self.store.mark_terminal_uid(uid):
                                resolved_terminal.append(uid)
                            else:
                                unresolved = True
                        self.store.flush()
                        with self.storage_condition:
                            for key, (step, observation) in initial:
                                if key in self.initial_frames and self.initial_frames[key][1] is observation:
                                    del self.initial_frames[key]
                            for frame in frames:
                                if self.frame_backlog and self.frame_backlog[0] is frame:
                                    self.frame_backlog.popleft()
                            for entry in batch:
                                if self.persist_backlog and self.persist_backlog[0][10].get('uid') == entry[10].get('uid'):
                                    self.persist_backlog.popleft()
                            for uid in resolved_terminal:
                                if self.terminal_updates and self.terminal_updates[0] == uid:
                                    self.terminal_updates.popleft()
                            if batch:
                                for entry in batch:
                                    self.journal_unwritten.pop(entry[10].get('uid'), None)
                                self.persisted_transitions += inserted
                                self.persist_last_batch = time.monotonic()
                            self.db_transitions_last_known = self.store.total_transitions
                            self.store_roundtrip_verified = self.store.first_commit_verified
                            self.keyframes_this_session = self.store.frames_saved
                            self.storage_force = False
                            self.storage_problem = None
                            self.storage_failures = 0
                    if checkpoint:
                        self._write_checkpoint()
                        with self.storage_condition:
                            if self.checkpoint_sequence == sequence:
                                self.checkpoint_requested = False
                    if stopping:
                        with self.storage_condition:
                            completed = not (self.persist_backlog or self.initial_frames or self.frame_backlog or self.terminal_updates or self.checkpoint_requested)
                        if completed or time.monotonic() - ending_since > 8.0:
                            if self.journal_unwritten:
                                self.storage_problem = f'仍有 {len(self.journal_unwritten)} 条数据无法写入经验日志，已请求检查点保留待写队列'
                            break
                    if not connected and pending:
                        self.storage_stop.wait(0.4)
                    elif connected and unresolved:
                        self.storage_stop.wait(0.35)
                except Exception as exc:
                    with self.storage_condition:
                        self.storage_problem = f'后台持久化失败，将重试：{type(exc).__name__}: {str(exc)[:160]}'
                        self.storage_failures += 1
                    disconnected = False
                    if self.store is not None:
                        try:
                            self.store.db.rollback()
                            self.store.frame_step.clear()
                            self.store.pending = 0
                            count = int(self.store.db.execute('SELECT COUNT(*) FROM keyframes').fetchone()[0])
                            self.store.frames_saved = max(0, count - self.store.start_frame_count)
                        except sqlite3.Error as rollback_exc:
                            self._store_failure(rollback_exc)
                            disconnected = True
                    if isinstance(exc, sqlite3.Error) and not disconnected:
                        self._store_failure(exc)
                    if stopping and time.monotonic() - ending_since > 8.0:
                        try:
                            self._write_checkpoint()
                        except Exception:
                            pass
                        if self.journal_unwritten:
                            self.storage_problem = f'仍有 {len(self.journal_unwritten)} 条数据无法写入经验日志，已尝试保存待写检查点'
                        break
                    self.storage_stop.wait(min(0.65, 0.05 * self.storage_failures))
        finally:
            if self.store is not None:
                try:
                    self.store.close()
                except Exception as exc:
                    self.storage_problem = f'存储连接关闭失败：{type(exc).__name__}: {exc}'
                self.store = None

    def _combine_pending(self, horizon):
        batch = list(self.pending_n)[:min(N_STEP, horizon)]
        for index, item in enumerate(batch):
            if item[6]:
                batch = batch[:index + 1]
                break
        discounted = sum((DISCOUNT ** index) * row[3] for index, row in enumerate(batch))
        first, last = batch[0], batch[-1]
        confidence = min(float(row[8]) if len(row) > 8 else 0.65 for row in batch)
        detail = first[9].copy() if len(first) > 9 and isinstance(first[9], dict) else {}
        if detail.get('uid'):
            detail['origin_uid'] = detail.pop('uid')
        return [first[0], first[1][:], first[2], discounted, last[4][:], max(0.025, abs(discounted) + 0.02), bool(last[6]), len(batch), confidence, detail]

    def flush_pending(self, done=True):
        with self.training_condition:
            if done and self.pending_n:
                newest = self.pending_n[-1]
                newest[6] = True
                uid = newest[9].get('uid') if len(newest) > 9 and isinstance(newest[9], dict) else None
                if uid:
                    updated = False
                    for pos in range(len(self.persist_backlog)-1, -1, -1):
                        row = self.persist_backlog[pos]
                        if row[10].get('uid') == uid:
                            replacement = list(row)
                            replacement[6] = True
                            self.persist_backlog[pos] = tuple(replacement)
                            updated = True
                            break
                    if uid not in self.terminal_updates:
                        if len(self.terminal_updates) >= 12000:
                            evicted = self.terminal_updates.popleft()
                            self.journal_unwritten.pop('terminal:' + evicted, None)
                            self.dropped_unpersisted += 1
                            self.store_problem = '存储失效期间终止状态积压达到内存上限，已有记录无法保全'
                        self.terminal_updates.append(uid)
                    self._journal_event({'terminal_uid': uid}, 'terminal:' + uid)
            while self.pending_n:
                combined = self._combine_pending(len(self.pending_n))
                if combined[7] > 1:
                    self.enqueue_training(combined)
                    self._append_persist(combined)
                    self.nstep_generated += 1
                self.pending_n.popleft()
            self._drain_persist(force=done)

    def learn_boundary(self, old, index, reason, effect=None):
        self.reward_info = {
            'proxy_reward': None,
            'reward_basis': 'unobserved_action_result_at_' + str(reason),
            'input_effect_is_causal': None,
            'verified_win': None,
            'verified_task_progress': None,
            'episode_boundary': True,
            'episode_boundary_reason': reason,
            'action_detail': effect.copy() if isinstance(effect, dict) else {},
        }
        self.flush_pending(done=True)
        return False

    def learn(self, old, index, new, reward, change, done=False, confidence_override=None, effect=None):
        with self.training_condition:
            game = self.game
            self.dirty_games.add(self.game_key)
            self.dirty_sequence += 1
            valid = bool(old.valid and new.valid and old.game == new.game == self.game_key
                         and not old.quality.get('low_information', False)
                         and not new.quality.get('low_information', False)
                         and len(old.features) == FEATURE_COUNT and len(new.features) == FEATURE_COUNT)
            confidence = min(float(old.quality.get('confidence', 1.0)), float(new.quality.get('confidence', 1.0)))
            if old.rect != new.rect:
                confidence = min(confidence, 0.52)
            if confidence_override is not None:
                confidence = min(confidence, max(0.0, min(1.0, float(confidence_override))))
            if isinstance(effect, dict):
                if effect.get('interrupted'):
                    completion = max(0.0, min(1.0, float(effect.get('completion_ratio', 0.0))))
                    confidence *= 0.15 + 0.55 * completion
                if effect.get('feedback_valid') is False:
                    valid = False
                if effect.get('emulated_touch') and effect.get('kind') in ('pinch', 'dual_touch'):
                    confidence *= 0.5
            priority = max(0.025, (abs(reward) + 0.045 + 0.13 * max(0.0, new.novelty - old.novelty)) * (0.25 + 0.75 * confidence))
            if valid:
                self.valid_transitions += 1
                action_detail = effect.copy() if isinstance(effect, dict) else {}
                transition = [self.game_key, old.features[:], index, float(reward), new.features[:], priority, bool(done), 1, confidence, action_detail]
                if len(game.exemplars) < game.exemplars.maxlen:
                    game.exemplars.append(transition)
                elif self.rng.randrange(max(1, game.game_steps + 1)) < game.exemplars.maxlen:
                    game.exemplars[self.rng.randrange(len(game.exemplars))] = transition
                self.enqueue_training(transition)
                self._append_persist(transition, change)
                self.record_action_result(index, action_detail, reward)
                self.pending_n.append(transition)
                if len(self.pending_n) >= N_STEP:
                    combined = self._combine_pending(N_STEP)
                    if combined[7] > 1:
                        self.enqueue_training(combined)
                        self._append_persist(combined, change)
                        self.nstep_generated += 1
                    self.pending_n.popleft()
                if done:
                    outcome = self.reward_info.get('screen_result_confirmation')
                    if outcome in ('win', 'task', 'loss'):
                        previous = [item for item in reversed(list(self.memory)[-18:-1])
                                    if item[0] == self.game_key and item[7] == 1 and len(item[1]) == FEATURE_COUNT][:8]
                        for distance, previous_action in enumerate(previous, 2):
                            shaped = float(reward) * (DISCOUNT ** (distance - 1)) * 0.62
                            trust = min(0.90, float(previous_action[8]), confidence) * (0.82 ** (distance - 1))
                            details = {'outcome_credit': outcome, 'origin_uid': previous_action[9].get('uid') if isinstance(previous_action[9], dict) else None,
                                       'source': 'persistent_local_result_text_not_game_verified'}
                            reinforced = [self.game_key, previous_action[1][:], previous_action[2], shaped,
                                          new.features[:], max(0.025, abs(shaped) * trust), True, distance, trust, details]
                            self.enqueue_training(reinforced)
                            self._append_persist(reinforced, change)
                            self.terminal_credit_samples += 1
                        self.reward_info['credited_prior_actions'] = len(previous)
                    self.flush_pending(done=True)
            else:
                self.invalid_observations += 1
                self.flush_pending(done=False)
            self._drain_persist(frame=(self.game_key, game.game_steps, index, new) if valid else None)
            game.counts[index] += 1
            game.game_steps += 1
            game.total_reward += reward
            self.step += 1
            self.total_reward += reward
            game.recent.append((index, old.features[:18], reward, new.signature, action_detail if valid else {}))
            stats = game.category_score.setdefault(self.actions[index].category, [0, 0.0])
            stats[0] += 1
            stats[1] = stats[1] * 0.95 + reward * 0.05
            if valid and reward > 0.08 and float(self.reward_info.get('causal_confidence', 0.0)) > 0.45 and (self.reward_info.get('screen_result_confirmation') in ('win', 'task') or float(self.reward_info.get('learned_hud_trend_signal', 0.0)) > 0.04) and len(game.recent) >= 2:
                sequence = list(game.recent)[-min(4, len(game.recent)):]
                key = '|'.join(self.actions[item[0]].id for item in sequence)
                if key not in game.skills and len(game.skills) >= 128:
                    discard = min(game.skills, key=lambda k: game.skills[k].get('quality', 0.0))
                    del game.skills[discard]
                item = game.skills.setdefault(key, {'count': 0, 'quality': 0.0, 'context': sequence[0][1], 'goal_signature': new.signature, 'goal_features': new.features[:18], 'attempts': 0, 'successes': 0})
                item['count'] += 1
                item['quality'] = 0.8 * item['quality'] + 0.2 * max(0.0, sum(t[2] for t in sequence))
                if reward >= item['quality'] * 0.65:
                    item['parameters'] = [t[4].copy() for t in sequence]

    def training_loop(self):
        while not self.training_stop.is_set():
            self.training_last_tick = time.monotonic()
            fresh = []
            try:
                with self.training_condition:
                    if not self.training_queue:
                        self.training_condition.wait(timeout=0.2)
                    if self.training_stop.is_set():
                        break
                    if not self.training_queue:
                        continue
                    if self.np is None:
                        capacity = 2
                        replay_count = 2
                    elif getattr(self.np, '__name__', '') == 'cupy':
                        capacity = 36 if len(self.training_queue) > 24 else 12
                        replay_count = 24
                    else:
                        capacity = 24 if len(self.training_queue) > 24 else 8
                        replay_count = 12
                    fresh = [self.training_queue.popleft() for _ in range(min(capacity, len(self.training_queue)))]
                    samples = list(fresh)
                    if len(self.memory) >= 10:
                        memory = list(self.memory)
                        candidate_count = min(2500, len(memory))
                        recent = memory[-candidate_count:]
                        weights = [max(0.025, float(t[5])) ** 0.65 * (0.22 + 0.78 * (float(t[8]) if len(t) > 8 else 0.65)) for t in recent]
                        samples.extend(self.rng.choices(recent, weights=weights, k=min(replay_count, len(recent))))
                    if len(self.games) > 1 and self.rng.random() < 0.65:
                        others = [item for key, item in self.games.items() if key != self.game_key and item.exemplars]
                        if others:
                            samples.append(self.rng.choice(self.rng.choice(others).exemplars))
                    snapshot = self._training_snapshot(samples)
                if self.training_stop.is_set():
                    break
                results = self._train_batch(samples, snapshot)
                self.training_last_tick = time.monotonic()
                if results:
                    if not self._commit_training(snapshot, results):
                        raise RuntimeError('学习后端在训练中发生切换，待重试当前批次')
                self.training_problem = None
                self.training_failures = 0
            except Exception as exc:
                self.training_failures += 1
                self.training_problem = f'学习线程训练失败：{type(exc).__name__}: {exc}'
                if self.training_failures >= 3 and self.np is not None:
                    try:
                        self.recover_backend()
                    except Exception as backend_exc:
                        self.training_problem = f'学习后端迁移失败：{type(backend_exc).__name__}: {backend_exc}'
                self.training_stop.wait(min(0.5, 0.05 * max(1, self.training_failures)))
            finally:
                if fresh and (self.training_stop.is_set() or self.training_problem is not None):
                    with self.training_condition:
                        for transition in reversed(fresh):
                            self.training_queue.appendleft(transition)
                        self.training_retried += len(fresh)
                        self.training_condition.notify_all()

    def stop_training(self):
        self.training_stop.set()
        with self.training_condition:
            self.training_condition.notify_all()
        if self.trainer.is_alive():
            self.trainer.join(timeout=3.0)

    def sync_target(self):
        with self.lock:
            self.target_encoder = self.encoder.copy() if self.np is not None else [row[:] for row in self.encoder]
            self.target_encoder_bias = self.encoder_bias.copy() if self.np is not None else self.encoder_bias[:]
            for game in self.games.values():
                game.sync_target()


    def checkpoint_payload(self):
        return {
            'format': MODEL_FORMAT,
            'feature_schema': 'spatiotemporal-color-tracking-v2',
            'reward_schema': 'screen-outcome-calibrated-v2',
            'feature_count': FEATURE_COUNT,
            'hidden_size': self.hidden_size,
            'step': self.step,
            'updates': self.updates,
            'td_error_ema': self.td_error_ema,
            'total_reward': self.total_reward,
            'valid_transitions': self.valid_transitions,
            'low_information_observations': self.low_information_observations,
            'nstep_generated': self.nstep_generated,
            'dropped_unpersisted': self.dropped_unpersisted,
            'spilled_transitions': self.spilled_transitions,
            'spool_recovered': self.spool_recovered,
            'journaled_transitions': self.journaled_transitions,
            'persist_backlog': list(self.persist_backlog),
            'terminal_updates': list(self.terminal_updates),
            'action_ids': [a.id for a in self.actions],
            'encoder': self.encoder.tolist() if self.np is not None else self.encoder,
            'encoder_bias': self.encoder_bias.tolist() if self.np is not None else self.encoder_bias,
            'games': {key: game.export() for key, game in self.games.items()},
            'visual_routes': self.visual_routes,
        }

    def save(self, force=False):
        with self.storage_condition:
            if not force and time.monotonic() - self.last_save < 34.0:
                return False
            self.checkpoint_requested = True
            self.checkpoint_sequence += 1
            if force:
                self.storage_force = True
            self.storage_condition.notify_all()
        return True

    def _write_checkpoint(self):
        now = time.monotonic()
        path = self.folder / 'learning_state.json.gz'
        delta_path = self.folder / 'learning_delta.json.gz'
        delta_mode = (path.exists() and self.delta_base_step is not None
                      and not self.storage_stop.is_set() and self.checkpoint_serial % 5 != 4)
        with self.lock:
            snapshot_revision = self.dirty_sequence
            if delta_mode:
                changed = {}
                for key in sorted(self.dirty_games):
                    game = self.games.get(key)
                    if game is None:
                        continue
                    changed[key] = game.export()
                complete = self.checkpoint_payload()
                payload = {name: value for name, value in complete.items() if name not in ('format', 'games')}
                payload.update({'format': 1, 'base_step': self.delta_base_step, 'games': changed})
            else:
                payload = self.checkpoint_payload()
            canonical = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
        temp = self.folder / ('learning_delta.json.gz.tmp' if delta_mode else 'learning_state.json.gz.tmp')
        backup = self.folder / 'learning_state.json.gz.bak'
        backup_temp = self.folder / 'learning_state.json.gz.bak.tmp'
        digest = hashlib.sha256(canonical).hexdigest().encode('ascii')
        serialized = canonical[:-1] + b',"integrity_sha256":"' + digest + b'"}'
        try:
            with temp.open('wb') as raw_stream:
                with gzip.GzipFile(fileobj=raw_stream, mode='wb', compresslevel=4) as stream:
                    stream.write(serialized)
                raw_stream.flush()
                os.fsync(raw_stream.fileno())
            with gzip.open(temp, 'rb') as verify:
                if hashlib.sha256(verify.read()).digest() != hashlib.sha256(serialized).digest():
                    raise OSError('新建学习状态的回读校验失败')
            if delta_mode:
                os.replace(temp, delta_path)
            else:
                if path.exists() and (self.checkpoint_serial % 6 == 0 or not backup.exists()):
                    try:
                        if path.stat().st_size > 140_000_000:
                            raise ValueError('旧检查点容量超限')
                        with gzip.open(path, 'rb') as old_stream:
                            old_raw = old_stream.read(260_000_001)
                        if len(old_raw) > 260_000_000:
                            raise ValueError('旧检查点解压容量超限')
                        old_payload = json.loads(old_raw)
                        old_digest = old_payload.pop('integrity_sha256', None)
                        if old_digest is not None:
                            old_bytes = json.dumps(old_payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                            if hashlib.sha256(old_bytes).hexdigest() != old_digest:
                                raise ValueError('旧检查点哈希错误')
                        shutil.copyfile(path, backup_temp)
                        os.replace(backup_temp, backup)
                    except (OSError, ValueError, TypeError, EOFError, gzip.BadGzipFile):
                        pass
                os.replace(temp, path)
                delta_path.unlink(missing_ok=True)
            with self.lock:
                self.last_checkpoint_summary = {
                    'step': int(payload['step']), 'updates': int(payload['updates']),
                    'games': {key: {'steps': game.get('game_steps', 0), 'skills': len(game.get('skills', {}))}
                              for key, game in list(payload.get('games', {}).items())[-32:]},
                    'sha256': hashlib.sha256(serialized).hexdigest(),
                    'kind': 'delta' if delta_mode else 'full',
                }
                self.checkpoint_compressed_bytes = (delta_path if delta_mode else path).stat().st_size
                self.checkpoint_verified = True
                self.checkpoint_serial += 1
                self.last_save = now
                if not delta_mode:
                    self.delta_base_step = payload['step']
                    if self.dirty_sequence == snapshot_revision:
                        self.dirty_games.clear()
            return True
        finally:
            temp.unlink(missing_ok=True)
            backup_temp.unlink(missing_ok=True)

    def restore(self):
        primary = self.folder / 'learning_state.json.gz'
        backup = self.folder / 'learning_state.json.gz.bak'
        if not primary.exists() and not backup.exists():
            return
        def number(value, default=0.0, lower=-1000000000.0, upper=1000000000.0):
            try:
                value = float(value)
                return max(lower, min(upper, value)) if math.isfinite(value) else default
            except (TypeError, ValueError, OverflowError):
                return default
        def integer(value, default=0, limit=1000000000):
            return int(number(value, default, 0, limit))
        def vector(value, length, limit=3.0):
            if not isinstance(value, list) or len(value) != length:
                return None
            result = [number(item, float('nan'), -limit, limit) for item in value]
            return result if all(math.isfinite(item) for item in result) else None
        def records(value):
            if isinstance(value, dict):
                return value.items()
            return value if isinstance(value, list) else []
        saved = None
        last_error = None
        for filename in (primary, backup):
            if not filename.exists():
                continue
            try:
                if filename.stat().st_size > 140_000_000:
                    raise ValueError('学习状态压缩文件过大')
                with gzip.open(filename, 'rb') as stream:
                    raw = stream.read(260_000_001)
                if len(raw) > 260_000_000:
                    raise ValueError('学习状态解压内容过大')
                entry = json.loads(raw)
                if not isinstance(entry, dict):
                    raise ValueError('学习状态结构错误')
                signature = entry.pop('integrity_sha256', None)
                if not isinstance(signature, str) or len(signature) != 64:
                    raise ValueError('学习检查点缺少校验信息')
                canonical = json.dumps(entry, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                if hashlib.sha256(canonical).hexdigest() != signature:
                    raise ValueError('学习检查点校验失败')
                if (entry.get('format') not in (7, MODEL_FORMAT)
                        or entry.get('feature_count') not in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)
                        or entry.get('hidden_size') not in (96, MODEL_HIDDEN_SIZE)):
                    raise ValueError('学习状态版本或维度不受支持')
                saved = entry
                self.checkpoint_verified = True
                if filename == backup:
                    self.store_problem = '主学习状态无法恢复，已从备份恢复'
                break
            except (ValueError, TypeError, OSError, EOFError, gzip.BadGzipFile) as exc:
                last_error = exc
        if saved is None:
            self.store_problem = f'学习状态恢复失败：{last_error}'
            return
        saved_width = int(saved['feature_count'])
        saved_hidden = int(saved['hidden_size'])
        self.checkpoint_migrated = (saved_width != FEATURE_COUNT or saved_hidden != self.hidden_size or saved['format'] != MODEL_FORMAT)
        self.delta_base_step = int(saved.get('step', 0))
        delta_path = self.folder / 'learning_delta.json.gz'
        if delta_path.exists():
            try:
                if delta_path.stat().st_size > 80_000_000:
                    raise ValueError('增量学习文件过大')
                with gzip.open(delta_path, 'rb') as stream:
                    raw_delta = stream.read(150_000_001)
                if len(raw_delta) > 150_000_000:
                    raise ValueError('增量学习内容过大')
                delta = json.loads(raw_delta)
                digest = delta.pop('integrity_sha256', None)
                canonical = json.dumps(delta, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                if (not isinstance(digest, str) or hashlib.sha256(canonical).hexdigest() != digest
                        or delta.get('format') != 1 or delta.get('base_step') != self.delta_base_step
                        or delta.get('feature_count') != saved_width or delta.get('hidden_size') != saved_hidden
                        or delta.get('action_ids') != saved.get('action_ids')
                        or not isinstance(delta.get('games'), dict)
                        or int(delta.get('step', -1)) < self.delta_base_step):
                    raise ValueError('增量学习状态与基础检查点不匹配')
                for key, value in delta.items():
                    if key not in ('format', 'base_step', 'games', 'integrity_sha256'):
                        saved[key] = value
                for key, data in delta['games'].items():
                    if isinstance(key, str) and isinstance(data, dict):
                        stored = saved.setdefault('games', {}).setdefault(key, {})
                        stored.update(data)
                        self.dirty_games.add(canonical_game_key(key))
            except (OSError, ValueError, TypeError, EOFError, gzip.BadGzipFile, KeyError, AttributeError) as exc:
                self.store_problem = f'增量学习状态未采用，继续使用完整检查点：{type(exc).__name__}: {exc}'
        def feature_vector(value, limit=3.0):
            length = len(value) if isinstance(value, list) else -1
            if length not in (saved_width, FEATURE_COUNT):
                return None
            values = vector(value, length, limit)
            return (values + [0.0] * (FEATURE_COUNT - length)) if values is not None and length <= FEATURE_COUNT else None
        try:
            encoder = [vector(row, saved_width, 1.2) for row in saved.get('encoder', [])]
            bias = vector(saved.get('encoder_bias'), saved_hidden, 1.2)
            if len(encoder) != saved_hidden or any(row is None for row in encoder) or bias is None:
                raise ValueError('视觉编码器参数无效')
            expanded = self.encoder.tolist() if self.np is not None else [row[:] for row in self.encoder]
            for i in range(min(saved_hidden, self.hidden_size)):
                expanded[i][:saved_width] = encoder[i]
                if saved_width < FEATURE_COUNT:
                    expanded[i][saved_width:] = [0.0] * (FEATURE_COUNT - saved_width)
            expanded_bias = [0.0] * self.hidden_size
            expanded_bias[:min(saved_hidden, self.hidden_size)] = bias[:min(saved_hidden, self.hidden_size)]
            self.encoder = self.np.asarray(expanded, dtype=self.np.float32) if self.np is not None else expanded
            self.encoder_bias = self.np.asarray(expanded_bias, dtype=self.np.float32) if self.np is not None else expanded_bias
            ids = saved.get('action_ids', [])
            if not isinstance(ids, list):
                raise ValueError('动作集合无效')
            mapping = [(old, self.action_index[name]) for old, name in enumerate(ids) if isinstance(name, str) and name in self.action_index]
            for key, stored in records(saved.get('games', {})):
                if not isinstance(key, str) or not isinstance(stored, dict) or not key or len(key) > 50:
                    continue
                game = GameData(len(self.actions), self.hidden_size, self.np)
                rows, biases, counts = stored.get('q', []), stored.get('bias', []), stored.get('counts', [])
                for old_idx, new_idx in mapping:
                    if old_idx >= len(rows) or old_idx >= len(biases) or old_idx >= len(counts):
                        continue
                    head = vector(rows[old_idx], saved_hidden, 2.5)
                    if head is None:
                        continue
                    head += [0.0] * (self.hidden_size - saved_hidden)
                    if self.np is not None:
                        game.q[new_idx] = self.np.asarray(head, dtype=self.np.float32)
                    else:
                        game.q[new_idx] = head
                    game.bias[new_idx] = number(biases[old_idx], 0.0, -3.0, 3.0)
                    game.counts[new_idx] = integer(counts[old_idx])
                    for field, result, minimum, maximum in (('action_effect', game.action_effect, -0.3, 1.0), ('action_effect_samples', game.action_effect_samples, 0.0, 1000000000.0)):
                        values = stored.get(field, [])
                        if old_idx < len(values):
                            val = number(values[old_idx], 0.0, minimum, maximum)
                            result[new_idx] = int(val) if field == 'action_effect_samples' else val
                for signature, count in list(records(stored.get('visits', [])))[-15000:]:
                    if isinstance(signature, str) and len(signature) == 16:
                        game.visits[signature] = max(1, integer(count))
                for signature, center in list(records(stored.get('scene_centers', [])))[-2400:]:
                    if isinstance(signature, str) and len(signature) == 16 and isinstance(center, list) and len(center) == 2:
                        values = vector(center[0], 20, 12.0)
                        if values is not None:
                            game.scene_centers[signature] = [values, max(1, integer(center[1]))]
                inverse = dict(mapping)
                for name, record in list(records(stored.get('world', {})))[-12500:]:
                    prefix, sep, suffix = str(name).partition('@')
                    try:
                        old = int(prefix)
                    except (TypeError, ValueError):
                        continue
                    if old not in inverse or not isinstance(record, list) or len(record) != 3:
                        continue
                    change = vector(record[0], 32, 2.0)
                    if change is not None:
                        new_key = f'{inverse[old]}@{suffix}' if sep else inverse[old]
                        game.world[new_key] = [change, max(1, integer(record[1])), number(record[2], 0.0, 0.0, 2.0)]
                for label, value in list(records(stored.get('targets', {})))[-720:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 2:
                        game.targets[label] = [number(value[0], 0.0, 0.0, 1.0), integer(value[1])]
                for label, value in list(records(stored.get('candidate_events', {})))[-350:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 2:
                        game.candidate_events[label] = [integer(value[0]), number(value[1], 0.0, 0.0, 1.0)]
                for name, item in list(records(stored.get('skills', {})))[-128:]:
                    if isinstance(name, str) and isinstance(item, dict) and vector(item.get('context'), 18) is not None:
                        game.skills[name] = item
                for sample in stored.get('exemplars', [])[-48:]:
                    if not isinstance(sample, list) or len(sample) != 10 or not isinstance(sample[2], int) or sample[2] not in inverse:
                        continue
                    before = feature_vector(sample[1])
                    after = feature_vector(sample[4])
                    if before is not None and after is not None:
                        game.exemplars.append([key, before, inverse[sample[2]], number(sample[3], 0.0, -3.0, 3.0), after, number(sample[5], 0.1, 0.025, 2.5), bool(sample[6]), max(1, integer(sample[7])), number(sample[8], 0.65, 0.0, 1.0), sample[9].copy() if isinstance(sample[9], dict) else {}])
                for label, count in list(records(stored.get('trajectories', [])))[-12000:]:
                    if isinstance(label, str) and len(label) < 100:
                        game.trajectories[label] = integer(count)
                for label, target in (('category_score', game.category_score), ('family_score', game.family_score)):
                    for group, value in records(stored.get(label, {})):
                        known = self.action_groups if label == 'category_score' else self.action_families
                        if group in known and isinstance(value, list) and len(value) == 2:
                            target[group] = [integer(value[0]), number(value[1], 0.0, -1.0, 1.0)]
                for label, value in list(records(stored.get('parameter_stats', [])))[-3200:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 3:
                        game.parameter_stats[label] = [number(value[0], 0.0, -1.0, 1.0), integer(value[1]), number(value[2], 0.0, 0.0, 1.0)]
                for kind, state in list(records(stored.get('parameter_heads', {})))[:64]:
                    if not isinstance(kind, str) or kind not in self.action_kinds_for_parameter or not isinstance(state, dict):
                        continue
                    rows = state.get('w', [])
                    biases = vector(state.get('b'), 4, 3.0)
                    weights = [vector(row, saved_hidden, 1.5) for row in rows] if isinstance(rows, list) else []
                    if len(weights) != 4 or any(row is None for row in weights) or biases is None:
                        continue
                    weights = [row + [0.0] * (self.hidden_size - saved_hidden) for row in weights]
                    game.parameter_heads[kind] = {'w': self.np.asarray(weights, dtype=self.np.float32) if self.np is not None else weights,
                                                  'b': self.np.asarray(biases, dtype=self.np.float32) if self.np is not None else biases,
                                                  'samples': integer(state.get('samples', 0), limit=10000000)}
                for label, value in list(records(stored.get('duration_stats', {})))[-1200:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 2:
                        game.duration_stats[label] = [number(value[0], 0.0, -1.0, 1.0), integer(value[1])]
                game.game_steps = integer(stored.get('game_steps'))
                game.total_reward = number(stored.get('total_reward'))
                game.baseline_change = number(stored.get('baseline_change'), 0.0, 0.0, 1.0)
                game.passive_change = number(stored.get('passive_change'), 0.0, 0.0, 1.0)
                game.passive_samples = integer(stored.get('passive_samples'))
                game.stagnation = integer(stored.get('stagnation'))
                game.feedback_delay = number(stored.get('feedback_delay'), 0.09, 0.035, 0.3)
                for name, value in list(records(stored.get('hud_trends', [])))[-160:] if not self.checkpoint_migrated else []:
                    allowed = isinstance(name, str) and ((name.isdecimal() and 0 <= int(name) < 48)
                                     or (name.startswith('number:') and len(name) <= 20))
                    if allowed and isinstance(value, list) and len(value) == 4:
                        game.hud_trends[name] = [integer(value[0]), number(value[1], 0.0, 0.0, 1000000.0), number(value[2], 0.0, 0.0, 1000000.0), number(value[3], 0.0, 0.0, 1.0)]
                for name, value in list(records(stored.get('goal_landmarks', [])))[-800:]:
                    if isinstance(name, str) and len(name) < 90 and isinstance(value, list) and len(value) == 3:
                        game.goal_landmarks[name] = [integer(value[0]), number(value[1], 0.0, 0.0, 1.0), number(value[2], 0.0, 0.0, 1.0)]
                if isinstance(stored.get('plan_success'), list) and len(stored['plan_success']) == 2:
                    game.plan_success = [integer(stored['plan_success'][0]), integer(stored['plan_success'][1])]
                outcome_totals = stored.get('screen_outcomes', {})
                if isinstance(outcome_totals, dict):
                    game.screen_outcomes = {name: integer(outcome_totals.get(name, 0)) for name in ('win', 'loss', 'task')}
                game.result_active = False
                for entry in stored.get('confirmed_results', [])[-96:]:
                    if isinstance(entry, (tuple, list)) and len(entry) == 2 and isinstance(entry[0], str) and len(entry[0]) < 96 and entry[1] in ('win', 'loss', 'task'):
                        game.confirmed_results[entry[0]] = entry[1]
                normalized = canonical_game_key(key)
                if normalized in self.games:
                    self.games[normalized].merge(game)
                else:
                    self.games[normalized] = game
            for base, profiles in records(saved.get('visual_routes', {})):
                if not isinstance(base, str) or len(base) > 35 or not isinstance(profiles, list):
                    continue
                accepted = []
                for entry in profiles[:12]:
                    if not isinstance(entry, dict) or not isinstance(entry.get('key'), str) or len(entry['key']) > 50:
                        continue
                    anchors = []
                    for item in entry.get('anchors', [])[:24]:
                        values = vector(item, 64, 1.0)
                        if values is not None and all(0.0 <= value <= 1.0 for value in values):
                            anchors.append(values)
                    if anchors:
                        legacy = entry['key']
                        suffix = legacy[len(base) + 1:] if legacy.startswith(base + ':') else ''
                        restored_key = f'{base}~g{suffix}' if suffix.isdecimal() else legacy
                        accepted.append({'key': restored_key, 'anchors': anchors, 'samples': max(1, integer(entry.get('samples', 1)))})
                if accepted:
                    self.visual_routes[base] = accepted
            self.step = integer(saved.get('step'))
            self.updates = integer(saved.get('updates'))
            self.td_error_ema = number(saved.get('td_error_ema'), 0.0, 0.0, 10.0)
            self.total_reward = number(saved.get('total_reward'))
            self.valid_transitions = integer(saved.get('valid_transitions'))
            self.low_information_observations = integer(saved.get('low_information_observations'))
            self.nstep_generated = integer(saved.get('nstep_generated'))
            self.dropped_unpersisted = integer(saved.get('dropped_unpersisted'))
            self.spilled_transitions = integer(saved.get('spilled_transitions'))
            self.spool_recovered = integer(saved.get('spool_recovered'))
            self.journaled_transitions = integer(saved.get('journaled_transitions'))
            saved_backlog = saved.get('persist_backlog', [])
            if isinstance(saved_backlog, list) and len(saved_backlog) > 12000:
                self.dropped_unpersisted += len(saved_backlog) - 12000
                self.store_problem = '旧版本学习检查点中待写队列超出内存上限，已截断并保留最新记录'
            for row in saved_backlog[-12000:] if isinstance(saved_backlog, list) else []:
                if not isinstance(row, list) or len(row) != 11 or not isinstance(row[0], str) or row[1] not in self.action_index:
                    continue
                before = feature_vector(row[3])
                after = feature_vector(row[4])
                if before is not None and after is not None:
                    self.persist_backlog.append((canonical_game_key(row[0]), row[1], number(row[2], 0.0, -3.0, 3.0), before, after, number(row[5], 0.0, 0.0, 1.0), bool(row[6]), max(1, integer(row[7])), number(row[8], 0.1, 0.025, 2.5), number(row[9], 0.65, 0.0, 1.0), row[10].copy() if isinstance(row[10], dict) else {}))
            for uid in saved.get('terminal_updates', [])[-1024:]:
                if isinstance(uid, str) and 12 <= len(uid) <= 80:
                    self.terminal_updates.append(uid)
            if self.checkpoint_migrated:
                self.delta_base_step = None
                self.checkpoint_requested = True
        except Exception as exc:
            self.store_problem = f'学习状态恢复不完整：{type(exc).__name__}: {exc}'

    def close(self):
        self.stop_training()
        self.flush_pending(done=False)
        with self.storage_condition:
            self.checkpoint_requested = True
            self.checkpoint_sequence += 1
            self.storage_force = True
            self.storage_stop.set()
            self.storage_condition.notify_all()
        self.storage_thread.join(timeout=12.0)
        if self.storage_thread.is_alive():
            self.storage_problem = '存储线程尚未结束；未确认最后一次写入成功'

class GameAgent:
    def __init__(self, native, folder, mode, stop_vk, own_hwnd, numpy_module):
        self.native, self.folder, self.mode, self.stop_vk, self.own_hwnd = native, folder, mode, stop_vk, own_hwnd
        self.np = numpy_module
        self.stop_event = threading.Event()
        self.stop_gate = StopKeyGate(native, stop_vk, self.stop_event)
        self.on_input_released = None
        self.input_release_verified = None
        self.window_hint = None
        self.events = deque(maxlen=350)
        self.errors = deque(maxlen=30)
        self.brain = None
        self.capture = None
        self.listener = None
        self.controller = None
        self.started = time.time()
        self.failure_count = 0
        self.last_rect = None
        self.last_error = None
        self.same_error_count = 0
        self.last_recorded_error = 0.0
        self.last_status_written = 0.0
        self.phase = 'starting'
        self.last_capture_at = None
        self.last_input_at = None
        self.last_experience_at = None
        self.last_capture_valid = None
        self.last_observation_quality = None
        self.last_signature = None
        self.completed_actions = 0
        self.partial_actions = 0
        self.capture_failures = 0
        self.input_failures = 0
        self.feedback_captures = 0
        self.visual_game_switches = 0
        self.visual_input_effects = 0
        self.episode_boundaries = 0
        self.sensor_condition = threading.Condition()
        self.sensor_thread = None
        self.sensor_stop = threading.Event()
        self.sensor_ready = threading.Event()
        self.sensor_frame = None
        self.sensor_sequence = 0
        self.last_sensor_sequence = 0
        self.sensor_error = None
        self.sensor_quality = None
        self.detail_requests = deque()
        self.capture_target_signature = None
        self.capture_target_pid = None
        self.capture_target_hwnd = None
        self.sensor_last_attempt = None
        self.sensor_last_success = None
        self.sensor_restarts = 0
        self.sensor_frames_total = 0
        self.monitor_breaks = 0
        self.last_visual_target_count = 0
        self.last_worker_check = 0.0

    def error(self, exc):
        self.failure_count += 1
        entry = {
            'at': round(time.time(), 3),
            'type': type(exc).__name__,
            'error': str(exc)[:350],
            'trace': traceback.format_exc(limit=5)[-1800:],
            'phase': self.phase,
        }
        self.errors.append(entry)
        if self.phase == 'capturing':
            self.capture_failures += 1
        elif self.phase == 'acting':
            self.input_failures += 1
        signature = (entry['type'], entry['error'])
        self.same_error_count = self.same_error_count + 1 if self.last_error == signature else 1
        self.last_error = signature
        now = time.monotonic()
        if self.same_error_count <= 2 or self.same_error_count % 30 == 0 or now - self.last_recorded_error > 15:
            try:
                with (self.folder / 'agent_errors.jsonl').open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps({**entry, 'repeats': self.same_error_count}, ensure_ascii=False) + '\n')
                self.last_recorded_error = now
            except OSError:
                pass


    def write_status(self, force=False):
        now = time.monotonic()
        if not force and now - self.last_status_written < 8:
            return
        with self.brain.lock if self.brain is not None else threading.RLock():
            stats = {
                'game': self.brain.game_key if self.brain is not None else None,
                'steps': self.brain.step if self.brain is not None else 0,
                'replay_in_memory': len(self.brain.memory) if self.brain is not None else 0,
                'valid_transitions': self.brain.valid_transitions if self.brain is not None else 0,
                'current_game_visual_profiles': len(self.brain.visual_routes.get(self.brain.visual_active_base, [])) if self.brain is not None else 0,
                'current_scene_profile': self.brain.visual_active_key if self.brain is not None else None,
                'fine_visual_targets': self.last_visual_target_count,
                'low_information_observations': self.brain.low_information_observations if self.brain is not None else 0,
                'invalid_observations': self.brain.invalid_observations if self.brain is not None else 0,
                'persisted_transitions_this_session': self.brain.persisted_transitions if self.brain is not None else 0,
                'transitions_in_database': self.brain.store.total_transitions if self.brain is not None and self.brain.store is not None else self.brain.db_transitions_last_known if self.brain is not None else None,
                'transitions_pending_write': len(self.brain.persist_backlog) if self.brain is not None else 0,
                'unpersisted_transitions_dropped': self.brain.dropped_unpersisted if self.brain is not None else 0,
                'overflow_records_spilled': self.brain.spilled_transitions if self.brain is not None else 0,
                'overflow_records_recovered': self.brain.spool_recovered if self.brain is not None else 0,
                'overflow_file_bytes': self.brain.spool_path.stat().st_size if self.brain is not None and self.brain.spool_path.exists() else 0,
                'sqlite_connected': bool(self.brain.store is not None) if self.brain is not None else False,
                'sqlite_reconnect_failures': self.brain.store_failures if self.brain is not None else 0,
                'nstep_generated': self.brain.nstep_generated if self.brain is not None else 0,
                'training_queue': len(self.brain.training_queue) if self.brain is not None else 0,
                'training_queue_evictions': self.brain.training_queue_evictions if self.brain is not None else 0,
                'training_retries': self.brain.training_retried if self.brain is not None else 0,
                'stale_training_batches': self.brain.training_stale_batches if self.brain is not None else 0,
                'terminal_credit_samples': self.brain.terminal_credit_samples if self.brain is not None else 0,
                'training_updates': self.brain.updates if self.brain is not None else 0,
                'mean_abs_td_error': round(self.brain.td_error_ema, 6) if self.brain is not None else 0.0,
                'total_proxy_reward': self.brain.total_reward if self.brain is not None else 0.0,
                'keyframes_this_session': self.brain.keyframes_this_session if self.brain is not None else 0,
                'last_reward': dict(self.brain.reward_info) if self.brain is not None else {},
                'training_failures': self.brain.training_failures if self.brain is not None else 0,
                'training_worker_heartbeat_age': round(time.monotonic() - self.brain.training_last_tick, 3) if self.brain is not None else None,
                'storage_worker_heartbeat_age': round(time.monotonic() - self.brain.storage_last_tick, 3) if self.brain is not None else None,
                'numeric_backend': 'pure_python' if self.brain is not None and self.brain.np is None else getattr(self.brain.np, '__name__', None) if self.brain is not None else None,
                'backend_recoveries': self.brain.backend_recoveries if self.brain is not None else 0,
                'training_problem': self.brain.training_problem if self.brain is not None else None,
                'storage_problem': self.brain.storage_problem if self.brain is not None else None,
                'storage_failures': self.brain.storage_failures if self.brain is not None else 0,
                'storage_queue_keyframes': len(self.brain.frame_backlog) if self.brain is not None else 0,
                'storage_keyframes_skipped': self.brain.keyframes_skipped if self.brain is not None else 0,
                'visual_game_switch_candidate': self.brain.visual_candidate_count if self.brain is not None else 0,
                'checkpoint_verified': self.brain.checkpoint_verified if self.brain is not None else False,
                'checkpoint_migrated': self.brain.checkpoint_migrated if self.brain is not None else False,
                'screen_outcome_totals': dict(self.brain.game.screen_outcomes) if self.brain is not None else {},
                'journaled_transitions': self.brain.journaled_transitions if self.brain is not None else 0,
                'journal_failures': self.brain.journal_failures if self.brain is not None else 0,
                'database_roundtrip_verified': self.brain.store_roundtrip_verified if self.brain is not None else False,
                'database_preflight_verified': self.brain.db_preflight_verified if self.brain is not None else False,
            }
        data = {
            'updated': time.time(),
            'running': not self.stop_event.is_set(),
            'phase': self.phase,
            'mode': self.mode,
            'stop_key': self.stop_vk,
            **stats,
            'failures': self.failure_count,
            'last_error': {'type': self.errors[-1]['type'], 'message': self.errors[-1]['error'], 'at': self.errors[-1]['at']} if self.errors else None,
            'completed_actions': self.completed_actions,
            'partially_executed_actions': self.partial_actions,
            'capture_failures': self.capture_failures,
            'input_failures': self.input_failures,
            'feedback_capture_batches': self.feedback_captures,
            'visually_observed_input_effects': self.visual_input_effects,
            'estimated_episode_boundaries': self.episode_boundaries,
            'visual_game_switches': self.visual_game_switches,
            'continuous_capture_frames': self.sensor_frames_total,
            'actions_cut_short_by_visual_feedback': self.monitor_breaks,
            'touch_injection_supported': self.controller.touch_available if self.controller is not None else None,
            'last_capture_at': self.last_capture_at,
            'last_input_at': self.last_input_at,
            'last_experience_at': self.last_experience_at,
            'last_capture_valid': self.last_capture_valid,
            'last_observation_quality': self.last_observation_quality,
            'capture_low_information_streak': self.capture.low_information_frames if self.capture is not None else None,
            'last_screen_signature': self.last_signature,
            'capture_backend': self.capture.backend if self.capture is not None else None,
            'capture_backend_problem': self.capture.backend_error if self.capture is not None else None,
            'sensor_thread_alive': bool(self.sensor_thread is not None and self.sensor_thread.is_alive()),
            'sensor_error': self.sensor_error,
            'sensor_last_success_age': round(time.monotonic() - self.sensor_last_success, 3) if self.sensor_last_success is not None else None,
            'sensor_restarts': self.sensor_restarts,
            'input_release_verified': self.input_release_verified,
            'stop_input_channels': self.listener.mode if self.listener is not None else None,
            'stop_raw_events': self.listener.raw_events if self.listener is not None else 0,
            'stop_hook_events': self.listener.hook_events if self.listener is not None else 0,
            'stop_hotkey_events': self.listener.hotkey_events if self.listener is not None else 0,
            'stop_poll_events': self.stop_gate.poll_stops,
            'stop_backup_poll_healthy': self.listener.poll_healthy() if self.listener is not None else False,
            'stop_event_listener_healthy': self.listener.event_healthy() if self.listener is not None else False,
            'stop_registered_channels': dict(self.listener.registered_channels) if self.listener is not None else {},
            'stop_registration_problem': self.listener.registration_error if self.listener is not None else None,
            'input_events_accepted_by_windows': self.controller.successful_inputs if self.controller is not None else 0,
            'game_received_input': None,
            'stop_detection': getattr(self.listener, 'mode', 'fallback_poll'),
            'first_run_checks': {
                'capture_ok': self.last_capture_valid is True and bool(self.last_signature),
                'capture_trainable': bool(self.last_observation_quality and self.last_observation_quality.get('trainable')),
                'feedback_captured': self.feedback_captures > 0,
                'completed_actions': self.completed_actions > 0,
                'input_effect_observed': self.visual_input_effects > 0,
                'valid_transitions': self.brain.valid_transitions > 0 if self.brain is not None else False,
                'experience_disk_roundtrip': self.brain.store_roundtrip_verified if self.brain is not None else False,
                'learning_updates': self.brain.updates > 0 if self.brain is not None else False,
                'sqlite_connected': bool(self.brain.store is not None) if self.brain is not None else False,
                'checkpoint_verified': self.brain.checkpoint_verified if self.brain is not None else False,
            },
        }
        path = self.folder / 'runtime_state.json'
        temp = self.folder / 'runtime_state.json.tmp'
        with temp.open('w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        os.replace(temp, path)
        self.last_status_written = now

    def safe_status(self, force=False):
        try:
            self.write_status(force=force)
        except Exception as exc:
            self.error(exc)

    def check_stop_fallback(self):
        if self.stop_event.is_set():
            return True
        return self.stop_gate.poll(allow_press=True)

    def ensure_listener(self):
        if (self.listener is not None and self.listener.healthy()
                and (self.listener.event_healthy() or self.listener.mode == 'poll')):
            return
        if self.listener is not None:
            self.listener.close()
        self.listener = StopListener(self.native, self.stop_vk, self.stop_event, self.stop_gate)
        self.listener.start()
        if not self.listener.healthy() and not self.stop_event.is_set():
            raise OSError('停止键双通道监听无法正常运行')

    def sensor_loop(self):
        com_initialized = self.native.ole.CoInitializeEx(None, 2) in (0, 1)
        local_capture = None
        capture_owned = False
        last_report = 0.0
        consecutive_sensor_errors = 0
        try:
            while not self.sensor_stop.is_set() and not self.stop_event.is_set():
                if CAPTURE_OWNER_LOCK.acquire(timeout=0.2):
                    capture_owned = True
                    break
            if not capture_owned:
                return
            local_capture = Capture(self.native, self.mode, self.own_hwnd)
            if self.mode == '窗口':
                if self.capture_target_signature is not None:
                    local_capture.target_signature = self.capture_target_signature
                    local_capture.target_pid = self.capture_target_pid
                    if self.capture_target_hwnd and self.native.user.IsWindow(self.capture_target_hwnd) and local_capture._same_target(self.capture_target_hwnd):
                        local_capture.target = self.capture_target_hwnd
                elif self.window_hint is not None and self.native.user.IsWindow(self.window_hint):
                    identity = local_capture._window_identity(self.window_hint)
                    candidate_rect = RECT()
                    allowed = bool(identity is not None and self.native.user.GetForegroundWindow() == self.window_hint
                                   and self.native.user.IsWindowVisible(self.window_hint)
                                   and not self.native.user.IsIconic(self.window_hint)
                                   and self.native.user.GetClientRect(self.window_hint, ctypes.byref(candidate_rect))
                                   and local_capture._window_rank(self.window_hint, identity, candidate_rect.right - candidate_rect.left,
                                                                  candidate_rect.bottom - candidate_rect.top, self.native.user.GetForegroundWindow()) is not None)
                    if allowed:
                        local_capture._stable_window_candidate((0, self.window_hint, identity), 0.45)
            self.capture = local_capture
            self.sensor_ready.set()
            while not self.sensor_stop.is_set() and not self.stop_event.is_set():
                request = None
                with self.sensor_condition:
                    if self.detail_requests:
                        request = self.detail_requests.popleft()
                    quality = self.sensor_quality
                    self.sensor_quality = None
                if request is not None:
                    try:
                        request['value'] = local_capture.grab_detail(*request['args'])
                    except Exception as exc:
                        request['error'] = exc
                    finally:
                        request['done'].set()
                try:
                    if quality is not None:
                        local_capture.review_frame_quality(quality)
                    self.sensor_last_attempt = time.monotonic()
                    raw, rect = local_capture.grab()
                    captured_at = time.monotonic()
                    with self.sensor_condition:
                        self.sensor_sequence += 1
                        self.sensor_frames_total += 1
                        self.sensor_frame = (raw, rect, captured_at, self.sensor_sequence)
                        self.sensor_error = None
                        self.sensor_last_success = captured_at
                        self.sensor_condition.notify_all()
                    consecutive_sensor_errors = 0
                    self.capture_target_signature = local_capture.target_signature
                    self.capture_target_pid = local_capture.target_pid
                    self.capture_target_hwnd = local_capture.target
                    if self.mode == '窗口' and local_capture.target and local_capture.target_signature:
                        self.window_hint = local_capture.target
                    self.sensor_stop.wait(0.02)
                except Exception as exc:
                    if self.mode == '窗口' and ('原游戏窗口' in str(exc) or '输入焦点' in str(exc)):
                        consecutive_sensor_errors = 0
                    else:
                        consecutive_sensor_errors += 1
                    if consecutive_sensor_errors >= 12 and not self.sensor_stop.is_set():
                        try:
                            signature, pid, hwnd = local_capture.target_signature, local_capture.target_pid, local_capture.target
                            local_capture.close()
                            local_capture = Capture(self.native, self.mode, self.own_hwnd)
                            local_capture.target_signature = signature
                            local_capture.target_pid = pid
                            if hwnd and self.native.user.IsWindow(hwnd) and local_capture._same_target(hwnd):
                                local_capture.target = hwnd
                            self.capture = local_capture
                            consecutive_sensor_errors = 0
                        except Exception as renew_exc:
                            self.error(renew_exc)
                    with self.sensor_condition:
                        self.sensor_error = f'{type(exc).__name__}: {str(exc)[:180]}'
                        self.sensor_condition.notify_all()
                    if time.monotonic() - last_report > 4.0:
                        self.capture_failures += 1
                        self.error(exc)
                        last_report = time.monotonic()
                    self.sensor_stop.wait(0.12)
        except Exception as exc:
            with self.sensor_condition:
                self.sensor_error = f'{type(exc).__name__}: {str(exc)[:180]}'
                self.sensor_condition.notify_all()
            self.error(exc)
        finally:
            self.sensor_ready.set()
            if local_capture is not None:
                self.capture_target_signature = local_capture.target_signature
                self.capture_target_pid = local_capture.target_pid
                self.capture_target_hwnd = local_capture.target
                try:
                    local_capture.close()
                except Exception as exc:
                    self.error(exc)
            with self.sensor_condition:
                for request in self.detail_requests:
                    request['error'] = OSError('图像采集线程已终止')
                    request['done'].set()
                self.detail_requests.clear()
                self.sensor_condition.notify_all()
            if self.capture is local_capture:
                self.capture = None
            if capture_owned:
                CAPTURE_OWNER_LOCK.release()
            if com_initialized:
                self.native.ole.CoUninitialize()

    def start_sensor(self):
        if self.sensor_thread is not None and self.sensor_thread.is_alive():
            if self.sensor_stop.is_set():
                raise OSError('旧采集线程尚未退出，等待释放原 DXGI/GDI 设备')
            return
        self.sensor_stop.clear()
        self.sensor_ready.clear()
        with self.sensor_condition:
            self.sensor_frame = None
            self.sensor_error = None
        self.sensor_restarts += 1
        self.sensor_thread = threading.Thread(target=self.sensor_loop, name='AgentVision', daemon=True)
        self.sensor_thread.start()
        deadline = time.monotonic() + 12.0
        while not self.stop_event.is_set() and self.sensor_thread.is_alive() and time.monotonic() < deadline:
            if self.sensor_ready.wait(0.12):
                break
        if self.stop_event.is_set():
            return
        if self.capture is None:
            raise OSError(self.sensor_error or '图像采集线程未能初始化，请检查驱动和窗口状态')

    def sample_frame(self, min_sequence=None, timeout=1.7):
        start = time.monotonic()
        deadline = start + max(0.2, timeout)
        last_attempt = self.sensor_last_attempt
        with self.sensor_condition:
            while not self.stop_event.is_set():
                frame = self.sensor_frame
                if frame is not None and (min_sequence is None or frame[3] > min_sequence):
                    if time.monotonic() - frame[2] <= 2.0:
                        self.last_sensor_sequence = frame[3]
                        return frame[0], frame[1]
                if self.sensor_thread is None or not self.sensor_thread.is_alive():
                    break
                now = time.monotonic()
                if self.sensor_last_attempt is not None and self.sensor_last_attempt != last_attempt:
                    last_attempt = self.sensor_last_attempt
                    deadline = max(deadline, min(start + 8.0, now + max(0.2, timeout)))
                remaining = deadline - now
                if remaining <= 0:
                    break
                self.sensor_condition.wait(min(0.10, remaining))
        raise OSError('等待新的游戏画面超时：' + str(self.sensor_error or '采集设备无新帧'))

    def sample_detail(self, rect, u, v):
        event = threading.Event()
        request = {'args': (rect, u, v), 'done': event}
        with self.sensor_condition:
            self.detail_requests.append(request)
            self.sensor_condition.notify_all()
        deadline = time.monotonic() + 4.0
        while not self.stop_event.is_set() and not event.is_set():
            if not self.sensor_thread or not self.sensor_thread.is_alive():
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            event.wait(min(0.10, remaining))
        if not event.is_set():
            with self.sensor_condition:
                try:
                    self.detail_requests.remove(request)
                except ValueError:
                    pass
            raise OSError('精细画面采集超时或采集线程已失效')
        if 'error' in request:
            raise request['error']
        return request['value']

    def note_frame_quality(self, quality):
        with self.sensor_condition:
            self.sensor_quality = quality

    def capture_is_stale(self, max_age=1.5):
        with self.sensor_condition:
            frame = self.sensor_frame
        return bool(self.sensor_thread is None or not self.sensor_thread.is_alive()
                    or frame is None or time.monotonic() - frame[2] > max_age)

    def action_monitor(self, old):
        if self.stop_event.is_set():
            return 'stop_key'
        if self.listener is None or not self.listener.healthy():
            return 'stop_listener_unhealthy'
        if self.capture_is_stale():
            return 'capture_stale'
        if self.mode == '窗口' and self.capture is not None and not self.capture.is_target_focused():
            return 'focus_lost'
        with self.sensor_condition:
            frame = self.sensor_frame
        if frame is None or frame[3] <= self.last_sensor_sequence or old.raw is None or frame[1] != old.rect:
            return True
        data = frame[0]
        step = max(1, (W * H) // 150)
        magnitude = sum(abs(data[i * 4] - old.raw[i * 4]) + abs(data[i * 4 + 1] - old.raw[i * 4 + 1]) + abs(data[i * 4 + 2] - old.raw[i * 4 + 2]) for i in range(0, W * H, step))
        samples = len(range(0, W * H, step))
        natural = max(old.change, self.brain.game.passive_change if self.brain is not None else 0.0)
        threshold = max(0.23, min(0.52, 0.29 + natural * 1.6))
        if magnitude / max(1, samples * 3 * 255) > threshold:
            self.monitor_breaks += 1
            return 'visual_change'
        return True

    def cleanup_capture(self):
        self.sensor_stop.set()
        with self.sensor_condition:
            self.sensor_condition.notify_all()
        worker = self.sensor_thread
        if worker is not None and worker.is_alive() and worker is not threading.current_thread():
            worker.join(timeout=2.5)
        if worker is not None and worker.is_alive():
            with self.sensor_condition:
                self.sensor_frame = None
                self.sensor_error = '旧采集线程退出超时，保留线程引用并阻止同时开启第二个采集器'
            return False
        if self.sensor_thread is worker:
            self.sensor_thread = None
        with self.sensor_condition:
            self.sensor_frame = None
        return True

    def resync_after_interruption(self):
        if self.controller is not None:
            self.controller.release(retries=5)
        self.phase = 'capturing'
        if self.capture_is_stale():
            raise OSError('动作中断后画面采集已失效，需要重新初始化')
        raw, rect = self.sample_frame(min_sequence=self.last_sensor_sequence, timeout=3.0)
        self.last_capture_at = time.time()
        self.last_rect = rect
        game_key = self.brain.identify_game(self.capture.game_identity(), raw)
        if game_key != self.brain.game_key:
            self.brain.set_game(game_key)
            self.visual_game_switches += 1
        self.brain.previous_lum = None
        self.brain.previous_motion = None
        self.brain.temporal_luma.clear()
        self.brain.last_attention_tracks = []
        self.brain.last_detail_focus = (0.5, 0.5)
        observation = self.brain.observe(raw, rect)
        self.last_visual_target_count = len(observation.attention_points)
        self.last_capture_valid = observation.valid
        self.last_observation_quality = observation.quality
        self.last_signature = observation.signature
        self.note_frame_quality(observation.quality)
        self.brain.persist_initial_frame(observation)
        self.safe_status()
        return observation, rect

    def capture_action_feedback(self, old, rect, action):
        start = time.monotonic()
        with self.sensor_condition:
            current_sequence = self.sensor_sequence
        raw, newrect = self.sample_frame(min_sequence=current_sequence)
        self.last_capture_at = time.time()
        self.last_rect = newrect
        delay = self.brain.game.feedback_delay
        if action.kind in ('move', 'look', 'aim', 'combat', 'hold', 'swipe', 'right_swipe'):
            deadlines = (max(0.025, delay * 0.45), max(0.07, delay * 1.3))
        else:
            deadlines = (max(0.045, delay * 0.85), max(0.10, delay * 2.1))
        if self.brain.step % 9 == 0:
            deadlines = (*deadlines, min(0.60, max(0.32, delay * 3.2)))
        samples = [(raw, newrect)]
        for deadline in deadlines:
            if newrect != rect or self.stop_event.wait(max(0.0, deadline - (time.monotonic() - start))):
                break
            with self.sensor_condition:
                current_sequence = self.sensor_sequence
            raw, newrect = self.sample_frame(min_sequence=current_sequence)
            self.last_capture_at = time.time()
            self.last_rect = newrect
            samples.append((raw, newrect))
        deltas = []
        recent_lum = []
        self.feedback_captures += 1
        if any(item[1] != rect for item in samples):
            return raw, newrect, {'frame_deltas': [], 'settled_change': 0.0, 'hud_stability': 0.0, 'frame_stability': 0.0}
        for data, _ in samples:
            pixels = self.brain.rgb_blocks(data)
            lum = [luminance_bgr(*pixel) for pixel in pixels]
            recent_lum.append(lum)
            deltas.append(sum(abs(a - b) for a, b in zip(old.lum, lum)) / (GW * GH))
        hud_indices = [r * GW + c for r in (0, 1, GH - 2, GH - 1) for c in range(GW)]
        final_change = sum(abs(old.lum[i] - recent_lum[-1][i]) for i in hud_indices) / len(hud_indices)
        drift = (sum(abs(recent_lum[-1][i] - recent_lum[-2][i]) for i in hud_indices) / len(hud_indices)) if len(recent_lum) > 1 else 0.0
        stability = max(0.0, min(1.0, 1.0 - drift / max(0.015, final_change * 1.4)))
        frame_drift = (sum(abs(a - b) for a, b in zip(recent_lum[-1], recent_lum[-2])) / (GW * GH)) if len(recent_lum) > 1 else 1.0
        frame_stability = max(0.0, min(1.0, 1.0 - frame_drift / max(0.025, deltas[-1] * 0.7)))
        return raw, newrect, {'frame_deltas': deltas, 'settled_change': deltas[-1], 'hud_stability': stability, 'frame_stability': frame_stability}


    def run(self):
        try:
            try:
                self.safe_status(force=True)
            except Exception as exc:
                self.error(exc)
            while not self.check_stop_fallback():
                try:
                    self.phase = 'initializing'
                    self.ensure_listener()
                    if self.capture is None or self.sensor_stop.is_set():
                        self.start_sensor()
                    if self.controller is None:
                        self.controller = Controller(self.native, self.stop_vk, self.stop_event)
                        self.controller.stop_gate = self.stop_gate
                    if self.brain is None:
                        self.brain = Brain(self.folder, self.stop_vk, self.np)
                        if self.brain.store_problem:
                            self.error(OSError(self.brain.store_problem))
                            self.brain.store_problem = None
                    self.phase = 'capturing'
                    raw, rect = self.sample_frame(timeout=3.0)
                    self.last_capture_at = time.time()
                    self.last_rect = rect
                    game_key = self.brain.identify_game(self.capture.game_identity(), raw)
                    self.brain.set_game(game_key)
                    try:
                        self.stop_event.wait(0.035)
                        passive, passive_rect = self.sample_frame(min_sequence=self.last_sensor_sequence)
                        if passive_rect == rect:
                            self.brain.record_passive_change(raw, passive)
                            raw = passive
                    except Exception as exc:
                        self.error(exc)
                    try:
                        detail = self.sample_detail(rect, 0.5, 0.5)
                    except Exception as exc:
                        self.error(exc)
                        detail = None
                    obs = self.brain.observe(raw, rect, detail)
                    self.last_visual_target_count = len(obs.attention_points)
                    self.last_capture_valid = obs.valid
                    self.last_observation_quality = obs.quality
                    self.last_signature = obs.signature
                    self.note_frame_quality(obs.quality)
                    self.brain.persist_initial_frame(obs)
                    self.safe_status(force=True)
                    plan = deque()
                    plan_parameters = deque()
                    plan_predictions = deque()
                    chosen_plan = []
                    while not self.check_stop_fallback():
                        now = time.monotonic()
                        if now - self.last_worker_check >= 0.75:
                            self.ensure_listener()
                            self.brain.ensure_workers()
                            self.last_worker_check = now
                        if self.capture_is_stale():
                            raise OSError('采集画面已过期或采集线程失效，需要重启采集器')
                        if not plan:
                            chosen_plan = self.brain.choose_plan(obs)
                            plan.extend(chosen_plan)
                            plan_parameters = deque(self.brain.last_plan_parameters)
                            plan_predictions = deque(self.brain.last_plan_predictions)
                        index = plan.popleft()
                        expected_state = plan_predictions.popleft() if plan_predictions else None
                        action = self.brain.actions[index]
                        self.phase = 'acting'
                        saved_parameters = plan_parameters.popleft() if plan_parameters else None
                        parameters = saved_parameters if saved_parameters is not None else self.brain.recommend_action_parameters(index, obs)
                        self.controller.guard = self.capture.is_target_focused if self.capture is not None else None
                        completed = self.controller.execute(action, obs, rect, self.brain.stagnation, parameters,
                                                            monitor=(lambda previous=obs: self.action_monitor(previous)),
                                                            feedback_delay=self.brain.game.feedback_delay)
                        action_detail = self.controller.last_action_detail
                        self.last_input_at = time.time() if action_detail and action_detail.get('input_sent') else self.last_input_at
                        if self.check_stop_fallback():
                            break
                        if self.controller.interruption_reason == 'capture_stale':
                            raise OSError('动作期间画面采集停滞，释放输入并恢复采集')
                        if self.controller.interruption_reason == 'stop_listener_unhealthy':
                            raise OSError('停止键监听心跳失效，重新安装键盘钩子')
                        if not completed or (isinstance(action_detail, dict) and action_detail.get('interrupted')):
                            if action_detail and action_detail.get('input_sent'):
                                self.partial_actions += 1
                            self.brain.learn_boundary(obs, index, 'action_interrupted', action_detail)
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                            obs, rect = self.resync_after_interruption()
                            continue
                        if action_detail.get('finished'):
                            self.completed_actions += 1
                        else:
                            self.partial_actions += 1
                            self.brain.learn_boundary(obs, index, 'action_partially_finished', action_detail)
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                            obs, rect = self.resync_after_interruption()
                            continue
                        self.phase = 'capturing'
                        newraw, newrect, feedback = self.capture_action_feedback(obs, rect, action)
                        action_detail['feedback_valid'] = newrect == rect and bool(feedback.get('frame_deltas'))
                        if self.check_stop_fallback():
                            break
                        following_game = self.brain.identify_game(self.capture.game_identity(), newraw)
                        if following_game != self.brain.game_key:
                            learned = self.brain.learn_boundary(obs, index, 'game_process_switch', self.controller.last_action_detail)
                            if learned:
                                self.last_experience_at = time.time()
                            self.episode_boundaries += 1
                            self.events.append({'t': round(time.time(), 2), 'game': self.brain.game_key, 'step': self.brain.step, 'action': action.id, 'game_switch': following_game, 'reward_basis': 'terminal_with_unobserved_result_no_cross_game_training'})
                            self.brain.set_game(following_game)
                            self.visual_game_switches += 1
                            plan.clear()
                            plan_predictions.clear()
                            following = self.brain.observe(newraw, newrect)
                            self.last_visual_target_count = len(following.attention_points)
                            self.brain.persist_initial_frame(following)
                            obs, rect = following, newrect
                            self.last_capture_valid = following.valid
                            self.last_observation_quality = following.quality
                            self.last_signature = following.signature
                            self.note_frame_quality(following.quality)
                            self.brain.save(force=self.brain.step == 1)
                            self.safe_status(force=True)
                            continue
                        detail = None
                        if self.brain.step % 4 == 0 or (action.kind in ('click', 'right', 'double', 'focus_click', 'press', 'touch_tap', 'swipe', 'touch_swipe', 'combat', 'aim') and (obs.novelty >= 0.60 or self.brain.stagnation > 8 or self.brain.step % 2 == 0)):
                            try:
                                u, v = self.brain.detail_focus(obs, self.controller.last_action_detail)
                                detail = self.sample_detail(newrect, u, v)
                            except Exception as exc:
                                self.error(exc)
                        following = self.brain.observe(newraw, newrect, detail)
                        self.last_visual_target_count = len(following.attention_points)
                        self.last_capture_valid = following.valid
                        self.last_observation_quality = following.quality
                        self.last_signature = following.signature
                        self.note_frame_quality(following.quality)
                        self.phase = 'learning'
                        self.brain.persist_initial_frame(following)
                        if not action_detail.get('feedback_valid', False):
                            self.brain.learn_boundary(obs, index, 'unreliable_action_feedback', action_detail)
                            self.safe_status()
                            plan.clear()
                            plan_predictions.clear()
                            obs, rect = following, newrect
                            continue
                        reward, delta = self.brain.reward_for(obs, following, index, action_detail, feedback)
                        if float(self.brain.reward_info.get('causal_confidence', 0.0)) >= 0.32 and float(self.brain.reward_info.get('persistent_visual_change', 0.0)) >= 0.35:
                            self.visual_input_effects += 1
                        episode_boundary = bool(self.brain.reward_info.get('episode_boundary', False))
                        if episode_boundary:
                            self.episode_boundaries += 1
                        before_count = self.brain.valid_transitions
                        self.brain.learn(obs, index, following, reward, delta, done=episode_boundary, effect=action_detail)
                        if self.brain.valid_transitions > before_count:
                            self.last_experience_at = time.time()
                        self.events.append({
                            't': round(time.time(), 2),
                            'game': self.brain.game_key,
                            'step': self.brain.step,
                            'category': action.category,
                            'action': action.id,
                            'observation_valid': following.valid,
                            **self.brain.reward_info,
                            'screen': following.signature,
                        })
                        prediction_deviation = (sum(abs(x - y) for x, y in zip(expected_state, following.features[:32])) / 32.0) if expected_state is not None else 0.0
                        if not plan and action_detail.get('finished'):
                            self.brain.mark_plan_result(chosen_plan, following, self.brain.reward_info)
                        if episode_boundary or prediction_deviation > 0.11:
                            plan.clear()
                            plan_predictions.clear()
                        if self.brain.step % 24 == 0 and not self.check_stop_fallback():
                            try:
                                self.stop_event.wait(0.04)
                                passive_raw, passive_rect = self.sample_frame(min_sequence=self.last_sensor_sequence)
                                if passive_rect == newrect:
                                    self.brain.record_passive_change(newraw, passive_raw)
                                    following = self.brain.observe(passive_raw, passive_rect)
                                    self.last_visual_target_count = len(following.attention_points)
                                    self.last_capture_valid = following.valid
                                    self.last_observation_quality = following.quality
                                    self.last_signature = following.signature
                                    self.note_frame_quality(following.quality)
                            except Exception as exc:
                                self.error(exc)
                        self.brain.save(force=(self.brain.step == 1))
                        self.safe_status(force=(self.brain.step == 1))
                        if self.brain.store_problem:
                            self.error(OSError(self.brain.store_problem))
                            self.brain.store_problem = None
                        if self.brain.training_problem:
                            self.error(RuntimeError(self.brain.training_problem))
                            self.brain.training_problem = None
                        if self.brain.storage_problem:
                            self.error(OSError(self.brain.storage_problem))
                            self.brain.storage_problem = None
                        if delta > 0.38:
                            plan.clear()
                            plan_predictions.clear()
                        obs, rect = following, newrect
                except Exception as exc:
                    failed_phase = self.phase
                    self.phase = 'recovering'
                    self.error(exc)
                    inputs_released = self.controller is None
                    try:
                        if self.controller is not None:
                            self.controller.release()
                            inputs_released = not (self.controller.down or self.controller.mouse_down or self.controller.touch_points)
                    except Exception as release_error:
                        self.error(release_error)
                    capture_failure = (failed_phase in ('initializing', 'capturing') or self.capture is None
                                       or self.capture_is_stale() or (self.sensor_thread is not None and not self.sensor_thread.is_alive()))
                    if failed_phase == 'acting' and self.controller is not None and inputs_released and not self.stop_event.is_set():
                        self.controller = None
                    if capture_failure:
                        try:
                            self.cleanup_capture()
                        except Exception as capture_error:
                            self.error(capture_error)
                    if self.brain is not None:
                        if failed_phase in ('initializing', 'learning', 'capturing') and self.brain.np is not None and self.same_error_count >= 2:
                            try:
                                if self.brain.recover_backend():
                                    self.np = self.brain.np
                            except Exception as backend_error:
                                self.error(backend_error)
                                try:
                                    self.brain.save(force=True)
                                    self.brain.close()
                                except Exception as closing_error:
                                    self.error(closing_error)
                                self.brain = None
                                try:
                                    self.np = importlib.import_module('numpy')
                                    validate_learning_backend(self.np)
                                except Exception:
                                    self.np = None
                        if self.brain is not None and capture_failure:
                            self.brain.previous_lum = None
                            self.brain.previous_motion = None
                            self.brain.temporal_luma.clear()
                            self.brain.last_attention_tracks = []
                        if self.brain is not None:
                            try:
                                self.brain.flush_pending(done=False)
                                self.brain.ensure_workers()
                            except Exception as storage_error:
                                self.error(storage_error)
                    try:
                        self.safe_status()
                    except Exception as status_error:
                        self.error(status_error)
                    if not self.check_stop_fallback():
                        self.stop_event.wait(min(0.8, 0.05 + self.same_error_count * 0.01))
        finally:
            self.phase = 'stopped' if self.stop_event.is_set() else 'recovering'
            self.input_release_verified = self.controller is None
            if self.controller is not None:
                try:
                    self.controller.release(retries=6)
                except Exception as exc:
                    self.error(exc)
                self.input_release_verified = not (self.controller.down or self.controller.mouse_down or self.controller.touch_points)
            if self.stop_event.is_set() and self.input_release_verified and self.on_input_released is not None:
                try:
                    self.on_input_released()
                except Exception as exc:
                    self.error(exc)
            if self.brain is not None:
                try:
                    self.brain.flush_pending(done=False)
                    self.brain.stop_training()
                    self.brain.save(force=True)
                except Exception as exc:
                    self.error(exc)
                try:
                    self.brain.close()
                except Exception as exc:
                    self.error(exc)
            try:
                self.safe_status(force=True)
            except Exception as exc:
                self.error(exc)
            try:
                self.cleanup_capture()
            except Exception as exc:
                self.error(exc)
            if self.listener is not None:
                self.listener.close()


def validate_learning_backend(module):
    worker = Brain.__new__(Brain)
    worker.np = module
    worker.actions = [Action('none', 'key'), Action('click', 'click'), Action('other', 'key')]
    before = [0.15 + (i % 5) * 0.035 for i in range(FEATURE_COUNT)]
    after = [0.25 + (i % 7) * 0.021 for i in range(FEATURE_COUNT)]
    rows = [[0.002] * FEATURE_COUNT for _ in range(8)]
    zeros = [0.0] * 8
    head = [[0.0] * 8 for _ in range(3)]
    bias = [0.0] * 3
    if module is not None:
        rows = module.asarray(rows, dtype=module.float32)
        zeros = module.asarray(zeros, dtype=module.float32)
        head = module.asarray(head, dtype=module.float32)
        bias = module.asarray(bias, dtype=module.float32)
    def clone(value):
        return value.copy() if module is not None else [row[:] if isinstance(row, list) else row for row in value]
    snapshot = {
        'encoder': clone(rows), 'encoder_bias': clone(zeros),
        'target_encoder': clone(rows), 'target_encoder_bias': clone(zeros),
        'games': {'verification': {
            'q': clone(head), 'bias': clone(bias),
            'target_q': clone(head), 'target_bias': clone(bias), 'counts': [0, 0, 0],
            'parameter_heads': {'click': {'w': module.zeros((4, 8), dtype=module.float32) if module is not None else [[0.0] * 8 for _ in range(4)],
                                           'b': module.zeros(4, dtype=module.float32) if module is not None else [0.0] * 4,
                                           'samples': 0}},
        }},
    }
    transition = ['verification', before, 1, 0.32, after, 0.3, True, 1, 1.0,
                  {'kind': 'click', 'input_sent': True, 'finished': True, 'spatial': True, 'start_x': 0.78,
                   'start_y': 0.25, 'requested_duration': 0.18, 'extent': 1.0}]
    results = worker._train_batch([transition], snapshot)
    if len(results) != 1 or not math.isfinite(results[0][1]):
        raise ArithmeticError('学习后端未能产生有效训练结果')
    value = snapshot['games']['verification']['bias'][1]
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ArithmeticError('学习后端没有完成参数更新')
    parameter = snapshot['games']['verification']['parameter_heads']['click']
    if parameter['samples'] != 1 or not math.isfinite(float(parameter['b'][0])) or float(parameter['b'][0]) <= 0.0:
        raise ArithmeticError('学习后端没有完成坐标和时长参数更新')
    return True


def acceleration_for(folder, status):
    runtime = folder / '_runtime'
    gpu_runtime = folder / '_gpu_runtime'
    wheel_dir = folder / '_verified_wheels'
    for path in (gpu_runtime, runtime):
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
    def gpu_backend():
        try:
            module = importlib.import_module('cupy')
            if module.cuda.runtime.getDeviceCount() <= 0:
                return None
            values = module.asarray([[1.0, 2.0], [3.0, 4.0]], dtype=module.float32)
            if module.asnumpy(values @ values).shape != (2, 2):
                return None
            module.clip(values, -1.0, 1.0, out=values)
            return module
        except Exception:
            return None
    def verified_cpu(module):
        try:
            x = module.asarray([[0.1] * FEATURE_COUNT, [0.2] * FEATURE_COUNT], dtype=module.float32)
            weight = module.ones((12, FEATURE_COUNT), dtype=module.float32) * module.float32(0.004)
            hidden = module.tanh(x @ weight.T)
            head = module.zeros((3, 12), dtype=module.float32)
            actions = module.asarray([0, 2], dtype=module.int32)
            module.add.at(head, actions, hidden * module.float32(0.01))
            values = (head @ hidden.T).tolist()
            return len(values) == 3 and len(values[0]) == 2 and all(math.isfinite(float(v)) for row in values for v in row)
        except Exception:
            return False
    def command(args, timeout):
        try:
            proc = subprocess.run(args, capture_output=True, stdin=subprocess.DEVNULL, timeout=timeout,
                                  creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            return proc.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False
    def wheel_compatible(filename):
        if not isinstance(filename, str) or not filename.endswith('.whl') or pathlib.PureWindowsPath(filename).name != filename or '/' in filename:
            return False
        parts = filename[:-4].split('-')
        if len(parts) not in (5, 6):
            return False
        interpreters, abis, platforms = (tag.split('.') for tag in parts[-3:])
        if not any(item in ('any', 'win_amd64') for item in platforms):
            return False
        version = sys.version_info.major * 100 + sys.version_info.minor
        free_threaded = bool(sysconfig.get_config_var('Py_GIL_DISABLED'))
        current_tag = f'cp{sys.version_info.major}{sys.version_info.minor}'
        current_abi = current_tag + ('t' if free_threaded else '')
        for interpreter in interpreters:
            if interpreter in ('py3', f'py{sys.version_info.major}{sys.version_info.minor}') and 'none' in abis:
                return True
            if interpreter == current_tag and any(abi in (current_abi, 'none') for abi in abis):
                return True
            if not free_threaded and interpreter.startswith('cp3') and interpreter[3:].isdigit() and int(interpreter[2:]) <= version and 'abi3' in abis:
                return True
        return False
    def cache_valid(package, requirement=None):
        manifest = wheel_dir / (package + '.json')
        try:
            info = json.loads(manifest.read_text(encoding='utf-8'))
            if (info.get('package') != package or not info.get('requirement')
                    or info.get('python') != f'{sys.version_info.major}.{sys.version_info.minor}' or info.get('platform') != sys.platform
                    or info.get('architecture') != 'x64' or info.get('implementation') != sys.implementation.cache_tag
                    or info.get('source') != 'pypi_release_sha256'
                    or (requirement is not None and info.get('requirement') != requirement)):

                return []
            selected = []
            for entry in info.get('wheels', []):
                if not isinstance(entry, dict):
                    return []
                name = entry.get('filename', '')
                path = wheel_dir / name
                if not wheel_compatible(name) or path.name != name or not path.is_file() or not zipfile.is_zipfile(path):
                    return []
                with path.open('rb') as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                if digest != entry.get('sha256'):
                    return []
                selected.append(path)
            return selected
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return []

    def select_requirement(package, minimum_version, maximum_major, fallback=None, distribution=None):
        distribution = distribution or package
        cached = cache_valid(package)
        if cached:
            try:
                saved = json.loads((wheel_dir / (package + '.json')).read_text(encoding='utf-8'))
                return saved['requirement']
            except (OSError, ValueError, KeyError, TypeError):
                pass
        url = 'https://pypi.org/pypi/' + urllib.parse.quote(distribution, safe='') + '/json'
        try:
            request = urllib.request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'OfflineGameAgent/1'})
            with urllib.request.urlopen(request, timeout=7.0) as response:
                raw = response.read(16_000_001)
            if len(raw) > 16_000_000:
                return fallback
            releases = json.loads(raw).get('releases', {})
            minimum = tuple(int(piece) for piece in minimum_version.split('.'))
            candidates = []
            for version, files in releases.items():
                parts = version.split('.')
                if not (2 <= len(parts) <= 4 and all(piece.isdecimal() for piece in parts)):
                    continue
                numbers = tuple(map(int, parts))
                if numbers < minimum or numbers[0] >= maximum_major:
                    continue
                if any(item.get('packagetype') == 'bdist_wheel' and wheel_compatible(item.get('filename'))
                       and not item.get('yanked', False) for item in files):
                    candidates.append((numbers, version))
            return f'{distribution}=={max(candidates)[1]}' if candidates else None
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            return fallback
    def authoritative_hash(filename):
        parts = filename[:-4].split('-')
        if len(parts) not in (5, 6):
            return None
        distribution, version = parts[0].replace('_', '-'), parts[1]
        url = ('https://pypi.org/pypi/' + urllib.parse.quote(distribution, safe='') + '/'
               + urllib.parse.quote(version, safe='') + '/json')
        request = urllib.request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'OfflineGameAgent/1'})
        with urllib.request.urlopen(request, timeout=10.0) as response:
            payload = response.read(12_000_001)
            if len(payload) > 12_000_000:
                raise ValueError('软件仓库发布元数据超过安全大小')
        release = json.loads(payload)
        for item in release.get('urls', []):
            if item.get('filename') == filename and item.get('packagetype') == 'bdist_wheel':
                value = item.get('digests', {}).get('sha256', '')
                return value.lower() if isinstance(value, str) and len(value) == 64 else None
        return None

    def download(package, requirement, timeout):
        cached = cache_valid(package, requirement)
        if cached:
            return cached
        online = False
        try:
            with socket.create_connection(('pypi.org', 443), timeout=2.0):
                online = True
        except OSError:
            pass
        if not online:
            return []
        stage_dir = folder / ('_wheel_download_' + uuid.uuid4().hex)
        stage_dir.mkdir(parents=True, exist_ok=True)
        try:
            cmd = [sys.executable, '-m', 'pip', 'download', requirement, '--dest', str(stage_dir),
                   '--only-binary=:all:', '--disable-pip-version-check', '--no-cache-dir', '--no-input', '--retries', '1' if online else '0', '--timeout', '7', '-q']
            if not command(cmd, timeout):
                return []
            wheels = sorted(stage_dir.glob('*.whl'))
            if not wheels:
                return []
            wheel_dir.mkdir(parents=True, exist_ok=True)
            info = {'package': package, 'requirement': requirement, 'python': f'{sys.version_info.major}.{sys.version_info.minor}', 'platform': sys.platform, 'architecture': 'x64', 'implementation': sys.implementation.cache_tag, 'source': 'pypi_release_sha256', 'wheels': []}
            paths = []
            for wheel in wheels:
                if not wheel_compatible(wheel.name) or not zipfile.is_zipfile(wheel):
                    return []
                with wheel.open('rb') as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                try:
                    published = authoritative_hash(wheel.name)
                except (OSError, ValueError, TypeError, json.JSONDecodeError):
                    return []
                if published is None or published != digest:
                    return []
                destination = wheel_dir / wheel.name
                if destination.exists() and destination.is_file():
                    with destination.open('rb') as stream:
                        previous = hashlib.file_digest(stream, 'sha256').hexdigest()
                    if previous != digest:
                        return []
                else:
                    os.replace(wheel, destination)
                paths.append(destination)
                info['wheels'].append({'filename': destination.name, 'sha256': digest})
            name = wheel_dir / (package + '.json')
            temp = wheel_dir / (package + '.json.tmp')
            with temp.open('w', encoding='utf-8') as stream:
                json.dump(info, stream, ensure_ascii=False, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, name)
            return paths
        finally:
            shutil.rmtree(stage_dir, ignore_errors=True)
    def install(package, requirement, destination, timeout, check):
        wheels = download(package, requirement, timeout)
        if not wheels:
            return False
        stage = folder / ('_runtime_stage_' + uuid.uuid4().hex)
        backup = folder / ('_runtime_old_' + uuid.uuid4().hex)
        try:
            stage.mkdir(parents=True, exist_ok=False)
            verified_wheel_dir = stage / '_wheels'
            verified_wheel_dir.mkdir()
            for wheel in wheels:
                shutil.copy2(wheel, verified_wheel_dir / wheel.name)
            cmd = [sys.executable, '-m', 'pip', 'install', requirement, '--target', str(stage),
                   '--no-index', '--find-links', str(verified_wheel_dir), '--only-binary=:all:',
                   '--disable-pip-version-check', '--no-cache-dir', '--no-input', '-q']
            if not command(cmd, timeout):
                return False
            check_code = ('import sys;sys.path.insert(0,' + repr(str(stage)) + ');'
                          + 'import numpy as n;assert n.__version__;a=n.ones((2,2));assert (a@a).shape==(2,2)'
                          if check == 'numpy' else
                          'import sys;sys.path.insert(0,' + repr(str(runtime)) + ');sys.path.insert(0,' + repr(str(stage)) + ');'
                          + 'import cupy as c;assert c.cuda.runtime.getDeviceCount()>0;assert c.asnumpy(c.ones((2,2))@c.ones((2,2))).shape==(2,2)')
            if not command([sys.executable, '-I', '-c', check_code], min(35, timeout)):
                return False
            shutil.rmtree(verified_wheel_dir)
            if destination.exists():
                os.replace(destination, backup)
            try:
                os.replace(stage, destination)
            except BaseException:
                if backup.exists() and not destination.exists():
                    os.replace(backup, destination)
                raise
            importlib.invalidate_caches()
            if str(destination) not in sys.path:
                sys.path.insert(0, str(destination))
            return True
        except (OSError, ValueError, RuntimeError):
            return False
        finally:
            shutil.rmtree(stage, ignore_errors=True)
            if backup.exists():
                shutil.rmtree(backup, ignore_errors=True)
    cpu = None
    try:
        imported = importlib.import_module('numpy')
        if verified_cpu(imported):
            cpu = imported
    except Exception:
        pass
    if cpu is None:
        status('智能下载：检查 Python 兼容的 NumPy wheel 与校验锁文件')
        requirement = select_requirement('numpy', '2.5.0', 3, 'numpy==2.5.5')
        if requirement is not None and install('numpy', requirement, runtime, 150, 'numpy'):
            try:
                imported = importlib.import_module('numpy')
                if verified_cpu(imported):
                    cpu = imported
            except Exception:
                pass
    if cpu is not None:
        status('CPU 数值库就绪；离线训练与本机图像采集可用')
    gpu = gpu_backend()
    if gpu is None and cpu is not None and os.name == 'nt':
        try:
            ctypes.WinDLL('nvcuda.dll')
            status('检测 NVIDIA 数值加速 wheel 的 Python 与 CUDA 兼容性')
            requirement = select_requirement('cupy', '14.2.0', 15, distribution='cupy-cuda12x')
            if requirement is not None and install('cupy', requirement, gpu_runtime, 150, 'cupy'):
                gpu = gpu_backend()
            elif requirement is None:
                status('当前 Python ABI 暂无已确认兼容的 GPU wheel，继续使用 CPU 离线后端')
        except Exception:
            pass
    if gpu is not None and cpu is not None:
        def measure(module):
            sample = [[(i + j) % 11 / 11.0 for j in range(FEATURE_COUNT)] for i in range(24)]
            weights = module.ones((96, FEATURE_COUNT), dtype=module.float32) * module.float32(0.012)
            heads = module.ones((len(actions_for(27)), 96), dtype=module.float32) * module.float32(0.012)
            def batch():
                x = module.asarray(sample, dtype=module.float32)
                hidden = module.tanh(x @ weights.T)
                logits = hidden @ heads.T
                indices = module.argmax(logits, axis=1)
                result = module.sum(hidden * heads[indices], axis=1)
                hidden.T @ x
                if getattr(module, '__name__', '') == 'cupy':
                    module.asnumpy(result)
                else:
                    result.tolist()
            for _ in range(3):
                batch()
            start = time.perf_counter()
            for _ in range(8):
                batch()
            if getattr(module, '__name__', '') == 'cupy':
                module.cuda.Stream.null.synchronize()
            return max(1e-8, (time.perf_counter() - start) / 8)
        try:
            cpu_time = measure(cpu)
            gpu_time = measure(gpu)
            if gpu_time < cpu_time * 0.90:
                status('GPU 已通过实际运算基准，使用 GPU 加速；可断网使用')
                return gpu
            status('CPU 在当前决策与学习负载下更快，使用 CPU 数值加速；可断网使用')
            return cpu
        except Exception:
            status('GPU 基准测试不可用，使用稳定的 CPU 数值加速；可断网使用')
            return cpu
    if gpu is not None:
        status('GPU 数值加速组件已就绪；可断网使用')
        return gpu
    if cpu is not None:
        status('CPU 数值加速组件已就绪；可断网使用')
        return cpu
    status('纯 Python 和 Windows GDI 离线后备方案可用；数值训练性能可能偏低')
    return None


def profile_runtime(folder, module, capture_seconds=None):
    probe = Brain.__new__(Brain)
    probe.np = module
    try:
        probe.cv_np = importlib.import_module('numpy') if module is not None and getattr(module, '__name__', '') == 'cupy' else module
    except ImportError:
        probe.cv_np = None
    probe.hidden_size = MODEL_HIDDEN_SIZE
    count = len(actions_for(27))
    features = [((i * 17) % 39) / 39 for i in range(FEATURE_COUNT)]
    if module is not None:
        probe.encoder = module.ones((MODEL_HIDDEN_SIZE, FEATURE_COUNT), dtype=module.float32) * module.float32(0.002)
        probe.encoder_bias = module.zeros(MODEL_HIDDEN_SIZE, dtype=module.float32)
        head = module.ones((count, MODEL_HIDDEN_SIZE), dtype=module.float32) * module.float32(0.002)
    else:
        probe.encoder = [[0.002] * FEATURE_COUNT for _ in range(MODEL_HIDDEN_SIZE)]
        probe.encoder_bias = [0.0] * MODEL_HIDDEN_SIZE
        head = [[0.002] * MODEL_HIDDEN_SIZE for _ in range(count)]
    raw = bytes((80, 130, 195, 255)) * (W * H)
    timings = {}
    for name, work in (
        ('visual_features', lambda: probe.rgb_blocks(raw)),
        ('encoder', lambda: probe._encode(features)),
    ):
        work()
        started = time.perf_counter()
        for _ in range(3):
            work()
        if module is not None and getattr(module, '__name__', '') == 'cupy':
            module.cuda.Stream.null.synchronize()
        timings[name + '_milliseconds'] = round((time.perf_counter() - started) * 1000 / 3, 3)
    probe.games = {'benchmark': GameData(count, MODEL_HIDDEN_SIZE, module)}
    probe.game_key = 'benchmark'
    probe.lock = threading.RLock()
    probe.previous_lum = None
    probe.previous_motion = None
    probe.temporal_luma = deque(maxlen=4)
    probe.last_change = 0.0
    probe.last_frame = None
    probe.last_detail = [0.0] * 24
    probe.last_detail_focus = (0.5, 0.5)
    probe.last_attention_tracks = []
    probe.step = 0
    probe.low_information_observations = 0
    probe.invalid_observations = 0
    textured = bytearray(raw)
    for index in range(0, W * H, 13):
        pos = index * 4
        textured[pos:pos + 3] = bytes((48 + (index % 83), 112 + (index % 67), 175 + (index % 53)))
    textured = bytes(textured)
    probe.observe(textured, (0, 0, 1280, 720))
    started = time.perf_counter()
    for _ in range(3):
        probe.observe(textured, (0, 0, 1280, 720))
    timings['complete_visual_observation_milliseconds'] = round((time.perf_counter() - started) * 1000 / 3, 3)
    hidden = probe._encode(features)
    def decision():
        if module is not None:
            result = head @ hidden
            return float(module.max(result))
        return max(sum(a * b for a, b in zip(row, hidden)) for row in head)
    decision()
    started = time.perf_counter()
    for _ in range(3):
        value = decision()
    timings['action_head_milliseconds'] = round((time.perf_counter() - started) * 1000 / 3, 3)
    if not math.isfinite(value):
        raise ArithmeticError('运行基准产生了非有限决策结果')
    result = {'backend': 'pure_python' if module is None else getattr(module, '__name__', 'numeric'),
              'python': sys.version.split()[0], 'offline_inference': True, 'offline_training': True,
              'capture_test_milliseconds': capture_seconds, 'action_count': count, **timings}
    result['estimated_single_decision_milliseconds'] = round(timings['complete_visual_observation_milliseconds'] + timings['encoder_milliseconds'] + timings['action_head_milliseconds'], 3)
    destination = folder / 'runtime_profile.json'
    temporary = folder / 'runtime_profile.json.tmp'
    with temporary.open('w', encoding='utf-8') as file:
        json.dump(result, file, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        file.flush()
        os.fsync(file.fileno())
    os.replace(temporary, destination)
    return result

def verify_local_storage(folder, native):
    actual = pathlib.Path(folder).resolve()
    if os.name == 'nt':
        root = pathlib.PureWindowsPath(str(actual)).anchor
        disk_type = native.kernel.GetDriveTypeW(root)
        if disk_type in (0, 1, 4, 5):
            raise OSError('所选工作目录不在可确认离线使用的本地磁盘上，请选择本地文件夹')
    probe = actual / '_agent_offline_rw.tmp'
    try:
        with probe.open('wb') as stream:
            stream.write(os.urandom(48))
            stream.flush()
            os.fsync(stream.fileno())
        if probe.stat().st_size != 48 or len(probe.read_bytes()) != 48:
            raise OSError('离线数据目录没有通过本地读写验证')
    finally:
        probe.unlink(missing_ok=True)
    return True


def verify_offline_cold_start(folder, module, stop_vk=27, mode='全屏'):
    workspace = pathlib.Path(tempfile.mkdtemp(prefix='_offline_preflight_', dir=folder))
    backend = getattr(module, '__name__', 'none') if module is not None else 'none'
    installed_paths = []
    for name in ('numpy', 'cupy'):
        imported = sys.modules.get(name)
        origin = getattr(imported, '__file__', None) if imported is not None else None
        if origin:
            installed_paths.append(str(pathlib.Path(origin).resolve().parent.parent))
    script = '''import importlib, importlib.util, pathlib, socket, sys, urllib.request
root, source, workspace, backend, stop_vk, mode = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]), sys.argv[4], int(sys.argv[5]), sys.argv[6]
assert mode in ('全屏', '窗口') and 1 <= stop_vk <= 255
sys.dont_write_bytecode = True
for installed in sys.argv[7:]:
    sys.path.insert(0, installed)
for name in ('_runtime', '_gpu_runtime'):
    location = root / name
    if location.is_dir():
        sys.path.insert(0, str(location))
def denied(*args, **kwargs):
    raise OSError('离线验证期间禁止访问网络')
socket.create_connection = denied
socket.socket.connect = denied
socket.socket.connect_ex = denied
socket.socket.sendto = denied
socket.getaddrinfo = denied
urllib.request.urlopen = denied
urllib.request.urlretrieve = denied
spec = importlib.util.spec_from_file_location('local_offline_agent_preflight', str(source))
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
if sys.platform == 'win32':
    win = engine.Native()
    engine.verify_local_storage(root, win)
    vision = engine.Capture(win, '全屏', None)
    try:
        image, box = vision.grab()
        detailed = vision.grab_detail(box, 0.5, 0.5)
        assert len(image) == engine.W * engine.H * 4 and len(detailed) == engine.DW * engine.DH * 4
    finally:
        vision.close()
    if mode == '窗口':
        window_probe = engine.Capture(win, '窗口', None)
        try:
            assert isinstance(window_probe._candidates(), list)
        finally:
            window_probe.close()
    if win.com_initialized:
        win.ole.CoUninitialize()
class FakeUser:
    def __init__(self):
        self.pressed = False
        self.accepted = 0
        self.fail_release_count = 0
        self.touch_release_failures = 0
    def GetAsyncKeyState(self, vk):
        return 0x8000 if self.pressed else 0
    def MapVirtualKeyW(self, vk, method):
        return 0
    def SendInput(self, count, data, size):
        packet = engine.ctypes.cast(data, engine.ctypes.POINTER(engine.INPUT)).contents
        is_release = ((packet.type == 1 and packet.value.ki.dwFlags & engine.KEYEVENTF_KEYUP)
                      or (packet.type == 0 and packet.value.mi.dwFlags & (engine.MOUSEEVENTF_LEFTUP | engine.MOUSEEVENTF_RIGHTUP | engine.MOUSEEVENTF_MIDDLEUP)))
        if is_release and self.fail_release_count:
            self.fail_release_count -= 1
            return 0
        self.accepted += count
        return count
    def InjectTouchInput(self, count, infos):
        if infos[0].pressure != 512:
            return 0
        if infos[0].pointerInfo.pointerFlags & 0x40000 and self.touch_release_failures:
            self.touch_release_failures -= 1
            return 0
        return 1
    def GetSystemMetrics(self, code):
        return {76: 0, 77: 0, 78: 1280, 79: 720}[code]
class FakeNative:
    def __init__(self):
        self.user = FakeUser()
fake = FakeNative()
flag = engine.threading.Event()
control = engine.Controller(fake, stop_vk, flag)
control.stop_gate = engine.StopKeyGate(fake, stop_vk, flag)
assert control.key(stop_vk, True) is False and fake.user.accepted == 0
candidate = next(v for v in (65, 66, 67, 68, 70, 71, 72) if not engine.stop_equivalent(v, stop_vk))
assert control.key(candidate, True) and control.down == {candidate}
control.release()
assert not control.down and fake.user.accepted == 2
assert control.key(candidate, True)
fake.user.fail_release_count = 5
try:
    control.release(retries=2)
    raise AssertionError('释放失败不能被误报为成功')
except OSError:
    pass
assert candidate in control.down
fake.user.fail_release_count = 0
assert control.release() and not control.down
control.touch_available = True
assert control.touch([(0.5, 0.5)], 'down', (0, 0, 1280, 720))
fake.user.touch_release_failures = 1
assert control.release(retries=3) and not control.touch_points
control.stop_gate.note_injected(True)
fake.user.pressed = True
assert not control.stop_gate.poll() and not flag.is_set()
control.stop_gate.note_injected(False)
fake.user.pressed = False
control.stop_gate.poll()
control.stop_gate.injected_release_grace_until = 0
fake.user.pressed = True
assert control.stop_gate.poll() and flag.is_set()
assert not control.key(candidate, True)
assert not control.down
numeric = importlib.import_module(backend) if backend != 'none' else None
assert engine.validate_learning_backend(numeric)
store = engine.ReplayStore(workspace)
try:
    assert store.verify_roundtrip()
finally:
    store.close()
agent = engine.Brain(workspace, stop_vk, numeric)
try:
    raw = bytearray(bytes((40, 95, 170, 255)) * (engine.W * engine.H))
    for index in range(0, engine.W * engine.H, 13):
        pos = index * 4
        raw[pos:pos + 3] = bytes((30 + index % 101, 70 + index % 91, 95 + index % 121))
    before = agent.observe(bytes(raw), (0, 0, 1280, 720))
    for index in range(0, engine.W * engine.H, 17):
        raw[index * 4] = (raw[index * 4] + 71) % 256
    after = agent.observe(bytes(raw), (0, 0, 1280, 720))
    assert before.quality['trainable'] and after.quality['trainable']
    assert len(before.features) == engine.FEATURE_COUNT
    assert len(engine.ReplayStore.unpack(engine.ReplayStore.pack(before.features))) == engine.FEATURE_COUNT
    assert len(engine.ReplayStore.unpack(engine.struct.pack('<384f', *([0.0] * 384)))) == engine.FEATURE_COUNT
    index = agent.action_index['click']
    agent.learn(before, index, after, 0.10, 0.08, done=True,
                effect={'kind': 'click', 'input_sent': True, 'finished': True, 'feedback_valid': True,
                        'spatial': True, 'start_x': 0.5, 'start_y': 0.5, 'requested_duration': 0.15})
    assert agent.step == 1
    agent.save(force=True)
finally:
    agent.close()
assert (workspace / 'learning_state.json.gz').is_file()
restored = engine.Brain(workspace, stop_vk, numeric)
try:
    assert restored.step >= 1 and restored.checkpoint_verified
finally:
    restored.close()
inspection = engine.inspect_checkpoint_bundle(workspace)
assert inspection['restores_latest'] and inspection['base_step'] >= 1
class DesktopNative:
    def desktop(self):
        return workspace
archive_path = engine.blackbox(DesktopNative(), workspace, None, mode, stop_vk)
assert archive_path.stat().st_size <= 1000000
with engine.zipfile.ZipFile(archive_path) as archive:
    assert 'report.json' in archive.namelist()
    metadata = engine.json.loads(archive.read('report.json'))
    assert metadata['mode'] == mode
archive_path.unlink()
probe = engine.Brain.__new__(engine.Brain)
probe.actions = [engine.Action('test', 'key')]
probe.spool_path = workspace / 'nonexistent' / 'experience_overflow.jsonl'
probe.spool_lock = engine.threading.Lock()
probe.persist_backlog = engine.deque()
probe.journal_unwritten = engine.OrderedDict()
probe.journal_failures = 0
probe.journaled_transitions = 0
probe.store_problem = None
probe.dropped_unpersisted = 0
probe.spilled_transitions = 0
vector = [0.1] * engine.FEATURE_COUNT
sample = ('desktop', 'test', 0.1, vector, vector, 0.0, False, 1, 0.2, 0.9, {'uid': 'offline_failover_uid_1'})
probe.persist_backlog = engine.deque([sample] * 12000)
probe.journal_unwritten[sample[10]['uid']] = sample
transition = ['desktop', vector, 0, 0.1, vector, 0.2, False, 1, 0.9, {'uid': 'offline_failover_uid_2'}]
probe._append_persist(transition)
assert len(probe.persist_backlog) == 12000 and probe.dropped_unpersisted == 1
assert probe.store_problem is not None
store = engine.ReplayStore(workspace)
try:
    assert store.total_transitions >= 1
finally:
    store.close()
'''
    command = [sys.executable, '-I', '-c', script, str(folder), str(pathlib.Path(__file__).resolve()),
               str(workspace), backend, str(stop_vk), mode, *installed_paths]
    try:
        run = subprocess.run(command, capture_output=True, stdin=subprocess.DEVNULL, timeout=120,
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if run.returncode != 0:
            message = run.stderr.decode('utf-8', errors='replace')[-700:]
            raise OSError('隔离网络后的离线重启与经验回读验证失败：' + message)
        return True
    finally:
        shutil.rmtree(workspace, ignore_errors=True)

def stop_options():
    names = {8: 'Backspace', 9: 'Tab', 13: 'Enter', 16: 'Shift', 17: 'Ctrl', 18: 'Alt', 19: 'Pause', 20: 'Caps Lock', 27: 'ESC', 32: 'Space', 33: 'Page Up', 34: 'Page Down', 35: 'End', 36: 'Home', 37: '←', 38: '↑', 39: '→', 40: '↓', 44: 'Print Screen', 45: 'Insert', 46: 'Delete', 91: 'Win Left', 92: 'Win Right', 93: 'Menu', 144: 'Num Lock', 145: 'Scroll Lock'}
    for vk in range(48, 58):
        names[vk] = chr(vk)
    for vk in range(65, 91):
        names[vk] = chr(vk)
    for vk in range(96, 106):
        names[vk] = f'Num {vk - 96}'
    for vk, label in ((106, 'Num *'), (107, 'Num +'), (109, 'Num -'), (110, 'Num .'), (111, 'Num /')):
        names[vk] = label
    for vk in range(112, 136):
        names[vk] = f'F{vk - 111}'
    for vk, label in ((160, 'L Shift'), (161, 'R Shift'), (162, 'L Ctrl'), (163, 'R Ctrl'), (164, 'L Alt'), (165, 'R Alt'), (166, 'Browser Back'), (167, 'Browser Forward'), (168, 'Browser Refresh'), (169, 'Browser Stop'), (170, 'Browser Search'), (171, 'Browser Favorites'), (172, 'Browser Home'), (173, 'Mute'), (174, 'Volume Down'), (175, 'Volume Up'), (176, 'Media Next'), (177, 'Media Previous'), (178, 'Media Stop'), (179, 'Media Play/Pause'), (180, 'Launch Mail'), (181, 'Launch Media'), (182, 'Launch App 1'), (183, 'Launch App 2'), (186, ';'), (187, '='), (188, ','), (189, '-'), (190, '.'), (191, '/'), (192, '`'), (219, '['), (220, '\\'), (221, ']'), (222, "'"), (226, 'OEM 102')):
        names[vk] = label
    ordered = [(names[v], v) for v in [27] + [v for v in sorted(names) if v != 27]]
    return ordered


def encode_png(raw):
    if len(raw) != W * H * 4:
        raise ValueError('无法将非基础分辨率的画面编码为 PNG')
    lines = bytearray()
    for y in range(H):
        lines.append(0)
        base = y * W * 4
        for x in range(W):
            idx = base + x * 4
            lines.extend((raw[idx + 2], raw[idx + 1], raw[idx]))
    def part(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)
    return b'\x89PNG\r\n\x1a\n' + part(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 2, 0, 0, 0)) + part(b'IDAT', zlib.compress(bytes(lines), 7)) + part(b'IEND', b'')


def inspect_checkpoint_bundle(folder):
    primary = folder / 'learning_state.json.gz'
    backup = folder / 'learning_state.json.gz.bak'
    delta_path = folder / 'learning_delta.json.gz'
    result = {'files': [], 'restores_latest': False, 'delta_present': delta_path.exists(),
              'delta_valid': False, 'backup_used': False, 'error': None, 'base_step': None, 'latest_step': None}
    def inspect(path, compressed_limit, expanded_limit):
        if path.stat().st_size > compressed_limit:
            raise ValueError('学习检查点压缩容量超限')
        with gzip.open(path, 'rb') as stream:
            raw = stream.read(expanded_limit + 1)
        if len(raw) > expanded_limit:
            raise ValueError('学习检查点解压容量超限')
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError('学习检查点结构错误')
        actual_hash = data.pop('integrity_sha256', None)
        payload = json.dumps(data, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
        if not isinstance(actual_hash, str) or hashlib.sha256(payload).hexdigest() != actual_hash:
            raise ValueError('学习检查点摘要校验失败')
        return data, actual_hash
    errors = []
    base = None
    base_hash = None
    chosen = None
    for candidate in (primary, backup):
        if not candidate.exists():
            continue
        try:
            proposed, digest = inspect(candidate, 140_000_000, 260_000_000)
            if (proposed.get('format') not in (7, MODEL_FORMAT)
                    or proposed.get('feature_count') not in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)
                    or proposed.get('hidden_size') not in (96, MODEL_HIDDEN_SIZE)
                    or not isinstance(proposed.get('action_ids'), list)):
                raise ValueError('基础学习检查点版本不匹配')
            base, base_hash, chosen = proposed, digest, candidate
            break
        except (OSError, ValueError, TypeError, OverflowError, EOFError, gzip.BadGzipFile, json.JSONDecodeError) as exc:
            errors.append(f'{candidate.name}: {type(exc).__name__}: {str(exc)[:120]}')
    if base is None:
        result['error'] = '; '.join(errors)[:300] if errors else 'base_not_found'
        return result
    result['files'] = [chosen]
    result['backup_used'] = chosen == backup
    result['base_step'] = int(base.get('step', 0))
    result['latest_step'] = result['base_step']
    result['base_sha256'] = base_hash
    result['restores_latest'] = not delta_path.exists() and not result['backup_used']
    if delta_path.exists():
        try:
            delta, delta_hash = inspect(delta_path, 80_000_000, 150_000_000)
            if (delta.get('format') != 1 or delta.get('base_step') != result['base_step']
                    or delta.get('feature_count') != base.get('feature_count')
                    or delta.get('hidden_size') != base.get('hidden_size')
                    or delta.get('action_ids') != base.get('action_ids')
                    or not isinstance(delta.get('games'), dict)
                    or int(delta.get('step', -1)) < result['base_step']):
                raise ValueError('增量与基础学习检查点不匹配')
            result['files'].append(delta_path)
            result['latest_step'] = int(delta['step'])
            result['delta_valid'] = True
            result['delta_sha256'] = delta_hash
            result['restores_latest'] = not result['backup_used']
        except (OSError, ValueError, TypeError, OverflowError, EOFError, gzip.BadGzipFile, json.JSONDecodeError) as exc:
            errors.append(f'{delta_path.name}: {type(exc).__name__}: {str(exc)[:120]}')
            result['restores_latest'] = False
    if errors:
        result['error'] = '; '.join(errors)[:300]
    return result


def blackbox(native, folder, agent, mode, stop_vk):
    destination = native.desktop()
    destination.mkdir(parents=True, exist_ok=True)
    unique_name = f'游戏Agent黑匣子_{time.strftime("%Y%m%d_%H%M%S")}_{uuid.uuid4().hex[:8]}.zip'
    final = destination / unique_name
    temp = destination / (unique_name + '.tmp')
    brain = agent.brain if agent else None
    manifest = {
        'created': time.strftime('%Y-%m-%d %H:%M:%S'),
        'platform': sys.platform,
        'python': sys.version.split()[0],
        'mode': mode,
        'stop_virtual_key': stop_vk,
        'data_directory': str(folder),
        'started': agent.started if agent else None,
        'steps': brain.step if brain else 0,
        'total_proxy_reward': brain.total_reward if brain else 0.0,
        'game_identity': brain.game_key if brain else None,
        'tracked_screens': len(brain.visits) if brain else 0,
        'replay_in_memory': len(brain.memory) if brain else 0,
        'valid_transitions': brain.valid_transitions if brain else 0,
        'low_information_observations': brain.low_information_observations if brain else 0,
        'persisted_transitions_this_session': brain.persisted_transitions if brain else 0,
        'transitions_pending_write': len(brain.persist_backlog) if brain else 0,
        'unpersisted_transitions_dropped': brain.dropped_unpersisted if brain else 0,
        'overflow_records_spilled': brain.spilled_transitions if brain else 0,
        'overflow_records_recovered': brain.spool_recovered if brain else 0,
        'overflow_file_bytes': brain.spool_path.stat().st_size if brain and brain.spool_path.exists() else 0,
        'transitions_in_database': brain.store.total_transitions if brain and brain.store else brain.db_transitions_last_known if brain else None,
        'sqlite_reconnect_failures': brain.store_failures if brain else 0,
        'sqlite_connected': bool(brain.store is not None) if brain else False,
        'nstep_generated': brain.nstep_generated if brain else 0,
        'learning_updates': brain.updates if brain else 0,
        'training_failures': brain.training_failures if brain else 0,
        'training_retries': brain.training_retried if brain else 0,
        'training_queue_evictions': brain.training_queue_evictions if brain else 0,
        'terminal_credit_samples': brain.terminal_credit_samples if brain else 0,
        'checkpoint_verified': brain.checkpoint_verified if brain else False,
        'checkpoint_migrated': brain.checkpoint_migrated if brain else False,
        'screen_outcome_totals': dict(brain.game.screen_outcomes) if brain else {},
        'journaled_transitions': brain.journaled_transitions if brain else 0,
        'journal_failures': brain.journal_failures if brain else 0,
        'database_roundtrip_verified': brain.store_roundtrip_verified if brain else False,
        'database_preflight_verified': brain.db_preflight_verified if brain else False,
        'capture_valid': agent.last_capture_valid if agent else None,
        'last_capture_at': agent.last_capture_at if agent else None,
        'last_experience_at': agent.last_experience_at if agent else None,
        'completed_actions': agent.completed_actions if agent else 0,
        'partially_executed_actions': agent.partial_actions if agent else 0,
        'capture_failures': agent.capture_failures if agent else 0,
        'input_failures': agent.input_failures if agent else 0,
        'feedback_capture_batches': agent.feedback_captures if agent else 0,
        'visually_observed_input_effects': agent.visual_input_effects if agent else 0,
        'estimated_episode_boundaries': agent.episode_boundaries if agent else 0,
        'visual_game_switches': agent.visual_game_switches if agent else 0,
        'continuous_capture_frames': agent.sensor_frames_total if agent else 0,
        'sensor_restarts': agent.sensor_restarts if agent else 0,
        'bound_target_pid': agent.capture_target_pid if agent else None,
        'bound_target_hwnd': agent.capture_target_hwnd if agent else None,
        'actions_cut_short_by_visual_feedback': agent.monitor_breaks if agent else 0,
        'touch_injection_supported': agent.controller.touch_available if agent and agent.controller else None,
        'storage_problem': brain.storage_problem if brain else None,
        'storage_failures': brain.storage_failures if brain else 0,
        'pending_keyframes': len(brain.frame_backlog) if brain else 0,
        'skipped_keyframes': brain.keyframes_skipped if brain else 0,
        'capture_backend': agent.capture.backend if agent and agent.capture else None,
        'stop_input_channels': agent.listener.mode if agent and agent.listener else None,
        'stop_raw_events': agent.listener.raw_events if agent and agent.listener else 0,
        'stop_hook_events': agent.listener.hook_events if agent and agent.listener else 0,
        'stop_poll_events': agent.stop_gate.poll_stops if agent else 0,
        'stop_registered_channels': dict(agent.listener.registered_channels) if agent and agent.listener else {},
        'stop_registration_problem': agent.listener.registration_error if agent and agent.listener else None,
        'capture_backend_problem': agent.capture.backend_error if agent and agent.capture else None,
        'failures': agent.failure_count if agent else 0,
        'last_rectangle': agent.last_rect if agent else None,
        'learning_note': '奖励以连续识别的屏幕胜负/任务结果与经该结果校准的 HUD 变化为主；均非游戏服务端真实结果，不能仅凭画面验证胜率或账号价值。',
        'win_verified': None,
        'model_excerpt_note': '若完整检查点超过容量上限，保存活动游戏的自建模型 FP16 诊断摘录；该摘录不是完整训练状态，不能直接替代检查点。',
    }
    events = list(agent.events) if agent else []
    errors = list(agent.errors) if agent else []
    state = folder / 'learning_state.json.gz'
    delta_state = folder / 'learning_delta.json.gz'
    checkpoint = inspect_checkpoint_bundle(folder)
    checkpoint_files = checkpoint['files']
    checkpoint_total = sum(file.stat().st_size for file in checkpoint_files)
    checkpoint_eligible = bool(checkpoint_files and checkpoint_total <= 920000)
    manifest['checkpoint_bundle'] = {key: value for key, value in checkpoint.items() if key != 'files'}
    runtime = folder / 'runtime_state.json'
    performance = folder / 'runtime_profile.json'
    error_file = folder / 'agent_errors.jsonl'
    manifest['learning_state_bytes'] = state.stat().st_size if state.exists() else 0
    manifest['learning_delta_bytes'] = delta_state.stat().st_size if delta_state.exists() else 0
    excerpt = None
    excerpt_meta = None
    if brain is not None:
        try:
            with brain.lock:
                active = brain.games.get(brain.game_key)
                if active is not None:
                    arrays = [('encoder', brain.encoder), ('encoder_bias', brain.encoder_bias),
                              ('head', active.q), ('head_bias', active.bias)]
                    for kind, parameters in sorted(active.parameter_heads.items(), key=lambda item: item[1]['samples'], reverse=True)[:24]:
                        if parameters['samples'] > 0:
                            arrays.append(('parameter_' + kind + '_weights', parameters['w']))
                            arrays.append(('parameter_' + kind + '_bias', parameters['b']))
                    parts = []
                    layout = []
                    for name, matrix in arrays:
                        numeric = matrix.tolist() if hasattr(matrix, 'tolist') else matrix
                        flat = [float(number) for row in numeric for number in row] if numeric and isinstance(numeric[0], (tuple, list)) else [float(number) for number in numeric]
                        flat = [max(-4.0, min(4.0, value)) if math.isfinite(value) else 0.0 for value in flat]
                        parts.append(struct.pack('<' + 'e' * len(flat), *flat))
                        layout.append({'name': name, 'shape': [len(numeric), len(numeric[0])] if numeric and isinstance(numeric[0], (tuple, list)) else [len(flat)], 'values': len(flat)})
                    excerpt = b''.join(parts)
                    excerpt_meta = {'game': brain.game_key, 'encoding': 'IEEE754-binary16-le', 'layout': layout,
                                    'sha256': hashlib.sha256(excerpt).hexdigest(), 'bytes': len(excerpt),
                                    'checkpoint_step': brain.step, 'checkpoint_updates': brain.updates,
                                    'checkpoint_last_summary': brain.last_checkpoint_summary}
        except Exception as exc:
            manifest['model_excerpt_error'] = f'{type(exc).__name__}: {str(exc)[:140]}'
    def write(include_state, event_count, include_screen, include_log, include_excerpt):
        manifest['archive_contents'] = {
            'checkpoint_included': bool(include_state and checkpoint_eligible),
            'checkpoint_pair_included': bool(include_state and checkpoint_eligible and checkpoint['delta_valid']),
            'checkpoint_restores_latest': bool(include_state and checkpoint_eligible and checkpoint['restores_latest']),
            'learning_delta_included': bool(include_state and checkpoint_eligible and checkpoint['delta_valid']),
            'active_model_excerpt_included': bool(include_excerpt and excerpt is not None),
            'screen_included': bool(include_screen and brain and brain.last_frame),
            'error_log_included': bool(include_log and error_file.exists()),
            'events_included': min(len(events), event_count),
            'events_omitted': max(0, len(events) - event_count),
            'checkpoint_omission': 'invalid_or_missing' if not checkpoint_files else 'size_limit' if not checkpoint_eligible else 'size_budget' if not include_state else None,
            'learning_delta_omission': ('not_found' if not checkpoint['delta_present'] else
                                        'invalid_or_incompatible' if not checkpoint['delta_valid'] else
                                        'size_limit' if not checkpoint_eligible else
                                        'size_budget' if not include_state else None),
            'screen_omission': 'size_budget' if not include_screen and brain and brain.last_frame else 'not_available' if not brain or not brain.last_frame else None,
            'error_log_omission': 'size_budget' if not include_log and error_file.exists() else 'not_found' if not error_file.exists() else None,
            'error_log_tail_truncated': bool(include_log and error_file.exists() and error_file.stat().st_size > 32000),
            'runtime_state_omission': 'not_found' if not runtime.exists() else 'size_limit' if runtime.stat().st_size > 30000 else None,
            'runtime_profile_omission': 'not_found' if not performance.exists() else 'size_limit' if performance.stat().st_size > 30000 else None,
        }
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('report.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            archive.writestr('recent_actions.json', json.dumps(events[-event_count:] if event_count else [], ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_errors.json', json.dumps(errors, ensure_ascii=False, separators=(',', ':')))
            if runtime.exists() and runtime.stat().st_size <= 30000:
                archive.write(runtime, 'runtime_state.json')
            if performance.exists() and performance.stat().st_size <= 30000:
                archive.write(performance, 'runtime_profile.json')
            if include_log and error_file.exists():
                with error_file.open('rb') as stream:
                    start = max(0, error_file.stat().st_size - 32000)
                    stream.seek(start)
                    lines = stream.read(32000)
                    if start:
                        boundary = lines.find(b'\n')
                        lines = lines[boundary + 1:] if boundary >= 0 else b''
                    if lines and not lines.endswith(b'\n'):
                        boundary = lines.rfind(b'\n')
                        lines = lines[:boundary + 1] if boundary >= 0 else b''
                    archive.writestr('error_log_tail.jsonl', lines)
            if include_screen and brain and brain.last_frame:
                archive.writestr('last_screen.png', encode_png(brain.last_frame))
            if include_state and checkpoint_eligible:
                for checkpoint_file in checkpoint_files:
                    archive.write(checkpoint_file, checkpoint_file.name)
            if include_excerpt and excerpt is not None:
                archive.writestr('active_model_fp16.bin', excerpt)
                archive.writestr('active_model_layout.json', json.dumps(excerpt_meta, ensure_ascii=False, separators=(',', ':')))
            if brain:
                with brain.lock:
                    diagnostics = {
                        'steps': brain.step,
                        'updates': brain.updates,
                        'valid_transitions': brain.valid_transitions,
                        'low_information_observations': brain.low_information_observations,
                        'database_pending': len(brain.persist_backlog),
                        'database_dropped': brain.dropped_unpersisted,
                        'pending_terminal_updates': len(brain.terminal_updates),
                        'pending_keyframes': len(brain.frame_backlog),
                        'last_reward': brain.reward_info,
                        'visual_game_routes': {name: [{'id': record.get('key'), 'samples': record.get('samples'), 'anchors': len(record.get('anchors', []))} for record in routes] for name, routes in list(brain.visual_routes.items())[-20:]},
                        'training_problem': brain.training_problem,
                        'database_problem': brain.store_problem,
                        'backend_recoveries': brain.backend_recoveries,
                        'checkpoint_summary': brain.last_checkpoint_summary,
                        'checkpoint_size_bytes': brain.checkpoint_compressed_bytes,
                        'confirmed_screen_results': {key: list(data.confirmed_results.items())[-16:] for key, data in list(brain.games.items())[-16:]},
                        'game_statistics': {key: {'steps': value.game_steps, 'tracked_screens': len(value.visits), 'world_states': len(value.world), 'target_regions': len(value.targets), 'possible_events': len(value.candidate_events), 'learned_hud_trends': len(value.hud_trends), 'duration_stats': len(value.duration_stats), 'trained_parameter_heads': {kind: int(head['samples']) for kind, head in value.parameter_heads.items()}, 'spatial_stats': len(value.parameter_stats), 'learned_skills': len(value.skills), 'plan_success': value.plan_success, 'screen_outcomes': value.screen_outcomes} for key, value in list(brain.games.items())[-32:]},
                    }
                archive.writestr('learning_diagnostics.json', json.dumps(diagnostics, ensure_ascii=False, separators=(',', ':')))
    try:
        for keep_state, event_count, screen, keep_log, keep_excerpt in (
                (True, 350, True, True, True), (True, 150, False, True, True),
                (True, 35, False, False, False), (False, 350, True, True, True),
                (False, 150, True, True, False), (False, 120, True, False, False),
                (False, 35, False, True, True), (False, 35, False, False, False),
                (False, 0, False, False, False)):
            write(keep_state, event_count, screen, keep_log, keep_excerpt)
            if temp.stat().st_size <= 1_000_000:
                os.replace(temp, final)
                return final
        minimal = {
            'created': manifest['created'], 'mode': mode, 'stop_virtual_key': stop_vk,
            'data_directory': str(folder), 'steps': manifest['steps'],
            'completed_actions': manifest['completed_actions'], 'failures': manifest['failures'],
            'last_error': (errors[-1] if errors else None),
            'note': '压缩包已裁剪为最小诊断信息；学习数据未包含在这个精简黑匣子中，仍位于选定文件夹。',
            'checkpoint_bundle': manifest['checkpoint_bundle'],
        }
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('report.json', json.dumps(minimal, ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_errors.json', json.dumps(errors[-3:], ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_actions.json', json.dumps(events[-12:], ensure_ascii=False, separators=(',', ':')))
            if brain is not None and brain.last_frame is not None:
                archive.writestr('last_screen.png', encode_png(brain.last_frame))
        if temp.stat().st_size <= 1_000_000:
            os.replace(temp, final)
            return final
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('report.json', json.dumps(minimal, ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_errors.json', json.dumps(errors[-1:], ensure_ascii=False, separators=(',', ':')))
        if temp.stat().st_size <= 1_000_000:
            os.replace(temp, final)
            return final
        raise OSError('精简后的黑匣子仍超过 1 MB')
    finally:
        temp.unlink(missing_ok=True)


class App:
    def __init__(self):
        self.n = Native()
        self.instance = self.n.kernel.GetModuleHandleW(None)
        self.window_callback = WINPROC(self.window_proc)
        self.classname = 'OpenGameAgentSingleFileNativeWindow'
        wc = WNDCLASSW()
        wc.lpfnWndProc = self.window_callback
        wc.hInstance = self.instance
        wc.hCursor = self.n.user.LoadCursorW(None, ctypes.c_void_p(32512))
        wc.hbrBackground = HWND(16)
        wc.lpszClassName = self.classname
        if not self.n.user.RegisterClassW(ctypes.byref(wc)):
            raise OSError('无法注册程序窗口')
        self.hwnd = self.n.user.CreateWindowExW(0, self.classname, '通用游戏 Agent', 0x00CA0000, 180, 140, 650, 330, None, None, self.instance, None)
        if not self.hwnd:
            raise OSError('无法创建主窗口')
        self.folder = None
        self.selected_folder = None
        self.workspace_lease = None
        self.prepared_config = None
        self.preparing_config = None
        self.blackbox_busy = False
        self.pending_release_controller = None
        self.release_repair_active = False
        self.worker = None
        self.numpy = None
        self.runtime_profile = None
        self.preparing = False
        self.ready = False
        self.running = False
        self.agent = None
        self.message = '请选择数据文件夹。'
        self.options = stop_options()
        self.controls = {}
        self.create_controls()
        self.n.user.ShowWindow(self.hwnd, 5)
        self.n.user.UpdateWindow(self.hwnd)
        self.n.user.PostMessageW(self.hwnd, WM_APP_CHOOSE, 0, 0)

    def control(self, name, title, style, x, y, w, h, id):
        hwnd = self.n.user.CreateWindowExW(0, name, title, style | 0x40000000 | 0x10000000, x, y, w, h, self.hwnd, HWND(id), self.instance, None)
        font = self.n.gdi.GetStockObject(17)
        self.n.user.SendMessageW(hwnd, WM_SETFONT, font or 0, 1)
        self.controls[id] = hwnd
        return hwnd

    def add_item(self, hwnd, label):
        text = ctypes.c_wchar_p(label)
        self.n.user.SendMessageW(hwnd, 0x0143, 0, ctypes.cast(text, HWND).value)

    def create_controls(self):
        self.control('STATIC', '游戏 Agent · 本地自主探索与在线学习', 0, 22, 17, 530, 30, 101)
        self.control('BUTTON', '选择文件夹', 0x00010000, 22, 63, 130, 32, 201)
        self.control('STATIC', '尚未选择文件夹', 0, 163, 68, 460, 29, 102)
        self.control('STATIC', 'Agent 操作范围：', 0, 22, 115, 152, 28, 103)
        range_box = self.control('COMBOBOX', '', 0x0003 | 0x00200000 | 0x00010000, 178, 107, 142, 220, 202)
        self.add_item(range_box, '全屏')
        self.add_item(range_box, '窗口')
        self.n.user.SendMessageW(range_box, 0x014E, 0, 0)
        self.control('STATIC', '停止键：', 0, 347, 115, 88, 28, 104)
        stop_box = self.control('COMBOBOX', '', 0x0003 | 0x00200000 | 0x00010000, 440, 107, 162, 220, 203)
        for label, _ in self.options:
            self.add_item(stop_box, label)
        self.n.user.SendMessageW(stop_box, 0x014E, 0, 0)
        self.control('BUTTON', '启动', 0x00010000, 23, 160, 142, 41, 204)
        self.control('BUTTON', '黑匣子', 0x00010000, 187, 160, 142, 41, 205)
        self.control('STATIC', '状态：请选择文件夹，准备完成后启动。', 0, 23, 218, 591, 52, 106)
        self.n.user.EnableWindow(self.controls[204], 0)
        self.n.user.EnableWindow(self.controls[205], 0)

    def set_status(self, message):
        self.message = message
        self.n.user.PostMessageW(self.hwnd, WM_APP_STATUS, 0, 0)

    def chosen_mode(self):
        index = self.n.user.SendMessageW(self.controls[202], 0x0147, 0, 0)
        return '窗口' if index == 1 else '全屏'

    def chosen_stop_key(self):
        index = self.n.user.SendMessageW(self.controls[203], 0x0147, 0, 0)
        return self.options[index][1] if 0 <= index < len(self.options) else 27

    def choose_folder(self):
        if self.running or self.preparing or self.blackbox_busy:
            return
        selected = self.n.folder(self.hwnd)
        if selected is None:
            return
        if selected != self.selected_folder:
            try:
                lease = WorkspaceLease(selected)
            except OSError as exc:
                self.set_status(f'数据目录不可用：{str(exc)[:140]}')
                return
            previous = self.workspace_lease
            self.workspace_lease = lease
            self.selected_folder = selected
            self.folder = lease.folder
            if previous is not None:
                previous.close()
            self.agent = None
            self.numpy = None
            self.runtime_profile = None
        self.n.user.SetWindowTextW(self.controls[102], str(self.folder))
        self.start_prepare()

    def start_prepare(self):
        if self.running or self.preparing or self.blackbox_busy or self.folder is None:
            return
        self.ready = False
        self.prepared_config = None
        self.preparing_config = (self.chosen_mode(), self.chosen_stop_key())
        self.preparing = True
        for number in (201, 202, 203, 204, 205):
            self.n.user.EnableWindow(self.controls[number], 0)
        self.set_status('检查工作目录、运行配置与所需组件…')
        threading.Thread(target=self.prepare, args=(self.preparing_config,), name='Preparation', daemon=True).start()

    def prepare(self, configuration):
        mode, stop_vk = configuration
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            probe = self.folder / '_agent_write_probe.tmp'
            with probe.open('wb') as stream:
                stream.write(b'ok')
                stream.flush()
                os.fsync(stream.fileno())
            if probe.read_bytes() != b'ok':
                raise OSError('工作目录回读失败')
            probe.unlink()
            verify_local_storage(self.folder, self.n)
            self.numpy = acceleration_for(self.folder, self.set_status)
            self.set_status('正在验证本地推理与训练运算')
            validate_learning_backend(self.numpy)
            self.set_status('正在验证屏幕采集链路')
            capture = Capture(self.n, '全屏', self.hwnd)
            try:
                capture_started = time.perf_counter()
                frame, rect = capture.grab()
                if len(frame) != W * H * 4 or rect[2] < 80 or rect[3] < 80:
                    raise OSError('屏幕采集返回了无效的尺寸')
                detail_frame = capture.grab_detail(rect, 0.5, 0.5)
                if len(detail_frame) != DW * DH * 4:
                    raise OSError('局部高分辨率采集不完整')
                capture_ms = round((time.perf_counter() - capture_started) * 500, 3)
            finally:
                capture.close()
            if mode == '窗口':
                window_probe = Capture(self.n, '窗口', self.hwnd)
                try:
                    window_probe._candidates()
                finally:
                    window_probe.close()
            self.set_status('正在测量离线视觉处理与动作决策速度')
            try:
                self.runtime_profile = profile_runtime(self.folder, self.numpy, capture_ms)
            except Exception:
                fallback = None
                if self.numpy is not None:
                    try:
                        imported = importlib.import_module('numpy')
                        if validate_learning_backend(imported):
                            fallback = imported
                    except Exception:
                        pass
                self.numpy = fallback
                self.runtime_profile = profile_runtime(self.folder, self.numpy, capture_ms)
            self.set_status('正在验证停止键监听初始化')
            probe_listener = StopListener(self.n, stop_vk, threading.Event())
            try:
                probe_listener.start()
                if not probe_listener.healthy():
                    raise OSError('停止键监听和独立轮询的健康检查失败')
            finally:
                probe_listener.close()
            self.set_status('正在验证经验库事务写入、回读及回滚')
            try:
                store = ReplayStore(self.folder)
            except sqlite3.DatabaseError as exc:
                if not quarantine_corrupt_store(self.folder, exc):
                    raise
                store = ReplayStore(self.folder)
            try:
                if not store.verify_roundtrip():
                    raise sqlite3.DatabaseError('经验库回读验证失败')
            finally:
                store.close()
            self.set_status('正在禁用网络测试离线重启、训练、经验持久化及恢复')
            verify_offline_cold_start(self.folder, self.numpy, stop_vk, mode)
            self.runtime_profile['offline_network_blocked_preflight_passed'] = True
            self.runtime_profile['physical_airplane_mode_tested'] = False
            profile = self.folder / 'runtime_profile.json'
            temporary = self.folder / 'runtime_profile.json.tmp'
            with temporary.open('w', encoding='utf-8') as stream:
                json.dump(self.runtime_profile, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, profile)
            estimated = self.runtime_profile['estimated_single_decision_milliseconds']
            self.set_status(f'一切就绪 · 本地离线运行 · 基准决策约 {estimated:.1f} 毫秒（不含采集、训练及游戏延迟）')
            self.prepared_config = configuration
            self.ready = True
        except BaseException as exc:
            self.ready = False
            self.set_status(f'准备失败：{str(exc)[:150]}')
        finally:
            self.preparing = False
            self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)

    def launch(self):
        if not self.ready or self.running or not self.folder or self.blackbox_busy or self.pending_release_controller is not None:
            return
        try:
            mode, stop_vk = self.chosen_mode(), self.chosen_stop_key()
            if (mode, stop_vk) != self.prepared_config:
                self.start_prepare()
                return
            agent = GameAgent(self.n, self.folder, mode, stop_vk, self.hwnd, self.numpy)
            if mode == '窗口':
                next_window = self.n.user.GetWindow(self.hwnd, 2)
                if next_window and next_window != self.hwnd and self.n.user.IsWindow(next_window):
                    agent.window_hint = next_window
            agent.on_input_released = lambda: self.n.user.PostMessageW(self.hwnd, WM_APP_RELEASED, 0, 0)
            agent.ensure_listener()
            if agent.check_stop_fallback():
                agent.listener.close()
                self.set_status('启动被停止键取消；界面保持显示。')
                return
            agent.stop_gate.on_stop = lambda: self.n.user.PostMessageW(self.hwnd, WM_APP_STOP_REQUESTED, 0, 0)
            worker = threading.Thread(target=self.agent_worker, name='GameAgent', daemon=False)
            self.worker = worker
            self.agent = agent
            self.running = True
            self.n.user.ShowWindow(self.hwnd, 0)
            worker.start()
        except Exception as exc:
            self.running = False
            if 'agent' in locals() and agent.listener is not None:
                agent.listener.close()
            self.n.user.ShowWindow(self.hwnd, 5)
            self.set_status(f'启动失败：{str(exc)[:150]}')

    def agent_worker(self):
        try:
            while self.agent is not None and not self.agent.stop_event.is_set():
                current = self.agent
                try:
                    current.run()
                except BaseException as exc:
                    current.error(exc)
                if current.stop_event.is_set():
                    break
                current.error(RuntimeError('运行循环异常退出，正在恢复 Agent'))
                while not current.check_stop_fallback() and not current.input_release_verified:
                    try:
                        if current.controller is None:
                            current.input_release_verified = True
                        else:
                            current.controller.release(retries=5)
                            current.input_release_verified = not (current.controller.down or current.controller.mouse_down or current.controller.touch_points)
                    except Exception as exc:
                        current.error(exc)
                        current.stop_event.wait(0.3)
                if current.stop_event.is_set():
                    break
                recovered = False
                while not current.check_stop_fallback() and not recovered:
                    try:
                        next_agent = GameAgent(self.n, self.folder, current.mode, current.stop_vk, self.hwnd, current.np)
                        next_agent.stop_event = current.stop_event
                        next_agent.stop_gate = current.stop_gate
                        next_agent.on_input_released = current.on_input_released
                        next_agent.window_hint = current.window_hint
                        next_agent.started = current.started
                        next_agent.events.extend(current.events)
                        next_agent.errors.extend(current.errors)
                        next_agent.completed_actions = current.completed_actions
                        next_agent.partial_actions = current.partial_actions
                        next_agent.feedback_captures = current.feedback_captures
                        next_agent.visual_game_switches = current.visual_game_switches
                        next_agent.sensor_frames_total = current.sensor_frames_total
                        next_agent.monitor_breaks = current.monitor_breaks
                        next_agent.capture_target_signature = current.capture_target_signature
                        next_agent.capture_target_pid = current.capture_target_pid
                        next_agent.capture_target_hwnd = current.capture_target_hwnd
                        next_agent.failure_count = current.failure_count
                        next_agent.last_error = current.last_error
                        next_agent.same_error_count = current.same_error_count
                        next_agent.last_capture_at = current.last_capture_at
                        next_agent.last_experience_at = current.last_experience_at
                        next_agent.visual_input_effects = current.visual_input_effects
                        next_agent.episode_boundaries = current.episode_boundaries
                        self.agent = next_agent
                        recovered = True
                    except BaseException as exc:
                        current.error(exc)
                        current.stop_event.wait(min(2.0, 0.1 + current.same_error_count * 0.02))
                if not recovered:
                    break
        finally:
            current = self.agent
            if current is not None and current.controller is not None and not current.input_release_verified:
                self.pending_release_controller = current.controller
            self.n.user.PostMessageW(self.hwnd, WM_APP_STOPPED, 0, 0)

    def repair_release(self, control):
        attempts = 0
        try:
            while self.pending_release_controller is control:
                attempts += 1
                try:
                    control.release(retries=5)
                    if not (control.down or control.mouse_down or control.touch_points):
                        if self.agent is not None:
                            self.agent.input_release_verified = True
                        self.pending_release_controller = None
                        self.n.user.PostMessageW(self.hwnd, WM_APP_RELEASED, 0, 0)
                        return
                except Exception as exc:
                    if self.agent is not None:
                        self.agent.error(exc)
                time.sleep(min(2.0, 0.18 + attempts * 0.06))
        finally:
            self.release_repair_active = False
            self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)

    def export_blackbox(self):
        if not self.folder or self.running or self.blackbox_busy or self.preparing:
            return
        self.blackbox_busy = True
        self.n.user.EnableWindow(self.controls[204], 0)
        self.n.user.EnableWindow(self.controls[205], 0)
        self.n.user.EnableWindow(self.controls[201], 0)
        self.set_status('正在创建黑匣子压缩包…')
        threading.Thread(target=self.export_blackbox_worker,
                         args=(self.folder, self.agent, self.chosen_mode(), self.chosen_stop_key()),
                         name='Blackbox', daemon=True).start()

    def export_blackbox_worker(self, folder, agent, mode, stop_vk):
        com_ready = self.n.ole.CoInitializeEx(None, 2) in (0, 1)
        try:
            path = blackbox(self.n, folder, agent, mode, stop_vk)
            self.set_status(f'黑匣子已保存到桌面：{path.name}（{path.stat().st_size} 字节）')
        except BaseException as exc:
            self.set_status(f'黑匣子创建失败：{str(exc)[:170]}')
        finally:
            if com_ready:
                self.n.ole.CoUninitialize()
            self.blackbox_busy = False
            self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)

    def window_proc(self, hwnd, msg, wp, lp):
        try:
            if msg == WM_COMMAND:
                number, notification = int(wp) & 0xFFFF, int(wp) >> 16
                if notification == 1 and number in (202, 203):
                    if not self.running and not self.preparing and self.folder is not None:
                        self.start_prepare()
                    return 0
                if notification == 0:
                    if number == 201:
                        self.choose_folder()
                    elif number == 204:
                        self.launch()
                    elif number == 205:
                        self.export_blackbox()
                    return 0
            if msg == WM_APP_CHOOSE:
                self.choose_folder()
                return 0
            if msg == WM_APP_STATUS:
                self.n.user.SetWindowTextW(self.controls[106], '状态：' + self.message)
                return 0
            if msg == WM_APP_READY:
                unlocked = not (self.running or self.preparing or self.blackbox_busy)
                for number in (201, 202, 203):
                    self.n.user.EnableWindow(self.controls[number], int(unlocked))
                can_start = unlocked and self.ready and self.pending_release_controller is None
                self.n.user.EnableWindow(self.controls[204], int(can_start))
                self.n.user.EnableWindow(self.controls[205], int(unlocked and self.ready))
                return 0
            if msg == WM_APP_STOP_REQUESTED:
                self.n.user.ShowWindow(self.hwnd, 5)
                self.n.user.UpdateWindow(self.hwnd)
                self.n.user.EnableWindow(self.controls[204], 0)
                self.n.user.EnableWindow(self.controls[205], 0)
                self.set_status('已收到停止键，正在释放输入与保存学习状态…')
                return 0
            if msg == WM_APP_RELEASED:
                self.n.user.ShowWindow(self.hwnd, 5)
                self.n.user.UpdateWindow(self.hwnd)
                if self.running:
                    self.n.user.EnableWindow(self.controls[204], 0)
                    self.n.user.EnableWindow(self.controls[205], 0)
                    self.set_status('输入释放已确认，正在保存学习状态…')
                else:
                    self.set_status('已确认 Agent 输入释放完成。')
                    self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)
                return 0
            if msg == WM_APP_STOPPED:
                self.running = False
                self.n.user.ShowWindow(self.hwnd, 5)
                self.n.user.UpdateWindow(self.hwnd)
                steps = self.agent.brain.step if self.agent and self.agent.brain else 0
                if self.pending_release_controller is not None:
                    self.set_status('已收到停止键；部分输入尚未确认释放，正在自动重试。')
                    if not self.release_repair_active:
                        self.release_repair_active = True
                        threading.Thread(target=self.repair_release,
                                         args=(self.pending_release_controller,), name='InputRelease', daemon=True).start()
                else:
                    self.set_status(f'Agent 已停止操作；累计学习 {steps} 步。')
                self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)
                return 0
            if msg == WM_CLOSE:
                if not self.running:
                    self.n.user.DestroyWindow(hwnd)
                return 0
            if msg == WM_DESTROY:
                self.n.user.PostQuitMessage(0)
                return 0
        except BaseException as exc:
            try:
                agent = getattr(self, 'agent', None)
                if agent is not None:
                    agent.error(exc)
                else:
                    folder = getattr(self, 'folder', None)
                    if folder is not None:
                        entry = {'at': time.time(), 'type': type(exc).__name__, 'error': str(exc)[:350],
                                 'phase': 'window_proc', 'message': int(msg), 'trace': traceback.format_exc(limit=8)[-2400:]}
                        with (folder / 'agent_errors.jsonl').open('a', encoding='utf-8') as stream:
                            stream.write(json.dumps(entry, ensure_ascii=False) + '\n')
            except Exception:
                pass
            return self.n.user.DefWindowProcW(hwnd, msg, wp, lp)
        return self.n.user.DefWindowProcW(hwnd, msg, wp, lp)

    def loop(self):
        message = MSG()
        try:
            while True:
                result = self.n.user.GetMessageW(ctypes.byref(message), None, 0, 0)
                if result <= 0:
                    return
                self.n.user.TranslateMessage(ctypes.byref(message))
                self.n.user.DispatchMessageW(ctypes.byref(message))
        finally:
            if self.workspace_lease is not None:
                self.workspace_lease.close()
            if self.n.com_initialized:
                self.n.ole.CoUninitialize()


def main():
    if os.name != 'nt':
        raise SystemExit('本程序需要 Windows 11。')
    try:
        ctypes.WinDLL('kernel32').FreeConsole()
    except Exception:
        pass
    App().loop()


if __name__ == '__main__':
    main()
