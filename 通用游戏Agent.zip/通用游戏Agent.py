import ctypes
import gzip
import hashlib
import importlib
import json
import math
import os
import pathlib
import random
import shutil
import socket
import sqlite3
import struct
import subprocess
import sys
sys.dont_write_bytecode = True
import sysconfig
import tempfile
import threading
import time
import traceback
import uuid
import urllib.parse
import urllib.request
import zipfile
import zlib
from collections import OrderedDict, deque

W, H, GW, GH, FEATURE_COUNT = 320, 180, 20, 12, 512
LEGACY_FEATURE_COUNT, MODEL_FORMAT, MODEL_HIDDEN_SIZE = 384, 17, 128
DETAIL_SCHEMA_START, DETAIL_META_START, GOAL_VALUE_FEATURES = 150, 154, 48
SEMANTIC_START, SEMANTIC_COUNT, WORLD_VISUAL_COUNT = 448, 64, 96
WORLD_SEMANTIC_SLOTS = tuple(range(12)) + tuple(range(24, 40)) + tuple(range(56, 60))
LEGACY_RECONSTRUCTION_INDICES = tuple(range(1, 10)) + tuple(18 + 7 * i for i in range(12)) + tuple(range(SEMANTIC_START, SEMANTIC_START + 8))
RECONSTRUCTION_INDICES = tuple(dict.fromkeys(LEGACY_RECONSTRUCTION_INDICES + tuple(range(18, 102, 7)) + tuple(range(20, 102, 7)) + tuple(range(SEMANTIC_START + 8, SEMANTIC_START + 16)) + tuple(range(SEMANTIC_START + 24, SEMANTIC_START + 56)) + tuple(range(SEMANTIC_START + 56, SEMANTIC_START + 60))))
DW, DH = 960, 540
WM_APP_STATUS, WM_APP_READY, WM_APP_STOPPED, WM_APP_CHOOSE, WM_APP_RELEASED, WM_APP_STOP_REQUESTED = 0x8001, 0x8002, 0x8003, 0x8004, 0x8005, 0x8006
WM_CLOSE, WM_DESTROY, WM_COMMAND, WM_KEYDOWN, WM_KEYUP, WM_SYSKEYDOWN, WM_SYSKEYUP = 0x0010, 0x0002, 0x0111, 0x0100, 0x0101, 0x0104, 0x0105
WM_QUIT, WM_SETFONT, WM_HOTKEY, WM_INPUT = 0x0012, 0x0030, 0x0312, 0x00FF
MOUSEEVENTF_MOVE, MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0001, 0x0002, 0x0004
MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP, MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP = 0x0008, 0x0010, 0x0020, 0x0040
MOUSEEVENTF_WHEEL, MOUSEEVENTF_ABSOLUTE, MOUSEEVENTF_VIRTUALDESK = 0x0800, 0x8000, 0x4000
KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP, KEYEVENTF_SCANCODE = 0x0001, 0x0002, 0x0008
SRCCOPY, CAPTUREBLT, DIB_RGB_COLORS = 0x00CC0020, 0x40000000, 0
DISCOUNT = 0.92
TIME_REFERENCE_SECONDS = 0.24
N_STEP = 6
LONG_GOAL_DISCOUNT = 0.996
LONG_GOAL_HORIZON = 128
INVERSE_WORLD_INDICES = (1, 2, 7, 8, 18, 25, 32, 39, 46, 53, 60, 67, 98, 99, 116, 125)
STABLE_TEMPORAL_INDICES = (1, 2, 3, 7, 8, 18, 25, 39, 53) + tuple(SEMANTIC_START + i for i in (3, 5, 24, 36))


def action_elapsed_seconds(detail):
    if not isinstance(detail, dict):
        return TIME_REFERENCE_SECONDS
    value = detail.get('effective_elapsed_seconds', detail.get('duration', detail.get('requested_duration', TIME_REFERENCE_SECONDS)))
    try:
        seconds = float(value)
    except (ValueError, TypeError, OverflowError):
        return TIME_REFERENCE_SECONDS
    return max(0.03, min(8.0, seconds)) if math.isfinite(seconds) else TIME_REFERENCE_SECONDS


def transition_elapsed_seconds(transition):
    if len(transition) > 9 and isinstance(transition[9], dict):
        data = transition[9]
        if 'cumulative_elapsed_seconds' in data:
            try:
                value = float(data['cumulative_elapsed_seconds'])
                if math.isfinite(value):
                    return max(0.03, min(48.0, value))
            except (ValueError, TypeError, OverflowError):
                pass
        return action_elapsed_seconds(data) * max(1, int(transition[7])) if 'effective_elapsed_seconds' not in data and int(transition[7]) > 1 else action_elapsed_seconds(data)
    return max(1, int(transition[7])) * TIME_REFERENCE_SECONDS


def temporal_discount(seconds):
    return DISCOUNT ** (max(0.0, min(48.0, float(seconds))) / TIME_REFERENCE_SECONDS)


def long_goal_discount(seconds):
    return LONG_GOAL_DISCOUNT ** (max(0.0, min(180.0, float(seconds))) / TIME_REFERENCE_SECONDS)

WORLD_FEATURE_COUNT = 128
WORLD_IMPORTANCE = tuple(2.6 if i >= 124 else 2.1 if i >= WORLD_VISUAL_COUNT
                         else 1.7 if i in (1, 2, 6, 7, 8, 14, 15, 16, 17, 18, 25, 39, 53, 67, 78)
                         else 1.0 for i in range(WORLD_FEATURE_COUNT))
WORLD_IMPORTANCE_SUM = sum(WORLD_IMPORTANCE)
DUAL_VALUE_INDICES = (1, 2, 3, 4, 5, 7, 8, 9, 14, 15, 18, 25, 32, 39, 46, 53) + tuple(SEMANTIC_START + i for i in (0, 1, 2, 3, 4, 5, 6, 7, 24, 26, 28, 30, 36, 37, 56, 57))
DUAL_VALUE_FEATURES = len(DUAL_VALUE_INDICES)
WORLD_ACTION_FEATURES, WORLD_NETWORK_HIDDEN = 24, 48
GLYPH_ROWS = {
    '0': ('01110', '10001', '10011', '10101', '11001', '10001', '01110'),
    '1': ('00100', '01100', '00100', '00100', '00100', '00100', '01110'),
    '2': ('01110', '10001', '00001', '00010', '00100', '01000', '11111'),
    '3': ('11110', '00001', '00001', '01110', '00001', '00001', '11110'),
    '4': ('00010', '00110', '01010', '10010', '11111', '00010', '00010'),
    '5': ('11111', '10000', '10000', '11110', '00001', '00001', '11110'),
    '6': ('01110', '10000', '10000', '11110', '10001', '10001', '01110'),
    '7': ('11111', '00001', '00010', '00100', '01000', '01000', '01000'),
    '8': ('01110', '10001', '10001', '01110', '10001', '10001', '01110'),
    '9': ('01110', '10001', '10001', '01111', '00001', '00001', '01110'),
    'A': ('01110', '10001', '10001', '11111', '10001', '10001', '10001'),
    'B': ('11110', '10001', '10001', '11110', '10001', '10001', '11110'),
    'H': ('10001', '10001', '10001', '11111', '10001', '10001', '10001'),
    'J': ('00111', '00010', '00010', '00010', '10010', '10010', '01100'),
    'K': ('10001', '10010', '10100', '11000', '10100', '10010', '10001'),
    'P': ('11110', '10001', '10001', '11110', '10000', '10000', '10000'),
    'Q': ('01110', '10001', '10001', '10001', '10101', '10010', '01101'),
    'X': ('10001', '10001', '01010', '00100', '01010', '10001', '10001'),
    'Z': ('11111', '00001', '00010', '00100', '01000', '10000', '11111'),
    'C': ('01111', '10000', '10000', '10000', '10000', '10000', '01111'),
    'D': ('11110', '10001', '10001', '10001', '10001', '10001', '11110'),
    'E': ('11111', '10000', '10000', '11110', '10000', '10000', '11111'),
    'F': ('11111', '10000', '10000', '11110', '10000', '10000', '10000'),
    'G': ('01111', '10000', '10000', '10111', '10001', '10001', '01110'),
    'I': ('11111', '00100', '00100', '00100', '00100', '00100', '11111'),
    'L': ('10000', '10000', '10000', '10000', '10000', '10000', '11111'),
    'M': ('10001', '11011', '10101', '10101', '10001', '10001', '10001'),
    'N': ('10001', '11001', '10101', '10011', '10001', '10001', '10001'),
    'O': ('01110', '10001', '10001', '10001', '10001', '10001', '01110'),
    'R': ('11110', '10001', '10001', '11110', '10100', '10010', '10001'),
    'S': ('01111', '10000', '10000', '01110', '00001', '00001', '11110'),
    'T': ('11111', '00100', '00100', '00100', '00100', '00100', '00100'),
    'U': ('10001', '10001', '10001', '10001', '10001', '10001', '01110'),
    'V': ('10001', '10001', '10001', '10001', '10001', '01010', '00100'),
    'W': ('10001', '10001', '10001', '10101', '10101', '10101', '01010'),
    'Y': ('10001', '10001', '01010', '00100', '00100', '00100', '00100'),
}


class LocalGlyphTemplates:
    def __init__(self):
        self.templates = {}
        if os.name != 'nt':
            return
        gdi = ctypes.WinDLL('gdi32', use_last_error=True)
        gdi.CreateFontW.argtypes = [ctypes.c_int] * 13 + [ctypes.c_wchar_p]
        gdi.CreateFontW.restype = HWND
        gdi.TextOutW.argtypes = [HWND, ctypes.c_int, ctypes.c_int, ctypes.c_wchar_p, ctypes.c_int]
        gdi.TextOutW.restype = ctypes.c_int
        gdi.SetTextColor.argtypes = [HWND, ctypes.c_ulong]
        gdi.SetTextColor.restype = ctypes.c_ulong
        gdi.SetBkMode.argtypes = [HWND, ctypes.c_int]
        gdi.SetBkMode.restype = ctypes.c_int
        gdi.CreateCompatibleDC.argtypes = [HWND]
        gdi.CreateCompatibleDC.restype = HWND
        gdi.DeleteDC.argtypes = [HWND]
        gdi.DeleteDC.restype = ctypes.c_int
        gdi.CreateDIBSection.argtypes = [HWND, ctypes.POINTER(BITMAPINFO), ctypes.c_uint, ctypes.POINTER(HWND), HWND, ctypes.c_ulong]
        gdi.CreateDIBSection.restype = HWND
        gdi.SelectObject.argtypes = [HWND, HWND]
        gdi.SelectObject.restype = HWND
        gdi.DeleteObject.argtypes = [HWND]
        gdi.DeleteObject.restype = ctypes.c_int
        dc = gdi.CreateCompatibleDC(None)
        if not dc:
            return
        dib = BITMAPINFO()
        dib.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        dib.bmiHeader.biWidth = 40
        dib.bmiHeader.biHeight = -40
        dib.bmiHeader.biPlanes = 1
        dib.bmiHeader.biBitCount = 32
        pointer = HWND()
        bitmap = gdi.CreateDIBSection(dc, ctypes.byref(dib), 0, ctypes.byref(pointer), None, 0)
        if not bitmap or not pointer.value:
            if bitmap:
                gdi.DeleteObject(bitmap)
            gdi.DeleteDC(dc)
            return
        old_bitmap = gdi.SelectObject(dc, bitmap)
        gdi.SetBkMode(dc, 1)
        gdi.SetTextColor(dc, 0xFFFFFF)
        chars = ('胜利失败通关成功任务完成获游戏结束恭喜挑战胜负已达标战败继续重试重新开始'
                 '暂停恢复返回菜单选择确认确定取消开始进入下一关再来一次关卡任务目标等级'
                 '生命血量护甲魔力能量时间积分得分分数金币钻石奖励成就解锁经验升级'
                 '装备道具背包使用购买出售获得领取接受拒绝设置选项帮助保存加载'
                 '地图位置角色玩家敌人攻击防御跳跃移动方向左右上下提示注意'
                 '单人多人模式剧情竞技匹配在线离线网络连接商店继续退出'
                 '任意按键点击触摸选中确定暂停请稍候刷新等待错误')
        try:
            for face in ('Microsoft YaHei UI', 'SimSun', 'Microsoft JhengHei UI'):
                for height in (14, 18, 24, 31):
                    font = gdi.CreateFontW(height, 0, 0, 0, 650 if height % 2 else 450, 0, 0, 0, 1, 0, 0, 5, 0, face)
                    if not font:
                        continue
                    old_font = gdi.SelectObject(dc, font)
                    try:
                        for char in set(chars):
                            ctypes.memset(pointer.value, 0, 40 * 40 * 4)
                            if not gdi.TextOutW(dc, 2, 1, char, 1):
                                continue
                            bitmap_data = ctypes.string_at(pointer.value, 40 * 40 * 4)
                            positions = [(i % 40, i // 40) for i in range(40 * 40) if bitmap_data[i * 4] >= 95]
                            if not positions:
                                continue
                            left, top = min(x for x, y in positions), min(y for x, y in positions)
                            right, bottom = max(x for x, y in positions), max(y for x, y in positions)
                            occupied = set(positions)
                            mask = set()
                            for y in range(12):
                                sy = top + min(bottom - top, int((y + 0.5) * (bottom - top + 1) / 12))
                                for x in range(10):
                                    sx = left + min(right - left, int((x + 0.5) * (right - left + 1) / 10))
                                    if (sx, sy) in occupied:
                                        mask.add(y * 10 + x)
                            if len(mask) >= 14:
                                variants = self.templates.setdefault(char, [])
                                if not any(2.0 * len(mask & existing) / max(1, len(mask) + len(existing)) >= 0.98
                                           for existing in variants):
                                    variants.append(mask)
                    finally:
                        gdi.SelectObject(dc, old_font)
                        gdi.DeleteObject(font)
        finally:
            gdi.SelectObject(dc, old_bitmap)
            gdi.DeleteObject(bitmap)
            gdi.DeleteDC(dc)
        self.buckets = {}
        for symbol, variants in self.templates.items():
            for shape in variants:
                self.buckets.setdefault(len(shape) // 10, []).append((symbol, shape))

    def best(self, sampled):
        result = (0.0, '')
        second = 0.0
        bucket = len(sampled) // 10
        for offset in range(-2, 3):
            for symbol, shape in getattr(self, 'buckets', {}).get(bucket + offset, []):
                score = 2.0 * len(sampled & shape) / max(1, len(sampled) + len(shape))
                if score > result[0]:
                    if result[1] != symbol:
                        second = max(second, result[0])
                    result = (score, symbol)
                elif symbol != result[1]:
                    second = max(second, score)
        return result if result[0] >= 0.87 and result[0] - second >= 0.055 else (0.0, '')

CAPTURE_OWNER_LOCK = threading.Lock()
HWND = ctypes.c_void_p
LRESULT = ctypes.c_ssize_t
WPARAM = ctypes.c_size_t
LPARAM = ctypes.c_ssize_t
WINPROC = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(LRESULT, HWND, ctypes.c_uint, WPARAM, LPARAM)
HOOKPROC = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(LRESULT, ctypes.c_int, WPARAM, LPARAM)
WNDENUMPROC = getattr(ctypes, 'WINFUNCTYPE', ctypes.CFUNCTYPE)(ctypes.c_int, HWND, LPARAM)


def luminance_bgr(blue, green, red):
    return (blue * 0.114 + green * 0.587 + red * 0.299) / 255.0


class POINT(ctypes.Structure):
    _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]


class RECT(ctypes.Structure):
    _fields_ = [('left', ctypes.c_long), ('top', ctypes.c_long), ('right', ctypes.c_long), ('bottom', ctypes.c_long)]


class MSG(ctypes.Structure):
    _fields_ = [('hwnd', HWND), ('message', ctypes.c_uint), ('wParam', WPARAM), ('lParam', LPARAM), ('time', ctypes.c_ulong), ('pt', POINT), ('lPrivate', ctypes.c_ulong)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [('style', ctypes.c_uint), ('lpfnWndProc', WINPROC), ('cbClsExtra', ctypes.c_int), ('cbWndExtra', ctypes.c_int), ('hInstance', HWND), ('hIcon', HWND), ('hCursor', HWND), ('hbrBackground', HWND), ('lpszMenuName', ctypes.c_wchar_p), ('lpszClassName', ctypes.c_wchar_p)]


class BROWSEINFOW(ctypes.Structure):
    _fields_ = [('hwndOwner', HWND), ('pidlRoot', HWND), ('pszDisplayName', ctypes.c_wchar_p), ('lpszTitle', ctypes.c_wchar_p), ('ulFlags', ctypes.c_uint), ('lpfn', HWND), ('lParam', LPARAM), ('iImage', ctypes.c_int)]


class GUID(ctypes.Structure):
    _fields_ = [('Data1', ctypes.c_ulong), ('Data2', ctypes.c_ushort), ('Data3', ctypes.c_ushort), ('Data4', ctypes.c_ubyte * 8)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [('biSize', ctypes.c_ulong), ('biWidth', ctypes.c_long), ('biHeight', ctypes.c_long), ('biPlanes', ctypes.c_ushort), ('biBitCount', ctypes.c_ushort), ('biCompression', ctypes.c_ulong), ('biSizeImage', ctypes.c_ulong), ('biXPelsPerMeter', ctypes.c_long), ('biYPelsPerMeter', ctypes.c_long), ('biClrUsed', ctypes.c_ulong), ('biClrImportant', ctypes.c_ulong)]


class BITMAPINFO(ctypes.Structure):
    _fields_ = [('bmiHeader', BITMAPINFOHEADER), ('bmiColors', ctypes.c_ulong * 3)]


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [('dx', ctypes.c_long), ('dy', ctypes.c_long), ('mouseData', ctypes.c_ulong), ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [('wVk', ctypes.c_ushort), ('wScan', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [('uMsg', ctypes.c_ulong), ('wParamL', ctypes.c_ushort), ('wParamH', ctypes.c_ushort)]


class INPUTUNION(ctypes.Union):
    _fields_ = [('mi', MOUSEINPUT), ('ki', KEYBDINPUT), ('hi', HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _fields_ = [('type', ctypes.c_ulong), ('value', INPUTUNION)]


class KBDLLHOOKSTRUCT(ctypes.Structure):
    _fields_ = [('vkCode', ctypes.c_ulong), ('scanCode', ctypes.c_ulong), ('flags', ctypes.c_ulong), ('time', ctypes.c_ulong), ('dwExtraInfo', ctypes.c_size_t)]


class RAWINPUTDEVICE(ctypes.Structure):
    _fields_ = [('usUsagePage', ctypes.c_ushort), ('usUsage', ctypes.c_ushort), ('dwFlags', ctypes.c_ulong), ('hwndTarget', HWND)]


class RAWINPUTHEADER(ctypes.Structure):
    _fields_ = [('dwType', ctypes.c_ulong), ('dwSize', ctypes.c_ulong), ('hDevice', HWND), ('wParam', WPARAM)]


class RAWKEYBOARD(ctypes.Structure):
    _fields_ = [('MakeCode', ctypes.c_ushort), ('Flags', ctypes.c_ushort), ('Reserved', ctypes.c_ushort), ('VKey', ctypes.c_ushort), ('Message', ctypes.c_uint), ('ExtraInformation', ctypes.c_ulong)]


class RAWKEYINPUT(ctypes.Structure):
    _fields_ = [('header', RAWINPUTHEADER), ('keyboard', RAWKEYBOARD)]


class POINTERINFO(ctypes.Structure):
    _fields_ = [('pointerType', ctypes.c_uint), ('pointerId', ctypes.c_uint), ('frameId', ctypes.c_uint), ('pointerFlags', ctypes.c_uint), ('sourceDevice', HWND), ('hwndTarget', HWND), ('ptPixelLocation', POINT), ('ptHimetricLocation', POINT), ('ptPixelLocationRaw', POINT), ('ptHimetricLocationRaw', POINT), ('dwTime', ctypes.c_ulong), ('historyCount', ctypes.c_uint), ('InputData', ctypes.c_int), ('dwKeyStates', ctypes.c_ulong), ('PerformanceCount', ctypes.c_ulonglong), ('ButtonChangeType', ctypes.c_uint)]


class POINTERTOUCHINFO(ctypes.Structure):
    _fields_ = [('pointerInfo', POINTERINFO), ('touchFlags', ctypes.c_ulong), ('touchMask', ctypes.c_ulong), ('rcContact', RECT), ('rcContactRaw', RECT), ('orientation', ctypes.c_uint), ('pressure', ctypes.c_uint)]


class Native:
    def __init__(self):
        self.user = ctypes.WinDLL('user32', use_last_error=True)
        self.gdi = ctypes.WinDLL('gdi32', use_last_error=True)
        self.shell = ctypes.WinDLL('shell32', use_last_error=True)
        self.kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        self.ole = ctypes.WinDLL('ole32', use_last_error=True)
        self.ole.CoInitializeEx.argtypes = [HWND, ctypes.c_ulong]
        self.ole.CoInitializeEx.restype = ctypes.c_long
        self.ole.CoUninitialize.argtypes = []
        self.ole.CoUninitialize.restype = None
        self.com_initialized = self.ole.CoInitializeEx(None, 2) in (0, 1)
        specs = [
            (self.user, 'RegisterClassW', [ctypes.POINTER(WNDCLASSW)], ctypes.c_ushort),
            (self.user, 'CreateWindowExW', [ctypes.c_ulong, ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_ulong, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, HWND, HWND, HWND, HWND], HWND),
            (self.user, 'DefWindowProcW', [HWND, ctypes.c_uint, WPARAM, LPARAM], LRESULT),
            (self.user, 'GetMessageW', [ctypes.POINTER(MSG), HWND, ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'PeekMessageW', [ctypes.POINTER(MSG), HWND, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'TranslateMessage', [ctypes.POINTER(MSG)], ctypes.c_int),
            (self.user, 'DispatchMessageW', [ctypes.POINTER(MSG)], LRESULT),
            (self.user, 'PostMessageW', [HWND, ctypes.c_uint, WPARAM, LPARAM], ctypes.c_int),
            (self.user, 'PostThreadMessageW', [ctypes.c_ulong, ctypes.c_uint, WPARAM, LPARAM], ctypes.c_int),
            (self.user, 'SendMessageW', [HWND, ctypes.c_uint, WPARAM, LPARAM], LRESULT),
            (self.user, 'ShowWindow', [HWND, ctypes.c_int], ctypes.c_int),
            (self.user, 'UpdateWindow', [HWND], ctypes.c_int),
            (self.user, 'SetWindowTextW', [HWND, ctypes.c_wchar_p], ctypes.c_int),
            (self.user, 'EnableWindow', [HWND, ctypes.c_int], ctypes.c_int),
            (self.user, 'DestroyWindow', [HWND], ctypes.c_int),
            (self.user, 'LoadCursorW', [HWND, HWND], HWND),
            (self.user, 'GetSystemMetrics', [ctypes.c_int], ctypes.c_int),
            (self.user, 'GetForegroundWindow', [], HWND),
            (self.user, 'EnumWindows', [WNDENUMPROC, LPARAM], ctypes.c_int),
            (self.user, 'GetWindow', [HWND, ctypes.c_uint], HWND),
            (self.user, 'GetWindowRect', [HWND, ctypes.POINTER(RECT)], ctypes.c_int),
            (self.user, 'IsWindowVisible', [HWND], ctypes.c_int),
            (self.user, 'GetClassNameW', [HWND, ctypes.c_wchar_p, ctypes.c_int], ctypes.c_int),
            (self.user, 'GetWindowTextW', [HWND, ctypes.c_wchar_p, ctypes.c_int], ctypes.c_int),
            (self.user, 'GetClientRect', [HWND, ctypes.POINTER(RECT)], ctypes.c_int),
            (self.user, 'ClientToScreen', [HWND, ctypes.POINTER(POINT)], ctypes.c_int),
            (self.user, 'IsWindow', [HWND], ctypes.c_int),
            (self.user, 'IsIconic', [HWND], ctypes.c_int),
            (self.user, 'SetForegroundWindow', [HWND], ctypes.c_int),
            (self.user, 'GetDC', [HWND], HWND),
            (self.user, 'ReleaseDC', [HWND, HWND], ctypes.c_int),
            (self.user, 'GetAsyncKeyState', [ctypes.c_int], ctypes.c_short),
            (self.user, 'SendInput', [ctypes.c_uint, ctypes.POINTER(INPUT), ctypes.c_int], ctypes.c_uint),
            (self.user, 'MapVirtualKeyW', [ctypes.c_uint, ctypes.c_uint], ctypes.c_uint),
            (self.user, 'SetWindowsHookExW', [ctypes.c_int, HOOKPROC, HWND, ctypes.c_ulong], HWND),
            (self.user, 'CallNextHookEx', [HWND, ctypes.c_int, WPARAM, LPARAM], LRESULT),
            (self.user, 'UnhookWindowsHookEx', [HWND], ctypes.c_int),
            (self.user, 'RegisterHotKey', [HWND, ctypes.c_int, ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'UnregisterHotKey', [HWND, ctypes.c_int], ctypes.c_int),
            (self.user, 'RegisterRawInputDevices', [ctypes.POINTER(RAWINPUTDEVICE), ctypes.c_uint, ctypes.c_uint], ctypes.c_int),
            (self.user, 'GetRawInputData', [HWND, ctypes.c_uint, HWND, ctypes.POINTER(ctypes.c_uint), ctypes.c_uint], ctypes.c_uint),
            (self.user, 'UnregisterClassW', [ctypes.c_wchar_p, HWND], ctypes.c_int),
            (self.user, 'GetWindowThreadProcessId', [HWND, ctypes.POINTER(ctypes.c_ulong)], ctypes.c_ulong),
            (self.gdi, 'CreateCompatibleDC', [HWND], HWND),
            (self.gdi, 'DeleteDC', [HWND], ctypes.c_int),
            (self.gdi, 'CreateDIBSection', [HWND, ctypes.POINTER(BITMAPINFO), ctypes.c_uint, ctypes.POINTER(HWND), HWND, ctypes.c_ulong], HWND),
            (self.gdi, 'SelectObject', [HWND, HWND], HWND),
            (self.gdi, 'DeleteObject', [HWND], ctypes.c_int),
            (self.gdi, 'SetStretchBltMode', [HWND, ctypes.c_int], ctypes.c_int),
            (self.gdi, 'StretchBlt', [HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_ulong], ctypes.c_int),
            (self.shell, 'SHBrowseForFolderW', [ctypes.POINTER(BROWSEINFOW)], HWND),
            (self.shell, 'SHGetPathFromIDListW', [HWND, ctypes.c_wchar_p], ctypes.c_int),
            (self.shell, 'SHGetKnownFolderPath', [ctypes.POINTER(GUID), ctypes.c_ulong, HWND, ctypes.POINTER(HWND)], ctypes.c_long),
            (self.ole, 'CoTaskMemFree', [HWND], None),
            (self.kernel, 'GetModuleHandleW', [ctypes.c_wchar_p], HWND),
            (self.kernel, 'OpenProcess', [ctypes.c_ulong, ctypes.c_int, ctypes.c_ulong], HWND),
            (self.kernel, 'QueryFullProcessImageNameW', [HWND, ctypes.c_ulong, ctypes.c_wchar_p, ctypes.POINTER(ctypes.c_ulong)], ctypes.c_int),
            (self.kernel, 'CloseHandle', [HWND], ctypes.c_int),
            (self.kernel, 'GetCurrentThreadId', [], ctypes.c_ulong),
            (self.kernel, 'GetDriveTypeW', [ctypes.c_wchar_p], ctypes.c_uint),
            (self.gdi, 'GetStockObject', [ctypes.c_int], HWND),
        ]
        for lib, name, args, result in specs:
            proc = getattr(lib, name)
            proc.argtypes = args
            proc.restype = result
        try:
            self.user.SetProcessDpiAwarenessContext.argtypes = [HWND]
            self.user.SetProcessDpiAwarenessContext.restype = ctypes.c_int
            self.user.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
        except Exception:
            try:
                self.user.SetProcessDPIAware()
            except Exception:
                pass

    def folder(self, owner):
        name = ctypes.create_unicode_buffer(512)
        browse = BROWSEINFOW()
        browse.hwndOwner = owner
        browse.pszDisplayName = ctypes.cast(name, ctypes.c_wchar_p)
        browse.lpszTitle = '选择用于保存游戏 Agent 数据的文件夹'
        browse.ulFlags = 0x0001 | (0x0040 if self.com_initialized else 0)
        pidl = self.shell.SHBrowseForFolderW(ctypes.byref(browse))
        if not pidl:
            return None
        try:
            path = ctypes.create_unicode_buffer(32768)
            if self.shell.SHGetPathFromIDListW(pidl, path):
                return pathlib.Path(path.value)
        finally:
            self.ole.CoTaskMemFree(pidl)
        return None

    def desktop(self):
        guid = GUID(0xB4BFCC3A, 0xDB2C, 0x424C, (ctypes.c_ubyte * 8)(0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41))
        output = HWND()
        if self.shell.SHGetKnownFolderPath(ctypes.byref(guid), 0, None, ctypes.byref(output)) == 0 and output.value:
            try:
                return pathlib.Path(ctypes.wstring_at(output.value))
            finally:
                self.ole.CoTaskMemFree(output)
        return pathlib.Path.home() / 'Desktop'


def canonical_game_key(key):
    key = str(key or 'desktop')[:50]
    base, separator, number = key.rpartition(':')
    if separator and number.isdecimal() and base:
        key = base
    return key


def stop_equivalent(a, b):
    if a == b:
        return True
    for generic, left, right in ((16, 160, 161), (17, 162, 163), (18, 164, 165)):
        if b == generic:
            return a in (generic, left, right)
        if b == left:
            return a in (generic, left)
        if b == right:
            return a == right
    return False


def physical_virtual_key(vk, scan, flags):
    if vk in (16, 160, 161):
        return 161 if scan == 0x36 or vk == 161 else 160
    if vk in (17, 162, 163):
        return 163 if flags & 0x01 or vk == 163 else 162
    if vk in (18, 164, 165):
        return 165 if flags & 0x01 or vk == 165 else 164
    return vk

class StopKeyGate:
    def __init__(self, native, vk, stop_event):
        self.native, self.vk, self.stop_event = native, vk, stop_event
        self.lock = threading.Lock()
        self.injected_down = False
        self.injected_release_grace_until = 0.0
        self.poll_stops = 0
        self.poll_accessible = True
        self.on_stop = None
        try:
            self.armed = not bool(native.user.GetAsyncKeyState(vk) & 0x8000)
        except Exception:
            self.armed = False

    def observe(self, pressed, physical=True):
        callback = None
        with self.lock:
            if not physical:
                return False
            if not pressed:
                self.armed = True
                return False
            if not self.armed or self.stop_event.is_set():
                return False
            self.armed = False
            self.stop_event.set()
            callback = self.on_stop
        if callback is not None:
            try:
                callback()
            except Exception:
                pass
        return True

    def note_injected(self, pressed):
        with self.lock:
            self.injected_down = bool(pressed)
            if not pressed:
                self.injected_release_grace_until = time.monotonic() + 0.12

    def injected_blocked(self):
        with self.lock:
            return self.injected_down or time.monotonic() < self.injected_release_grace_until

    def poll(self, allow_press=True):
        try:
            state = int(self.native.user.GetAsyncKeyState(self.vk)) & 0xFFFF
            pressed = bool(state & 0x8000)
            tapped = bool(state & 0x0001)
        except Exception:
            self.poll_accessible = False
            return self.stop_event.is_set()
        self.poll_accessible = True
        if not pressed:
            with self.lock:
                if self.injected_down:
                    self.injected_down = False
                    self.injected_release_grace_until = time.monotonic() + 0.12
            self.observe(False)
            if allow_press and tapped and not self.injected_blocked() and self.observe(True):
                self.poll_stops += 1
        elif allow_press and not self.injected_blocked() and self.observe(True):
            self.poll_stops += 1
        return self.stop_event.is_set()


class StopListener:
    def __init__(self, native, stop_vk, stop_event, gate=None):
        self.native = native
        self.stop_vk = stop_vk
        self.stop_event = stop_event
        self.gate = gate if gate is not None else StopKeyGate(native, stop_vk, stop_event)
        self.ending = threading.Event()
        self.thread_id = 0
        self.mode = 'initializing'
        self.callback = None
        self.window_callback = None
        self.window = None
        self.ready = threading.Event()
        self.last_tick = time.monotonic()
        self.last_poll_tick = time.monotonic()
        self.poll_ready = threading.Event()
        self.poll_failures = 0
        self.loop_failures = 0
        self.raw_events = 0
        self.hook_events = 0
        self.hotkey_events = 0
        self.registered_channels = {'hook': False, 'raw': False, 'hotkey': False}
        self.registration_error = None
        self.thread = threading.Thread(target=self.run, name='StopKey', daemon=True)
        self.poll_thread = threading.Thread(target=self.poll_loop, name='StopKeyBackup', daemon=True)

    def start(self):
        self.poll_thread.start()
        self.thread.start()
        self.poll_ready.wait(2.0)
        self.ready.wait(2.0)
        if not self.healthy():
            self.close()
            raise OSError('停止键事件监听与独立轮询均未通过健康检查')

    def alive(self):
        return self.thread.is_alive() or self.poll_thread.is_alive()

    def event_healthy(self):
        return (self.thread.is_alive() and self.ready.is_set()
                and any(self.registered_channels.values())
                and time.monotonic() - self.last_tick < 1.5 and not self.ending.is_set())

    def poll_healthy(self):
        return (self.poll_thread.is_alive() and self.poll_ready.is_set() and self.gate.poll_accessible
                and time.monotonic() - self.last_poll_tick < 1.5 and not self.ending.is_set())

    def healthy(self):
        return self.event_healthy() or self.poll_healthy()

    def poll_loop(self):
        while not self.ending.is_set() and not self.stop_event.is_set():
            try:
                self.gate.poll(allow_press=True)
            except Exception:
                self.poll_failures += 1
            finally:
                self.last_poll_tick = time.monotonic()
                self.poll_ready.set()
            self.ending.wait(0.008)

    def run(self):
        self.thread_id = self.native.kernel.GetCurrentThreadId()
        hook = None
        registered = False
        raw_registered = False
        registered_class = False
        class_name = f'OpenGameAgentStopRaw_{os.getpid()}_{id(self)}'
        instance = self.native.kernel.GetModuleHandleW(None)
        try:
            def keyboard(code, wp, lp):
                try:
                    if code >= 0:
                        info = ctypes.cast(lp, ctypes.POINTER(KBDLLHOOKSTRUCT)).contents
                        physical_vk = physical_virtual_key(info.vkCode, info.scanCode, info.flags)
                        if stop_equivalent(physical_vk, self.stop_vk):
                            if info.flags & 0x10:
                                self.gate.note_injected(wp in (WM_KEYDOWN, WM_SYSKEYDOWN))
                                return self.native.user.CallNextHookEx(hook, code, wp, lp)
                            self.hook_events += 1
                            if wp in (WM_KEYUP, WM_SYSKEYUP):
                                self.gate.observe(False)
                                return 1
                            if wp in (WM_KEYDOWN, WM_SYSKEYDOWN):
                                self.gate.observe(True)
                                return 1
                except Exception:
                    pass
                return self.native.user.CallNextHookEx(hook, code, wp, lp)

            def raw_window(hwnd, msg, wp, lp):
                if msg == WM_INPUT:
                    try:
                        length = ctypes.c_uint(0)
                        header_size = ctypes.sizeof(RAWINPUTHEADER)
                        result = self.native.user.GetRawInputData(HWND(lp), 0x10000003, None, ctypes.byref(length), header_size)
                        if result != 0xFFFFFFFF and header_size + ctypes.sizeof(RAWKEYBOARD) <= length.value <= 65536:
                            buffer = ctypes.create_string_buffer(length.value)
                            copied = self.native.user.GetRawInputData(HWND(lp), 0x10000003, ctypes.cast(buffer, HWND), ctypes.byref(length), header_size)
                            if copied != 0xFFFFFFFF and copied >= header_size + ctypes.sizeof(RAWKEYBOARD):
                                data = ctypes.cast(buffer, ctypes.POINTER(RAWKEYINPUT)).contents
                                if data.header.dwType == 1:
                                    keyboard_input = data.keyboard
                                    vk = physical_virtual_key(int(keyboard_input.VKey), int(keyboard_input.MakeCode), int(keyboard_input.Flags >> 1) & 1)
                                    if stop_equivalent(vk, self.stop_vk):
                                        self.raw_events += 1
                                        self.gate.observe(not bool(keyboard_input.Flags & 1))
                    except Exception:
                        self.loop_failures += 1
                    if wp & 0xFF == 0:
                        self.native.user.DefWindowProcW(hwnd, msg, wp, lp)
                    return 0
                return self.native.user.DefWindowProcW(hwnd, msg, wp, lp)

            self.callback = HOOKPROC(keyboard)
            hook = self.native.user.SetWindowsHookExW(13, self.callback, None, 0)
            self.window_callback = WINPROC(raw_window)
            wc = WNDCLASSW()
            wc.lpfnWndProc = self.window_callback
            wc.hInstance = instance
            wc.lpszClassName = class_name
            if self.native.user.RegisterClassW(ctypes.byref(wc)):
                registered_class = True
                self.window = self.native.user.CreateWindowExW(0, class_name, '', 0, 0, 0, 0, 0,
                                                                HWND(-3), None, instance, None)
                if self.window:
                    device = RAWINPUTDEVICE(1, 6, 0x100, self.window)
                    raw_registered = bool(self.native.user.RegisterRawInputDevices(ctypes.byref(device), 1, ctypes.sizeof(RAWINPUTDEVICE)))
            registered = bool(self.native.user.RegisterHotKey(None, 8915, 0x4000, self.stop_vk))
            self.registered_channels = {'raw': raw_registered, 'hook': bool(hook), 'hotkey': registered}
            channels = [name for name, enabled in self.registered_channels.items() if enabled]
            self.mode = '+'.join(channels) if channels else 'poll'
            if not channels:
                self.registration_error = '键盘钩子、Raw Input 与系统热键均不可用，已启用独立键盘状态轮询'
            self.ready.set()
            msg = MSG()
            while not self.ending.is_set() and not self.stop_event.is_set():
                self.last_tick = time.monotonic()
                try:
                    self.gate.poll(allow_press=True)
                    while self.native.user.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                        if msg.message == WM_QUIT:
                            self.ending.set()
                            break
                        if msg.message == WM_HOTKEY and msg.wParam == 8915:
                            self.hotkey_events += 1
                            if not self.gate.injected_blocked():
                                self.gate.observe(True)
                            continue
                        self.native.user.TranslateMessage(ctypes.byref(msg))
                        self.native.user.DispatchMessageW(ctypes.byref(msg))
                except Exception:
                    self.loop_failures += 1
                    self.ending.set()
                self.ending.wait(0.009)
        except Exception as exc:
            self.registration_error = f'{type(exc).__name__}: {str(exc)[:180]}'
            self.mode = 'poll'
            self.ready.set()
        finally:
            self.registered_channels = {'hook': False, 'raw': False, 'hotkey': False}
            if raw_registered:
                try:
                    removal = RAWINPUTDEVICE(1, 6, 0x00000001, None)
                    self.native.user.RegisterRawInputDevices(ctypes.byref(removal), 1, ctypes.sizeof(RAWINPUTDEVICE))
                except Exception:
                    pass
            if hook:
                try:
                    self.native.user.UnhookWindowsHookEx(hook)
                except Exception:
                    pass
            if registered:
                try:
                    self.native.user.UnregisterHotKey(None, 8915)
                except Exception:
                    pass
            if self.window:
                try:
                    self.native.user.DestroyWindow(self.window)
                except Exception:
                    pass
                self.window = None
            if registered_class:
                try:
                    self.native.user.UnregisterClassW(class_name, instance)
                except Exception:
                    pass

    def close(self):
        self.ending.set()
        if self.thread_id:
            try:
                self.native.user.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)
            except Exception:
                pass
        if self.thread.ident is not None and self.thread is not threading.current_thread():
            self.thread.join(timeout=1.0)
        if self.poll_thread.ident is not None and self.poll_thread is not threading.current_thread():
            self.poll_thread.join(timeout=0.6)


class DXGIOutputDescription(ctypes.Structure):
    _fields_ = [('DeviceName', ctypes.c_wchar * 32), ('DesktopCoordinates', RECT), ('AttachedToDesktop', ctypes.c_int), ('Rotation', ctypes.c_uint), ('Monitor', HWND)]


class DXGIFrameInfo(ctypes.Structure):
    _fields_ = [('LastPresentTime', ctypes.c_longlong), ('LastMouseUpdateTime', ctypes.c_longlong), ('AccumulatedFrames', ctypes.c_uint), ('RectsCoalesced', ctypes.c_int), ('ProtectedContentMaskedOut', ctypes.c_int), ('PointerPosition', POINT), ('PointerVisible', ctypes.c_int), ('TotalMetadataBufferSize', ctypes.c_uint), ('PointerShapeBufferSize', ctypes.c_uint)]


class D3DTextureDescription(ctypes.Structure):
    _fields_ = [('Width', ctypes.c_uint), ('Height', ctypes.c_uint), ('MipLevels', ctypes.c_uint), ('ArraySize', ctypes.c_uint), ('Format', ctypes.c_uint), ('SampleCount', ctypes.c_uint), ('SampleQuality', ctypes.c_uint), ('Usage', ctypes.c_uint), ('BindFlags', ctypes.c_uint), ('CPUAccessFlags', ctypes.c_uint), ('MiscFlags', ctypes.c_uint)]


class D3DMappedResource(ctypes.Structure):
    _fields_ = [('pData', HWND), ('RowPitch', ctypes.c_uint), ('DepthPitch', ctypes.c_uint)]


class NativeDXGI:
    def __init__(self, np_module=None):
        if os.name != 'nt' or ctypes.sizeof(HWND) != 8:
            raise OSError('原生 DXGI 采集要求 Windows 11 x64')
        self.np = np_module
        self.device = HWND()
        self.context = HWND()
        self.outputs = []
        self.duplication = HWND()
        self.staging = HWND()
        self.active = None
        self.buffer = None
        self.pitch = 0
        self.buffer_width = 0
        self.buffer_height = 0
        self.frame_protected = False
        try:
            library = ctypes.WinDLL('d3d11.dll')
            create = library.D3D11CreateDevice
            create.argtypes = [HWND, ctypes.c_uint, HWND, ctypes.c_uint, HWND, ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(HWND), ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(HWND)]
            create.restype = ctypes.c_long
            level = ctypes.c_uint()
            result = create(None, 1, None, 0x20, None, 0, 7, ctypes.byref(self.device), ctypes.byref(level), ctypes.byref(self.context))
            if result < 0 or not self.device.value or not self.context.value:
                raise OSError('D3D11 硬件设备初始化失败')
            dxgi = self.query(self.device, '54ec77fa-1377-44e6-8c32-88fd5f44c84c')
            adapter = HWND()
            try:
                self.invoke(dxgi, 7, ctypes.c_long, ctypes.POINTER(HWND))(dxgi, ctypes.byref(adapter))
                if not adapter.value:
                    raise OSError('无法获取 DXGI 显示适配器')
                index = 0
                while index < 16:
                    output = HWND()
                    status = self.invoke(adapter, 7, ctypes.c_long, ctypes.c_uint, ctypes.POINTER(HWND))(adapter, index, ctypes.byref(output))
                    if status < 0 or not output.value:
                        break
                    try:
                        desc = DXGIOutputDescription()
                        status = self.invoke(output, 7, ctypes.c_long, ctypes.POINTER(DXGIOutputDescription))(output, ctypes.byref(desc))
                        if status < 0 or not desc.AttachedToDesktop or desc.Rotation != 1:
                            continue
                        rect = desc.DesktopCoordinates
                        if rect.right <= rect.left or rect.bottom <= rect.top:
                            continue
                        output1 = self.query(output, '00cddea8-939b-4b83-a340-a685226666cc')
                        self.outputs.append(((rect.left, rect.top, rect.right, rect.bottom), output1))
                    except OSError:
                        pass
                    finally:
                        self.release(output)
                        index += 1
            finally:
                self.release(adapter)
                self.release(dxgi)
            if not self.outputs:
                raise OSError('没有可用的 DXGI 桌面输出')
        except Exception:
            self.close()
            raise

    @staticmethod
    def invoke(pointer, slot, result, *arguments):
        vtable = ctypes.cast(pointer, ctypes.POINTER(ctypes.POINTER(HWND))).contents
        address = vtable[slot]
        if not address:
            raise OSError('DirectX COM 方法不可用')
        return ctypes.WINFUNCTYPE(result, HWND, *arguments)(ctypes.cast(address, HWND).value)

    @classmethod
    def release(cls, pointer):
        if pointer is not None and pointer.value:
            cls.invoke(pointer, 2, ctypes.c_ulong)(pointer)
            pointer.value = None

    @classmethod
    def query(cls, pointer, guid):
        iid = GUID.from_buffer_copy(uuid.UUID(guid).bytes_le)
        output = HWND()
        result = cls.invoke(pointer, 0, ctypes.c_long, ctypes.POINTER(GUID), ctypes.POINTER(HWND))(pointer, ctypes.byref(iid), ctypes.byref(output))
        if result < 0 or not output.value:
            raise OSError(f'DXGI 接口不可用：{guid}')
        return output

    def _reset(self):
        self.release(self.staging)
        self.release(self.duplication)
        self.active = None
        self.buffer = None
        self.pitch = 0
        self.frame_protected = False

    def _select(self, rect):
        x, y, width, height = rect
        for index, (bounds, _) in enumerate(self.outputs):
            left, top, right, bottom = bounds
            if x >= left and y >= top and x + width <= right and y + height <= bottom:
                return index
        return None

    def _connect(self, index):
        if self.active == index and self.duplication.value:
            return
        self._reset()
        output = self.outputs[index][1]
        result = self.invoke(output, 22, ctypes.c_long, HWND, ctypes.POINTER(HWND))(output, self.device, ctypes.byref(self.duplication))
        if result < 0 or not self.duplication.value:
            raise OSError(f'桌面复制接口不可用：0x{result & 0xffffffff:08x}')
        self.active = index

    def _stage(self, width, height):
        if self.staging.value and self.buffer_width == width and self.buffer_height == height:
            return
        self.release(self.staging)
        desc = D3DTextureDescription(width, height, 1, 1, 87, 1, 0, 3, 0, 0x20000, 0)
        result = self.invoke(self.device, 5, ctypes.c_long, ctypes.POINTER(D3DTextureDescription), HWND, ctypes.POINTER(HWND))(self.device, ctypes.byref(desc), None, ctypes.byref(self.staging))
        if result < 0 or not self.staging.value:
            raise OSError('无法创建 DirectX CPU 读取纹理')
        self.buffer_width, self.buffer_height = width, height

    def _capture(self, index):
        bounds = self.outputs[index][0]
        width, height = bounds[2] - bounds[0], bounds[3] - bounds[1]
        info = DXGIFrameInfo()
        resource = HWND()
        status = self.invoke(self.duplication, 8, ctypes.c_long, ctypes.c_uint, ctypes.POINTER(DXGIFrameInfo), ctypes.POINTER(HWND))(self.duplication, 24, ctypes.byref(info), ctypes.byref(resource))
        if status == ctypes.c_long(0x887a0027).value:
            return self.buffer is not None
        if status < 0:
            self._reset()
            raise OSError(f'DXGI 获取屏幕帧失败：0x{status & 0xffffffff:08x}')
        texture = HWND()
        mapped_ok = False
        try:
            self.frame_protected = bool(info.ProtectedContentMaskedOut)
            texture = self.query(resource, '6f15aaf2-d208-4e89-9ab4-489535d34f9c')
            incoming = D3DTextureDescription()
            self.invoke(texture, 10, None, ctypes.POINTER(D3DTextureDescription))(texture, ctypes.byref(incoming))
            if incoming.Format != 87 or incoming.Width != width or incoming.Height != height:
                return False
            self._stage(width, height)
            self.invoke(self.context, 47, None, HWND, HWND)(self.context, self.staging, texture)
            mapped = D3DMappedResource()
            result = self.invoke(self.context, 14, ctypes.c_long, HWND, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.POINTER(D3DMappedResource))(self.context, self.staging, 0, 1, 0, ctypes.byref(mapped))
            if result < 0 or not mapped.pData or mapped.RowPitch < width * 4:
                raise OSError('DirectX 帧映射失败')
            mapped_ok = True
            self.pitch = int(mapped.RowPitch)
            self.buffer = ctypes.string_at(mapped.pData, self.pitch * height)
            return True
        finally:
            if mapped_ok:
                self.invoke(self.context, 15, None, HWND, ctypes.c_uint)(self.context, self.staging, 0)
            self.release(texture)
            self.release(resource)
            if self.duplication.value:
                self.invoke(self.duplication, 14, ctypes.c_long)(self.duplication)

    def grab(self, rect, width, height):
        index = self._select(rect)
        if index is None:
            return None
        self._connect(index)
        if not self._capture(index) or self.frame_protected:
            return None
        left, top, right, bottom = self.outputs[index][0]
        sx, sy = rect[0] - left, rect[1] - top
        rw, rh = rect[2], rect[3]
        if self.np is not None:
            np = self.np
            image = np.frombuffer(self.buffer, dtype=np.uint8).reshape(self.buffer_height, self.pitch)
            xs = sx + np.minimum(rw - 1, np.arange(width, dtype=np.int32) * rw // width)
            ys = sy + np.minimum(rh - 1, np.arange(height, dtype=np.int32) * rh // height)
            image = image[:, :self.buffer_width * 4].reshape(self.buffer_height, self.buffer_width, 4)
            return np.ascontiguousarray(image[ys[:, None], xs[None, :]]).tobytes()
        raw = self.buffer
        result = bytearray(width * height * 4)
        xs = [sx + min(rw - 1, c * rw // width) for c in range(width)]
        for row in range(height):
            source = (sy + min(rh - 1, row * rh // height)) * self.pitch
            destination = row * width * 4
            for col, x in enumerate(xs):
                pos = source + x * 4
                result[destination + col * 4:destination + col * 4 + 4] = raw[pos:pos + 4]
        return bytes(result)

    def close(self):
        self._reset()
        for _, output in self.outputs:
            self.release(output)
        self.outputs.clear()
        self.release(self.context)
        self.release(self.device)


class WorkspaceLease:
    def __init__(self, selected):
        self.selected = pathlib.Path(selected).resolve()
        self.selected.mkdir(parents=True, exist_ok=True)
        self.stream = None
        self.folder = None
        import msvcrt
        for attempt in range(2):
            folder = self.selected if attempt == 0 else self.selected / '并行运行数据' / (time.strftime('%Y%m%d_%H%M%S') + '_' + str(os.getpid()) + '_' + uuid.uuid4().hex[:8])
            folder.mkdir(parents=True, exist_ok=True)
            stream = (folder / '.agent_workspace.lock').open('a+b')
            try:
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                stream.close()
                if attempt == 0:
                    continue
                raise
            self.folder = folder
            self.stream = stream
            return
        raise OSError('无法锁定选定的数据目录')

    def close(self):
        if self.stream is None:
            return
        stream, self.stream = self.stream, None
        try:
            import msvcrt
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        finally:
            stream.close()


class Capture:
    def __init__(self, native, mode, own_hwnd):
        self.n = native
        self.mode = mode
        self.own_hwnd = own_hwnd
        self.target = None
        self.target_signature = None
        self.target_pid = None
        self.target_candidate = None
        self.target_candidate_count = 0
        self.target_candidate_since = 0.0
        self.target_last_focus_attempt = 0.0
        self.target_rank = 0
        self.target_candidate_frame = None
        self.target_candidate_motion = 0.0
        self.target_candidate_last_probe = 0.0
        self.capture_lock = threading.RLock()
        self.identity_base = None
        self.identity_title = ''
        self.identity_candidate = ''
        self.identity_count = 0
        self.low_information_frames = 0
        self.last_backend_probe = 0.0
        self.base = None
        self.detail = None
        self.dx = None
        self.native_dx = None
        self.cv_np = None
        self.backend_error = None
        try:
            self.cv_np = importlib.import_module('numpy')
        except ImportError:
            pass
        self._initialize_fast_capture()
        try:
            self.base = self._surface(W, H)
            self.detail = self._surface(DW, DH)
        except Exception:
            self.close()
            raise

    @property
    def backend(self):
        if self.native_dx is not None:
            return 'native_dxgi'
        if self.dx is not None:
            return 'dxcam'
        return 'gdi'

    def _initialize_fast_capture(self):
        if self.native_dx is None:
            try:
                self.native_dx = NativeDXGI(self.cv_np)
                self.backend_error = None
            except Exception as exc:
                self.backend_error = f'原生 DXGI 采集未启用：{type(exc).__name__}: {exc}'
        if self.native_dx is None and self.dx is None and self.cv_np is not None:
            try:
                library = importlib.import_module('dxcam')
                self.dx = library.create(output_idx=0, output_color='BGRA')
            except Exception as exc:
                self.backend_error = f'{self.backend_error or ""}; dxcam 不可用：{type(exc).__name__}: {exc}'

    def _surface(self, width, height):
        dc = self.n.gdi.CreateCompatibleDC(None)
        if not dc:
            raise OSError('无法创建图像采集内存设备')
        bitmap = None
        try:
            bmi = BITMAPINFO()
            bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
            bmi.bmiHeader.biWidth = width
            bmi.bmiHeader.biHeight = -height
            bmi.bmiHeader.biPlanes = 1
            bmi.bmiHeader.biBitCount = 32
            bmi.bmiHeader.biCompression = 0
            bmi.bmiHeader.biSizeImage = width * height * 4
            bits = HWND()
            bitmap = self.n.gdi.CreateDIBSection(dc, ctypes.byref(bmi), DIB_RGB_COLORS, ctypes.byref(bits), None, 0)
            if not bitmap or not bits.value:
                raise OSError('无法创建图像采集缓冲区')
            previous = self.n.gdi.SelectObject(dc, bitmap)
            if not previous:
                raise OSError('无法选取图像采集缓冲区')
            self.n.gdi.SetStretchBltMode(dc, 3)
            return (dc, bitmap, previous, bits.value, width, height)
        except Exception:
            if bitmap:
                self.n.gdi.DeleteObject(bitmap)
            self.n.gdi.DeleteDC(dc)
            raise

    def game_identity(self):
        hwnd = self.target if self.mode == '窗口' and self.target else self.n.user.GetForegroundWindow()
        if not hwnd or hwnd == self.own_hwnd or not self.n.user.IsWindow(hwnd):
            return 'desktop'
        try:
            pid = ctypes.c_ulong()
            self.n.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
            exe = ''
            if pid.value:
                process = self.n.kernel.OpenProcess(0x1000, 0, pid.value)
                if process:
                    try:
                        buffer = ctypes.create_unicode_buffer(32768)
                        size = ctypes.c_ulong(len(buffer))
                        if self.n.kernel.QueryFullProcessImageNameW(process, 0, buffer, ctypes.byref(size)):
                            exe = pathlib.PureWindowsPath(buffer.value).name.lower()
                    finally:
                        self.n.kernel.CloseHandle(process)
            label = ctypes.create_unicode_buffer(260)
            self.n.user.GetClassNameW(hwnd, label, len(label))
            basis = '|'.join((exe or f'pid:{pid.value}', label.value.lower()))
            if exe in ('chrome.exe', 'msedge.exe', 'firefox.exe', 'brave.exe', 'opera.exe'):
                title = ctypes.create_unicode_buffer(512)
                self.n.user.GetWindowTextW(hwnd, title, len(title))
                clean = ''.join('#' if c.isdigit() else c for c in title.value.lower().strip()).split(' - ')[0][:75]
                if self.identity_base != basis:
                    self.identity_base = basis
                    self.identity_title = clean
                    self.identity_candidate = clean
                    self.identity_count = 0
                elif clean != self.identity_title:
                    if clean == self.identity_candidate:
                        self.identity_count += 1
                    else:
                        self.identity_candidate = clean
                        self.identity_count = 1
                    if self.identity_count >= 90 and clean:
                        self.identity_title = clean
                        self.identity_count = 0
                basis += '|' + self.identity_title
            else:
                self.identity_base = basis
                self.identity_title = ''
            return hashlib.blake2b(basis.encode('utf-8'), digest_size=10).hexdigest()
        except Exception:
            return 'desktop'

    def _window_identity(self, hwnd):
        if not hwnd or hwnd == self.own_hwnd or not self.n.user.IsWindow(hwnd):
            return None
        pid = ctypes.c_ulong()
        self.n.user.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value or pid.value == os.getpid():
            return None
        label = ctypes.create_unicode_buffer(256)
        self.n.user.GetClassNameW(hwnd, label, len(label))
        executable = ''
        process = self.n.kernel.OpenProcess(0x1000, 0, pid.value)
        if process:
            try:
                path = ctypes.create_unicode_buffer(32768)
                length = ctypes.c_ulong(len(path))
                if self.n.kernel.QueryFullProcessImageNameW(process, 0, path, ctypes.byref(length)):
                    executable = str(path.value).casefold()
            finally:
                self.n.kernel.CloseHandle(process)
        if label.value.casefold() in ('progman', 'workerw', 'shell_traywnd'):
            return None
        title_buffer = ctypes.create_unicode_buffer(512)
        self.n.user.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
        stable_title = ''.join('#' if char.isdecimal() else char for char in title_buffer.value.strip().casefold())[:120]
        return (int(pid.value), label.value.casefold(), executable, stable_title)

    def _same_target(self, hwnd):
        record = self._window_identity(hwnd)
        if record is None or self.target_signature is None:
            return False
        if record[1] != self.target_signature[0]:
            return False
        if record[0] == self.target_pid:
            return not self.target_signature[1] or record[2] == self.target_signature[1]
        if not self.target_signature[1] or record[2] != self.target_signature[1]:
            return False
        if len(self.target_signature) > 2 and self.target_signature[2] and record[3] != self.target_signature[2]:
            return False
        if self.n.user.GetForegroundWindow() != hwnd:
            return False
        old_process = self.n.kernel.OpenProcess(0x1000, 0, self.target_pid or 0)
        if old_process:
            try:
                return False
            finally:
                self.n.kernel.CloseHandle(old_process)
        return getattr(ctypes, 'get_last_error', lambda: 0)() == 87

    def _window_rank(self, hwnd, identity, width, height, foreground):
        if identity is None or width < 80 or height < 80:
            return None
        executable = pathlib.PureWindowsPath(identity[2]).name.casefold()
        window_class = identity[1].casefold()
        if executable in ('explorer.exe', 'taskmgr.exe', 'searchhost.exe', 'startmenuexperiencehost.exe', 'shellexperiencehost.exe', 'systemsettings.exe', 'control.exe', 'gamebar.exe', 'steam.exe'):
            return None
        if window_class in ('cabinetwclass', 'explorewclass', 'progman', 'workerw', 'shell_traywnd', 'windows.ui.core.corewindow'):
            return None
        if self.n.user.GetWindow(hwnd, 4):
            return None
        area = width * height
        screen_area = max(1, self.n.user.GetSystemMetrics(0) * self.n.user.GetSystemMetrics(1))
        recognized = any(token in window_class or token in executable for token in ('unitywndclass', 'unrealwindow', 'sdl_app', 'glfw', 'godot', 'game', 'pygame', 'roblox', 'steam', 'rpg', 'emulator', 'retroarch'))
        return (min(15000000, area) + (45000000 if hwnd == foreground else 0)
                + (2500000 if area >= screen_area * 0.70 else 0)
                + (8000000 if recognized else 0))

    def _candidate_is_game_like(self, selected):
        if selected is None:
            return False
        identity = selected[2]
        name = (identity[1] + ' ' + pathlib.PureWindowsPath(identity[2]).name).casefold()
        return any(token in name for token in ('unitywndclass', 'unrealwindow', 'sdl_app', 'glfw', 'godot', 'game', 'pygame', 'roblox', 'steam', 'rpg', 'emulator', 'retroarch'))

    def _candidate_visual_evidence(self, hwnd):
        rect = RECT()
        origin = POINT()
        if not self.n.user.GetClientRect(hwnd, ctypes.byref(rect)) or not self.n.user.ClientToScreen(hwnd, ctypes.byref(origin)):
            return False
        width, height = rect.right - rect.left, rect.bottom - rect.top
        if width < 80 or height < 80:
            return False
        now = time.monotonic()
        if now - self.target_candidate_last_probe < 0.18:
            return self.target_candidate_motion >= 0.012
        self.target_candidate_last_probe = now
        frame = self._grab(self.base, (origin.x, origin.y, width, height))
        old = self.target_candidate_frame
        self.target_candidate_frame = frame
        if old is not None and len(old) == len(frame):
            step = max(4, len(frame) // 2000 // 4 * 4)
            indices = range(0, len(frame), step)
            changed = sum(abs(old[i] - frame[i]) for i in indices) / max(1, len(indices) * 255)
            self.target_candidate_motion = max(changed, self.target_candidate_motion * 0.92)
        return self.target_candidate_motion >= 0.012

    def _candidates(self, previously_bound=False):
        visible = []
        foreground = self.n.user.GetForegroundWindow()
        def visit(hwnd, unused):
            try:
                identity = self._window_identity(hwnd)
                if identity is None or not self.n.user.IsWindowVisible(hwnd) or self.n.user.IsIconic(hwnd):
                    return 1
                if previously_bound and not self._same_target(hwnd):
                    return 1
                rect = RECT()
                if not self.n.user.GetClientRect(hwnd, ctypes.byref(rect)):
                    return 1
                width, height = rect.right - rect.left, rect.bottom - rect.top
                score = self._window_rank(hwnd, identity, width, height, foreground)
                if score is None:
                    return 1
                if previously_bound and identity[0] == self.target_pid:
                    score += 16000000
                if self.target and hwnd == self.target:
                    score += 32000000
                visible.append((score, int(hwnd), identity))
            except (OSError, ValueError, TypeError):
                pass
            return 1
        callback = WNDENUMPROC(visit)
        self.n.user.EnumWindows(callback, 0)
        visible.sort(reverse=True)
        return visible

    def _stable_window_candidate(self, selected, seconds):
        candidate = (selected[1], selected[2]) if selected is not None else None
        if candidate is None:
            self.target_candidate = None
            self.target_candidate_count = 0
            self.target_candidate_since = 0.0
            self.target_candidate_frame = None
            self.target_candidate_motion = 0.0
            return False
        if candidate != self.target_candidate:
            self.target_candidate = candidate
            self.target_candidate_count = 1
            self.target_candidate_since = time.monotonic()
            self.target_candidate_frame = None
            self.target_candidate_motion = 0.0
            self.target_candidate_last_probe = 0.0
        else:
            self.target_candidate_count += 1
        stable_for = time.monotonic() - self.target_candidate_since
        if self.target_candidate_count < 4 or stable_for < seconds:
            return False
        if self._candidate_is_game_like(selected):
            return True
        if stable_for >= 6.0:
            return True
        return self._candidate_visual_evidence(selected[1]) and stable_for >= 0.8

    def _bind_window(self, selected):
        self.target = selected[1]
        self.target_signature = selected[2][1:]
        self.target_pid = selected[2][0]
        self.target_rank = selected[0]
        self.target_candidate = None
        self.target_candidate_count = 0
        self.target_candidate_since = 0.0
        self.target_candidate_frame = None
        self.target_candidate_motion = 0.0

    def is_target_focused(self):
        if self.mode != '窗口':
            return True
        return bool(self.target and self.n.user.IsWindow(self.target)
                    and not self.n.user.IsIconic(self.target)
                    and self._same_target(self.target)
                    and self.n.user.GetForegroundWindow() == self.target)

    def bounds(self):
        if self.mode == '窗口':
            foreground = self.n.user.GetForegroundWindow()
            if self.target_signature is None:
                options = self._candidates()
                selected = next((item for item in options if item[1] == foreground), None)
                if self._stable_window_candidate(selected, 0.45):
                    self._bind_window(selected)
            elif not self.target or not self.n.user.IsWindow(self.target) or not self._same_target(self.target):
                self.target = None
                options = self._candidates(previously_bound=True)
                selected = next((item for item in options if item[1] == foreground), None)
                if selected is None and len(options) == 1 and options[0][2][0] == self.target_pid:
                    selected = options[0]
                if self._stable_window_candidate(selected, 0.80):
                    self._bind_window(selected)
            else:
                self.target_candidate = None
                self.target_candidate_count = 0
                self.target_candidate_since = 0.0
            if self.target and self.n.user.IsWindow(self.target) and self._same_target(self.target):
                if self.n.user.IsIconic(self.target):
                    self.n.user.ShowWindow(self.target, 9)
                rect = RECT()
                origin = POINT()
                if self.n.user.GetClientRect(self.target, ctypes.byref(rect)) and self.n.user.ClientToScreen(self.target, ctypes.byref(origin)):
                    width, height = rect.right - rect.left, rect.bottom - rect.top
                    if width >= 80 and height >= 80:
                        if not self.is_target_focused() and time.monotonic() - self.target_last_focus_attempt >= 0.28:
                            self.target_last_focus_attempt = time.monotonic()
                            self.n.user.SetForegroundWindow(self.target)
                        if not self.is_target_focused():
                            raise OSError('原游戏窗口尚未获得输入焦点，正持续尝试恢复')
                        return (origin.x, origin.y, width, height)
            raise OSError('等待有效前台游戏窗口；仅允许稳定绑定或恢复原程序窗口，不切换到无关窗口')
        return (
            self.n.user.GetSystemMetrics(76),
            self.n.user.GetSystemMetrics(77),
            max(1, self.n.user.GetSystemMetrics(78)),
            max(1, self.n.user.GetSystemMetrics(79)),
        )

    def review_frame_quality(self, quality):
        if quality.get('low_information'):
            self.low_information_frames += 1
        else:
            self.low_information_frames = 0
        if self.low_information_frames < 12:
            return
        now = time.monotonic()
        if now - self.last_backend_probe < 25.0:
            return
        self.last_backend_probe = now
        if self.native_dx is not None:
            self.native_dx.close()
            self.native_dx = None
        elif self.dx is not None:
            camera = self.dx
            self.dx = None
            try:
                camera.stop()
                camera.release()
            except Exception:
                pass
        else:
            self._initialize_fast_capture()
        self.low_information_frames = 0

    def _grab(self, surface, rect):
        dc, _, _, bits, width, height = surface
        if self.native_dx is not None:
            try:
                frame = self.native_dx.grab(rect, width, height)
                if frame is not None and len(frame) == width * height * 4:
                    return frame
            except Exception as exc:
                self.backend_error = f'DXGI 采集失败：{type(exc).__name__}: {exc}'
                self.native_dx.close()
                self.native_dx = None
        if self.dx is not None and self.cv_np is not None:
            try:
                x, y, rw, rh = rect
                frame = self.dx.grab(region=(x, y, x + rw, y + rh), new_frame_only=False)
                if frame is not None and len(frame.shape) == 3 and frame.shape[2] == 4:
                    sy = self.cv_np.minimum(rh - 1, (self.cv_np.arange(height) * rh // height))
                    sx = self.cv_np.minimum(rw - 1, (self.cv_np.arange(width) * rw // width))
                    return self.cv_np.ascontiguousarray(frame[sy[:, None], sx[None, :]]).tobytes()
            except Exception:
                camera = self.dx
                self.dx = None
                if camera is not None:
                    try:
                        camera.stop()
                    except Exception:
                        pass
                    try:
                        camera.release()
                    except Exception:
                        pass
        desktop = self.n.user.GetDC(None)
        if not desktop:
            raise OSError('屏幕采集源不可用')
        try:
            ok = self.n.gdi.StretchBlt(dc, 0, 0, width, height, desktop, rect[0], rect[1], rect[2], rect[3], SRCCOPY | CAPTUREBLT)
            if not ok:
                raise OSError('屏幕采集失败')
            return ctypes.string_at(bits, width * height * 4)
        finally:
            self.n.user.ReleaseDC(None, desktop)

    def grab(self):
        with self.capture_lock:
            rect = self.bounds()
            return self._grab(self.base, rect), rect

    def grab_detail(self, rect, u, v):
        rw = min(rect[2], max(96, int(rect[2] * 0.38)))
        rh = min(rect[3], max(96, int(rect[3] * 0.38)))
        ox = rect[0] + max(0, min(rect[2] - rw, int(u * rect[2] - rw * 0.5)))
        oy = rect[1] + max(0, min(rect[3] - rh, int(v * rect[3] - rh * 0.5)))
        with self.capture_lock:
            return self._grab(self.detail, (ox, oy, rw, rh))

    def close(self):
        if self.native_dx is not None:
            try:
                self.native_dx.close()
            except Exception:
                pass
            self.native_dx = None
        if self.dx is not None:
            try:
                self.dx.stop()
            except Exception:
                pass
            try:
                self.dx.release()
            except Exception:
                pass
            self.dx = None
        for name in ('base', 'detail'):
            surface = getattr(self, name, None)
            if surface is None:
                continue
            dc, bitmap, previous, _, _, _ = surface
            try:
                self.n.gdi.SelectObject(dc, previous)
            finally:
                try:
                    self.n.gdi.DeleteObject(bitmap)
                finally:
                    self.n.gdi.DeleteDC(dc)
            setattr(self, name, None)


class Controller:
    def __init__(self, native, stop_vk, stopped):
        self.n = native
        self.stop_vk = stop_vk
        self.stopped = stopped
        self.down = set()
        self.mouse_down = set()
        self.successful_inputs = 0
        self.last_successful_input = None
        self.last_action_detail = None
        self.guard = None
        self.stop_gate = None
        self.releasing = False
        self.feedback_break = False
        self.interruption_reason = None
        self.monitor = None
        self.monitor_interval = 0.045
        self.touch_points = []
        self.touch_available = False
        try:
            self.n.user.InitializeTouchInjection.argtypes = [ctypes.c_uint, ctypes.c_ulong]
            self.n.user.InitializeTouchInjection.restype = ctypes.c_int
            self.n.user.InjectTouchInput.argtypes = [ctypes.c_uint, ctypes.POINTER(POINTERTOUCHINFO)]
            self.n.user.InjectTouchInput.restype = ctypes.c_int
            self.touch_available = bool(self.n.user.InitializeTouchInjection(10, 3))
        except Exception:
            self.touch_available = False

    def touch(self, locations, phase, rect):
        if not self.touch_available and phase != 'up':
            return False
        if phase == 'up' and not self.touch_points:
            return True
        if phase != 'up':
            if self.stop_gate is not None:
                self.stop_gate.poll(allow_press=True)
            if self.stopped.is_set():
                return False
            if self.guard is not None and not self.guard():
                raise OSError('触摸输入焦点不属于已绑定的游戏窗口')
        infos = (POINTERTOUCHINFO * len(locations))()
        flags = {'down': 0x10006, 'update': 0x20006, 'up': 0x40000}[phase]
        for i, (u, v) in enumerate(locations):
            x = rect[0] + round(min(1.0, max(0.0, u)) * max(0, rect[2] - 1))
            y = rect[1] + round(min(1.0, max(0.0, v)) * max(0, rect[3] - 1))
            infos[i].pointerInfo.pointerType = 2
            infos[i].pointerInfo.pointerId = i
            infos[i].pointerInfo.pointerFlags = flags
            infos[i].pointerInfo.ptPixelLocation = POINT(x, y)
            infos[i].touchMask = 7
            infos[i].rcContact = RECT(x - 3, y - 3, x + 3, y + 3)
            infos[i].orientation = 90
            infos[i].pressure = 512
        if not self.n.user.InjectTouchInput(len(locations), infos):
            if phase != 'up':
                self.touch_available = False
            raise OSError('Windows 触摸注入失败，触摸释放状态保留以便重试')
        self.touch_points = [(locations, rect)] if phase != 'up' else []
        self.successful_inputs += 1
        self.last_successful_input = time.monotonic()
        return True

    def send(self, inp):
        release_input = (inp.type == 1 and bool(inp.value.ki.dwFlags & KEYEVENTF_KEYUP)) or (inp.type == 0 and bool(inp.value.mi.dwFlags & (MOUSEEVENTF_LEFTUP | MOUSEEVENTF_RIGHTUP | MOUSEEVENTF_MIDDLEUP)))
        if inp.type == 1:
            code = int(inp.value.ki.wVk)
            scan = int(inp.value.ki.wScan)
            flags = int(inp.value.ki.dwFlags)
            if scan and not code:
                code = int(self.n.user.MapVirtualKeyW(scan | (0xE000 if flags & KEYEVENTF_EXTENDEDKEY else 0), 3))
            if stop_equivalent(physical_virtual_key(code, scan, 1 if flags & KEYEVENTF_EXTENDEDKEY else 0), self.stop_vk):
                return False
        if not self.releasing and not release_input:
            if self.stop_gate is not None:
                self.stop_gate.poll(allow_press=True)
            if self.stopped.is_set():
                return False
            if self.guard is not None and not self.guard():
                raise OSError('当前输入焦点不属于已绑定的游戏窗口')
            if self.stopped.is_set():
                return False
        sent = self.n.user.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))
        if sent != 1:
            code = getattr(ctypes, 'get_last_error', lambda: 0)()
            raise OSError(code, f'SendInput 失败：{sent}/1，可能受到进程权限或输入保护的阻止')
        self.successful_inputs += 1
        self.last_successful_input = time.monotonic()
        return True

    def key(self, vk, pressed):
        if stop_equivalent(vk, self.stop_vk):
            return False
        scan = self.n.user.MapVirtualKeyW(vk, 0)
        extended = vk in (33, 34, 35, 36, 37, 38, 39, 40, 45, 46, 91, 92, 93, 111, 163, 165)
        flags = (KEYEVENTF_SCANCODE if scan else 0) | (KEYEVENTF_EXTENDEDKEY if extended else 0) | (0 if pressed else KEYEVENTF_KEYUP)
        data = INPUT()
        data.type = 1
        data.value.ki = KEYBDINPUT(0 if scan else vk, scan, flags, 0, 0)
        if not self.send(data):
            return False
        if pressed:
            self.down.add(vk)
        else:
            self.down.discard(vk)
        return True

    def mouse(self, flags, wheel=0, x=0, y=0):
        data = INPUT()
        data.type = 0
        data.value.mi = MOUSEINPUT(x, y, wheel & 0xFFFFFFFF, flags, 0, 0)
        if not self.send(data):
            return False
        for bit in (MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_MIDDLEDOWN):
            if flags & bit:
                self.mouse_down.add(bit)
        for down, up in ((MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP), (MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP), (MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP)):
            if flags & up:
                self.mouse_down.discard(down)

    def move(self, u, v, rect):
        x = rect[0] + round(min(1.0, max(0.0, u)) * max(0, rect[2] - 1))
        y = rect[1] + round(min(1.0, max(0.0, v)) * max(0, rect[3] - 1))
        sx, sy = self.n.user.GetSystemMetrics(76), self.n.user.GetSystemMetrics(77)
        sw, sh = max(1, self.n.user.GetSystemMetrics(78) - 1), max(1, self.n.user.GetSystemMetrics(79) - 1)
        px = max(0, min(65535, round((x - sx) * 65535 / sw)))
        py = max(0, min(65535, round((y - sy) * 65535 / sh)))
        self.mouse(MOUSEEVENTF_MOVE | MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_VIRTUALDESK, x=px, y=py)

    def delay(self, seconds):
        deadline = time.monotonic() + max(0.0, seconds)
        while not self.stopped.is_set() and not self.feedback_break:
            if self.stop_gate is not None and self.stop_gate.poll(allow_press=True):
                return False
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return True
            if self.stopped.wait(min(self.monitor_interval, remaining)):
                return False
            if self.monitor is not None:
                monitor_result = self.monitor()
                if monitor_result is not True:
                    self.feedback_break = True
                    self.interruption_reason = monitor_result if isinstance(monitor_result, str) else 'visual_change'
                    return False
        return False

    def release(self, preserve_keys=(), preserve_mouse=(), retries=4):
        keep_keys = set(preserve_keys)
        keep_mouse = set(preserve_mouse)
        mapping = {MOUSEEVENTF_LEFTDOWN: MOUSEEVENTF_LEFTUP,
                   MOUSEEVENTF_RIGHTDOWN: MOUSEEVENTF_RIGHTUP,
                   MOUSEEVENTF_MIDDLEDOWN: MOUSEEVENTF_MIDDLEUP}
        failure = None
        self.releasing = True
        try:
            for attempt in range(max(1, int(retries))):
                for vk in tuple(self.down):
                    if vk not in keep_keys:
                        try:
                            if not self.key(vk, False):
                                failure = OSError('输入释放被拒绝')
                        except Exception as exc:
                            failure = exc
                for pressed in tuple(self.mouse_down):
                    if pressed not in keep_mouse:
                        try:
                            self.mouse(mapping[pressed])
                        except Exception as exc:
                            failure = exc
                for locations, rect in tuple(self.touch_points):
                    try:
                        if not self.touch(locations, 'up', rect):
                            failure = OSError('触摸释放未成功')
                    except Exception as exc:
                        failure = exc
                pending = bool(self.down - keep_keys or self.mouse_down - keep_mouse or self.touch_points)
                if not pending:
                    return True
                if attempt + 1 < retries:
                    time.sleep(0.035)
            raise OSError('仍存在未确认释放的按键、鼠标或触摸输入') from failure
        finally:
            self.releasing = False

    def _focus_point(self, obs):
        ranked = sorted(range(GW * GH), key=lambda i: obs.salience[i] + 0.025 * (1 - abs((i % GW + 0.5) / GW - 0.5)) + random.random() * 0.065, reverse=True)
        if obs.attention_points and random.random() < 0.55:
            x, y, _ = random.choice(obs.attention_points[:min(18, len(obs.attention_points))])
            return x, y
        chosen = random.choice(ranked[:min(10, len(ranked))])
        return ((chosen % GW + random.random()) / GW, (chosen // GW + random.random()) / GH)

    def _refine_point(self, x, y, obs, stagnation, certainty=0.0):
        cx = max(0, min(GW - 1, int(x * GW)))
        cy = max(0, min(GH - 1, int(y * GH)))
        radius = 2 if stagnation >= 14 else 1
        candidates = [r * GW + c for r in range(max(0, cy - radius), min(GH, cy + radius + 1)) for c in range(max(0, cx - radius), min(GW, cx + radius + 1))]
        best = max(candidates, key=lambda i: obs.salience[i] - 0.045 * ((i % GW - cx) ** 2 + (i // GW - cy) ** 2) + random.random() * 0.012)
        certainty = min(1.0, max(0.0, float(certainty)))
        strength = min(0.7, max(0.0, obs.salience[best] * 1.4)) * (1.0 - certainty * 0.94)
        u = x * (1 - strength) + ((best % GW + 0.5) / GW) * strength
        v = y * (1 - strength) + ((best // GW + 0.5) / GH) * strength
        jitter = (0.012 if stagnation < 12 else 0.025) * (1.0 - certainty * 0.98)
        return max(0.0, min(1.0, u + random.uniform(-jitter, jitter))), max(0.0, min(1.0, v + random.uniform(-jitter, jitter)))

    def execute(self, action, observation, rect, stagnation, parameters=None, monitor=None, feedback_delay=0.09):
        if self.stopped.is_set():
            return False
        kind, a, b, x, y = action.kind, action.a, action.b, action.x, action.y
        requested_duration = parameters[2] if parameters is not None else action.duration
        extent = max(0.5, min(1.5, float(parameters[3]))) if parameters is not None and len(parameters) > 3 else 1.0
        certainty = max(0.0, min(1.0, float(parameters[4]))) if parameters is not None and len(parameters) > 4 and math.isfinite(float(parameters[4])) else 0.0
        planned_coordinates = bool(parameters is not None and len(parameters) > 5 and parameters[5] == 'world_plan')
        tempo = max(0.42, min(1.30, 0.11 / max(0.035, feedback_delay)))
        if kind not in ('hold', 'pair_hold', 'move_fire', 'combat', 'aim', 'look', 'key', 'chord', 'swipe', 'right_swipe', 'touch_swipe'):
            tempo = 1.0
        activity = max(0.55, 1.0 - min(0.40, observation.change * 0.75))
        requested_duration = float(requested_duration)
        if not math.isfinite(requested_duration) or requested_duration < 0.0:
            requested_duration = action.duration
        duration = max(0.025, requested_duration * tempo * activity * (1.0 + min(18, stagnation) / 25.0))
        self.monitor = monitor
        self.monitor_interval = min(0.065, max(0.012, feedback_delay * (0.24 if kind in ('combat', 'aim', 'look') else 0.46)))
        self.feedback_break = False
        self.interruption_reason = None
        initial_x, initial_y = x, y
        self.last_action_detail = None
        command_start_monotonic = time.monotonic()
        emitted_before = self.successful_inputs
        emitted_during_action = 0
        planned_wait = 0.0
        actual_wait = 0.0
        finished = False
        primary_input_sent = False
        down_was_held = kind == 'hold' and a in self.down
        def pause(seconds):
            nonlocal planned_wait, actual_wait
            seconds = max(0.0, float(seconds))
            planned_wait += seconds
            start = time.monotonic()
            result = self.delay(seconds)
            actual_wait += min(seconds, time.monotonic() - start)
            return result
        def glide(x0, y0, x1, y1, seconds):
            distance = math.hypot((x1 - x0) * rect[2], (y1 - y0) * rect[3])
            frames = max(4, min(48, int(max(distance / 15.0, seconds / 0.018))))
            for j in range(1, frames + 1):
                if self.stopped.is_set() or self.feedback_break:
                    return False
                fraction = j / frames
                eased = fraction * fraction * (3.0 - 2.0 * fraction)
                self.move(x0 + (x1 - x0) * eased, y0 + (y1 - y0) * eased, rect)
                if not pause(seconds / frames):
                    return False
            return True
        try:
            self.release(preserve_keys=(a,) if kind == 'hold' else ())
            emitted_before = self.successful_inputs
            if kind in ('key', 'hold'):
                if down_was_held or self.key(a, True):
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind == 'chord':
                if self.key(a, True) and self.key(b, True):
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind == 'pair_hold':
                if self.key(a, True) and self.key(b, True):
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind == 'move_fire':
                if self.key(a, True):
                    self.mouse(MOUSEEVENTF_LEFTDOWN)
                    primary_input_sent = True
                    finished = pause(duration)
            elif kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press'):
                if planned_coordinates:
                    x, y = max(0.0, min(1.0, float(parameters[0]))), max(0.0, min(1.0, float(parameters[1])))
                elif parameters is not None:
                    x, y = self._refine_point(parameters[0], parameters[1], observation, stagnation, certainty)
                elif kind.startswith('focus_') or kind == 'press':
                    x, y = self._focus_point(observation)
                else:
                    x, y = self._refine_point(x, y, observation, stagnation, certainty)
                initial_x, initial_y = x, y
                self.move(x, y, rect)
                if pause(0.016):
                    if kind in ('right', 'focus_right'):
                        down, up = MOUSEEVENTF_RIGHTDOWN, MOUSEEVENTF_RIGHTUP
                    elif kind == 'middle':
                        down, up = MOUSEEVENTF_MIDDLEDOWN, MOUSEEVENTF_MIDDLEUP
                    else:
                        down, up = MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP
                    finished = True
                    for _ in range(2 if kind in ('double', 'focus_double') else 1):
                        if self.stopped.is_set() or self.feedback_break:
                            finished = False
                            break
                        self.mouse(down)
                        primary_input_sent = True
                        held = pause(duration if kind == 'press' else max(0.028, min(0.14, duration * 0.36)))
                        self.mouse(up)
                        if not held or not pause(0.045):
                            finished = False
                            break
            elif kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch'):
                x, y = parameters[:2] if parameters is not None else self._focus_point(observation)
                if not planned_coordinates:
                    x, y = self._refine_point(x, y, observation, stagnation, certainty)
                initial_x, initial_y = x, y
                if self.touch_available:
                    if kind == 'dual_touch':
                        x, y = min(0.42, max(0.08, x)), min(0.93, max(0.55, y))
                        positions = [(x, y), (0.82, 0.74)]
                    else:
                        positions = [(max(0.02, x - 0.14), y), (min(0.98, x + 0.14), y)] if kind == 'pinch' else [(x, y)]
                    finished = self.touch(positions, 'down', rect)
                    primary_input_sent = bool(finished)
                    frames = max(6, min(40, int(duration / 0.024))) if kind != 'touch_tap' else 1
                    for j in range(frames):
                        if self.stopped.is_set() or self.feedback_break or not finished:
                            finished = False
                            break
                        if kind == 'pinch':
                            offset = 0.14 + (j + 1) * a * 0.018 * extent
                            positions = [(max(0.02, x - offset), y), (min(0.98, x + offset), y)]
                        elif kind == 'touch_swipe':
                            positions = [(max(0.02, min(0.98, x + a * (j + 1) * 0.045 * extent)), max(0.02, min(0.98, y + b * (j + 1) * 0.045 * extent)))]
                        elif kind == 'dual_touch':
                            phase = (j + 1) / frames
                            positions = [(max(0.08, min(0.45, x + a * 0.13 * extent * phase)),
                                          max(0.55, min(0.94, y + b * 0.13 * extent * phase))),
                                         (max(0.64, min(0.96, 0.82 + a * 0.10 * extent * phase)),
                                          max(0.55, min(0.94, 0.74 + b * 0.10 * extent * phase)))]
                        if not self.touch(positions, 'update', rect) or not pause(duration / frames):
                            finished = False
                            break
                    self.touch(positions, 'up', rect)
                else:
                    self.move(x, y, rect)
                    self.mouse(MOUSEEVENTF_LEFTDOWN)
                    primary_input_sent = True
                    finished = True
                    if kind in ('touch_swipe', 'dual_touch'):
                        finished = glide(x, y, x + a * 0.36 * extent, y + b * 0.36 * extent, duration)
                    elif kind == 'pinch':
                        finished = pause(0.06)
                        if finished:
                            self.mouse(MOUSEEVENTF_WHEEL, (1 if a > 0 else -1) * 120)
                    else:
                        finished = pause(duration)
                    self.mouse(MOUSEEVENTF_LEFTUP)
            elif kind == 'move':
                x, y = parameters[:2] if parameters is not None else self._focus_point(observation)
                if not planned_coordinates:
                    x, y = self._refine_point(x, y, observation, stagnation, certainty)
                initial_x, initial_y = x, y
                self.move(x, y, rect)
                primary_input_sent = True
                finished = pause(max(0.02, min(0.18, duration * 0.30)))
            elif kind in ('swipe', 'right_swipe'):
                x, y = parameters[:2] if parameters is not None else self._focus_point(observation)
                dx = a * extent * min(0.5, 0.25 + stagnation * 0.008)
                dy = b * extent * min(0.5, 0.25 + stagnation * 0.008)
                x, y = min(1.0, max(0.0, x - dx * 0.5)), min(1.0, max(0.0, y - dy * 0.5))
                initial_x, initial_y = x, y
                self.move(x, y, rect)
                self.mouse(MOUSEEVENTF_RIGHTDOWN if kind == 'right_swipe' else MOUSEEVENTF_LEFTDOWN)
                primary_input_sent = True
                finished = True
                target_x, target_y = min(1.0, max(0.0, x + dx)), min(1.0, max(0.0, y + dy))
                finished = glide(x, y, target_x, target_y, duration)
                x, y = target_x, target_y
            elif kind == 'look':
                finished = True
                for _ in range(8):
                    if self.stopped.is_set() or self.feedback_break:
                        finished = False
                        break
                    self.mouse(MOUSEEVENTF_MOVE, x=int(a * extent * max(2, rect[2] * 0.01)), y=int(b * extent * max(2, rect[3] * 0.01)))
                    primary_input_sent = True
                    if not pause(duration / 8):
                        finished = False
                        break
            elif kind == 'wheel':
                self.mouse(MOUSEEVENTF_WHEEL, a * 120)
                primary_input_sent = True
                finished = pause(0.05)
            elif kind in ('combat', 'aim'):
                if not a or self.key(a, True):
                    self.mouse(MOUSEEVENTF_LEFTDOWN)
                    primary_input_sent = True
                    finished = pause(duration * 0.45)
                    if finished and kind == 'aim':
                        for j in range(3):
                            if self.stopped.is_set() or self.feedback_break:
                                finished = False
                                break
                            self.mouse(MOUSEEVENTF_MOVE, x=int(b * 8 * extent), y=int((j - 1) * 5 * extent))
                            if not pause(duration * 0.12):
                                finished = False
                                break
                    elif finished:
                        finished = pause(duration * 0.55)
        finally:
            emitted_during_action = self.successful_inputs - emitted_before
            self.monitor = None
            if kind == 'hold' and finished and not self.stopped.is_set() and not self.feedback_break:
                self.release(preserve_keys=(a,))
            else:
                self.release()
            emitted = emitted_during_action + int(down_was_held)
            interrupted = bool(self.stopped.is_set() or self.feedback_break or not finished)
            if emitted > 0 and primary_input_sent:
                self.last_action_detail = {
                    'kind': kind, 'a': int(a), 'b': int(b), 'x': float(x), 'y': float(y),
                    'start_x': float(initial_x), 'start_y': float(initial_y),
                    'duration': float(actual_wait), 'requested_duration': float(requested_duration), 'extent': float(extent),
                    'scheduled_duration': float(duration),
                    'completion_ratio': (max(0.0, min(1.0 if finished else 0.85, actual_wait / planned_wait)) if planned_wait else (1.0 if finished else 0.0)),
                    'interrupted': interrupted, 'finished': bool(finished and not interrupted),
                    'interruption_reason': 'stop_key' if self.stopped.is_set() else self.interruption_reason if self.feedback_break else 'incomplete_action' if not finished else None,
                    'input_sent': True, 'sent_events': int(emitted),
                    'command_start_monotonic': command_start_monotonic,
                    'command_finished_monotonic': time.monotonic(),
                    'emulated_touch': bool(kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch') and not self.touch_available),
                    'actual_touch_points': (2 if kind in ('pinch', 'dual_touch') else 1) if self.touch_available and kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch') else 0,
                    'spatial': kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch'),
                }
        return bool(self.last_action_detail and not self.stopped.is_set())

class Action:
    __slots__ = ('id', 'kind', 'a', 'b', 'x', 'y', 'prior', 'duration', 'category')

    def __init__(self, id, kind, a=0, b=0, x=0.0, y=0.0, prior=1.0, duration=0.15, category='explore'):
        self.id, self.kind, self.a, self.b = id, kind, a, b
        self.x, self.y, self.prior, self.duration, self.category = x, y, prior, duration, category


def actions_for(stop_vk):
    common = {ord(c) for c in 'WASDQERFGTZXCVBIJKLNM1234567890'} | {13, 9, 32, 37, 38, 39, 40, 16, 17, 18, 27, 8}
    actions = []
    for vk in range(8, 255):
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'key:{vk}', 'key', a=vk, prior=4.5 if vk in common else 0.025, duration=0.11, category='interact'))
    for vk in list(map(ord, 'WASDQERFGTZXCVBIJKLNM1234567890')) + [32, 37, 38, 39, 40, 16, 17, 18, 9, 13, 8]:
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'hold:{vk}', 'hold', a=vk, prior=3.1 if vk in (87, 65, 83, 68) else 1.0, duration=0.35, category='navigate'))
    for modifier in (16, 17, 18):
        if stop_equivalent(modifier, stop_vk):
            continue
        for vk in list(map(ord, 'WASDQERFGTZXCVBIJKLNM1234567890')) + [32, 37, 38, 39, 40, 9, 13]:
            if not stop_equivalent(vk, stop_vk):
                actions.append(Action(f'chord:{modifier}:{vk}', 'chord', a=modifier, b=vk, prior=0.9, duration=0.2, category='combat'))
    for first, second in ((87, 65), (87, 68), (83, 65), (83, 68), (38, 37), (38, 39), (40, 37), (40, 39)):
        if not stop_equivalent(first, stop_vk) and not stop_equivalent(second, stop_vk):
            actions.append(Action(f'pair_hold:{first}:{second}', 'pair_hold', a=first, b=second, prior=1.15, duration=0.42, category='navigate'))
    for vk in (87, 65, 83, 68, 32):
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'move_fire:{vk}', 'move_fire', a=vk, prior=1.2, duration=0.38, category='combat'))
    for kind, prior in (('click', 4.0), ('right', 1.3), ('double', 1.5), ('move', 0.8), ('middle', 0.4), ('focus_click', 2.0), ('focus_right', 0.8), ('focus_double', 0.9), ('press', 1.5)):
        actions.append(Action(kind, kind, x=0.5, y=0.5, prior=prior, duration=0.48 if kind == 'press' else 0.15, category='interact'))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)):
        for kind, prior in (('swipe', 1.4), ('right_swipe', 0.6), ('look', 1.5)):
            actions.append(Action(f'{kind}:{dx}:{dy}', kind, a=dx, b=dy, prior=prior, duration=0.25, category='navigate'))
    actions.append(Action('touch_tap', 'touch_tap', prior=1.4, duration=0.09, category='interact'))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        actions.append(Action(f'touch_swipe:{dx}:{dy}', 'touch_swipe', a=dx, b=dy, prior=0.8, duration=0.45, category='navigate'))
    for dx, dy in ((-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (1, -1), (-1, 1), (1, 1)):
        actions.append(Action(f'dual_touch:{dx}:{dy}', 'dual_touch', a=dx, b=dy, prior=0.85, duration=0.45, category='combat'))
    for direction in (-1, 1):
        actions.append(Action(f'pinch:{direction}', 'pinch', a=direction, prior=0.35, duration=0.5, category='navigate'))
        actions.append(Action(f'wheel:{direction}', 'wheel', a=direction, prior=1.1, category='interact'))
    for vk in (87, 65, 83, 68, 32, 0):
        if not stop_equivalent(vk, stop_vk):
            actions.append(Action(f'combat:{vk}', 'combat', a=vk, prior=1.1, duration=0.45, category='combat'))
    for dx in (-1, 1):
        actions.append(Action(f'aim:{dx}', 'aim', b=dx, prior=1.0, duration=0.32, category='combat'))
    return actions


class Observation:
    __slots__ = ('lum', 'rgb', 'salience', 'motion', 'edges', 'features', 'signature', 'change', 'novelty', 'rect', 'raw', 'hud', 'game', 'valid', 'quality', 'frame_uid', 'region_signals', 'scene_key', 'attention_points', 'hud_readouts', 'ui_text', 'ui_numbers', 'hud_meters', 'objects', 'temporal_summary', 'ui_state', 'phase', 'phase_confidence', 'scene_identity', 'state_uncertainty', 'interaction_targets', 'camera_motion', 'belief_state')

    def __init__(self, lum, rgb, salience, motion, edges, features, signature, change, novelty, rect, raw, hud, game, valid=True, quality=None):
        self.lum, self.rgb, self.salience, self.motion, self.edges = lum, rgb, salience, motion, edges
        self.valid = valid
        self.quality = quality or {}
        self.features, self.signature, self.change, self.novelty = features, signature, change, novelty
        self.rect, self.raw, self.hud, self.game = rect, raw, hud, game
        self.frame_uid = uuid.uuid4().hex
        self.region_signals = []
        self.scene_key = game
        self.attention_points = []
        self.hud_readouts = []
        self.ui_text = []
        self.ui_numbers = []
        self.hud_meters = {}
        self.objects = []
        self.temporal_summary = {}
        self.ui_state = {}
        self.phase = 'unknown'
        self.phase_confidence = 0.0
        self.scene_identity = game
        self.state_uncertainty = 1.0
        self.interaction_targets = []
        self.camera_motion = (0, 0, 0.0)
        self.belief_state = {}



def quarantine_corrupt_store(folder, failure):
    words = ('malformed', 'not a database', '完整性检查失败', 'database disk image', 'file is not a database')
    if not isinstance(failure, sqlite3.DatabaseError) or not any(word in str(failure).lower() for word in words):
        return False
    stamp = str(time.time_ns())
    moved = False
    for suffix in ('', '-wal', '-shm'):
        source = folder / ('experience.sqlite3' + suffix)
        if source.exists():
            source.replace(folder / ('experience.sqlite3' + suffix + '.corrupt.' + stamp))
            moved = True
    return moved


class ReplayStore:
    def __init__(self, folder):
        self.db = sqlite3.connect(str(folder / 'experience.sqlite3'), timeout=12)
        try:
            self.db.execute('PRAGMA journal_mode=WAL')
            self.db.execute('PRAGMA synchronous=FULL')
            integrity = self.db.execute('PRAGMA quick_check(1)').fetchone()
            if not integrity or integrity[0] != 'ok':
                raise sqlite3.DatabaseError('数据库完整性检查失败')
            self.db.execute("CREATE TABLE IF NOT EXISTS transitions (id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL, game TEXT NOT NULL, action TEXT NOT NULL, reward REAL NOT NULL, before BLOB NOT NULL, after BLOB NOT NULL, change REAL NOT NULL, done INTEGER NOT NULL DEFAULT 0, horizon INTEGER NOT NULL DEFAULT 1, priority REAL NOT NULL DEFAULT 0.1, confidence REAL NOT NULL DEFAULT 0, action_detail TEXT NOT NULL DEFAULT '{}', uid TEXT NOT NULL UNIQUE, feature_version INTEGER NOT NULL DEFAULT 11, signal_kind INTEGER NOT NULL DEFAULT 0)")
            present = {column[1] for column in self.db.execute('PRAGMA table_info(transitions)')}
            for name, column_type, default in (('done', 'INTEGER', '0'), ('horizon', 'INTEGER', '1'), ('priority', 'REAL', '0.1'), ('confidence', 'REAL', '0'), ('action_detail', 'TEXT', "'{}'"), ('feature_version', 'INTEGER', '9'), ('signal_kind', 'INTEGER', '0')):
                if name not in present:
                    self.db.execute(f'ALTER TABLE transitions ADD COLUMN {name} {column_type} NOT NULL DEFAULT {default}')
            if 'uid' not in present:
                self.db.execute('ALTER TABLE transitions ADD COLUMN uid TEXT')
                previous_ids = self.db.execute('SELECT id FROM transitions').fetchall()
                if previous_ids:
                    self.db.executemany('UPDATE transitions SET uid=? WHERE id=?', ((uuid.uuid4().hex, entry[0]) for entry in previous_ids))
            self.db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_transitions_uid ON transitions(uid)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_transitions_game ON transitions(game, id)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_transitions_priority ON transitions(priority DESC, id DESC)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_transitions_result ON transitions(done, id DESC)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_transitions_signal_kind ON transitions(signal_kind, id DESC)')
            self.db.execute('CREATE TABLE IF NOT EXISTS keyframes (id INTEGER PRIMARY KEY AUTOINCREMENT, at REAL NOT NULL, game TEXT NOT NULL, step INTEGER NOT NULL, action TEXT NOT NULL, signature TEXT NOT NULL, valid INTEGER NOT NULL, width INTEGER NOT NULL, height INTEGER NOT NULL, frame BLOB NOT NULL)')
            self.db.execute('CREATE INDEX IF NOT EXISTS idx_frames_game_step ON keyframes(game, step)')
            if 'uid' not in {col[1] for col in self.db.execute('PRAGMA table_info(keyframes)')}:
                self.db.execute('ALTER TABLE keyframes ADD COLUMN uid TEXT')
            self.db.execute('CREATE UNIQUE INDEX IF NOT EXISTS idx_keyframes_uid ON keyframes(uid)')
            self.db.execute('CREATE TABLE IF NOT EXISTS sessions (id INTEGER PRIMARY KEY AUTOINCREMENT, started REAL NOT NULL, python TEXT NOT NULL)')
            for table in ('transitions', 'keyframes'):
                for (identity,) in self.db.execute(f'SELECT DISTINCT game FROM {table}').fetchall():
                    normalized = canonical_game_key(identity)
                    if normalized != identity:
                        self.db.execute(f'UPDATE {table} SET game=? WHERE game=?', (normalized, identity))
            self.db.execute('INSERT INTO sessions(started,python) VALUES (?,?)', (time.time(), sys.version.split()[0]))
            self.db.commit()
            self.pending = 0
            self.last_commit = time.monotonic()
            self.frame_step = {}
            self.frames_saved = 0
            self.start_frame_count = int(self.db.execute('SELECT COUNT(*) FROM keyframes').fetchone()[0])
            self.total_transitions = int(self.db.execute('SELECT COUNT(*) FROM transitions').fetchone()[0])
            self.first_commit_verified = self.total_transitions > 0
        except Exception:
            self.db.close()
            raise

    @staticmethod
    def pack(values):
        if len(values) != FEATURE_COUNT:
            raise ValueError('经验样本特征长度不正确')
        return struct.pack('<' + 'f' * FEATURE_COUNT, *values)

    @staticmethod
    def unpack(raw, version=MODEL_FORMAT):
        if len(raw) not in (LEGACY_FEATURE_COUNT * 4, FEATURE_COUNT * 4):
            raise ValueError('经验样本特征长度不正确')
        count = len(raw) // 4
        values = list(struct.unpack('<' + 'f' * count, raw)) + [0.0] * (FEATURE_COUNT - count)
        if int(version) < 10:
            values[SEMANTIC_START:] = [0.0] * SEMANTIC_COUNT
        if int(version) < 11:
            values[DETAIL_SCHEMA_START:DETAIL_META_START + 4] = [0.0] * 8
        return values

    def verify_roundtrip(self):
        before = [float(i % 13) / 13.0 for i in range(FEATURE_COUNT)]
        after = [float((i + 1) % 13) / 13.0 for i in range(FEATURE_COUNT)]
        marker = 'preflight:' + hashlib.sha256(os.urandom(16)).hexdigest()
        self.db.execute('SAVEPOINT agent_verify')
        try:
            self.db.execute('INSERT INTO transitions(at,game,action,reward,before,after,change,done,horizon,priority,confidence,action_detail,uid,feature_version) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)', (time.time(), marker, 'preflight', 0.1, sqlite3.Binary(self.pack(before)), sqlite3.Binary(self.pack(after)), 0.01, 0, 1, 0.1, 1.0, '{}', uuid.uuid4().hex, MODEL_FORMAT))
            row = self.db.execute('SELECT before,after,action_detail,feature_version FROM transitions WHERE game=? ORDER BY id DESC LIMIT 1', (marker,)).fetchone()
            if row is None or bytes(row[0]) != self.pack(before) or bytes(row[1]) != self.pack(after) or row[2] != '{}' or row[3] != MODEL_FORMAT:
                raise sqlite3.DatabaseError('经验库写入及回读验证失败')
        finally:
            self.db.execute('ROLLBACK TO agent_verify')
            self.db.execute('RELEASE agent_verify')
        if self.db.execute('SELECT COUNT(*) FROM transitions WHERE game=?', (marker,)).fetchone()[0]:
            raise sqlite3.DatabaseError('经验库测试事务回滚失败')
        return True

    def add_many(self, rows):
        if not rows:
            return 0
        timestamp = time.time()
        entries = []
        for row in rows:
            game, action, reward, before, after, change, done, horizon, priority, confidence = row[:10]
            detail = row[10].copy() if len(row) > 10 and isinstance(row[10], dict) else {}
            uid = detail.get('uid')
            if not isinstance(uid, str) or not (12 <= len(uid) <= 80):
                uid = uuid.uuid4().hex
                detail['uid'] = uid
            encoded = json.dumps(detail, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
            effective = bool(detail.get('input_sent') and detail.get('feedback_valid', True))
            effect_flag = int(effective and detail.get('learning_effect_observation') == 0.0)
            try:
                error = float(detail.get('learning_world_prediction_error') or 0.0)
                surprising = int(effective and float(confidence) >= 0.48
                                 and math.isfinite(error) and error >= 0.07)
            except (ValueError, TypeError, OverflowError):
                surprising = 0
            controlling = int(effective and float(detail.get('learning_action_effect') or 0.0) >= 0.015
                              and float(detail.get('learning_causality') or 0.0) >= 0.38)
            signal_kind = effect_flag + 2 * surprising + 4 * controlling
            entries.append((timestamp, canonical_game_key(game), action, float(reward), sqlite3.Binary(self.pack(before)), sqlite3.Binary(self.pack(after)), float(change), int(done), int(horizon), max(0.01, float(priority)), max(0.0, min(1.0, float(confidence))), encoded, uid, MODEL_FORMAT, signal_kind))
        try:
            cursor = self.db.executemany('INSERT INTO transitions(at,game,action,reward,before,after,change,done,horizon,priority,confidence,action_detail,uid,feature_version,signal_kind) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO NOTHING', entries)
            inserted = cursor.rowcount
            if inserted < 0 or inserted > len(entries):
                raise sqlite3.DatabaseError('经验批量写入结果异常')
            if not self.first_commit_verified and inserted:
                verified = False
                for expected in reversed(entries):
                    sample = self.db.execute('SELECT action,before,after,action_detail FROM transitions WHERE uid=?', (expected[12],)).fetchone()
                    if (sample is not None and sample[0] == expected[2] and bytes(sample[1]) == bytes(expected[4])
                            and bytes(sample[2]) == bytes(expected[5]) and sample[3] == expected[11]):
                        verified = True
                        break
                if not verified:
                    raise sqlite3.DatabaseError('首次经验写入后回读校验失败')
            self.db.commit()
            if inserted:
                self.first_commit_verified = True
        except Exception:
            self.db.rollback()
            raise
        self.total_transitions += inserted
        self.pending = 0
        self.last_commit = time.monotonic()
        return inserted

    def frame(self, game, step, action, obs, force=False):
        last = self.frame_step.get(game, -10000)
        if not force and step - last < (8 if obs.novelty > 0.9 else 28):
            return False
        if obs.raw is None or len(obs.raw) != W * H * 4:
            return False
        compressed = zlib.compress(obs.raw, 4)
        uid = str(getattr(obs, 'frame_uid', '')) or hashlib.sha256(compressed + str(game).encode() + str(step).encode() + str(action).encode()).hexdigest()
        result = self.db.execute('INSERT INTO keyframes(at,game,step,action,signature,valid,width,height,frame,uid) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(uid) DO NOTHING', (time.time(), canonical_game_key(game), int(step), action, obs.signature, int(obs.valid), W, H, sqlite3.Binary(compressed), uid))
        self.frame_step[game] = step
        if result.rowcount:
            self.frames_saved += 1
            self.pending += 1
        return bool(result.rowcount)

    def recent(self, indices, limit=1000):
        limit = max(1, min(10000, int(limit)))
        columns = 'id,game,action,reward,before,after,priority,done,horizon,confidence,action_detail,feature_version'
        latest = max(1, int(limit * 0.40))
        priority = max(1, int(limit * 0.20))
        rare = max(1, int(limit * 0.12))
        failed = max(1, int(limit * 0.10))
        surprising = max(1, int(limit * 0.10))
        rows = self.db.execute(f'SELECT {columns} FROM transitions ORDER BY id DESC LIMIT ?', (latest,)).fetchall()
        rows.extend(self.db.execute(f'SELECT {columns} FROM transitions ORDER BY priority DESC, id DESC LIMIT ?', (priority,)).fetchall())
        rows.extend(self.db.execute(f'SELECT {columns} FROM transitions WHERE done=1 OR ABS(reward)>=0.24 ORDER BY id DESC LIMIT ?', (rare,)).fetchall())
        rows.extend(self.db.execute(f'SELECT {columns} FROM transitions WHERE signal_kind IN (1,3,5,7) ORDER BY id DESC LIMIT ?', (failed,)).fetchall())
        rows.extend(self.db.execute(f'SELECT {columns} FROM transitions WHERE signal_kind IN (2,3,6,7) ORDER BY id DESC LIMIT ?', (surprising,)).fetchall())
        max_id = int(self.db.execute('SELECT COALESCE(MAX(id),0) FROM transitions').fetchone()[0])
        if max_id:
            for _ in range(min(max(0, limit - latest - priority - rare - failed - surprising), 350)):
                location = random.randint(1, max_id)
                row = self.db.execute(f'SELECT {columns} FROM transitions WHERE id>=? ORDER BY id LIMIT 1', (location,)).fetchone()
                if row is not None:
                    rows.append(row)
        output = []
        seen_ids = set()
        for identifier, game, action, reward, before, after, weight, done, horizon, confidence, detail, version in reversed(rows):
            if identifier in seen_ids or action not in indices:
                continue
            seen_ids.add(identifier)
            try:
                params = json.loads(detail) if detail else {}
                if not isinstance(params, dict):
                    params = {}
                output.append([canonical_game_key(game), self.unpack(before, version), indices[action], float(reward),
                               self.unpack(after, version), max(0.02, float(weight)), bool(done), max(1, int(horizon)),
                               max(0.0, min(1.0, float(confidence))), params])
            except (ValueError, struct.error, TypeError, json.JSONDecodeError):
                continue
        return output

    def mark_terminal_uid(self, uid):
        result = self.db.execute('UPDATE transitions SET done=1 WHERE uid=? AND horizon=1', (uid,))
        self.db.commit()
        self.last_commit = time.monotonic()
        self.pending = 0
        return result.rowcount > 0

    def flush(self):
        if self.pending:
            self.db.commit()
            self.pending = 0
            self.last_commit = time.monotonic()

    def close(self):
        try:
            self.flush()
        finally:
            self.db.close()



class GameData:
    def __init__(self, count, hidden, np_module):
        self.np = np_module
        scale = 0.03 / math.sqrt(hidden)
        if self.np is not None:
            self.q = self.np.asarray([[random.uniform(-scale, scale) for _ in range(hidden)] for _ in range(count)], dtype=self.np.float32)
            self.bias = self.np.zeros(count, dtype=self.np.float32)
        else:
            self.q = [[random.uniform(-scale, scale) for _ in range(hidden)] for _ in range(count)]
            self.bias = [0.0] * count
        self.counts = [0] * count
        self.action_attempts = [0] * count
        self.action_effect = [0.0] * count
        self.action_effect_samples = [0] * count
        self.action_goal = [0.0] * count
        self.action_goal_samples = [0] * count
        self.control_posteriors = [[1.0, 1.0] for _ in range(count)]
        self.control_head = self.np.zeros((count, DUAL_VALUE_FEATURES), dtype=self.np.float32) if self.np is not None else [[0.0] * DUAL_VALUE_FEATURES for _ in range(count)]
        self.objective_head = self.np.zeros((count, DUAL_VALUE_FEATURES), dtype=self.np.float32) if self.np is not None else [[0.0] * DUAL_VALUE_FEATURES for _ in range(count)]
        self.control_head_bias = self.np.zeros(count, dtype=self.np.float32) if self.np is not None else [0.0] * count
        self.objective_head_bias = self.np.zeros(count, dtype=self.np.float32) if self.np is not None else [0.0] * count
        self.control_head_samples = [0] * count
        self.objective_head_samples = [0] * count
        self.phase_votes = OrderedDict()
        self.feedback_latency_by_kind = OrderedDict()
        self.visits = OrderedDict()
        self.scene_centers = OrderedDict()
        self.world = OrderedDict()
        self.world_parameters = OrderedDict()
        self.world_effects = OrderedDict()
        self.passive_world = OrderedDict()
        self.world_events = OrderedDict()
        self.spatial_context_stats = OrderedDict()
        self.duration_context_stats = OrderedDict()
        self.control_profiles = OrderedDict()
        self.hierarchical_controls = OrderedDict()
        self.repeat_effects = OrderedDict()
        self.inverse_dynamics = OrderedDict()
        self.world_condition_errors = OrderedDict()
        self.world_network = None
        self.world_network_steps = 0
        self.world_network_error = 0.13
        self.world_action_samples = [0] * count
        self.world_action_errors = [0.15] * count
        self.world_action_error_variance = [0.02] * count
        self.world_validation_samples = [0] * count
        self.diagnostics = {name: 0 for name in ('feedback_actions', 'effect_verified', 'no_effect_verified', 'objective_evidence', 'low_confidence_learning', 'spatial_anchor_samples', 'world_holdout_evaluations', 'transfer_trials', 'transfer_successes', 'control_head_updates', 'objective_head_updates', 'uncertain_action_feedback', 'event_transition_samples', 'first_effect_action', 'effective_controls', 'repeated_ineffective_controls', 'credible_goal_progress', 'uncertain_goal_events', 'causal_profile_samples', 'temporal_prediction_samples', 'skill_intent_remaps', 'validated_world_plans', 'repeatable_effects', 'inverse_dynamics_updates', 'long_horizon_credits', 'condition_error_updates', 'hierarchical_effect_updates', 'goal_candidate_observations', 'goal_candidate_reversals', 'intent_shared_updates', 'predictive_state_evaluations', 'game_profile_switches', 'skill_purpose_confirmations', 'scene_group_holdout_evaluations', 'passive_world_updates', 'passive_world_holdouts', 'objective_context_checks', 'objective_contradictions', 'objective_duplicate_confirmations', 'active_experiment_families', 'contrastive_visual_updates', 'transfer_multistep_trials', 'transfer_multistep_successes', 'replay_counterexamples', 'plan_action_mismatches')}
        self.transfer_skill_stats = OrderedDict()
        self.prediction_error_mean = 0.11
        self.prediction_error_variance = 0.0009
        self.prediction_error_samples = 0
        self.plan_error_stats = OrderedDict()
        self.goal_value_weights = [random.uniform(-0.003, 0.003) for _ in range(GOAL_VALUE_FEATURES)]
        self.goal_value_bias = 0.0
        self.goal_value_samples = 0
        self.goal_value_error = 0.0
        self.goal_recent = deque(maxlen=160)
        self.goal_proposals = OrderedDict()
        self.intent_values = OrderedDict()
        self.passive_scenes = OrderedDict()
        self.passive_timed = OrderedDict()
        self.passive_motion_profiles = OrderedDict()
        self.context_action = OrderedDict()
        self.action_applicability = OrderedDict()
        self.parameter_baselines = OrderedDict()
        self.ui_history = OrderedDict()
        self.targets = OrderedDict()
        self.candidate_events = OrderedDict()
        self.skills = {}
        self.trajectories = OrderedDict()
        self.recent = deque(maxlen=14)
        self.exemplars = deque(maxlen=48)
        self.game_steps = 0
        self.total_reward = 0.0
        self.baseline_change = 0.0
        self.passive_change = 0.0
        self.passive_samples = 0
        self.stagnation = 0
        self.category_score = {}
        self.family_score = {}
        self.feedback_delay = 0.09
        self.parameter_stats = OrderedDict()
        self.duration_stats = {}
        self.parameter_heads = {}
        self.goal_landmarks = OrderedDict()
        self.hud_trends = OrderedDict()
        self.goal_hypotheses = OrderedDict()
        self.goal_context_support = OrderedDict()
        self.goal_evidence = deque(maxlen=24)
        self.goal_signal_conflict = 0.0
        self.phase_sequence = deque(maxlen=7)
        self.screen_outcomes = {'win': 0, 'loss': 0, 'task': 0}
        self.plan_success = [0, 0]
        self.result_streak = 0
        self.result_label = None
        self.result_scene = None
        self.result_active = False
        self.result_misses = 0
        self.result_appeared = False
        self.result_position = None
        self.numeric_recent = deque(maxlen=64)
        self.confirmed_results = OrderedDict()
        self.focus_recent = deque(maxlen=14)
        self.scene_history = deque(maxlen=18)
        self.target_q = self.q.copy() if self.np is not None else [row[:] for row in self.q]
        self.target_bias = self.bias.copy() if self.np is not None else self.bias[:]

    def ensure_parameter_head(self, kind, hidden):
        if kind not in self.parameter_heads:
            if self.np is not None:
                weights = self.np.zeros((4, hidden), dtype=self.np.float32)
                bias = self.np.zeros(4, dtype=self.np.float32)
            else:
                weights = [[0.0] * hidden for _ in range(4)]
                bias = [0.0] * 4
            self.parameter_heads[kind] = {'w': weights, 'b': bias, 'samples': 0}
        return self.parameter_heads[kind]

    def ensure_world_network(self):
        if self.world_network is None:
            width = WORLD_FEATURE_COUNT + WORLD_ACTION_FEATURES
            scale = 0.12 / math.sqrt(width)
            first = [[random.uniform(-scale, scale) for _ in range(width)] for _ in range(WORLD_NETWORK_HIDDEN)]
            second = [[0.0] * WORLD_NETWORK_HIDDEN for _ in range(WORLD_FEATURE_COUNT + 1)]
            if self.np is not None:
                first = self.np.asarray(first, dtype=self.np.float32)
                second = self.np.asarray(second, dtype=self.np.float32)
                zeros1 = self.np.zeros(WORLD_NETWORK_HIDDEN, dtype=self.np.float32)
                zeros2 = self.np.zeros(WORLD_FEATURE_COUNT + 1, dtype=self.np.float32)
            else:
                zeros1 = [0.0] * WORLD_NETWORK_HIDDEN
                zeros2 = [0.0] * (WORLD_FEATURE_COUNT + 1)
            self.world_network = {'w1': first, 'b1': zeros1, 'w2': second, 'b2': zeros2}
        if 'w1_alt' not in self.world_network or 'b1_alt' not in self.world_network:
            if 'w2_alt' in self.world_network:
                source = self.world_network['w1']
                first = source.copy() if self.np is not None else [row[:] for row in source]
                prior = self.world_network['b1']
                bias = prior.copy() if self.np is not None else prior[:]
            else:
                width = WORLD_FEATURE_COUNT + WORLD_ACTION_FEATURES
                scale = 0.12 / math.sqrt(width)
                first = [[random.uniform(-scale, scale) for _ in range(width)] for _ in range(WORLD_NETWORK_HIDDEN)]
                first = self.np.asarray(first, dtype=self.np.float32) if self.np is not None else first
                bias = self.np.zeros(WORLD_NETWORK_HIDDEN, dtype=self.np.float32) if self.np is not None else [0.0] * WORLD_NETWORK_HIDDEN
            self.world_network['w1_alt'] = first
            self.world_network['b1_alt'] = bias
        if 'w2_alt' not in self.world_network or 'b2_alt' not in self.world_network:
            seed = [[random.uniform(-0.007, 0.007) for _ in range(WORLD_NETWORK_HIDDEN)]
                    for _ in range(WORLD_FEATURE_COUNT + 1)]
            self.world_network['w2_alt'] = self.np.asarray(seed, dtype=self.np.float32) if self.np is not None else seed
            self.world_network['b2_alt'] = self.np.zeros(WORLD_FEATURE_COUNT + 1, dtype=self.np.float32) if self.np is not None else [0.0] * (WORLD_FEATURE_COUNT + 1)
        return self.world_network

    def sync_target(self):
        self.target_q = self.q.copy() if self.np is not None else [row[:] for row in self.q]
        self.target_bias = self.bias.copy() if self.np is not None else self.bias[:]

    def merge(self, other):
        self_steps = self.game_steps
        other_steps = other.game_steps
        for i in range(len(self.counts)):
            self.action_attempts[i] += other.action_attempts[i]
            left, right = self.counts[i], other.counts[i]
            if right > 0:
                if left > 0:
                    blend = right / (left + right)
                    self.q[i] = self.q[i] * (1.0 - blend) + other.q[i] * blend if self.np is not None else [a * (1.0 - blend) + b * blend for a, b in zip(self.q[i], other.q[i])]
                    self.bias[i] = self.bias[i] * (1.0 - blend) + other.bias[i] * blend
                else:
                    self.q[i] = other.q[i].copy() if self.np is not None else other.q[i][:]
                    self.bias[i] = other.bias[i]
                self.counts[i] += right
            left_effect, right_effect = self.action_effect_samples[i], other.action_effect_samples[i]
            if right_effect:
                self.action_effect[i] = (self.action_effect[i] * left_effect + other.action_effect[i] * right_effect) / (left_effect + right_effect)
                self.action_effect_samples[i] += right_effect
            left_goal, right_goal = self.action_goal_samples[i], other.action_goal_samples[i]
            if right_goal:
                self.action_goal[i] = (self.action_goal[i] * left_goal + other.action_goal[i] * right_goal) / (left_goal + right_goal)
                self.action_goal_samples[i] = min(1000000000, left_goal + right_goal)
            for name in ('control', 'objective'):
                samples = getattr(self, name + '_head_samples')
                additional = getattr(other, name + '_head_samples')[i]
                if additional:
                    old = samples[i]
                    fraction = additional / max(1, old + additional)
                    own_head, other_head = getattr(self, name + '_head'), getattr(other, name + '_head')
                    own_bias, other_bias = getattr(self, name + '_head_bias'), getattr(other, name + '_head_bias')
                    if self.np is not None:
                        own_head[i] = own_head[i] * (1.0 - fraction) + other_head[i] * fraction
                    else:
                        own_head[i] = [a * (1.0 - fraction) + b * fraction for a, b in zip(own_head[i], other_head[i])]
                    own_bias[i] = own_bias[i] * (1.0 - fraction) + other_bias[i] * fraction
                    samples[i] = min(1000000000, old + additional)
            mine, incoming = self.control_posteriors[i], other.control_posteriors[i]
            mine[0] = min(1000000.0, mine[0] + max(0.0, incoming[0] - 1.0))
            mine[1] = min(1000000.0, mine[1] + max(0.0, incoming[1] - 1.0))
        for metric in self.diagnostics:
            if metric == 'first_effect_action':
                observed = [value for value in (self.diagnostics[metric], other.diagnostics.get(metric, 0)) if value > 0]
                self.diagnostics[metric] = min(observed) if observed else 0
            else:
                self.diagnostics[metric] += max(0, int(other.diagnostics.get(metric, 0)))
        for name, limit in (('hierarchical_controls', 2800), ('repeat_effects', 5000),
                            ('inverse_dynamics', 120), ('world_condition_errors', 3000)):
            mine, theirs = getattr(self, name), getattr(other, name)
            for key, incoming in theirs.items():
                previous = mine.get(key)
                if previous is None:
                    mine[key] = list(incoming)
                elif name in ('hierarchical_controls', 'repeat_effects') and len(previous) == len(incoming):
                    mine[key] = [min(1000000.0, float(a) + float(b)) for a, b in zip(previous, incoming)]
                elif name == 'inverse_dynamics' and len(previous) == len(incoming) == 4:
                    n, m = max(0, int(previous[0])), max(0, int(incoming[0]))
                    if n + m and len(previous[1]) == len(incoming[1]) == len(INVERSE_WORLD_INDICES):
                        mine[key] = [min(1000000, n + m),
                                     [(a * n + b * m) / (n + m) for a, b in zip(previous[1], incoming[1])],
                                     (float(previous[2]) * n + float(incoming[2]) * m) / (n + m),
                                     min(1000000, int(previous[3]) + int(incoming[3]))]
                elif name == 'world_condition_errors' and len(previous) == len(incoming) == 3:
                    n, m = max(0, int(previous[0])), max(0, int(incoming[0]))
                    if n + m:
                        delta = float(incoming[1]) - float(previous[1])
                        mine[key] = [min(1000000, n + m), float(previous[1]) + delta * m / (n + m),
                                     max(0.00001, (float(previous[2]) * n + float(incoming[2]) * m
                                      + delta * delta * n * m / (n + m)) / (n + m))]
                mine.move_to_end(key)
            while len(mine) > limit:
                mine.popitem(last=False)
        for key, entry in other.transfer_skill_stats.items():
            prior = self.transfer_skill_stats.get(key, [0, 0, 0])
            self.transfer_skill_stats[key] = [min(1000000, int(a) + int(b)) for a, b in zip(prior, entry)]
            self.transfer_skill_stats.move_to_end(key)
        while len(self.transfer_skill_stats) > 800:
            self.transfer_skill_stats.popitem(last=False)
        for key, record in other.world_events.items():
            mine = self.world_events.get(key, [0.0] * 12)
            if isinstance(record, list) and len(record) in (7, 12):
                expanded = record + [0.0] * (12 - len(record))
                mine = mine + [0.0] * (12 - len(mine))
                self.world_events[key] = [min(1000000.0, max(0.0, float(a)) + max(0.0, float(b)))
                                          for a, b in zip(mine, expanded)]
                self.world_events.move_to_end(key)
        while len(self.world_events) > 1800:
            self.world_events.popitem(last=False)
        for name, limit in (('goal_proposals', 240), ('intent_values', 2000)):
            mine, theirs = getattr(self, name), getattr(other, name)
            for key, record in theirs.items():
                if name == 'intent_values':
                    prior = mine.get(key, [0.0, 0.0, 0.0, 0.0])
                    if len(record) == 4:
                        mine[key] = [max(-1000000.0, min(1000000.0, float(a) + float(b))) for a, b in zip(prior, record)]
                elif len(record) == 5:
                    prior = mine.get(key)
                    if prior is None:
                        mine[key] = list(record)
                    else:
                        combined_mask = max(0, int(prior[4])) | max(0, int(record[4]))
                        mine[key] = [min(1000000.0, float(prior[0]) + float(record[0])),
                                     float(combined_mask.bit_count()),
                                     min(1000000.0, float(prior[2]) + float(record[2])),
                                     record[3], combined_mask]
                mine.move_to_end(key)
            while len(mine) > limit:
                mine.popitem(last=False)
        for key, incoming in other.goal_context_support.items():
            own = self.goal_context_support.get(key, [0, 0, 0])
            if isinstance(incoming, list) and len(incoming) == 3:
                self.goal_context_support[key] = [int(own[0]) | int(incoming[0]), int(own[1]) | int(incoming[1]),
                                                  min(1000000, int(own[2]) + int(incoming[2]))]
                self.goal_context_support.move_to_end(key)
        while len(self.goal_context_support) > 320:
            self.goal_context_support.popitem(last=False)
        for key, incoming in other.goal_hypotheses.items():
            own = self.goal_hypotheses.get(key, [0.0, 0.0, 0.0, 0.0])
            self.goal_hypotheses[key] = [min(1000000.0, max(0.0, float(a)) + max(0.0, float(b)))
                                         for a, b in zip(own, incoming)]
            self.goal_hypotheses.move_to_end(key)
        while len(self.goal_hypotheses) > 160:
            self.goal_hypotheses.popitem(last=False)
        for name, limit in (('visits', 15000), ('trajectories', 12000)):
            a, b = getattr(self, name), getattr(other, name)
            for key, value in b.items():
                a[key] = a.get(key, 0) + value
                a.move_to_end(key)
            while len(a) > limit:
                a.popitem(last=False)
        for key, record in other.phase_votes.items():
            current = self.phase_votes.get(key, [0.0] * 4)
            self.phase_votes[key] = [min(10000.0, float(a) + float(b)) for a, b in zip(current, record)]
            self.phase_votes.move_to_end(key)
        while len(self.phase_votes) > 800:
            self.phase_votes.popitem(last=False)
        for kind, record in other.feedback_latency_by_kind.items():
            previous = self.feedback_latency_by_kind.get(kind)
            if previous is None:
                self.feedback_latency_by_kind[kind] = list(record)
            else:
                total = max(1, int(previous[1]) + int(record[1]))
                previous[0] = (previous[0] * previous[1] + record[0] * record[1]) / total
                previous[1] = total
            self.feedback_latency_by_kind.move_to_end(kind)
        while len(self.feedback_latency_by_kind) > 96:
            self.feedback_latency_by_kind.popitem(last=False)
        for name, limit in (('scene_centers', 2400), ('ui_history', 128), ('targets', 720), ('candidate_events', 350), ('goal_landmarks', 800), ('hud_trends', 160), ('parameter_stats', 3200)):
            a, b = getattr(self, name), getattr(other, name)
            for key, value in b.items():
                if key not in a:
                    a[key] = value
                    a.move_to_end(key)
            while len(a) > limit:
                a.popitem(last=False)
        for key, record in other.passive_motion_profiles.items():
            if not isinstance(record, list) or len(record) != 2 or not isinstance(record[0], list) or len(record[0]) != 12:
                continue
            prior = self.passive_motion_profiles.get(key)
            if prior is None:
                self.passive_motion_profiles[key] = [record[0][:], max(1, int(record[1]))]
            else:
                old_count, new_count = max(1, int(prior[1])), max(1, int(record[1]))
                weight = new_count / max(1, old_count + new_count)
                prior[0] = [max(0.0, min(1.0, a * (1.0 - weight) + b * weight)) for a, b in zip(prior[0], record[0])]
                prior[1] = min(1000000, old_count + new_count)
            self.passive_motion_profiles.move_to_end(key)
        while len(self.passive_motion_profiles) > 180:
            self.passive_motion_profiles.popitem(last=False)
        for key, entry in other.world_effects.items():
            if not isinstance(entry, list) or len(entry) != 3:
                continue
            current = self.world_effects.get(key, [1.0, 1.0, 0])
            current = [min(1000000.0, current[0] + max(0.0, entry[0] - 1.0)),
                       min(1000000.0, current[1] + max(0.0, entry[1] - 1.0)),
                       min(1000000, current[2] + max(0, entry[2]))]
            self.world_effects[key] = current
            self.world_effects.move_to_end(key)
        while len(self.world_effects) > 14000:
            self.world_effects.popitem(last=False)
        for name, limit in (('spatial_context_stats', 6500), ('duration_context_stats', 1800)):
            target = getattr(self, name)
            for key, entry in getattr(other, name).items():
                if not isinstance(entry, list) or len(entry) != 4:
                    continue
                old = target.get(key, [0, 0.0, 0.0, 0.0])
                weight = max(0, int(old[0])) + max(0, int(entry[0]))
                target[key] = ([weight] + [(float(old[i]) * max(0, old[0]) + float(entry[i]) * max(0, entry[0])) / weight
                                         for i in range(1, 4)]) if weight else entry[:]
                target.move_to_end(key)
            while len(target) > limit:
                target.popitem(last=False)
        for key, entry in other.control_profiles.items():
            if not isinstance(entry, list) or len(entry) != 6:
                continue
            old = self.control_profiles.get(key, [0.0] * 5 + [0])
            total = max(0, int(old[5])) + max(0, int(entry[5]))
            if total:
                self.control_profiles[key] = [(old[i] * old[5] + entry[i] * entry[5]) / total for i in range(5)] + [total]
                self.control_profiles.move_to_end(key)
        while len(self.control_profiles) > 700:
            self.control_profiles.popitem(last=False)
        for key, record in other.world.items():
            current = self.world.get(key)
            if current is None:
                self.world[key] = [record[0][:], max(1, int(record[1])), float(record[2]),
                                   float(record[3]) if len(record) > 3 else 0.0]
            else:
                left, right = max(1, int(current[1])), max(1, int(record[1]))
                total = left + right
                left_delta, right_delta = current[0], record[0]
                merged = []
                for pos in range(max(len(left_delta), len(right_delta))):
                    if pos < len(left_delta) and pos < len(right_delta):
                        merged.append((left_delta[pos] * left + right_delta[pos] * right) / total)
                    elif pos < len(left_delta):
                        merged.append(left_delta[pos])
                    else:
                        merged.append(right_delta[pos])
                current[:] = [merged, min(1000000000, total),
                              (current[2] * left + record[2] * right) / total,
                              ((current[3] if len(current) > 3 else 0.0) * left
                               + (record[3] if len(record) > 3 else 0.0) * right) / total]
            self.world.move_to_end(key)
        while len(self.world) > 12500:
            self.world.popitem(last=False)
        for key, record in other.context_action.items():
            current = self.context_action.get(key)
            if current is None:
                self.context_action[key] = record[:]
            else:
                left, right = max(1, int(current[0])), max(1, int(record[0]))
                total = left + right
                difference = record[1] - current[1]
                current[:] = [min(10000000, total),
                              current[1] + difference * right / total,
                              min(20.0, current[2] + record[2] + difference * difference * left * right / total)]
            self.context_action.move_to_end(key)
        while len(self.context_action) > 8000:
            self.context_action.popitem(last=False)
        for key, record in other.world_parameters.items():
            current = self.world_parameters.get(key)
            if current is None:
                self.world_parameters[key] = record.copy()
            else:
                left, right = max(1, int(current['count'])), max(1, int(record['count']))
                total = left + right
                for field in ('start_x', 'start_y', 'duration', 'reward'):
                    current[field] = (float(current[field]) * left + float(record[field]) * right) / total
                if right >= left:
                    current['spatial'] = bool(record['spatial'])
                current['count'] = min(10000000, total)
            self.world_parameters.move_to_end(key)
        while len(self.world_parameters) > 4800:
            self.world_parameters.popitem(last=False)
        for name in ('action_applicability', 'parameter_baselines'):
            target = getattr(self, name)
            for key, record in getattr(other, name).items():
                if key in target and len(record) == len(target[key]):
                    previous = target[key]
                    total = max(1, int(previous[0]) + int(record[0]))
                    target[key] = [total] + [(a * previous[0] + b * record[0]) / total for a, b in zip(previous[1:], record[1:])]
                else:
                    target[key] = record[:]
                target.move_to_end(key)
            while len(target) > (8000 if name == 'action_applicability' else 2400):
                target.popitem(last=False)
        for name in ('category_score', 'family_score', 'duration_stats'):
            a = getattr(self, name)
            for key, value in getattr(other, name).items():
                if key in a:
                    total = max(1, a[key][0] + value[0]) if name != 'duration_stats' else max(1, a[key][1] + value[1])
                    if name == 'duration_stats':
                        a[key] = [(a[key][0] * a[key][1] + value[0] * value[1]) / total, total]
                    else:
                        a[key] = [total, (a[key][1] * a[key][0] + value[1] * value[0]) / total]
                else:
                    a[key] = value
        for kind, source in other.parameter_heads.items():
            destination = self.parameter_heads.get(kind)
            if destination is None:
                self.parameter_heads[kind] = {
                    'w': source['w'].copy() if self.np is not None else [row[:] for row in source['w']],
                    'b': source['b'].copy() if self.np is not None else source['b'][:],
                    'samples': int(source.get('samples', 0)),
                }
            else:
                old_count, add_count = int(destination.get('samples', 0)), int(source.get('samples', 0))
                if add_count:
                    factor = add_count / max(1, old_count + add_count)
                    if self.np is not None:
                        destination['w'] = destination['w'] * (1.0 - factor) + source['w'] * factor
                        destination['b'] = destination['b'] * (1.0 - factor) + source['b'] * factor
                    else:
                        destination['w'] = [[a * (1.0 - factor) + b * factor for a, b in zip(row, other_row)] for row, other_row in zip(destination['w'], source['w'])]
                        destination['b'] = [a * (1.0 - factor) + b * factor for a, b in zip(destination['b'], source['b'])]
                    destination['samples'] = old_count + add_count
        for key, value in other.skills.items():
            if key not in self.skills or float(value.get('quality', 0.0)) > float(self.skills[key].get('quality', 0.0)):
                self.skills[key] = value
        for exemplar in other.exemplars:
            sample = exemplar[:]
            sample[0] = canonical_game_key(sample[0])
            self.exemplars.append(sample)
        self.game_steps += other_steps
        self.total_reward += other.total_reward
        weighted = max(1, self_steps + other_steps)
        for name in ('baseline_change', 'passive_change', 'feedback_delay'):
            setattr(self, name, (getattr(self, name) * self_steps + getattr(other, name) * other_steps) / weighted)
        self.passive_samples += other.passive_samples
        for context, incoming in other.passive_world.items():
            if not isinstance(incoming, list) or len(incoming) != 3 or len(incoming[0]) != WORLD_FEATURE_COUNT:
                continue
            current = self.passive_world.get(context)
            if current is None:
                self.passive_world[context] = [incoming[0][:], int(incoming[1]), float(incoming[2])]
            else:
                left, right = max(0, int(current[1])), max(0, int(incoming[1]))
                total = left + right
                if total:
                    gap = sum(abs(a - b) for a, b in zip(current[0], incoming[0])) / WORLD_FEATURE_COUNT
                    current[0] = [(a * left + b * right) / total for a, b in zip(current[0], incoming[0])]
                    current[1] = min(1000000, total)
                    current[2] = min(1.0, (current[2] * left + incoming[2] * right + gap * min(left, right)) / total)
            self.passive_world.move_to_end(context)
        while len(self.passive_world) > 256:
            self.passive_world.popitem(last=False)
        for scene, sample in other.passive_scenes.items():
            current = self.passive_scenes.get(scene)
            if current is None:
                self.passive_scenes[scene] = sample[:]
            else:
                n1, n2 = max(1, int(current[2])), max(1, int(sample[2]))
                difference = sample[0] - current[0]
                total = n1 + n2
                current[:] = [current[0] + difference * n2 / total,
                              current[1] + sample[1] + difference * difference * n1 * n2 / total, total]
            self.passive_scenes.move_to_end(scene)
        while len(self.passive_scenes) > 180:
            self.passive_scenes.popitem(last=False)
        for label, record in other.passive_timed.items():
            if not isinstance(record, list) or len(record) != 4:
                continue
            current = self.passive_timed.get(label)
            if current is None:
                self.passive_timed[label] = record[:]
            else:
                n, m = max(0, int(current[2])), max(0, int(record[2]))
                total = n + m
                if total:
                    deviation = float(record[0]) - float(current[0])
                    current[:] = [current[0] + deviation * m / total,
                                  (current[1] * n + record[1] * m + deviation * deviation * n * m / total) / total,
                                  min(1000000, total),
                                  (current[3] * n + record[3] * m) / total]
            self.passive_timed.move_to_end(label)
        while len(self.passive_timed) > 300:
            self.passive_timed.popitem(last=False)
        previous_steps, incoming_steps = self.world_network_steps, other.world_network_steps
        if other.world_network is not None and incoming_steps:
            other.ensure_world_network()
            if self.world_network is None:
                self.world_network = {key: value.copy() if self.np is not None else [row[:] if isinstance(row, list) else row for row in value] for key, value in other.world_network.items()}
            else:
                self.ensure_world_network()
                ratio = incoming_steps / max(1, previous_steps + incoming_steps)
                for name in self.world_network:
                    left, right = self.world_network[name], other.world_network[name]
                    if self.np is not None:
                        self.world_network[name] = left * (1 - ratio) + right * ratio
                    elif isinstance(left[0], list):
                        self.world_network[name] = [[a * (1 - ratio) + b * ratio for a, b in zip(x, y)] for x, y in zip(left, right)]
                    else:
                        self.world_network[name] = [a * (1 - ratio) + b * ratio for a, b in zip(left, right)]
            self.world_network_steps = previous_steps + incoming_steps
            self.world_network_error = (self.world_network_error * previous_steps + other.world_network_error * incoming_steps) / max(1, self.world_network_steps)
        for i, n in enumerate(other.world_action_samples):
            prior = self.world_action_samples[i]
            previous_validation = self.world_validation_samples[i]
            incoming_validation = other.world_validation_samples[i]
            if incoming_validation:
                total = previous_validation + incoming_validation
                difference = other.world_action_errors[i] - self.world_action_errors[i]
                self.world_action_errors[i] += difference * incoming_validation / total
                self.world_action_error_variance[i] = max(0.00001, (
                    self.world_action_error_variance[i] * previous_validation
                    + other.world_action_error_variance[i] * incoming_validation
                    + difference * difference * previous_validation * incoming_validation / total) / total)
                self.world_validation_samples[i] = min(100000000, total)
            self.world_action_samples[i] = prior + n
        if other.prediction_error_samples:
            n1, n2 = self.prediction_error_samples, other.prediction_error_samples
            total = n1 + n2
            distance = other.prediction_error_mean - self.prediction_error_mean
            self.prediction_error_mean += distance * n2 / total
            self.prediction_error_variance = max(0.0, (self.prediction_error_variance * n1 + other.prediction_error_variance * n2 + distance * distance * n1 * n2 / total) / total)
            self.prediction_error_samples = total
        self.stagnation = min(self.stagnation, other.stagnation)
        self.plan_success = [a + b for a, b in zip(self.plan_success, other.plan_success)]
        for outcome in self.screen_outcomes:
            self.screen_outcomes[outcome] += other.screen_outcomes.get(outcome, 0)
        for key, result in other.confirmed_results.items():
            self.confirmed_results[key] = result
        while len(self.confirmed_results) > 96:
            self.confirmed_results.popitem(last=False)
        for label, entries in other.plan_error_stats.items():
            old = self.plan_error_stats.get(label)
            if old is None:
                self.plan_error_stats[label] = entries[:]
            else:
                left, right = max(0, int(old[0])), max(0, int(entries[0]))
                if right:
                    total = left + right
                    difference = entries[1] - old[1]
                    self.plan_error_stats[label] = [total, old[1] + difference * right / total,
                        max(0.0, (left * old[2] + right * entries[2] + difference * difference * left * right / total) / total)]
            self.plan_error_stats.move_to_end(label)
        while len(self.plan_error_stats) > 1200:
            self.plan_error_stats.popitem(last=False)
        a, b = max(0, self.goal_value_samples), max(0, other.goal_value_samples)
        if b:
            rate = b / max(1, a + b)
            self.goal_value_weights = [left * (1.0 - rate) + right * rate for left, right in zip(self.goal_value_weights, other.goal_value_weights)]
            self.goal_value_bias = self.goal_value_bias * (1.0 - rate) + other.goal_value_bias * rate
            self.goal_value_error = self.goal_value_error * (1.0 - rate) + other.goal_value_error * rate
            self.goal_value_samples = a + b
        self.sync_target()

    def export(self):
        return {
            'q': self.q.tolist() if self.np is not None else self.q,
            'bias': self.bias.tolist() if self.np is not None else self.bias,
            'counts': self.counts,
            'action_attempts': self.action_attempts,
            'action_effect': self.action_effect,
            'action_effect_samples': self.action_effect_samples,
            'action_goal': self.action_goal,
            'action_goal_samples': self.action_goal_samples,
            'control_posteriors': self.control_posteriors,
            'control_head': self.control_head.tolist() if self.np is not None else self.control_head,
            'objective_head': self.objective_head.tolist() if self.np is not None else self.objective_head,
            'control_head_bias': self.control_head_bias.tolist() if self.np is not None else self.control_head_bias,
            'objective_head_bias': self.objective_head_bias.tolist() if self.np is not None else self.objective_head_bias,
            'control_head_samples': self.control_head_samples,
            'objective_head_samples': self.objective_head_samples,
            'phase_votes': list(self.phase_votes.items())[-800:],
            'feedback_latency_by_kind': list(self.feedback_latency_by_kind.items())[-96:],
            'visits': list(self.visits.items()),
            'scene_centers': list(self.scene_centers.items()),
            'world': {str(k): v for k, v in self.world.items()},
            'world_parameters': list(self.world_parameters.items())[-4800:],
            'world_effects': list(self.world_effects.items())[-14000:],
            'passive_world': list(self.passive_world.items())[-256:],
            'world_events': list(self.world_events.items())[-1800:],
            'spatial_context_stats': list(self.spatial_context_stats.items())[-6500:],
            'duration_context_stats': list(self.duration_context_stats.items())[-1800:],
            'control_profiles': list(self.control_profiles.items())[-700:],
            'hierarchical_controls': list(self.hierarchical_controls.items())[-2800:],
            'repeat_effects': list(self.repeat_effects.items())[-5000:],
            'inverse_dynamics': list(self.inverse_dynamics.items())[-120:],
            'world_condition_errors': list(self.world_condition_errors.items())[-3000:],
            'world_network': ({name: value.tolist() if self.np is not None else value for name, value in self.world_network.items()} if self.world_network is not None else None),
            'world_network_steps': self.world_network_steps,
            'world_network_error': self.world_network_error,
            'world_action_samples': self.world_action_samples,
            'world_action_errors': self.world_action_errors,
            'world_action_error_variance': self.world_action_error_variance,
            'world_validation_samples': self.world_validation_samples,
            'diagnostics': self.diagnostics,
            'transfer_skill_stats': list(self.transfer_skill_stats.items())[-800:],
            'prediction_error_mean': self.prediction_error_mean,
            'prediction_error_variance': self.prediction_error_variance,
            'prediction_error_samples': self.prediction_error_samples,
            'plan_error_stats': list(self.plan_error_stats.items())[-1200:],
            'goal_value_weights': self.goal_value_weights,
            'goal_value_bias': self.goal_value_bias,
            'goal_value_samples': self.goal_value_samples,
            'goal_value_error': self.goal_value_error,
            'passive_scenes': list(self.passive_scenes.items())[-180:],
            'passive_timed': list(self.passive_timed.items())[-300:],
            'passive_motion_profiles': list(self.passive_motion_profiles.items())[-180:],
            'context_action': list(self.context_action.items())[-8000:],
            'action_applicability': list(self.action_applicability.items())[-8000:],
            'parameter_baselines': list(self.parameter_baselines.items())[-2400:],
            'ui_history': list(self.ui_history.items())[-128:],
            'targets': dict(self.targets),
            'candidate_events': dict(self.candidate_events),
            'skills': self.skills,
            'exemplars': list(self.exemplars),
            'trajectories': list(self.trajectories.items())[-5000:],
            'game_steps': self.game_steps,
            'total_reward': self.total_reward,
            'baseline_change': self.baseline_change,
            'passive_change': self.passive_change,
            'passive_samples': self.passive_samples,
            'stagnation': self.stagnation,
            'category_score': self.category_score,
            'family_score': self.family_score,
            'feedback_delay': self.feedback_delay,
            'parameter_stats': list(self.parameter_stats.items()),
            'duration_stats': self.duration_stats,
            'parameter_heads': {kind: {'w': head['w'].tolist() if self.np is not None else head['w'],
                                       'b': head['b'].tolist() if self.np is not None else head['b'],
                                       'samples': head['samples']} for kind, head in self.parameter_heads.items()},
            'goal_landmarks': list(self.goal_landmarks.items())[-800:],
            'hud_trends': list(self.hud_trends.items())[-160:],
            'goal_hypotheses': list(self.goal_hypotheses.items())[-160:],
            'goal_context_support': list(self.goal_context_support.items())[-320:],
            'goal_proposals': list(self.goal_proposals.items())[-240:],
            'intent_values': list(self.intent_values.items())[-2000:],
            'plan_success': self.plan_success,
            'screen_outcomes': self.screen_outcomes,
            'confirmed_results': list(self.confirmed_results.items())[-96:],
            'result_active': self.result_active,
        }


class Brain:

    def __init__(self, folder, stop_vk, numpy_module):
        self.folder = folder
        self.stop_vk = stop_vk
        self.np = numpy_module
        self.cv_np = importlib.import_module('numpy') if numpy_module is not None and getattr(numpy_module, '__name__', '') == 'cupy' else numpy_module
        self.actions = actions_for(stop_vk)
        try:
            self.local_glyphs = LocalGlyphTemplates()
        except Exception:
            self.local_glyphs = None
        self.action_index = {a.id: i for i, a in enumerate(self.actions)}
        self.priors = [a.prior for a in self.actions]
        self.action_groups = {}
        self.action_families = {}
        self.action_kinds = {}
        self.family_for_action = []
        for i, action in enumerate(self.actions):
            self.action_groups.setdefault(action.category, []).append(i)
            family = ('keyboard' if action.kind in ('key', 'hold', 'pair_hold', 'chord') else
                      'pointer' if action.kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'touch_tap') else
                      'navigation' if action.kind in ('move', 'swipe', 'right_swipe', 'look', 'wheel', 'touch_swipe', 'pinch', 'dual_touch') else 'combat')
            self.family_for_action.append(family)
            self.action_families.setdefault(family, []).append(i)
            self.action_kinds.setdefault((family, action.kind), []).append(i)
        self.probe_representatives = {self.action_index[item] for item in
            ('key:87', 'key:83', 'key:65', 'key:68', 'key:38', 'key:40', 'key:37', 'key:39',
             'key:32', 'key:13', 'key:69', 'key:70', 'key:82', 'key:27', 'hold:87',
             'hold:83', 'hold:65', 'hold:68', 'click', 'right', 'focus_click',
             'touch_tap', 'move', 'swipe:-1:0', 'swipe:1:0', 'wheel:1')
            if item in self.action_index}
        self.action_kinds_for_parameter = {action.kind for action in self.actions}
        self.action_parameter_keys = {self.parameter_head_key(action) for action in self.actions}
        self.action_intents = [self.action_intent(action) for action in self.actions]
        self.intent_actions = {}
        for index, intent in enumerate(self.action_intents):
            self.intent_actions.setdefault(intent, []).append(index)
        self.experiment_relatives = []
        movement_equivalents = ({87, 38}, {83, 40}, {65, 37}, {68, 39})
        pointer_equivalents = ({'click', 'focus_click', 'touch_tap'}, {'right', 'focus_right'}, {'double', 'focus_double'})
        for i, candidate in enumerate(self.actions):
            related = []
            for j, alternative in enumerate(self.actions):
                if i == j:
                    continue
                if ((candidate.kind in ('key', 'hold') and alternative.kind in ('key', 'hold')
                     and any(candidate.a in pair and alternative.a in pair for pair in movement_equivalents))
                    or (candidate.a == alternative.a and candidate.a and {candidate.kind, alternative.kind} == {'key', 'hold'})
                    or (any(candidate.kind in group and alternative.kind in group for group in pointer_equivalents))):
                    related.append(j)
            self.experiment_relatives.append(related[:16])
        self.action_neighbors = []
        for i, item in enumerate(self.actions):
            candidates = []
            for j, other in enumerate(self.actions):
                if i == j or self.family_for_action[i] != self.family_for_action[j]:
                    continue
                if item.kind == other.kind and (item.a, item.b) == (other.a, other.b):
                    similarity = 0.72
                elif {item.kind, other.kind} == {'key', 'hold'} and item.a == other.a and item.b == other.b:
                    similarity = 0.57
                elif ((item.kind, other.kind) in (('click', 'focus_click'), ('focus_click', 'click'),
                                                      ('right', 'focus_right'), ('focus_right', 'right'),
                                                      ('double', 'focus_double'), ('focus_double', 'double'))):
                    similarity = 0.41
                else:
                    continue
                candidates.append((similarity, j))
            candidates.sort(reverse=True)
            top = candidates[:5]
            scale = sum(weight for weight, _ in top) or 1.0
            self.action_neighbors.append([(j, weight / scale) for weight, j in top])
        self.hidden_size = MODEL_HIDDEN_SIZE
        self.rng = random.Random()
        self.encoder = [[self.rng.uniform(-0.035, 0.035) for _ in range(FEATURE_COUNT)] for _ in range(self.hidden_size)]
        self.encoder_bias = [0.0] * self.hidden_size
        self.decoder = [[self.rng.uniform(-0.008, 0.008) for _ in range(self.hidden_size)] for _ in RECONSTRUCTION_INDICES]
        self.decoder_bias = [0.0] * len(RECONSTRUCTION_INDICES)
        if self.np is not None:
            self.encoder = self.np.asarray(self.encoder, dtype=self.np.float32)
            self.encoder_bias = self.np.zeros(self.hidden_size, dtype=self.np.float32)
            self.decoder = self.np.asarray(self.decoder, dtype=self.np.float32)
            self.decoder_bias = self.np.zeros(len(RECONSTRUCTION_INDICES), dtype=self.np.float32)
        self.target_encoder = None
        self.target_encoder_bias = None
        self.games = {}
        self.game_key = 'desktop'
        self.last_skill_source = None
        self.last_transfer_key = None
        self.last_skill_reference = None
        self.last_plan_parameters = []
        self.last_plan_predictions = []
        self.outcome_trace = deque(maxlen=LONG_GOAL_HORIZON)
        self.visual_routes = {}
        self.visual_active_base = None
        self.visual_active_key = None
        self.visual_candidate = None
        self.visual_candidate_vector = None
        self.visual_candidate_count = 0
        self.visual_candidate_diversity = 0
        self.last_attention_tracks = []
        self.visual_tracks = OrderedDict()
        self.control_scores = OrderedDict()
        self.next_track_id = 1
        self.previous_lum = None
        self.previous_motion = None
        self.track_last_time = None
        self.temporal_luma = deque(maxlen=4)
        self.temporal_observations = deque(maxlen=5)
        self.belief_history = deque(maxlen=7)
        self.last_change = 0.0
        self.last_frame = None
        self.last_detail = [0.0] * 20
        self.last_detail_focus = (0.5, 0.5)
        self.last_detail_location = (0.5, 0.5)
        self.last_detail_step = None
        self.detail_focus_visits = [0] * 15
        self.adaptive_glyphs = {}
        self.glyph_votes = OrderedDict()
        self.checkpoint_verified = False
        self.checkpoint_migrated = False
        self.checkpoint_serial = 0
        self.last_checkpoint_summary = {}
        self.checkpoint_compressed_bytes = 0
        self.delta_base_step = None
        self.dirty_games = set()
        self.dirty_sequence = 0
        self.store_roundtrip_verified = False
        self.db_preflight_verified = False
        self.step = 0
        self.backend_generation = 0
        self.backend_recoveries = 0
        self.updates = 0
        self.td_error_ema = 0.0
        self.total_reward = 0.0
        self.last_save = 0.0
        self.keyframes_this_session = 0
        self.valid_transitions = 0
        self.low_information_observations = 0
        self.invalid_observations = 0
        self.persisted_transitions = 0
        self.dropped_unpersisted = 0
        self.spilled_transitions = 0
        self.spool_recovered = 0
        self.journaled_transitions = 0
        self.journal_failures = 0
        self.journal_unwritten = OrderedDict()
        self.spool_path = self.folder / 'experience_overflow.jsonl'
        self.persist_backlog = deque()
        self.frame_backlog = deque()
        self.terminal_updates = deque()
        self.initial_frames = OrderedDict()
        self.initial_frame_games = set()
        self.persist_last_batch = time.monotonic()
        self.store_reconnect_at = 0.0
        self.store_failures = 0
        self.db_transitions_last_known = 0
        self.nstep_generated = 0
        self.reward_info = {}
        self.lock = threading.RLock()
        self.storage_condition = threading.Condition(self.lock)
        self.storage_stop = threading.Event()
        self.storage_force = False
        self.checkpoint_sequence = 0
        self.keyframes_skipped = 0
        self.checkpoint_requested = False
        self.storage_problem = None
        self.storage_failures = 0
        self.spool_lock = threading.Lock()
        self.training_condition = threading.Condition(self.lock)
        self.training_stop = threading.Event()
        self.training_queue = deque(maxlen=4096)
        self.pending_n = deque()
        self.training_problem = None
        self.training_failures = 0
        self.training_last_tick = time.monotonic()
        self.storage_last_tick = time.monotonic()
        self.vision_cost_ema = 0.0
        self.training_cost_ema = 0.0
        self.training_retried = 0
        self.training_stale_batches = 0
        self.training_queue_evictions = 0
        self.terminal_credit_samples = 0
        self.memory = deque(maxlen=16000 if self.np is not None else 3500)
        self.rare_memory = deque(maxlen=800 if self.np is not None else 250)
        self.control_memory = deque(maxlen=640 if self.np is not None else 160)
        self.failure_memory = deque(maxlen=640 if self.np is not None else 160)
        self.surprise_memory = deque(maxlen=700 if self.np is not None else 180)
        self.goal_memory = deque(maxlen=680 if self.np is not None else 170)
        self.store = None
        self.store_problem = None
        self.restore()
        self.set_game('desktop')
        self.sync_target()
        self._connect_store()
        if self.store is not None:
            try:
                for _ in range(8):
                    if not self.spool_path.exists() or not self.spool_path.stat().st_size:
                        break
                    self._drain_spool()
                self.memory.extend(self.store.recent(self.action_index, limit=3500 if self.np is not None else 900))
                for transition in self.memory:
                    if self.rare_transition(transition):
                        self.rare_memory.append(transition)
                    if self.control_transition(transition):
                        self.control_memory.append(transition)
                    if self.failure_transition(transition):
                        self.failure_memory.append(transition)
                    if self.surprise_transition(transition):
                        self.surprise_memory.append(transition)
                    if self.goal_transition(transition):
                        self.goal_memory.append(transition)
                for transition in list(self.memory)[-min(96, len(self.memory)):]:
                    self.training_queue.append(transition)
            except Exception as exc:
                self._store_failure(exc)
            finally:
                if self.store is not None:
                    self.store.close()
                    self.store = None
        self.storage_thread = threading.Thread(target=self.storage_loop, name='AgentStorage', daemon=True)
        self.storage_thread.start()
        self.trainer = threading.Thread(target=self.training_loop, name='AgentLearner', daemon=True)
        self.trainer.start()

    def hierarchical_control_prediction(self, game, obs, index):
        family = self.family_for_action[index]
        kind = self.actions[index].kind
        context = self.experiment_context(obs)
        keys = ((context + ':f:' + family, 0.33), (context + ':k:' + kind, 0.43),
                ('f:' + family, 0.14), ('k:' + family + ':' + kind, 0.10))
        estimate, weight, strength = 0.0, 0.0, 0.0
        for key, importance in keys:
            record = game.hierarchical_controls.get(key)
            if record is None or record[2] < 2:
                continue
            evidence = max(0.0, float(record[0]) + float(record[1]) - 2.0)
            trust = evidence / (evidence + (6.0 if key.startswith('c:') else 20.0))
            score = max(0.0, min(1.0, float(record[0]) / max(2.0, float(record[0]) + float(record[1]))))
            estimate += importance * trust * score
            weight += importance * trust
            strength += importance * trust
        return ((estimate + max(0.0, 1.0 - weight) * 0.5) / max(1.0, weight),
                min(1.0, strength))

    @staticmethod
    def inverse_delta(before, after):
        first = Brain.world_state(before)
        second = Brain.world_state(after)
        return [max(-1.0, min(1.0, (float(second[i]) - float(first[i])) * 6.0))
                for i in INVERSE_WORLD_INDICES]

    def learn_inverse_dynamics(self, game, before, after, index, confidence):
        if confidence < 0.35:
            return None
        signal = self.inverse_delta(before, after)
        if not all(math.isfinite(value) for value in signal) or sum(abs(v) for v in signal) < 0.04:
            return None
        intent = self.action_intents[index]
        candidates = [(key, record) for key, record in game.inverse_dynamics.items()
                      if record[0] >= 3 and len(record[1]) == len(signal)]
        guess = min(candidates, key=lambda pair: sum((a - b) ** 2 for a, b in zip(pair[1][1], signal))) if candidates else None
        record = game.inverse_dynamics.get(intent)
        if record is None:
            record = [0, [0.0] * len(signal), 0.15, 0]
        n = min(1000000, int(record[0]) + 1)
        residual = sum((a - b) ** 2 for a, b in zip(record[1], signal)) / len(signal)
        rate = min(0.17, max(0.015, confidence / (n + 2.0)))
        record[1] = [max(-1.0, min(1.0, old + rate * (new - old))) for old, new in zip(record[1], signal)]
        record[2] = max(0.0, min(1.0, (1.0 - rate) * record[2] + rate * residual))
        record[0] = n
        if guess is not None and guess[0] == intent:
            record[3] = min(1000000, int(record[3]) + 1)
        game.inverse_dynamics[intent] = record
        game.inverse_dynamics.move_to_end(intent)
        while len(game.inverse_dynamics) > 120:
            game.inverse_dynamics.popitem(last=False)
        game.diagnostics['inverse_dynamics_updates'] += 1
        return residual

    def inverse_intent_confidence(self, game, index):
        record = game.inverse_dynamics.get(self.action_intents[index])
        if record is None or record[0] < 4:
            intent = self.action_intents[index]
            if intent not in ('move_up', 'move_down', 'move_left', 'move_right', 'primary_select',
                              'double_select', 'pointer_navigation', 'zoom_or_scroll', 'confirm'):
                return 0.0
            examples = [other.inverse_dynamics[intent] for other in self.games.values()
                        if other is not game and intent in other.inverse_dynamics
                        and other.inverse_dynamics[intent][0] >= 12
                        and other.inverse_dynamics[intent][2] < 0.15]
            if not examples:
                return 0.0
            return min(0.12, 0.025 * sum(min(1.0, item[0] / 32.0)
                                         * (1.0 - min(1.0, item[2] * 5.0)) for item in examples))
        distinct = max(1, len(game.inverse_dynamics))
        trust = min(1.0, record[0] / 20.0) / (1.0 + 6.0 * max(0.0, record[2]))
        return trust * (0.55 if distinct < 2 else 0.65 + 0.35 * min(1.0, record[3] / max(1, record[0] - 3)))

    @staticmethod
    def action_intent(action):
        if action.kind in ('key', 'hold', 'pair_hold', 'chord'):
            movement = {87: 'move_up', 38: 'move_up', 83: 'move_down', 40: 'move_down',
                        65: 'move_left', 37: 'move_left', 68: 'move_right', 39: 'move_right'}
            if action.kind in ('key', 'hold') and action.a in movement:
                return movement[action.a]
            if action.kind in ('key', 'hold') and action.a in (13, 32):
                return 'confirm_or_jump' if action.a == 32 else 'confirm'
            if action.kind in ('key', 'hold') and action.a in (69, 70, 82):
                return 'interact'
            return 'keyboard:' + action.kind + ':' + str(action.a) + ':' + str(action.b)
        if action.kind in ('click', 'focus_click', 'touch_tap'):
            return 'primary_select'
        if action.kind in ('double', 'focus_double'):
            return 'double_select'
        if action.kind in ('right', 'focus_right'):
            return 'secondary_select'
        if action.kind in ('move', 'swipe', 'right_swipe', 'touch_swipe'):
            return 'pointer_navigation'
        if action.kind in ('wheel', 'pinch', 'dual_touch'):
            return 'zoom_or_scroll'
        if action.kind in ('look', 'aim'):
            return 'aim_or_look'
        if action.kind == 'combat':
            return 'combat'
        return action.kind

    def remap_skill_intent(self, game, obs, index):
        intent = self.action_intents[index]
        options = self.intent_actions.get(intent, [index])
        if len(options) < 2:
            return index
        state_key = self.experiment_context(obs)
        def estimate(candidate):
            alpha, beta = game.control_posteriors[candidate]
            total = max(0.0, alpha + beta - 2.0)
            local = game.action_applicability.get(state_key + ':' + str(candidate))
            attempts = float(local[0]) if local else 0.0
            local_effect = (max(0.0, min(1.0, float(local[1]))) * (1.0 - max(0.0, min(1.0, float(local[3]))))) if local else 0.5
            probability = max(0.0, (alpha - 1.0) / total) if total >= 1.0 else 0.5
            trust = min(1.0, (total + attempts) / 8.0)
            return trust * (0.60 * probability + 0.40 * local_effect) + (1.0 - trust) * 0.42, trust
        original, original_trust = estimate(index)
        winner = max(options, key=lambda candidate: estimate(candidate)[0])
        better, better_trust = estimate(winner)
        if winner != index and better_trust >= 0.34 and better > original + (0.07 if original_trust < 0.15 else 0.12):
            game.diagnostics['skill_intent_remaps'] += 1
            return winner
        return index

    @property
    def game(self):
        return self.games[self.game_key]

    @property
    def stagnation(self):
        return self.game.stagnation

    @property
    def visits(self):
        return self.game.visits


    def set_game(self, key):
        key = canonical_game_key(key)
        with self.lock:
            if key not in self.games:
                self.games[key] = GameData(len(self.actions), self.hidden_size, self.np)
                self.dirty_games.add(key)
                self.dirty_sequence += 1
            if self.game_key != key:
                self.flush_pending(done=False)
                self.previous_lum = None
                self.previous_motion = None
                self.track_last_time = None
                self.temporal_luma.clear()
                self.temporal_observations.clear()
                self.last_change = 0.0
                self.last_detail = [0.0] * 20
                self.last_detail_focus = (0.5, 0.5)
                self.last_detail_location = (0.5, 0.5)
                self.last_detail_step = None
                self.last_attention_tracks = []
                self.visual_tracks.clear()
                self.control_scores.clear()
                self.outcome_trace.clear()
            self.game_key = key
            self.last_skill_source = None
            self.last_transfer_key = None
            self.last_skill_reference = None
            self.last_plan_parameters = []
            self.last_plan_predictions = []
            self.belief_history.clear()

    @staticmethod
    def regional_rgb_motion(before, after):
        if len(before) != GW * GH or len(after) != GW * GH:
            return [0.0] * 12
        regions = []
        for gy in range(3):
            for gx in range(4):
                indices = (row * GW + col for row in range(gy * 4, (gy + 1) * 4)
                           for col in range(gx * 5, (gx + 1) * 5))
                regions.append(sum(sum(abs(before[i][k] - after[i][k]) for k in range(3))
                                   for i in indices) / (60.0 * 255.0))
        return regions

    def record_passive_change(self, before, after, observation=None, elapsed_seconds=0.06):
        pixels_a = self.rgb_blocks(before)
        pixels_b = self.rgb_blocks(after)
        difference = sum(abs(a[k] - b[k]) for a, b in zip(pixels_a, pixels_b) for k in range(3)) / (GW * GH * 3 * 255.0)
        region_motion = self.regional_rgb_motion(pixels_a, pixels_b)
        elapsed = max(0.012, min(4.0, float(elapsed_seconds)))
        with self.lock:
            game = self.game
            rate = min(0.17, 1.0 / (game.passive_samples + 1))
            game.passive_change = game.passive_change * (1.0 - rate) + rate * difference
            game.passive_samples += 1
            keys = [game.scene_history[-1] if game.scene_history else 'default']
            if observation is not None and observation.game == self.game_key:
                keys.append('context:' + self.experiment_context(observation))
            duration_band = 'short' if elapsed < 0.12 else 'medium' if elapsed < 0.42 else 'long'
            for context in keys:
                label = context + ':time:' + duration_band
                rate_value = min(5.0, difference / elapsed)
                current = game.passive_timed.get(label, [0.0, 0.0, 0, 0.0])
                total = min(1000000, int(current[2]) + 1)
                gain = min(0.12, 1.0 / total)
                deviation = rate_value - current[0]
                current[0] += gain * deviation
                current[1] = max(0.0, (1.0 - gain) * current[1] + gain * deviation * deviation)
                current[2] = total
                current[3] += gain * (elapsed - current[3])
                game.passive_timed[label] = current
                game.passive_timed.move_to_end(label)
            while len(game.passive_timed) > 300:
                game.passive_timed.popitem(last=False)
            for scene in dict.fromkeys(keys):
                sample = game.passive_scenes.get(scene)
                if sample is None:
                    sample = [difference, 0.0, 1]
                else:
                    n = min(100000, int(sample[2]) + 1)
                    deviation = difference - sample[0]
                    mean = sample[0] + deviation / n
                    sample = [mean, max(0.0, sample[1] + deviation * (difference - mean)), n]
                game.passive_scenes[scene] = sample
                game.passive_scenes.move_to_end(scene)
                regional = game.passive_motion_profiles.get(scene)
                if regional is None:
                    game.passive_motion_profiles[scene] = [region_motion[:], 1]
                else:
                    n = min(1000000, int(regional[1]) + 1)
                    rate_regional = min(0.20, 1.0 / n)
                    regional[0] = [a * (1.0 - rate_regional) + b * rate_regional
                                   for a, b in zip(regional[0], region_motion)]
                    regional[1] = n
                game.passive_motion_profiles.move_to_end(scene)
                game.diagnostics['temporal_prediction_samples'] += 1
            while len(game.passive_motion_profiles) > 180:
                game.passive_motion_profiles.popitem(last=False)
            while len(game.passive_scenes) > 180:
                game.passive_scenes.popitem(last=False)
            self.dirty_games.add(self.game_key)
            self.dirty_sequence += 1
        return difference

    def identify_game(self, base_key, raw):
        base = str(base_key or 'desktop')[:35]
        rgb = self.rgb_blocks(raw)
        vector = []
        for row in range(4):
            for col in range(4):
                cells = [rgb[r * GW + c] for r in range(row * 3, row * 3 + 3) for c in range(col * 5, col * 5 + 5)]
                vector.extend(sum(pixel[channel] for pixel in cells) / (255.0 * len(cells)) for channel in range(3))
                values = [luminance_bgr(*pixel) for pixel in cells]
                vector.append(sum(abs(values[k] - values[k - 1]) for k in range(1, len(values))) / max(1, len(values) - 1))
        def distance(a, b):
            return sum(abs(x - y) for x, y in zip(a, b)) / 64.0
        with self.lock:
            profiles = self.visual_routes.setdefault(base, [])
            if self.visual_active_base != base:
                self.visual_active_base = base
                self.visual_active_key = base
                self.visual_candidate = None
                self.visual_candidate_vector = None
                self.visual_candidate_count = 0
                self.visual_candidate_diversity = 0
            if not profiles:
                profiles.append({'key': base, 'anchors': [vector], 'samples': 1})
                self.visual_active_key = base
                self.dirty_sequence += 1
                return base
            current = next((item for item in profiles if item['key'] == self.visual_active_key), None)
            best = min(profiles, key=lambda item: min(distance(vector, anchor) for anchor in item['anchors']))
            best_distance = min(distance(vector, anchor) for anchor in best['anchors'])
            current_distance = min(distance(vector, anchor) for anchor in current['anchors']) if current is not None else 1.0
            if current is not None and current_distance < 0.16:
                current['samples'] = min(1000000000, int(current.get('samples', 1)) + 1)
                if current_distance > 0.045 and current['samples'] % 17 == 0:
                    if len(current['anchors']) >= 24:
                        current['anchors'].pop(1)
                    current['anchors'].append(vector)
                self.visual_candidate = None
                self.visual_candidate_vector = None
                self.visual_candidate_count = 0
                self.visual_candidate_diversity = 0
            else:
                proposed = best['key'] if best_distance < 0.12 else 'new_profile'
                gap = distance(vector, self.visual_candidate_vector) if self.visual_candidate_vector is not None else 1.0
                if proposed == self.visual_candidate and gap < 0.16:
                    self.visual_candidate_count += 1
                    if gap > 0.012:
                        self.visual_candidate_diversity += 1
                else:
                    self.visual_candidate = proposed
                    self.visual_candidate_count = 1
                    self.visual_candidate_diversity = 0
                self.visual_candidate_vector = vector
                if proposed != 'new_profile' and self.visual_candidate_count >= 10:
                    self.visual_active_key = proposed
                    self.game.diagnostics['game_profile_switches'] += 1
                    self.visual_candidate = None
                    self.visual_candidate_count = 0
                elif (proposed == 'new_profile' and self.visual_candidate_count >= 48
                      and self.visual_candidate_diversity >= 3 and len(profiles) < 12
                      and self.game.game_steps >= 48 and self.visual_candidate_vector is not None):
                    existing = {item['key'] for item in profiles}
                    suffix = 1
                    while f'{base}~g{suffix}' in existing:
                        suffix += 1
                    key = f'{base}~g{suffix}'
                    profiles.append({'key': key, 'anchors': [vector], 'samples': 1})
                    self.visual_active_key = key
                    self.game.diagnostics['game_profile_switches'] += 1
                    self.visual_candidate = None
                    self.visual_candidate_count = 0
                    self.visual_candidate_diversity = 0
                    self.dirty_sequence += 1
            return self.visual_active_key if self.visual_active_key in {item['key'] for item in profiles} else base

    def update_belief_state(self, observation):
        scene = str(observation.scene_identity)
        history = [item for item in self.belief_history if item['scene'] == scene]
        previous = history[-1] if history else None
        now = time.monotonic()
        interval = max(0.04, min(1.6, now - previous['time'])) if previous else 0.12
        phase_votes = {}
        for entry in history[-4:]:
            phase_votes[entry['phase']] = phase_votes.get(entry['phase'], 0.0) + entry['phase_confidence']
        phase_votes[observation.phase] = phase_votes.get(observation.phase, 0.0) + observation.phase_confidence * 1.6
        predicted_phase = max(phase_votes, key=phase_votes.get) if phase_votes else observation.phase
        phase_strength = min(1.0, phase_votes.get(predicted_phase, 0.0) / max(1.0, len(history) * 0.65 + 1.0))
        controlled = max(observation.objects, key=lambda item: float(item.get('control_probability', 0.0))
                         * float(item.get('confidence', 0.0)), default=None)
        player = None
        if controlled is not None and float(controlled.get('control_probability', 0.0)) >= 0.25 and int(controlled.get('age', 0)) >= 2:
            prior_player = previous.get('player') if previous else None
            if prior_player and prior_player[0] == controlled['track_id']:
                vx = 0.65 * float(controlled['vx']) + 0.35 * prior_player[3]
                vy = 0.65 * float(controlled['vy']) + 0.35 * prior_player[4]
            else:
                vx, vy = float(controlled['vx']), float(controlled['vy'])
            player = (controlled['track_id'], float(controlled['x']), float(controlled['y']),
                      vx, vy, min(1.0, float(controlled['confidence']) * float(controlled['control_probability'])))
        relative = None
        if player is not None:
            neighbors = [item for item in observation.objects if item['track_id'] != player[0]
                         and float(item.get('confidence', 0.0)) >= 0.48 and int(item.get('age', 0)) >= 2]
            if neighbors:
                target = min(neighbors, key=lambda item: math.hypot(item['x'] - player[1], item['y'] - player[2]))
                dx, dy = float(target['x']) - player[1], float(target['y']) - player[2]
                distance = math.hypot(dx, dy)
                current_closing = -(dx * (float(target.get('vx', 0.0)) - player[3])
                                    + dy * (float(target.get('vy', 0.0)) - player[4])) / max(0.025, distance)
                prior_relative = previous.get('relative') if previous else None
                if prior_relative and prior_relative[0] == target['track_id'] and previous.get('player', [None])[0] == player[0]:
                    current_closing = 0.45 * current_closing + 0.55 * (prior_relative[3] - distance) / max(0.06, interval)
                    current_closing = 0.65 * current_closing + 0.35 * prior_relative[4]
                relative = (target['track_id'], dx, dy, distance,
                            max(-1.0, min(1.0, current_closing)), min(player[5], float(target['confidence'])))
        meters = {}
        prior_meters = previous.get('meters', {}) if previous else {}
        for key, amount in observation.hud_meters.items():
            value = max(0.0, min(1.0, float(amount)))
            meters[key] = 0.60 * value + 0.40 * prior_meters[key] if key in prior_meters else value
        confidence = (0.25 * observation.phase_confidence + 0.20 * phase_strength
                      + 0.34 * (player[5] if player else 0.0)
                      + 0.21 * max((float(item.get('temporal_confidence', 0.0)) for item in observation.ui_text), default=0.0))
        confidence *= max(0.0, min(1.0, float(observation.quality.get('confidence', 0.0))))
        belief = {'scene': scene, 'time': now, 'phase': predicted_phase, 'phase_confidence': phase_strength,
                  'player': player, 'relative': relative, 'meters': meters, 'interval': interval,
                  'confidence': max(0.0, min(1.0, confidence)), 'frames': min(7, len(history) + 1)}
        observation.belief_state = belief
        observation.temporal_summary['belief_confidence'] = round(belief['confidence'], 4)
        observation.temporal_summary['target_closing'] = round(relative[4], 4) if relative else 0.0
        if player is not None:
            observation.temporal_summary['controlled_velocity'] = (round(player[3], 4), round(player[4], 4))
        self.belief_history.append(belief)
        return belief

    def detail_focus(self, obs, detail=None):
        points = []
        for item in obs.ui_text[:28]:
            confidence = max(0.0, min(1.0, float(item.get('temporal_confidence', item.get('confidence', 0.0)))))
            urgency = (0.22 + 0.60 * (1.0 - confidence)) if confidence < 0.90 else 0.10
            points.append((float(item['x']), float(item['y']), urgency))
        belief = getattr(obs, 'belief_state', {})
        if belief.get('relative') is not None and belief.get('player') is not None:
            relative = belief['relative']
            player = belief['player']
            if relative[5] >= 0.25:
                points.append((max(0.01, min(0.99, player[1] + relative[1])),
                               max(0.01, min(0.99, player[2] + relative[2])),
                               0.16 + 0.29 * relative[5] * (1.0 - belief['confidence'] * 0.30)))
        for item in getattr(obs, 'interaction_targets', [])[:24]:
            points.append((float(item['x']), float(item['y']), 0.18 + 0.34 * float(item.get('priority', 0.0))))
        for item in obs.objects[:16]:
            confidence = float(item.get('confidence', 0.0))
            if confidence >= 0.22:
                points.append((float(item['x']), float(item['y']), 0.13 + 0.22 * confidence
                               + 0.26 * float(item.get('control_probability', 0.0))))
        for x, y, strength in obs.attention_points[:24]:
            points.append((x, y, 0.08 + 0.18 * min(1.0, strength)))
        if isinstance(detail, dict) and detail.get('spatial'):
            points.append((float(detail.get('start_x', detail.get('x', 0.5))),
                           float(detail.get('start_y', detail.get('y', 0.5))), 0.62))
        grid = []
        for cy in range(3):
            for cx in range(5):
                x, y = (cx + 0.5) / 5.0, (cy + 0.5) / 3.0
                visits = self.detail_focus_visits[cy * 5 + cx]
                cell_x = min(GW - 1, int(x * GW))
                cell_y = min(GH - 1, int(y * GH))
                cell = cell_y * GW + cell_x
                uncertainty = float(getattr(obs, 'state_uncertainty', 1.0))
                score = (0.14 + 0.17 * obs.edges[cell] + 0.24 * obs.motion[cell]
                         + 0.14 * obs.salience[cell] + 0.15 * uncertainty
                         + (0.10 if cy in (0, 2) and not obs.ui_text else 0.0))
                score += max((weight * max(0.0, 1.0 - math.hypot((px - x) * 2.4, (py - y) * 2.1))
                              for px, py, weight in points), default=0.0)
                score += 0.19 / math.sqrt(1.0 + visits)
                score -= 0.12 * math.log1p(visits)
                grid.append((score, x, y, cx, cy))
        if self.step % (7 if obs.state_uncertainty > 0.50 else 11) == 0:
            target = min(grid, key=lambda row: (self.detail_focus_visits[row[4] * 5 + row[3]], -row[0]))
        else:
            target = max(grid, key=lambda row: row[0] + 0.015 * self.rng.random())
        _, x, y, cx, cy = target
        candidates = [(px, py, weight) for px, py, weight in points
                      if abs(px - x) <= 0.13 and abs(py - y) <= 0.21]
        if candidates:
            selected = max(candidates, key=lambda row: row[2])
            x = 0.65 * selected[0] + 0.35 * x
            y = 0.65 * selected[1] + 0.35 * y
        x, y = max(0.01, min(0.99, x)), max(0.01, min(0.99, y))
        self.detail_focus_visits[cy * 5 + cx] = min(200, self.detail_focus_visits[cy * 5 + cx] + 1)
        if max(self.detail_focus_visits) >= 180:
            self.detail_focus_visits = [max(0, value // 2) for value in self.detail_focus_visits]
        self.last_detail_focus = (x, y)
        return self.last_detail_focus

    def attention_proposals(self, raw, detail, rect, obs):
        candidates = []
        def scan(data, width, height, left, top, span_x, span_y, weight):
            game = self.game
            stride = 12 if width > 700 else 8
            for cy in range(4, height - 4, stride):
                for cx in range(4, width - 4, stride):
                    pos = (cy * width + cx) * 4
                    right = pos + 16
                    leftward = pos - 16
                    below = pos + width * 16
                    above = pos - width * 16
                    base = luminance_bgr(data[pos], data[pos + 1], data[pos + 2])
                    horizontal = abs(luminance_bgr(data[right], data[right + 1], data[right + 2]) - luminance_bgr(data[leftward], data[leftward + 1], data[leftward + 2]))
                    vertical = abs(luminance_bgr(data[below], data[below + 1], data[below + 2]) - luminance_bgr(data[above], data[above + 1], data[above + 2]))
                    edge = 0.55 * (horizontal + vertical) + 0.35 * (abs(base - luminance_bgr(data[right], data[right + 1], data[right + 2])) + abs(base - luminance_bgr(data[below], data[below + 1], data[below + 2])))
                    corner = min(horizontal, vertical)
                    color = (max(data[pos], data[pos + 1], data[pos + 2]) - min(data[pos], data[pos + 1], data[pos + 2])) / 255.0
                    u, v = left + span_x * cx / width, top + span_y * cy / height
                    j = min(GH - 1, int(v * GH)) * GW + min(GW - 1, int(u * GW))
                    target = game.targets.get(f'{j % GW}:{j // GW}')
                    useful = max(0.0, float(target[0])) * min(1.0, float(target[1]) / 6.0) if target else 0.0
                    temporal = min(1.0, obs.motion[j] * 2.5)
                    controlled = max((self.control_scores.get(track_id, (0.0, 0))[0]
                                      * min(1.0, self.control_scores.get(track_id, (0.0, 0))[1] / 5.0)
                                      * max(0.0, 1.0 - math.hypot((float(obj['x']) - u) * 8.0,
                                                                       (float(obj['y']) - v) * 7.0))
                                      for track_id, obj in list(self.visual_tracks.items())[-20:]), default=0.0)
                    value = weight * (min(1.0, edge * 0.47) + corner * 0.23 + color * 0.11
                                      + obs.salience[j] * 0.25 + temporal * 0.15 + useful * 0.16
                                      + controlled * 0.23)
                    if value > 0.12:
                        candidates.append((u, v, value))
        scan(raw, W, H, 0.0, 0.0, 1.0, 1.0, 1.0)
        if detail is not None and len(detail) == DW * DH * 4:
            rw = min(rect[2], max(96, int(rect[2] * 0.38)))
            rh = min(rect[3], max(96, int(rect[3] * 0.38)))
            fx, fy = self.last_detail_focus
            ox = max(0, min(rect[2] - rw, int(fx * rect[2] - rw * 0.5)))
            oy = max(0, min(rect[3] - rh, int(fy * rect[3] - rh * 0.5)))
            scan(detail, DW, DH, ox / rect[2], oy / rect[3], rw / rect[2], rh / rect[3], 1.3)
        candidates.sort(key=lambda entry: entry[2], reverse=True)
        retained = []
        for item in candidates:
            if all(abs(item[0] - prior[0]) > 0.023 or abs(item[1] - prior[1]) > 0.032 for prior in retained):
                retained.append(item)
            if len(retained) >= 48:
                break
        return retained

    def rgb_blocks(self, raw):
        if len(raw) != W * H * 4:
            raise ValueError(f'屏幕图像长度错误：{len(raw)}')
        if self.cv_np is not None:
            pixels = self.cv_np.frombuffer(raw, dtype=self.cv_np.uint8).reshape(GH, H // GH, GW, W // GW, 4)
            return pixels[:, 2::4, :, 2::4, :3].mean(axis=(1, 3)).reshape(GH * GW, 3).tolist()
        cells = []
        cell_width, cell_height = W // GW, H // GH
        for row in range(GH):
            for col in range(GW):
                blue = green = red = 0
                for dy in (2, 6, 10, 14):
                    for dx in (2, 6, 10, 14):
                        index = ((row * cell_height + dy) * W + col * cell_width + dx) * 4
                        blue += raw[index]
                        green += raw[index + 1]
                        red += raw[index + 2]
                cells.append([blue / 16.0, green / 16.0, red / 16.0])
        return cells

    def detail_features(self, raw):
        if raw is not None:
            if len(raw) != DW * DH * 4:
                raise ValueError('精细采集图像长度错误')
            samples = []
            texture = []
            color = []
            for row in range(4):
                for col in range(4):
                    mean = grad = chroma = 0.0
                    n = 0
                    for dy in range(4, DH // 4 - 4, 10):
                        for dx in range(4, DW // 4 - 4, 10):
                            cy = row * (DH // 4) + dy
                            cx = col * (DW // 4) + dx
                            pos = (cy * DW + cx) * 4
                            right = pos + 4 * 3
                            below = pos + DW * 4 * 3
                            v = luminance_bgr(raw[pos], raw[pos + 1], raw[pos + 2])
                            mean += v
                            grad += abs(v - luminance_bgr(raw[right], raw[right + 1], raw[right + 2]))
                            grad += abs(v - luminance_bgr(raw[below], raw[below + 1], raw[below + 2]))
                            chroma += (max(raw[pos], raw[pos + 1], raw[pos + 2]) - min(raw[pos], raw[pos + 1], raw[pos + 2])) / 255.0
                            n += 1
                    samples.append(mean / max(1, n))
                    texture.append(grad / max(1, 2 * n))
                    color.append(chroma / max(1, n))
            sections = []
            for row in range(2):
                for col in range(2):
                    ids = [(row * 2 + ry) * 4 + col * 2 + cx for ry in range(2) for cx in range(2)]
                    sections.append(0.60 * sum(texture[i] for i in ids) / 4.0 + 0.40 * sum(color[i] for i in ids) / 4.0)
            self.last_detail = samples + sections
            self.last_detail_location = self.last_detail_focus
            self.last_detail_step = self.step
        if self.last_detail_step is None:
            return self.last_detail + [0.5, 0.5, 1.0, 0.0]
        age = max(0, self.step - self.last_detail_step)
        location = self.last_detail_location
        return self.last_detail + [location[0], location[1], min(1.0, age / 16.0), 1.0 / (1.0 + age * 0.35)]

    def observe_glyph_pattern(self, symbol, high_resolution):
        if not high_resolution or len(high_resolution) < 13 or len(symbol) != 1:
            return
        sample = frozenset(high_resolution)
        existing = self.adaptive_glyphs.get(symbol, [])
        if any(2.0 * len(sample & template) / max(1, len(sample) + len(template)) >= 0.97 for template in existing):
            return
        key = (symbol, sample)
        vote = self.glyph_votes.get(key, [0, -1])
        if vote[1] != self.step:
            vote = [vote[0] + 1, self.step]
        self.glyph_votes[key] = vote
        self.glyph_votes.move_to_end(key)
        if vote[0] >= 3:
            existing.append(sample)
            self.adaptive_glyphs[symbol] = existing[-5:]
            del self.glyph_votes[key]
        while len(self.glyph_votes) > 450:
            self.glyph_votes.popitem(last=False)

    def read_ui_symbols(self, raw):
        width, height = W, H
        visible = bytearray(width * height)
        zones = ((0, height),)
        for top, bottom in zones:
            for y in range(top, bottom):
                offset = y * width
                for x in range(width):
                    pos = (offset + x) * 4
                    blue, green, red = raw[pos], raw[pos + 1], raw[pos + 2]
                    bright_text = (min(red, green, blue) >= 177 and max(red, green, blue) - min(red, green, blue) <= 56) or (red > 218 and green > 189 and blue < 146)
                    if not bright_text and 128 <= max(red, green, blue) <= 246:
                        base = (red * 3 + green * 6 + blue) // 10
                        contrast = 0
                        for nx, ny in ((x - 3, y), (x + 3, y), (x, y - 3), (x, y + 3)):
                            if 0 <= nx < width and top <= ny < bottom:
                                other = (ny * width + nx) * 4
                                near = (raw[other + 2] * 3 + raw[other + 1] * 6 + raw[other]) // 10
                                contrast = max(contrast, base - near)
                        bright_text = contrast >= 92 and (min(red, green, blue) >= 112 or max(red, green, blue) - min(red, green, blue) >= 80)
                    dark_text = False
                    if not bright_text and max(red, green, blue) <= 87:
                        for nx, ny in ((x - 6, y), (x + 6, y), (x, y - 4), (x, y + 4)):
                            if 0 <= nx < width and top <= ny < bottom:
                                other = (ny * width + nx) * 4
                                if min(raw[other], raw[other + 1], raw[other + 2]) >= 163:
                                    dark_text = True
                                    break
                    if bright_text:
                        visible[offset + x] = 1
                    elif dark_text:
                        visible[offset + x] = 3
        glyphs = []
        templates = {}
        for symbol, rows in GLYPH_ROWS.items():
            columns = [x for x in range(5) if any(row[x] == '1' for row in rows)]
            left, right = min(columns), max(columns)
            bits = set()
            for y in range(7):
                for x in range(5):
                    rx = left + min(right - left, int((x + 0.5) * (right - left + 1) / 5))
                    if rows[y][rx] == '1':
                        bits.add(y * 5 + x)
            templates[symbol] = bits
        for polarity in (1, 3):
            for top, bottom in zones:
                for y in range(top, bottom):
                    for x in range(width):
                        index = y * width + x
                        if visible[index] != polarity:
                            continue
                        pending = [index]
                        visible[index] = polarity + 1
                        x0 = x1 = x
                        y0 = y1 = y
                        points = []
                        for pixel in pending:
                            py, px = divmod(pixel, width)
                            points.append(pixel)
                            x0, x1 = min(x0, px), max(x1, px)
                            y0, y1 = min(y0, py), max(y1, py)
                            for ny in range(max(top, py - 1), min(bottom, py + 2)):
                                for nx in range(max(0, px - 1), min(width, px + 2)):
                                    target = ny * width + nx
                                    if visible[target] == polarity:
                                        visible[target] = polarity + 1
                                        pending.append(target)
                        cw, ch = x1 - x0 + 1, y1 - y0 + 1
                        if not (2 <= cw <= 22 and 6 <= ch <= 28 and 7 <= len(points) <= 290 and 0.18 <= cw / ch <= 1.9):
                            continue
                        covered = set(points)
                        sampled = set()
                        for gy in range(7):
                            sy = y0 + min(ch - 1, int((gy + 0.5) * ch / 7))
                            for gx in range(5):
                                sx = x0 + min(cw - 1, int((gx + 0.5) * cw / 5))
                                if sy * width + sx in covered:
                                    sampled.add(gy * 5 + gx)
                        if len(sampled) < 6:
                            continue
                        scores = sorted(((2 * len(sampled & template) / max(1, len(sampled) + len(template)), symbol)
                                         for symbol, template in templates.items()), reverse=True)
                        score, char = scores[0]
                        high_resolution = set()
                        if 0.28 <= cw / ch <= 1.65 and (score >= 0.74 or self.adaptive_glyphs or
                                getattr(self, 'local_glyphs', None) is not None and self.local_glyphs.templates):
                            for gy in range(12):
                                sy = y0 + min(ch - 1, int((gy + 0.5) * ch / 12))
                                for gx in range(10):
                                    sx = x0 + min(cw - 1, int((gx + 0.5) * cw / 10))
                                    if sy * width + sx in covered:
                                        high_resolution.add(gy * 10 + gx)
                        identified = None
                        if score >= 0.79 and (score - scores[1][0] >= 0.035 or score >= 0.96):
                            identified = (char, score, score - scores[1][0])
                        if identified is None and len(high_resolution) >= 14 and self.adaptive_glyphs:
                            matched = []
                            for label, shapes in self.adaptive_glyphs.items():
                                similarity = max((2.0 * len(high_resolution & shape) / max(1, len(high_resolution) + len(shape))
                                                  for shape in shapes), default=0.0)
                                matched.append((similarity, label))
                            matched.sort(reverse=True)
                            if matched and matched[0][0] >= 0.90 and (len(matched) == 1 or matched[0][0] - matched[1][0] >= 0.07):
                                identified = (matched[0][1], matched[0][0], 0.0)
                        if identified is None and len(high_resolution) >= 14 and 0.48 <= cw / ch <= 1.35 and getattr(self, 'local_glyphs', None) is not None and self.local_glyphs.templates:
                            result_score, result_char = self.local_glyphs.best(high_resolution)
                            if result_char:
                                identified = (result_char, result_score, result_score - 0.84)
                        if identified is not None:
                            label, certainty, margin = identified
                            glyphs.append((x0, y0, x1, y1, label, certainty))
                            if certainty >= 0.92 and margin >= 0.08 and len(high_resolution) >= 14:
                                self.observe_glyph_pattern(label, high_resolution)
        glyphs.sort(key=lambda item: item[5], reverse=True)
        distinct = []
        for candidate in glyphs:
            overlap = False
            for previous in distinct:
                common_w = max(0, min(candidate[2], previous[2]) - max(candidate[0], previous[0]) + 1)
                common_h = max(0, min(candidate[3], previous[3]) - max(candidate[1], previous[1]) + 1)
                if common_w * common_h >= 0.72 * min((candidate[2] - candidate[0] + 1) * (candidate[3] - candidate[1] + 1),
                                                     (previous[2] - previous[0] + 1) * (previous[3] - previous[1] + 1)):
                    overlap = True
                    break
            if not overlap:
                distinct.append(candidate)
        glyphs = sorted(distinct, key=lambda item: (item[1] // 8, item[0]))
        lines = []
        for glyph in glyphs:
            x0, y0, x1, y1, char, score = glyph
            options = [line for line in lines if x0 >= line['right'] and x0 - line['right'] <= max(12, (y1 - y0 + 1) * 1.4)
                       and abs((y0 + y1) / 2 - line['center']) <= max(4, (y1 - y0 + 1) * 0.4)]
            if options:
                line = min(options, key=lambda item: (x0 - item['right']) + abs((y0 + y1) / 2 - item['center']))
                line['text'] += char
                line['confidence'] = min(line['confidence'], score)
                line['right'] = x1
                line['top'] = min(line['top'], y0)
                line['bottom'] = max(line['bottom'], y1)
                line['center'] = ((y0 + y1) / 2 + line['center']) / 2
            else:
                lines.append({'text': char, 'confidence': score, 'left': x0, 'top': y0,
                              'right': x1, 'bottom': y1, 'center': (y0 + y1) / 2})
        result = []
        for line in lines:
            content = line['text']
            if (len(content) >= 2 and line['confidence'] >= 0.79 or
                    len(content) == 1 and content.isdigit() and line['confidence'] >= 0.89):
                bounds = [line['left'] / width, line['top'] / height,
                          (line['right'] + 1) / width, (line['bottom'] + 1) / height]
                result.append({'text': content[:24], 'confidence': round(line['confidence'], 3),
                               'x': round((bounds[0] + bounds[2]) * 0.5, 3),
                               'y': round((bounds[1] + bounds[3]) * 0.5, 3),
                               'bounds': [round(value, 4) for value in bounds]})
        return result[:30]

    def detect_hud_meters(self, raw):
        runs = {}
        for y in range(3, H - 2, 3):
            current, start = None, 0
            for x in range(W + 1):
                tone = None
                if x < W:
                    pos = (y * W + x) * 4
                    b, g, r = raw[pos], raw[pos + 1], raw[pos + 2]
                    maximum, minimum = max(r, g, b), min(r, g, b)
                    if g >= 105 and g >= r * 1.38 and g >= b * 1.26:
                        tone = 'green'
                    elif r >= 112 and r >= g * 1.40 and r >= b * 1.26:
                        tone = 'red'
                    elif b >= 110 and b >= r * 1.40 and b >= g * 1.30:
                        tone = 'blue'
                    elif g >= 110 and b >= 110 and r < min(g, b) * 0.72:
                        tone = 'cyan'
                    elif r >= 125 and g >= 110 and b < min(r, g) * 0.72:
                        tone = 'yellow'
                    elif r >= 125 and b >= 110 and g < min(r, b) * 0.72:
                        tone = 'magenta'
                    elif minimum >= 188 and maximum - minimum < 27:
                        tone = 'light'
                if tone != current:
                    size = x - start
                    if current is not None and 18 <= size <= W * 0.65:
                        location = 'top' if y < 36 else 'bottom' if y >= H - 36 else 'middle' + str(y // 30)
                        key = (location, start // 12, current)
                        runs.setdefault(key, []).append((size / W, y))
                    current, start = tone, x
        results = {}
        for (part, start, tone), samples in runs.items():
            samples.sort(key=lambda item: item[1])
            clusters, cluster = [], []
            for item in samples:
                if cluster and item[1] - cluster[-1][1] > 6:
                    clusters.append(cluster)
                    cluster = []
                cluster.append(item)
            if cluster:
                clusters.append(cluster)
            best = max(clusters, key=len, default=[])
            if len(best) >= 2:
                lengths = sorted(value for value, _ in best)
                results[f'{part}:{start}:{tone}'] = round(lengths[len(lengths) // 2], 4)
        return results

    def semantic_features(self, obs):
        game = self.game
        text_items = sorted(obs.ui_text, key=lambda item: float(item.get('temporal_confidence', item.get('confidence', 0.0))), reverse=True)
        recognized = ''.join(str(item.get('text', '')).upper() for item in text_items[:14])
        menu_words = ('START', 'PLAY', 'MENU', 'RETRY', 'CONTINUE', 'PAUSE', '开始', '继续', '菜单', '重试')
        win_words = ('VICTORY', 'YOUWIN', '获胜', '胜利', '通关')
        loss_words = ('DEFEAT', 'GAMEOVER', 'FAILED', '失败', '战败')
        task_words = ('SUCCESS', 'CLEAR', '完成', '成功')
        trustworthy = [float(item.get('temporal_confidence', item.get('confidence', 0.0))) for item in text_items]
        numeric = [item for item in text_items if str(item.get('text', '')).isdigit()]
        result = [min(1.0, len(text_items) / 20.0), sum(trustworthy) / max(1, len(trustworthy)),
                  min(1.0, len(numeric) / 8.0), float(any(token in recognized for token in menu_words)),
                  float(any(token in recognized for token in win_words)),
                  float(any(token in recognized for token in loss_words)),
                  float(any(token in recognized for token in task_words)), min(1.0, len(obs.hud_meters) / 8.0)]
        for item in text_items[:4]:
            value = str(item.get('text', ''))
            normalized = min(1.0, math.log1p(int(value)) / 18.0) if value.isdigit() and len(value) < 9 else 0.0
            result.extend((float(item['x']), float(item['y']), float(item.get('temporal_confidence', item.get('confidence', 0.0))), normalized))
        result.extend([0.0] * (24 - len(result)))
        for side in ('top', 'bottom'):
            for color in ('green', 'red', 'blue'):
                values = [float(v) for key, v in obs.hud_meters.items() if key.startswith(side + ':') and key.endswith(':' + color)]
                result.extend((max(values, default=0.0), min(1.0, len(values) / 4.0)))
        ranked = sorted(obs.objects, key=lambda item: (float(item.get('control_probability', 0.0)) * 1.3 + float(item.get('confidence', 0.0)) * 0.5 + float(item.get('activity', 0.0)) * 0.3), reverse=True)
        for item in ranked[:4]:
            result.extend((float(item['x']), float(item['y']), min(1.0, math.hypot(item['vx'], item['vy']) * 8.0), float(item.get('control_probability', 0.0))))
        result.extend([0.0] * (52 - len(result)))
        temporal = obs.temporal_summary
        controlled = max(obs.objects, key=lambda item: float(item.get('control_probability', 0.0)), default=None)
        relative = [0.0, 0.0, 0.0, 0.0]
        if controlled is not None and float(controlled.get('confidence', 0.0)) >= 0.36:
            neighbors = [item for item in obs.objects if item is not controlled and float(item.get('confidence', 0.0)) >= 0.35]
            if neighbors:
                closest = min(neighbors, key=lambda item: math.hypot(float(item['x']) - float(controlled['x']), float(item['y']) - float(controlled['y'])))
                dx, dy = float(closest['x']) - float(controlled['x']), float(closest['y']) - float(controlled['y'])
                distance = math.hypot(dx, dy)
                velocity_x = float(closest.get('vx', 0.0)) - float(controlled.get('vx', 0.0))
                velocity_y = float(closest.get('vy', 0.0)) - float(controlled.get('vy', 0.0))
                closing = -(dx * velocity_x + dy * velocity_y) / max(0.025, distance)
                relative = [max(-1.0, min(1.0, dx)), max(-1.0, min(1.0, dy)),
                            max(-1.0, min(1.0, closing * 8.0)), 1.0 / (1.0 + distance * 6.0)]
        belief = getattr(obs, 'belief_state', {})
        stable_relative = belief.get('relative') if belief.get('frames', 0) >= 2 and belief.get('confidence', 0.0) >= 0.48 else None
        if stable_relative is not None and stable_relative[5] >= 0.30:
            relative = [max(-1.0, min(1.0, stable_relative[1])),
                        max(-1.0, min(1.0, stable_relative[2])),
                        max(-1.0, min(1.0, stable_relative[4] * 4.0)),
                        1.0 / (1.0 + stable_relative[3] * 6.0)]
        result.extend((min(1.0, float(temporal.get('motion_average', temporal.get('motion_energy', 0.0))) * 5.0),
                       max(-1.0, min(1.0, float(temporal.get('motion_trend', 0.0)) * 6.0)),
                       min(1.0, float(temporal.get('tracked_speed', 0.0)) * 8.0),
                       min(1.0, float(temporal.get('persistent_tracks', 0)) / 15.0),
                       *relative))
        recent = list(game.recent)[-2:]
        while len(recent) < 2:
            recent.insert(0, None)
        for entry in recent:
            result.extend(((entry[0] + 1) / len(self.actions), max(-1.0, min(1.0, float(entry[2])))) if entry is not None else (0.0, 0.0))
        if len(result) != SEMANTIC_COUNT:
            raise ValueError('视觉语义特征数量错误')
        return [max(-1.0, min(1.0, float(value))) for value in result]

    @staticmethod
    def build_interaction_targets(obs):
        targets = []
        words = ('START', 'PLAY', 'CONTINUE', 'NEXT', 'RETRY', 'RESUME', 'OK', 'YES',
                 '开始', '继续', '下一关', '重试', '确认', '确定', '进入', '挑战')
        for item in getattr(obs, 'ui_text', [])[:28]:
            confidence = float(item.get('temporal_confidence', item.get('confidence', 0.0)))
            if confidence < 0.32:
                continue
            label = ''.join(c for c in str(item.get('text', '')).upper() if c.isalnum())
            priority = 0.24 if any(word in label for word in words) else 0.07
            if getattr(obs, 'phase', '') == 'result' and any(word in label for word in ('RETRY', 'AGAIN', '重试', '重新')):
                priority += 0.12
            x, y = float(item.get('x', 0.5)), float(item.get('y', 0.5))
            bounds = item.get('bounds', [])
            center = [(x, y)]
            if len(bounds) == 4:
                x0, y0, x1, y1 = map(float, bounds)
                center.extend(((x, min(0.98, y1 + min(0.045, (y1 - y0) * 1.1))),
                               (x, max(0.02, y0 - min(0.045, (y1 - y0) * 1.1)))))
            for j, (cx, cy) in enumerate(center):
                targets.append({'x': max(0.01, min(0.99, cx)), 'y': max(0.01, min(0.99, cy)),
                                'confidence': min(1.0, confidence * (1.0 if j == 0 else 0.65)),
                                'priority': priority * (1.0 if j == 0 else 0.6), 'label': label[:24]})
        if getattr(obs, 'phase', '') == 'playing':
            for item in getattr(obs, 'objects', [])[:20]:
                confidence = max(0.0, min(1.0, float(item.get('confidence', 0.0))))
                activity = max(0.0, min(1.0, float(item.get('activity', 0.0))))
                control = max(0.0, min(1.0, float(item.get('control_probability', 0.0))))
                if confidence >= 0.56 and int(item.get('age', 0)) >= 3 and control < 0.32:
                    targets.append({'x': float(item['x']), 'y': float(item['y']),
                                    'confidence': confidence * min(1.0, 0.6 + activity),
                                    'priority': 0.10 + 0.10 * activity, 'label': 'tracked_object'})
        targets.sort(key=lambda item: item['priority'] * item['confidence'], reverse=True)
        return targets[:48]

    def infer_scene_phase(self, obs):
        game = self.game
        tokens = ''.join(''.join(ch for ch in str(item.get('text', '')).upper() if ch.isalnum())
                         for item in obs.ui_text if float(item.get('temporal_confidence', item.get('confidence', 0.0))) >= 0.42)
        menu_words = ('START', 'PLAY', 'MENU', 'CONTINUE', 'OPTIONS', 'SETTINGS', '开始', '继续', '菜单', '设置')
        result_words = ('VICTORY', 'DEFEAT', 'GAMEOVER', 'SUCCESS', 'YOUWIN', 'FAILED', '胜利', '失败', '通关', '完成')
        explicit_menu = any(word in tokens for word in menu_words)
        explicit_result = any(word in tokens for word in result_words)
        motion = min(1.0, float(obs.temporal_summary.get('motion_energy', 0.0)) * 8.0)
        activity = min(1.0, float(obs.temporal_summary.get('active_objects', 0)) / 5.0)
        hud = min(1.0, len(obs.hud_meters) / 3.0 + len(obs.ui_numbers) / 6.0)
        stability = max(0.0, 1.0 - motion)
        letter_evidence = min(1.0, sum(float(item.get('temporal_confidence', item.get('confidence', 0.0)))
                                       for item in obs.ui_text[:12]) / 3.0)
        current = [0.12 + 0.17 * stability + 0.26 * letter_evidence + 0.82 * float(explicit_menu),
                   0.14 + 0.65 * motion + 0.32 * activity + 0.35 * hud,
                   0.05 + 0.55 * stability * (1.0 - hud) * (1.0 - letter_evidence) * (1.0 - activity),
                   0.02 + 1.22 * float(explicit_result)]
        if obs.quality.get('low_information', False):
            current = [0.05, 0.03, 1.0, 0.01]
        stored = game.phase_votes.get(obs.signature, [0.0] * 4)
        weight = max(0.15, min(1.0, float(obs.quality.get('confidence', 1.0))))
        votes = [min(100.0, entry * 0.97 + weight * value) for entry, value in zip(stored, current)]
        game.phase_votes[obs.signature] = votes
        game.phase_votes.move_to_end(obs.signature)
        while len(game.phase_votes) > 800:
            game.phase_votes.popitem(last=False)
        totals = [0.70 * value + 0.30 * prior / max(1.0, sum(votes)) * sum(current)
                  for value, prior in zip(current, votes)]
        ranking = sorted(range(4), key=totals.__getitem__, reverse=True)
        leader, runner = totals[ranking[0]], totals[ranking[1]]
        certainty = max(0.0, min(1.0, (leader - runner) / max(0.15, leader)))
        phase = ('menu', 'playing', 'transition', 'result')[ranking[0]] if certainty >= 0.22 else 'unknown'
        if (not explicit_menu and not explicit_result and not obs.quality.get('low_information', False)
                and game.phase_sequence and phase not in ('unknown', 'result')):
            recent = list(game.phase_sequence)[-4:]
            previous = recent[-1]
            same = sum(item[0] == previous[0] and item[1] >= 0.42 for item in recent)
            if (phase != previous[0] and previous[0] in ('menu', 'playing') and same >= 2
                    and certainty < 0.46 and previous[1] >= 0.47):
                phase = previous[0]
                certainty = max(0.22, min(0.55, 0.65 * previous[1]))
        obs.phase_confidence = certainty
        obs.phase = phase
        game.phase_sequence.append((phase, certainty))
        obs.quality['scene_phase'] = phase
        obs.quality['scene_phase_confidence'] = round(certainty, 4)
        return phase

    def infer_controllability(self, old, new, action_index, confidence, camera_shift=(0, 0), camera_confidence=0.0):
        action = self.actions[action_index]
        if confidence < 0.13 or action.kind not in ('key', 'hold', 'pair_hold', 'chord', 'move_fire',
                'move', 'swipe', 'right_swipe', 'touch_swipe', 'look', 'combat', 'aim', 'dual_touch'):
            return 0.0
        previous = {item['track_id']: item for item in old.objects}
        correspondences = []
        for item in new.objects:
            past = previous.get(item['track_id'])
            if past is not None and past.get('age', 0) >= 2:
                correspondences.append((item, item['x'] - past['x'], item['y'] - past['y']))
        camera_dx = camera_shift[0] / float(GW) if camera_confidence > 0.18 else 0.0
        camera_dy = camera_shift[1] / float(GH) if camera_confidence > 0.18 else 0.0
        new.camera_motion = (camera_shift[0], camera_shift[1], camera_confidence)
        new.temporal_summary['camera_motion'] = min(1.0, math.hypot(camera_dx, camera_dy) * 10.0)
        if not correspondences:
            return 0.0
        dx = sorted(pair[1] for pair in correspondences)[len(correspondences) // 2]
        dy = sorted(pair[2] for pair in correspondences)[len(correspondences) // 2]
        background_dx, background_dy = ((camera_dx, camera_dy) if camera_confidence > 0.28 else
                                        (dx, dy) if len(correspondences) >= 3 else (0.0, 0.0))
        profile = self.game.control_profiles.get(action.id)
        expected_x, expected_y = (profile[0], profile[1]) if profile is not None and profile[5] >= 3 else (0.0, 0.0)
        prior_x = float(int(action.a in (68, 39)) - int(action.a in (65, 37)))
        prior_y = float(int(action.a in (83, 40)) - int(action.a in (87, 38)))
        if action.kind in ('swipe', 'right_swipe', 'touch_swipe', 'dual_touch'):
            prior_x, prior_y = float(action.a), float(action.b)
        best = 0.0
        best_vector = (0.0, 0.0)
        for item, mx, my in correspondences:
            relative_x, relative_y = mx - background_dx, my - background_dy
            magnitude = math.hypot(relative_x, relative_y)
            overall = math.hypot(mx, my)
            if len(correspondences) <= 2 and camera_confidence < 0.25:
                magnitude = max(magnitude, overall * 0.82)
            learned_alignment = (max(0.0, (relative_x * expected_x + relative_y * expected_y)
                               / max(1e-4, magnitude * math.hypot(expected_x, expected_y)))
                               if expected_x or expected_y else 0.0)
            prior_alignment = (max(0.0, (mx * prior_x + my * prior_y)
                               / max(0.02, overall * math.hypot(prior_x, prior_y)))
                               if prior_x or prior_y else 0.0)
            contrast = max(0.0, min(1.0, magnitude * 13.0))
            visible = max(0.0, min(1.0, float(item.get('confidence', 0.0)) * 1.4))
            evidence = confidence * visible * (0.78 * contrast + 0.16 * learned_alignment * contrast
                                                 + 0.06 * prior_alignment * contrast)
            entry = self.control_scores.get(item['track_id'], [0.0, 0])
            entry[0] += (evidence - entry[0]) / min(14, entry[1] + 1)
            entry[1] += 1
            self.control_scores[item['track_id']] = entry
            self.control_scores.move_to_end(item['track_id'])
            score = entry[0] * min(1.0, entry[1] / 5.0)
            if score > best:
                best, best_vector = score, (relative_x, relative_y)
        while len(self.control_scores) > 80:
            self.control_scores.popitem(last=False)
        camera_evidence = (confidence * camera_confidence *
                           min(1.0, math.hypot(camera_dx, camera_dy) * 10.0) * 0.35)
        best = max(best, camera_evidence)
        profile = self.game.control_profiles.get(action.id, [0.0] * 5 + [0])
        if (best >= 0.07 or camera_confidence * confidence >= 0.24) and new.quality.get('trainable', False):
            n = min(1000000, profile[5] + 1)
            rate = 1.0 / min(32, n)
            for slot, value in enumerate((best_vector[0], best_vector[1], camera_dx, camera_dy,
                                          max(best, camera_confidence * confidence * 0.45))):
                profile[slot] += rate * (value - profile[slot])
            profile[5] = n
            self.game.control_profiles[action.id] = profile
            self.game.control_profiles.move_to_end(action.id)
            while len(self.game.control_profiles) > 700:
                self.game.control_profiles.popitem(last=False)
        for item in new.objects:
            record = self.control_scores.get(item['track_id'], [0.0, 0])
            item['control_probability'] = max(0.0, min(1.0, record[0] * min(1.0, record[1] / 5.0)))
        new.features[SEMANTIC_START:] = self.semantic_features(new)
        return best

    @staticmethod
    def world_state(features):
        values = features.features if hasattr(features, 'features') else features
        return list(values[:WORLD_VISUAL_COUNT]) + [values[SEMANTIC_START + slot] for slot in WORLD_SEMANTIC_SLOTS]

    @staticmethod
    def world_error(first, second):
        if len(first) != WORLD_FEATURE_COUNT or len(second) != WORLD_FEATURE_COUNT:
            raise ValueError('世界模型状态长度错误')
        return sum(weight * abs(float(a) - float(b)) for a, b, weight
                   in zip(first, second, WORLD_IMPORTANCE)) / WORLD_IMPORTANCE_SUM

    @staticmethod
    def apply_world_delta(features, changes):
        result = list(features)
        for index, delta in enumerate(changes[:WORLD_FEATURE_COUNT]):
            location = index if index < WORLD_VISUAL_COUNT else SEMANTIC_START + WORLD_SEMANTIC_SLOTS[index - WORLD_VISUAL_COUNT]
            result[location] = max(-2.0, min(2.0, result[location] + delta))
        return result

    def observe(self, raw, rect, detail=None):
        vision_started = time.perf_counter()
        try:
            rgb = self.rgb_blocks(raw)
        except Exception:
            self.invalid_observations += 1
            raise
        if detail is not None and len(detail) != DW * DH * 4:
            self.invalid_observations += 1
            detail = None
        count = GW * GH
        lum = [luminance_bgr(b, g, r) for b, g, r in rgb]
        motion = [abs(v - p) for v, p in zip(lum, self.previous_lum)] if self.previous_lum is not None else [0.0] * count
        prior_motion = self.previous_motion if self.previous_motion is not None else [0.0] * count
        two_frames_ago = self.temporal_luma[-2] if len(self.temporal_luma) >= 2 else self.previous_lum
        long_motion = [abs(v - p) for v, p in zip(lum, two_frames_ago)] if two_frames_ago is not None else [0.0] * count
        change = sum(motion) / count
        edges = []
        salience = []
        saturation = []
        for row in range(GH):
            for col in range(GW):
                i = row * GW + col
                edge = 0.0
                if col:
                    edge += abs(lum[i] - lum[i - 1])
                if row:
                    edge += abs(lum[i] - lum[i - GW])
                edge *= 0.5
                edges.append(edge)
                salience.append(min(1.0, motion[i] * 1.3 + edge * 0.85))
                saturation.append((max(rgb[i]) - min(rgb[i])) / 255.0)
        avg = sum(lum) / count
        variance = math.sqrt(sum((v - avg) ** 2 for v in lum) / count)
        mean_rgb = [sum(pixel[k] for pixel in rgb) / (255.0 * count) for k in range(3)]
        bright = sum(v > 0.78 for v in lum) / count
        dark = sum(v < 0.22 for v in lum) / count
        max_s = max(range(count), key=salience.__getitem__)
        weighted_motion = sum(motion) + 1e-9
        weighted_salience = sum(salience) + 1e-9
        motion_x = sum((i % GW + 0.5) / GW * motion[i] for i in range(count)) / weighted_motion
        motion_y = sum((i // GW + 0.5) / GH * motion[i] for i in range(count)) / weighted_motion
        salience_x = sum((i % GW + 0.5) / GW * salience[i] for i in range(count)) / weighted_salience
        salience_y = sum((i // GW + 0.5) / GH * salience[i] for i in range(count)) / weighted_salience
        game = self.game
        fingerprint = []
        for channel in range(3):
            for row in range(4):
                for col in range(5):
                    ids = [r * GW + c for r in range(row * 3, (row + 1) * 3) for c in range(col * 4, (col + 1) * 4)]
                    amount = (sum(lum[i] for i in ids) / len(ids) if channel == 0 else
                              sum((rgb[i][2] - rgb[i][0]) / 255.0 for i in ids) / len(ids) * 0.5 + 0.5 if channel == 1 else
                              sum(edges[i] for i in ids) / len(ids) * 1.5)
                    fingerprint.append(max(0, min(11, int(12 * amount))))
        signature = hashlib.blake2b(bytes(fingerprint), digest_size=8).hexdigest()
        with self.lock:
            nearest = None
            distance = 1000.0
            for old_signature, (center, _) in list(game.scene_centers.items())[-96:]:
                if len(center) != len(fingerprint):
                    continue
                gap = (sum(abs(x - y) for x, y in zip(fingerprint[:20], center[:20])) / 20.0
                       + 0.40 * sum(abs(x - y) for x, y in zip(fingerprint[20:40], center[20:40])) / 20.0
                       + 0.28 * sum(abs(x - y) for x, y in zip(fingerprint[40:], center[40:])) / 20.0)
                if gap < distance:
                    distance, nearest = gap, old_signature
            if nearest is not None and distance < 0.43:
                signature = nearest
            count_seen = game.visits.get(signature, 0)
            game.visits[signature] = count_seen + 1
            game.visits.move_to_end(signature)
            scene_record = game.scene_centers.get(signature)
            if scene_record is None:
                game.scene_centers[signature] = [[float(x) for x in fingerprint], 1]
            else:
                center, previous = scene_record
                rate = 1.0 / min(30, previous + 1)
                for i, value in enumerate(fingerprint):
                    center[i] += rate * (value - center[i])
                scene_record[1] = previous + 1
                game.scene_centers.move_to_end(signature)
            game.scene_history.append(signature)
            if len(game.visits) > 15000:
                game.visits.popitem(last=False)
            if len(game.scene_centers) > 2400:
                game.scene_centers.popitem(last=False)
        novelty = 1.0 / math.sqrt(1 + count_seen)
        features = [
            1.0, avg, variance * 1.7, mean_rgb[0], mean_rgb[1], mean_rgb[2],
            change * 2.0, sum(edges) / count * 2.0, sum(saturation) / count,
            bright, dark, novelty, min(1.0, game.stagnation / 35.0),
            self.last_change * 2.0, motion_x, motion_y, salience_x, salience_y,
        ]
        for row in range(3):
            for col in range(4):
                ids = [r * GW + c for r in range(row * 4, (row + 1) * 4) for c in range(col * 5, (col + 1) * 5)]
                reciprocal = 1.0 / len(ids)
                features.extend((
                    sum(lum[i] for i in ids) * reciprocal,
                    sum(rgb[i][0] for i in ids) * reciprocal / 255.0,
                    sum(rgb[i][1] for i in ids) * reciprocal / 255.0,
                    sum(rgb[i][2] for i in ids) * reciprocal / 255.0,
                    sum(motion[i] for i in ids) * reciprocal * 2.0,
                    sum(edges[i] for i in ids) * reciprocal * 2.0,
                    sum(saturation[i] for i in ids) * reciprocal,
                ))
        for row in range(4):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                ids = [r * GW + c for r in range(row * 3, (row + 1) * 3) for c in range(x0, x1)]
                features.append(sum(lum[i] for i in ids) / max(1, len(ids)))
        detail_vector = self.detail_features(detail)
        features.extend(detail_vector)
        features.extend(((max_s % GW + 0.5) / GW, (max_s // GW + 0.5) / GH))
        for row in range(4):
            for col in range(8):
                ids = [r * GW + c for r in range(row * 3, (row + 1) * 3) for c in range(col * GW // 8, (col + 1) * GW // 8)]
                scale = 1.0 / len(ids)
                features.extend((sum(motion[i] for i in ids) * scale, sum(edges[i] for i in ids) * scale, sum(saturation[i] for i in ids) * scale))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cells = [r * GW + c for r in range(y0, y1) for c in range(x0, x1)]
                features.append(sum(lum[i] for i in cells) / len(cells))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cells = [r * GW + c for r in range(y0, y1) for c in range(x0, x1)]
                features.append(sum(0.32 * motion[i] + 0.25 * prior_motion[i] + 0.23 * long_motion[i] + 0.20 * edges[i] for i in cells) / len(cells))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cells = [r * GW + c for r in range(y0, y1) for c in range(x0, x1)]
                features.append(sum((rgb[i][2] - rgb[i][0]) / 255.0 for i in cells) / len(cells))
        for row in range(8):
            for col in range(8):
                x0, x1 = col * GW // 8, (col + 1) * GW // 8
                y0, y1 = row * GH // 8, (row + 1) * GH // 8
                cx, cy = (x0 + x1) / (2 * GW), (y0 + y1) / (2 * GH)
                tracked = sum(max(0.0, min(1.0, weight)) * max(0.0, 1.0 - abs(x + vx - cx) * 6.0 - abs(y + vy - cy) * 6.0)
                              for x, y, weight, vx, vy in self.last_attention_tracks[:30])
                features.append(min(1.0, tracked))
        if len(features) != FEATURE_COUNT:
            raise ValueError(f'视觉特征数量错误：{len(features)}')
        hud_ids = [r * GW + c for r in list(range(2)) + list(range(GH - 2, GH)) for c in range(GW)]
        hud = sum((saturation[i] * 0.4 + edges[i] * 0.6) for i in hud_ids) / len(hud_ids)
        identical = self.previous_lum is not None and change < 0.0001
        self.temporal_luma.append(lum[:])
        self.previous_lum = lum
        self.previous_motion = motion
        self.last_change = change
        self.last_frame = raw
        blank = variance < 0.006 and (avg < 0.012 or avg > 0.988)
        color_deviation = math.sqrt(sum((pixel[channel] / 255.0 - mean_rgb[channel]) ** 2 for pixel in rgb for channel in range(3)) / (count * 3))
        uniform = color_deviation < 0.006
        low_information = bool(blank or uniform)
        confidence = 0.16 if low_information else 0.62 if identical else 1.0
        if low_information:
            self.low_information_observations += 1
        quality = {'blank': bool(blank), 'uniform': bool(uniform), 'low_information': low_information, 'trainable': not low_information, 'confidence': confidence, 'variance': round(variance, 5), 'same_as_previous': bool(identical), 'temporal_frames': len(self.temporal_luma), 'scene': 'blank' if low_information else 'changing' if change > 0.16 else 'active' if change > 0.012 else 'steady', 'capture_integrity': True, 'detail_age': round(detail_vector[-2], 4), 'detail_reliability': round(detail_vector[-1], 4), 'detail_position': detail_vector[-4:-2]}
        observation = Observation(lum, rgb, salience, motion, edges, features, signature, change, novelty, rect, raw, hud, self.game_key, True, quality)
        regions = []
        for r0, r1, c0, c1 in ((0, 2, 0, 10), (0, 2, 10, 20), (10, 12, 0, 10), (10, 12, 10, 20), (2, 10, 0, 5), (2, 10, 5, 15), (2, 10, 15, 20)):
            ids = [r * GW + c for r in range(r0, r1) for c in range(c0, c1)]
            regions.append((sum(lum[i] for i in ids) / len(ids), sum(saturation[i] for i in ids) / len(ids), sum(edges[i] for i in ids) / len(ids)))
        observation.region_signals = regions
        hud_readouts = []
        for row_first in (0, GH - 2):
            for segment in range(6):
                indices = [r * GW + c for r in range(row_first, row_first + 2) for c in range(segment * GW // 6, (segment + 1) * GW // 6)]
                hud_readouts.extend((
                    sum(saturation[i] > 0.23 and lum[i] > 0.12 for i in indices) / len(indices),
                    sum(rgb[i][1] > rgb[i][0] * 1.22 and rgb[i][1] > rgb[i][2] * 1.22 for i in indices) / len(indices),
                    sum(rgb[i][2] > rgb[i][0] * 1.28 and rgb[i][2] > rgb[i][1] * 1.28 for i in indices) / len(indices),
                    sum(lum[i] > 0.70 for i in indices) / len(indices),
                ))
        observation.hud_readouts = hud_readouts
        observation.hud_meters = self.detect_hud_meters(raw) if not low_information else {}
        observation.ui_text = self.read_ui_symbols(raw) if not low_information else []
        if not low_information and detail is not None:
            def detail_patch(left, top, width, height):
                small = bytearray(W * H * 4)
                for y in range(H):
                    source_y = min(DH - 1, top + y * height // H)
                    output = y * W * 4
                    input_row = source_y * DW * 4
                    for x in range(W):
                        sample = input_row + min(DW - 1, left + x * width // W) * 4
                        small[output + x * 4:output + x * 4 + 4] = detail[sample:sample + 4]
                return bytes(small)
            region_width = min(rect[2], max(96, int(rect[2] * 0.38)))
            region_height = min(rect[3], max(96, int(rect[3] * 0.38)))
            fx, fy = self.last_detail_focus
            offset_x = max(0, min(rect[2] - region_width, int(fx * rect[2] - region_width * 0.5)))
            offset_y = max(0, min(rect[3] - region_height, int(fy * rect[3] - region_height * 0.5)))
            crops = [(0, 0, DW, DH)]
            half_w, half_h = DW // 2, DH // 2
            index = self.step % 4
            crops.append(((index % 2) * half_w, (index // 2) * half_h, half_w, half_h))
            uncertain_text = [item for item in observation.ui_text
                              if float(item.get('confidence', 0.0)) >= 0.73]
            if uncertain_text:
                focus_text = min(uncertain_text, key=lambda item: float(item.get('temporal_confidence', item.get('confidence', 0.0))))
                local_x = (float(focus_text['x']) * rect[2] - offset_x) / max(1, region_width)
                local_y = (float(focus_text['y']) * rect[3] - offset_y) / max(1, region_height)
                if 0.0 <= local_x <= 1.0 and 0.0 <= local_y <= 1.0:
                    sub_w, sub_h = DW // 3, DH // 3
                    crops.append((max(0, min(DW - sub_w, int(local_x * DW - sub_w * 0.5))),
                                  max(0, min(DH - sub_h, int(local_y * DH - sub_h * 0.5))), sub_w, sub_h))
            elif self.step % 3 == 1:
                sub_w, sub_h = DW // 3, DH // 3
                crops.append((max(0, min(DW - sub_w, (index % 3) * sub_w)),
                              max(0, min(DH - sub_h, (index // 2) * sub_h)), sub_w, sub_h))
            for left, top, width, height in crops:
                for item in self.read_ui_symbols(detail_patch(left, top, width, height)):
                    u = (left + item['x'] * width) / DW
                    v = (top + item['y'] * height) / DH
                    absolute_x = (offset_x + u * region_width) / max(1, rect[2])
                    absolute_y = (offset_y + v * region_height) / max(1, rect[3])
                    if not any(existing['text'] == item['text'] and abs(existing['x'] - absolute_x) < 0.025 and abs(existing['y'] - absolute_y) < 0.025 for existing in observation.ui_text):
                        shifted = dict(item)
                        bounds = item.get('bounds')
                        if isinstance(bounds, list) and len(bounds) == 4:
                            shifted['bounds'] = [max(0.0, min(1.0, (offset_x + (left + bounds[k] * width) * region_width / DW) / max(1, rect[2])))
                                                 if k % 2 == 0 else max(0.0, min(1.0, (offset_y + (top + bounds[k] * height) * region_height / DH) / max(1, rect[3])))
                                                 for k in range(4)]
                        shifted.update({'x': absolute_x, 'y': absolute_y, 'source': 'detail'})
                        observation.ui_text.append(shifted)
            observation.ui_text.sort(key=lambda item: item['confidence'], reverse=True)
            observation.ui_text = observation.ui_text[:36]
        scene_id = (self.visual_active_key if self.visual_active_key == self.game_key
                    or self.visual_active_base == self.game_key else self.game_key)
        for item in observation.ui_text:
            ui_key = (str(scene_id)[-12:] + ':' + str(min(15, max(0, int(item['x'] * 16))))
                      + ':' + str(min(9, max(0, int(item['y'] * 10)))))
            previous = game.ui_history.get(ui_key)
            numeric = item['text'].isdigit() and len(item['text']) <= 8
            proximity = bool(previous and 0 <= game.game_steps - previous[2] <= 3)
            continuity = bool(proximity and previous[0] == item['text'])
            stable_count = (min(100, previous[1] + 1) if game.game_steps > previous[2] else previous[1]) if continuity else 1
            votes = list(previous[4]) if proximity and len(previous) >= 5 and isinstance(previous[4], list) else []
            if not previous or game.game_steps > previous[2]:
                votes.append([str(item['text'])[:24], float(item['confidence'])])
            elif votes:
                votes[-1] = [str(item['text'])[:24], float(item['confidence'])]
            else:
                votes.append([str(item['text'])[:24], float(item['confidence'])])
            votes = votes[-5:]
            agreement = sum(max(0.0, min(1.0, float(vote[1]))) for vote in votes if vote[0] == item['text'])
            total_votes = sum(max(0.0, min(1.0, float(vote[1]))) for vote in votes)
            consistency = agreement / max(0.0001, total_votes)
            reliability = float(item['confidence']) * (0.30 + 0.70 * min(1.0, stable_count / 3.0))
            reliability *= 0.60 + 0.40 * consistency
            if numeric and proximity and previous[0].isdigit() and previous[0] != item['text']:
                reliability = max(reliability, min(0.72, float(item['confidence']) * 0.76,
                                                   float(previous[3]) * 0.76))
            if len(votes) >= 3 and agreement >= 2.5 and consistency >= 0.82:
                reliability = max(reliability, min(0.98, float(item['confidence']) * 0.86 + 0.11))
            item['temporal_confidence'] = round(max(0.0, min(1.0, reliability)), 4)
            item['temporal_votes'] = len(votes)
            game.ui_history[ui_key] = [item['text'], stable_count, game.game_steps, float(item['confidence']), votes]
            game.ui_history.move_to_end(ui_key)
            observation.ui_state[ui_key] = {'text': item['text'], 'stability': stable_count, 'confidence': reliability}
        while len(game.ui_history) > 128:
            game.ui_history.popitem(last=False)
        observation.ui_numbers = [entry for entry in observation.ui_text if entry['text'].isdigit() and len(entry['text']) <= 8]
        proposed = self.attention_proposals(raw, detail, rect, observation)
        predicted = []
        for x, y, confidence, vx, vy in self.last_attention_tracks:
            matches = [point for point in proposed[:35] if abs(point[0] - x) < 0.095 and abs(point[1] - y) < 0.12]
            if matches:
                nx, ny, weight = min(matches, key=lambda point: abs(point[0] - x) + abs(point[1] - y))
                tracked_x = max(0.01, min(0.99, nx + (nx - x + vx) * 0.28))
                tracked_y = max(0.01, min(0.99, ny + (ny - y + vy) * 0.28))
                predicted.append((tracked_x, tracked_y, min(2.0, weight * 1.18 + confidence * 0.10)))
        proposed = sorted(proposed + predicted, key=lambda point: point[2], reverse=True)
        observation.attention_points = []
        for point in proposed:
            if all(abs(point[0] - old_point[0]) > 0.016 or abs(point[1] - old_point[1]) > 0.024
                   for old_point in observation.attention_points):
                observation.attention_points.append(point)
            if len(observation.attention_points) >= 48:
                break
        now = time.monotonic()
        frame_interval = max(0.04, min(0.70, now - self.track_last_time)) if self.track_last_time is not None else 0.12
        self.track_last_time = now
        time_scale = 0.12 / frame_interval
        retained_tracks = OrderedDict()
        present_tracks = []
        available = set(self.visual_tracks)
        for x, y, weight in observation.attention_points[:36]:
            col = min(GW - 1, max(0, int(x * GW)))
            row = min(GH - 1, max(0, int(y * GH)))
            cell = row * GW + col
            color = tuple(channel / 255.0 for channel in rgb[cell])
            neighborhood = [rgb[row * GW + col] for col, row in
                            ((max(0, col - 1), row), (min(GW - 1, col + 1), row),
                             (col, max(0, row - 1)), (col, min(GH - 1, row + 1)))]
            appearance = tuple(sum(float(point[channel]) for point in neighborhood)
                               / (255.0 * len(neighborhood)) for channel in range(3))
            closest = None
            distance_best = 1e9
            for track_id in available:
                previous = self.visual_tracks[track_id]
                dx = abs(x - previous['x'] - previous['vx'] / max(0.15, time_scale))
                dy = abs(y - previous['y'] - previous['vy'] / max(0.15, time_scale))
                dc = sum(abs(a - b) for a, b in zip(color, previous['color']))
                da = sum(abs(a - b) for a, b in zip(appearance, previous.get('appearance', appearance)))
                if dx > 0.13 or dy > 0.17 or dc > 0.50 or da > 0.62:
                    continue
                distance = (dx / 0.13 + dy / 0.17 + dc / 0.45 + 0.45 * da / 0.62
                            - min(0.08, previous['age'] * 0.008))
                if distance < distance_best:
                    distance_best, closest = distance, track_id
            if closest is not None:
                previous = self.visual_tracks[closest]
                available.remove(closest)
                vx = max(-0.10, min(0.10, 0.64 * (x - previous['x']) * time_scale + 0.36 * previous['vx']))
                vy = max(-0.10, min(0.10, 0.64 * (y - previous['y']) * time_scale + 0.36 * previous['vy']))
                age = min(1000000, previous['age'] + 1)
                track_id = closest
                confidence = min(1.0, 0.18 + 0.28 * weight + 0.04 * min(age, 8))
            else:
                track_id = self.next_track_id
                self.next_track_id += 1
                vx, vy, age = 0.0, 0.0, 1
                confidence = max(0.0, min(1.0, weight * 0.40))
            retained_tracks[track_id] = {'x': x, 'y': y, 'vx': vx, 'vy': vy, 'color': color,
                                         'appearance': appearance, 'age': age, 'misses': 0,
                                         'confidence': confidence, 'weight': weight}
            present_tracks.append((track_id, retained_tracks[track_id], motion[cell]))
        lost = 0
        for track_id in available:
            previous = self.visual_tracks[track_id]
            misses = previous['misses'] + 1
            if misses <= 3 and len(retained_tracks) < 50:
                decayed = previous.copy()
                decayed['misses'] = misses
                decayed['confidence'] *= 0.55
                retained_tracks[track_id] = decayed
            elif previous['age'] >= 2:
                lost += 1
        self.visual_tracks = retained_tracks
        self.last_attention_tracks = [(item['x'], item['y'], item['weight'], item['vx'], item['vy'])
                                      for _, item, _ in present_tracks[:30]]
        coherent = [(item['vx'], item['vy']) for _, item, _ in present_tracks if item['age'] >= 3]
        camera_dx, camera_dy, camera_consensus = 0.0, 0.0, 0.0
        if len(coherent) >= 6:
            median_x = sorted(value[0] for value in coherent)[len(coherent) // 2]
            median_y = sorted(value[1] for value in coherent)[len(coherent) // 2]
            consistent = sum(math.hypot(vx - median_x, vy - median_y) < 0.020 for vx, vy in coherent)
            camera_consensus = consistent / len(coherent) if math.hypot(median_x, median_y) > 0.006 else 0.0
            if camera_consensus >= 0.68:
                camera_dx, camera_dy = median_x, median_y
            else:
                camera_consensus = 0.0
        observation.camera_motion = (camera_dx, camera_dy, camera_consensus)
        observation.objects = []
        for track_id, item, activity in present_tracks[:30]:
            observation.objects.append({'track_id': track_id, 'age': item['age'], 'x': item['x'], 'y': item['y'],
                                        'vx': item['vx'], 'vy': item['vy'], 'confidence': item['confidence'],
                                        'activity': min(1.0, activity + abs(item['vx']) * 3 + abs(item['vy']) * 3),
                                        'color': item['color'],
                                        'control_probability': max(0.0, min(1.0, self.control_scores.get(track_id, (0.0, 0))[0]
                                            * min(1.0, self.control_scores.get(track_id, (0.0, 0))[1] / 5.0)
                                            * (0.65 if camera_consensus > 0.68
                                               and math.hypot(item['vx'] - camera_dx, item['vy'] - camera_dy) < 0.004
                                               else 1.0)))})
        observation.temporal_summary = {
            'motion_energy': round(change, 5),
            'long_motion_energy': round(sum(long_motion) / count, 5),
            'motion_center': (motion_x, motion_y),
            'active_objects': sum(item['activity'] > 0.08 for item in observation.objects),
            'tracked_speed': (sum(math.hypot(item['vx'] - camera_dx, item['vy'] - camera_dy) for item in observation.objects)
                              / max(1, len(observation.objects))),
            'frame_interval_seconds': round(frame_interval, 4),
            'camera_consensus': round(camera_consensus, 4),
            'persistent_tracks': sum(item['age'] >= 3 for item in observation.objects),
            'disappeared_tracks': lost,
            'history_frames': len(self.temporal_luma),
        }
        past_motion = [item[0] for item in self.temporal_observations if item[2] == scene_id]
        past_object_speed = [item[1] for item in self.temporal_observations if item[2] == scene_id]
        if past_motion:
            observation.temporal_summary['motion_trend'] = max(-1.0, min(1.0, change - sum(past_motion) / len(past_motion)))
            observation.temporal_summary['motion_average'] = (change + sum(past_motion)) / (len(past_motion) + 1)
        else:
            observation.temporal_summary['motion_trend'] = 0.0
            observation.temporal_summary['motion_average'] = change
        if past_object_speed:
            observation.temporal_summary['object_speed_trend'] = observation.temporal_summary['tracked_speed'] - sum(past_object_speed) / len(past_object_speed)
        else:
            observation.temporal_summary['object_speed_trend'] = 0.0
        self.temporal_observations.append((change, observation.temporal_summary['tracked_speed'], scene_id))
        observation.scene_key = scene_id
        observation.scene_identity = scene_id
        self.infer_scene_phase(observation)
        observation.state_uncertainty = max(0.0, min(1.0,
            0.32 * (1.0 - observation.phase_confidence)
            + 0.25 * (1.0 - float(observation.quality.get('confidence', 0.0)))
            + 0.23 * (1.0 - max((float(item.get('control_probability', 0.0)) for item in observation.objects), default=0.0))
            + 0.20 * (1.0 - max((float(item.get('temporal_confidence', 0.0)) for item in observation.ui_text), default=0.0))))
        observation.quality['state_uncertainty'] = round(observation.state_uncertainty, 4)
        self.update_belief_state(observation)
        observation.interaction_targets = self.build_interaction_targets(observation)
        observation.features[SEMANTIC_START:] = self.semantic_features(observation)
        observed_cost = max(0.0, min(10.0, time.perf_counter() - vision_started))
        self.vision_cost_ema = (0.84 * self.vision_cost_ema + 0.16 * observed_cost
                                if self.vision_cost_ema else observed_cost)
        return observation

    def _encode(self, features, target=False):
        matrix = self.target_encoder if target else self.encoder
        bias = self.target_encoder_bias if target else self.encoder_bias
        if self.np is not None:
            x = self.np.asarray(features, dtype=self.np.float32)
            return self.np.tanh(matrix @ x + bias)
        return [math.tanh(sum(weight * value for weight, value in zip(row, features)) + bias[j]) for j, row in enumerate(matrix)]

    def _values(self, features, game, target=False, include_hidden=False):
        hidden = self._encode(features, target)
        matrix = game.target_q if target else game.q
        bias = game.target_bias if target else game.bias
        if self.np is not None:
            scores = matrix @ hidden + bias
            return (scores, hidden) if include_hidden else scores
        scores = [sum(w * h for w, h in zip(row, hidden)) + bias[i] for i, row in enumerate(matrix)]
        return (scores, hidden) if include_hidden else scores


    @staticmethod
    def state_signature(obs):
        features = obs.features
        data = [str(getattr(obs, 'scene_identity', getattr(obs, 'scene_key', '')))]
        phase = getattr(obs, 'phase', 'unknown')
        if phase != 'unknown' and float(getattr(obs, 'phase_confidence', 0.0)) >= 0.53:
            data.append(phase)
        for index in (1, 2, 7, 8, 18, 25, 32, 39, 46, 53, 60, 67):
            value = float(features[index])
            data.append(str(max(-10, min(10, round(value * 7.0)))))
        for index in (0, 1, 2, 3, 4, 5, 6, 7, 36, 37, 56, 57, 58, 59):
            value = float(features[SEMANTIC_START + index])
            data.append(str(max(-10, min(10, round(value * 7.0)))))
        stable_objects = [item for item in getattr(obs, 'objects', [])
                          if float(item.get('confidence', 0.0)) >= 0.45 and int(item.get('age', 0)) >= 2]
        stable_objects.sort(key=lambda item: (-float(item.get('control_probability', 0.0)),
                                                    -float(item.get('confidence', 0.0))))
        for item in stable_objects[:3]:
            data.extend((str(max(0, min(11, round(float(item['x']) * 11)))),
                         str(max(0, min(8, round(float(item['y']) * 8))))))
        controlled = max(stable_objects, key=lambda item: float(item.get('control_probability', 0.0)), default=None)
        if controlled is not None and float(controlled.get('control_probability', 0.0)) >= 0.38:
            near = sorted((item for item in stable_objects if item is not controlled),
                          key=lambda item: math.hypot(float(item['x']) - float(controlled['x']),
                                                      float(item['y']) - float(controlled['y'])))
            for item in near[:2]:
                dx = float(item['x']) - float(controlled['x'])
                dy = float(item['y']) - float(controlled['y'])
                data.extend(('r', str(max(-4, min(4, round(dx * 5)))),
                             str(max(-4, min(4, round(dy * 5)))),
                             str(max(0, min(5, round(math.hypot(dx, dy) * 6))))))
        belief = getattr(obs, 'belief_state', {})
        player = belief.get('player')
        if player and belief.get('confidence', 0.0) >= 0.52 and belief.get('frames', 0) >= 3:
            data.extend(('velocity', str(max(-4, min(4, round(player[3] * 75.0)))),
                         str(max(-4, min(4, round(player[4] * 75.0))))))
        for key, value in sorted(getattr(obs, 'hud_meters', {}).items())[:8]:
            data.extend((str(key), str(max(0, min(12, round(float(value) * 12))))))
        for item in sorted(getattr(obs, 'ui_numbers', []), key=lambda x: float(x.get('confidence', 0.0)), reverse=True)[:3]:
            if float(item.get('temporal_confidence', item.get('confidence', 0.0))) >= 0.78:
                data.extend((str(item.get('text', ''))[:8], str(max(0, min(9, round(float(item['x']) * 9))))))
        for item in sorted(getattr(obs, 'ui_text', []), key=lambda x: float(x.get('temporal_confidence', x.get('confidence', 0.0))), reverse=True)[:2]:
            if float(item.get('temporal_confidence', item.get('confidence', 0.0))) >= 0.72:
                data.append(''.join(c for c in str(item.get('text', '')).upper() if c.isalnum())[:12])
        return hashlib.blake2b('|'.join(data).encode('utf-8'), digest_size=8).hexdigest()

    @staticmethod
    def experiment_context(obs):
        scene = str(getattr(obs, 'scene_key', None) or getattr(obs, 'game', 'desktop'))
        phase = getattr(obs, 'phase', 'unknown')
        ui = getattr(obs, 'ui_text', [])
        menu = int(phase == 'menu' or any(float(item.get('temporal_confidence', 0.0)) >= 0.55
                                           for item in ui[:6]))
        key = scene + ':' + str(phase) + ':' + str(menu)
        stable = [item for item in getattr(obs, 'objects', [])
                  if float(item.get('confidence', 0.0)) >= 0.60 and int(item.get('age', 0)) >= 3]
        controlled = max(stable, key=lambda item: float(item.get('control_probability', 0.0)), default=None)
        if controlled is not None and float(controlled.get('control_probability', 0.0)) >= 0.45:
            neighbors = [item for item in stable if item is not controlled]
            if neighbors:
                near = min(neighbors, key=lambda item: math.hypot(float(item['x']) - float(controlled['x']),
                                                                    float(item['y']) - float(controlled['y'])))
                dx, dy = float(near['x']) - float(controlled['x']), float(near['y']) - float(controlled['y'])
                key += ':r' + str(max(-2, min(2, round(dx * 3)))) + ':' + str(max(-2, min(2, round(dy * 3))))
        return 'c:' + hashlib.blake2b(key.encode('utf-8'), digest_size=7).hexdigest()

    def applicability_record(self, game, obs, index):
        exact = game.action_applicability.get(self.state_signature(obs) + ':' + str(index))
        context = game.action_applicability.get(self.experiment_context(obs) + ':' + str(index))
        if exact is None:
            return context
        if context is None:
            return exact
        return exact if exact[0] >= 3 else context

    def effect_keys(self, obs, index, parameters=None):
        identifier = self.actions[index].id
        if not hasattr(obs, 'signature'):
            return ['a:' + identifier]
        keys = ['a:' + identifier,
                self.experiment_context(obs) + ':' + identifier,
                's:' + self.state_signature(obs) + ':' + identifier]
        if isinstance(parameters, dict) and parameters.get('spatial'):
            try:
                x = float(parameters.get('start_x', parameters.get('x', 0.5)))
                y = float(parameters.get('start_y', parameters.get('y', 0.5)))
                if math.isfinite(x) and math.isfinite(y):
                    cell = f':{max(0, min(5, int(x * 6)))}:{max(0, min(3, int(y * 4)))}'
                    keys.append(self.experiment_context(obs) + ':' + identifier + cell)
            except (ValueError, TypeError, OverflowError):
                pass
        return keys

    def effect_prediction(self, game, obs, index, parameters=None):
        keys = self.effect_keys(obs, index, parameters)
        samples = []
        for strength, key in zip((0.15, 0.50, 0.80, 0.68), keys):
            record = game.world_effects.get(key)
            if isinstance(record, list) and len(record) == 3 and record[2] > 0:
                n = max(0, int(record[2]))
                confidence = strength * n / (n + (5.0 if strength >= 0.5 else 16.0))
                samples.append((max(0.01, min(0.99, record[0] / max(2.0, record[0] + record[1]))), confidence, n))
        if not samples:
            return 0.5, 0.0, 0.25
        total = sum(item[1] for item in samples)
        probability = sum(probability * weight for probability, weight, _ in samples) / max(0.001, total)
        confidence = max(0.0, min(0.92, total / (0.70 + total)))
        variance = probability * (1.0 - probability) / (1.0 + sum(n * weight for _, weight, n in samples))
        return probability, confidence, variance

    def observe_action_effect(self, game, obs, index, effect, causal, magnitude, persistence, quality, stability,
                              peak, background, post_drift, samples):
        if not isinstance(effect, dict) or not effect.get('input_sent') or not effect.get('feedback_valid', True):
            return 0.0, None, 0.0
        if samples < 2 or quality < 0.53 or stability < 0.48 or post_drift > max(0.024, peak * 0.78):
            return 0.0, None, 0.0
        reliable = quality * stability * min(1.0, samples / 3.0)
        if causal >= 0.23 and magnitude >= max(0.009, background * 0.32) and persistence >= 0.35:
            outcome = 1.0
        elif (game.passive_samples >= 2 and peak <= max(0.011, background * 1.30)
              and magnitude < 0.008 and causal <= 0.13 and persistence <= 0.55):
            outcome = 0.0
        else:
            return 0.0, None, 0.0
        local_key = self.experiment_context(obs) + ':' + self.actions[index].id
        repeat = game.repeat_effects.get(local_key, [0.0, 0.0, 0.0, 0])
        repeat[0] = min(1000000.0, repeat[0] + reliable * outcome)
        repeat[1] = min(1000000.0, repeat[1] + reliable * (1.0 - outcome))
        repeat[2] = min(1000000.0, repeat[2] + reliable * max(0.0, min(1.0, causal)))
        repeat[3] = min(1000000, int(repeat[3]) + 1)
        game.repeat_effects[local_key] = repeat
        game.repeat_effects.move_to_end(local_key)
        while len(game.repeat_effects) > 5000:
            game.repeat_effects.popitem(last=False)
        if outcome == 1.0 and repeat[3] >= 3 and repeat[0] > 2.0 * repeat[1]:
            game.diagnostics['repeatable_effects'] += 1
        reproducibility = (repeat[0] + 1.0) / (repeat[0] + repeat[1] + 2.0)
        if outcome == 1.0:
            reliable *= 0.80 + 0.20 * reproducibility
        else:
            reliable *= 0.80 + 0.20 * (1.0 - reproducibility)
        gained = 0.0
        for key in self.effect_keys(obs, index, effect):
            record = game.world_effects.get(key, [1.0, 1.0, 0])
            prior_p = record[0] / max(2.0, record[0] + record[1])
            prior_entropy = -(prior_p * math.log(max(1e-9, prior_p)) + (1.0 - prior_p) * math.log(max(1e-9, 1.0 - prior_p)))
            record[0] = min(1000000.0, record[0] + reliable * outcome)
            record[1] = min(1000000.0, record[1] + reliable * (1.0 - outcome))
            record[2] = min(1000000, record[2] + 1)
            newer_p = record[0] / max(2.0, record[0] + record[1])
            new_entropy = -(newer_p * math.log(max(1e-9, newer_p)) + (1.0 - newer_p) * math.log(max(1e-9, 1.0 - newer_p)))
            gained += max(0.0, prior_entropy - new_entropy)
            game.world_effects[key] = record
            game.world_effects.move_to_end(key)
        while len(game.world_effects) > 14000:
            game.world_effects.popitem(last=False)
        return min(0.012, gained * 0.028 * reliable), outcome, reliable

    def world_event_key(self, obs, index):
        return self.experiment_context(obs) + ':' + str(index)

    def record_world_event(self, game, old, index, new, outcome, confidence):
        if confidence < 0.35 or not old.valid or not new.valid:
            return
        key = self.world_event_key(old, index)
        record = game.world_events.get(key, [0.0] * 12)
        if len(record) == 7:
            record.extend([0.0] * 5)
        weight = min(1.0, max(0.0, confidence))
        record[0] = min(1000000.0, record[0] + weight)
        phase_slot = {'menu': 1, 'playing': 2, 'transition': 3, 'result': 4}.get(new.phase)
        if phase_slot is not None and new.phase_confidence >= 0.20:
            record[phase_slot] = min(1000000.0, record[phase_slot] + weight * new.phase_confidence)
        if outcome in ('win', 'task', 'loss'):
            slot = 6 if outcome == 'loss' else 5
            record[slot] = min(1000000.0, record[slot] + weight)
        transition = (old.phase != new.phase and old.phase != 'unknown' and new.phase != 'unknown'
                      and old.phase_confidence >= 0.52 and new.phase_confidence >= 0.52)
        meter = any(abs(float(value) - float(old.hud_meters.get(name, value))) >= 0.035
                    for name, value in new.hud_meters.items() if name in old.hud_meters)
        old_numbers = {(round(float(item['x']) * 12), round(float(item['y']) * 8)): str(item.get('text', ''))
                       for item in old.ui_numbers if float(item.get('confidence', 0.0)) >= 0.82}
        meter = meter or any(old_numbers.get((round(float(item['x']) * 12), round(float(item['y']) * 8)),
                                            str(item.get('text', ''))) != str(item.get('text', ''))
                                 for item in new.ui_numbers if float(item.get('confidence', 0.0)) >= 0.82)
        relation = (abs(float(old.features[SEMANTIC_START + 59]) - float(new.features[SEMANTIC_START + 59])) >= 0.12
                    and min(float(old.features[SEMANTIC_START + 59]), float(new.features[SEMANTIC_START + 59])) > 0.02)
        scene = (old.signature != new.signature and old.scene_identity == new.scene_identity
                 and old.phase == new.phase and new.novelty >= 0.30)
        old_text = {str(item.get('text', '')).upper() for item in old.ui_text
                    if float(item.get('temporal_confidence', item.get('confidence', 0.0))) >= 0.70}
        ui = any(str(item.get('text', '')).upper() not in old_text
                 and float(item.get('temporal_confidence', item.get('confidence', 0.0))) >= 0.80
                 for item in new.ui_text)
        for slot, present in ((7, transition), (8, meter), (9, relation), (10, scene), (11, ui)):
            if present:
                record[slot] = min(1000000.0, record[slot] + weight)
                game.diagnostics['event_transition_samples'] += 1
        game.world_events[key] = record
        game.world_events.move_to_end(key)
        while len(game.world_events) > 1800:
            game.world_events.popitem(last=False)

    def predict_world_event(self, game, obs, index):
        if not hasattr(obs, 'scene_key'):
            return 0.0, 0.0
        record = game.world_events.get(self.world_event_key(obs, index))
        if not isinstance(record, list) or len(record) not in (7, 12) or record[0] < 3.0:
            return 0.0, 0.0
        success, loss = float(record[5]), float(record[6])
        signed = max(-1.0, min(1.0, (success - loss) / (success + loss + 3.0)))
        confidence = min(0.55, float(record[0]) / (float(record[0]) + 12.0))
        return signed, confidence

    def event_forecast(self, game, obs, index):
        record = game.world_events.get(self.world_event_key(obs, index))
        if not isinstance(record, list) or len(record) != 12 or record[0] < 4.0:
            return (0.0, 0.0)
        count = max(0.1, float(record[0]))
        probabilities = [max(0.0, min(1.0, float(record[slot]) / count)) for slot in range(7, 12)]
        confidence = min(0.65, count / (count + 18.0))
        informational = 0.22 * probabilities[0] + 0.27 * probabilities[1] + 0.26 * probabilities[2] + 0.13 * probabilities[3] + 0.12 * probabilities[4]
        return informational, confidence

    def _world_key(self, index, obs, parameters=None):
        features = obs.features if hasattr(obs, 'features') else obs
        blocks = [features[18 + 7 * i] for i in range(12)]
        regions = ((0, 1, 4, 5), (2, 3, 6, 7), (4, 5, 8, 9), (6, 7, 10, 11))
        tokens = [str(max(0, min(3, int(sum(blocks[i] for i in cells))))) for cells in regions]
        tokens.append(str(min(3, max(0, int(features[8] * 4)))))
        tokens.append(str(min(3, max(0, int(features[2] * 6)))))
        scene_identity = getattr(obs, 'scene_key', None) or self.visual_active_key or self.game_key
        scene = hashlib.blake2b(str(scene_identity).encode('utf-8'), digest_size=3).hexdigest()
        key = str(index) + '@' + scene + ':' + ''.join(tokens)
        if parameters is not None:
            try:
                if isinstance(parameters, dict):
                    px = float(parameters.get('start_x', parameters.get('x', 0.5)))
                    py = float(parameters.get('start_y', parameters.get('y', 0.5)))
                    duration = float(parameters.get('requested_duration', parameters.get('duration', 0.2)))
                    spatial = bool(parameters.get('spatial'))
                else:
                    px, py, duration = map(float, parameters[:3])
                    spatial = True
                if not all(math.isfinite(value) for value in (px, py, duration)):
                    return key
                px = max(0, min(3, int(px * 4))) if spatial else 0
                py = max(0, min(2, int(py * 3))) if spatial else 0
                duration = max(0, min(4, int(math.log2(1.0 + max(0.0, duration)) * 4)))
                return key + ':p' + str(px) + str(py) + str(duration)
            except (TypeError, ValueError, OverflowError, IndexError):
                pass
        return key

    def _world_record(self, game, index, obs, parameters=None):
        keys = []
        if parameters is None:
            scene = getattr(obs, 'signature', None)
            hint = game.world_parameters.get(str(scene) + ':' + str(index)) if scene is not None else None
            if hint is None:
                hint = game.world_parameters.get(str(index))
            if isinstance(hint, dict) and hint.get('count', 0) >= 3 and hint.get('reward', 0.0) >= -0.015:
                parameters = hint
        if parameters is not None:
            keys.append(self._world_key(index, obs, parameters))
        keys.extend((self._world_key(index, obs), index))
        fallback = None
        for key in dict.fromkeys(keys):
            record = game.world.get(key)
            if record is not None:
                if record[1] >= 5 and record[2] <= 0.24:
                    return record
                if fallback is None or record[1] > fallback[1]:
                    fallback = record
        return fallback

    def _remember_world_parameters(self, game, index, obs, effect, reward, confidence):
        if not isinstance(effect, dict) or not effect.get('input_sent') or confidence < 0.20:
            return
        try:
            parameters = {'start_x': float(effect.get('start_x', effect.get('x', 0.5))),
                          'start_y': float(effect.get('start_y', effect.get('y', 0.5))),
                          'duration': float(effect.get('requested_duration', effect.get('duration', 0.2))),
                          'spatial': bool(effect.get('spatial'))}
            if not all(math.isfinite(parameters[field]) for field in ('start_x', 'start_y', 'duration')):
                return
        except (ValueError, TypeError):
            return
        for key in (str(index), obs.signature + ':' + str(index)):
            previous = game.world_parameters.get(key, {})
            n = min(10000000, int(previous.get('count', 0)) + 1)
            blend = min(0.2, 1.0 / n) * confidence
            record = {field: max(0.0, min(1.0, previous.get(field, parameters[field]) * (1.0 - blend)
                      + parameters[field] * blend)) for field in ('start_x', 'start_y')}
            record['duration'] = max(0.025, min(1.5, previous.get('duration', parameters['duration']) * (1.0 - blend)
                                + parameters['duration'] * blend))
            record['spatial'] = parameters['spatial']
            record['count'] = n
            record['reward'] = max(-1.0, min(1.0, float(previous.get('reward', reward)) * (1.0 - blend) + reward * blend))
            game.world_parameters[key] = record
            game.world_parameters.move_to_end(key)
        while len(game.world_parameters) > 4800:
            game.world_parameters.popitem(last=False)

    def _update_world_reward(self, game, keys, reward, confidence):
        for key in dict.fromkeys(keys):
            record = game.world.get(key)
            if record is not None:
                if len(record) < 4:
                    record.append(0.0)
                rate = max(0.006, min(0.10, confidence / max(2.0, min(24, record[1]))))
                record[3] = max(-1.0, min(1.0, record[3] * (1.0 - rate) + reward * rate))

    def world_input(self, features, index, parameters=None):
        action = self.actions[index]
        source = parameters if isinstance(parameters, dict) else {}
        def normalized(name, fallback):
            try:
                value = float(source.get(name, fallback))
                return value if math.isfinite(value) else fallback
            except (TypeError, ValueError, OverflowError):
                return fallback
        kind = action.kind
        codes = [1.0 if kind in group else 0.0 for group in (
            ('key', 'hold', 'chord', 'pair_hold'),
            ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'touch_tap'),
            ('move', 'swipe', 'right_swipe', 'look', 'wheel', 'touch_swipe', 'pinch'),
            ('combat', 'aim', 'move_fire', 'dual_touch'),
        )]
        keys = (action.a, action.b)
        horizontal = (int(68 in keys or 39 in keys) - int(65 in keys or 37 in keys))
        vertical = (int(83 in keys or 40 in keys) - int(87 in keys or 38 in keys))
        if kind in ('swipe', 'right_swipe', 'touch_swipe', 'dual_touch', 'look'):
            horizontal, vertical = action.a, action.b
        codes += [float(horizontal), float(vertical),
                  float(32 in keys), float(13 in keys), float(9 in keys),
                  float(any(v in keys for v in (16, 17, 18))),
                  float(any(v in keys for v in tuple(range(48, 58)))),
                  float(any(v in keys for v in tuple(range(65, 91)))),
                  float(kind in ('chord', 'pair_hold', 'move_fire')),
                  float(kind in ('hold', 'pair_hold', 'press', 'combat', 'aim')),
                  float(kind in ('double', 'focus_double')),
                  float(kind in ('right', 'focus_right', 'right_swipe')),
                  float(kind in ('wheel', 'pinch')),
                  float(kind in ('touch_tap', 'touch_swipe', 'pinch', 'dual_touch')),
                  float(action.a) / 255.0 if 0 <= action.a <= 255 else 0.0,
                  float(action.b) / 255.0 if 0 <= action.b <= 255 else 0.0]
        coding = codes + [2.0 * max(0.0, min(1.0, normalized('start_x', normalized('x', action.x)))) - 1.0,
                          2.0 * max(0.0, min(1.0, normalized('start_y', normalized('y', action.y)))) - 1.0,
                          max(0.0, min(1.0, normalized('requested_duration', normalized('duration', action.duration)) / 1.5)),
                          max(-1.0, min(1.0, normalized('extent', 1.0) - 1.0))]
        if len(coding) != WORLD_ACTION_FEATURES:
            raise ValueError('世界模型动作语义编码长度错误')
        return [max(-2.0, min(2.0, float(value))) for value in self.world_state(features)] + coding

    def world_condition_keys(self, index, features=None, parameters=None):
        action = self.actions[index]
        source = parameters if isinstance(parameters, dict) else {}
        try:
            duration = float(source.get('effective_elapsed_seconds', source.get('requested_duration', action.duration)))
        except (ValueError, TypeError, OverflowError):
            duration = action.duration
        if not math.isfinite(duration):
            duration = action.duration
        bucket = 'short' if duration < 0.18 else 'medium' if duration < 0.55 else 'long'
        category = action.kind + ':' + bucket
        keys = ['k:' + category]
        if hasattr(features, 'scene_key'):
            scene = str(getattr(features, 'scene_key', None) or getattr(features, 'game', 'desktop'))
            context = hashlib.blake2b(scene.encode('utf-8'), digest_size=5).hexdigest()
            keys.insert(0, 's:' + context + ':' + category)
        return keys

    def calibrated_world_prediction(self, game, index, prediction, features, parameters=None):
        if prediction is None:
            return None
        errors = []
        for key in self.world_condition_keys(index, features, parameters):
            record = game.world_condition_errors.get(key)
            if record is not None and record[0] >= 4:
                errors.append((record[0], record[1], record[2]))
        if not errors:
            return prediction
        n, mean, variance = errors[0]
        risk = max(0.0, float(mean) + 1.3 * math.sqrt(max(0.00001, float(variance))))
        trust = min(1.0, n / (n + 14.0))
        multiplier = max(0.15, 1.0 - trust * max(0.0, risk - 0.045) * 5.0)
        delta, reward, confidence, uncertainty = prediction
        return delta, reward, max(0.0, confidence * multiplier), min(1.0, uncertainty + 0.35 * trust * risk)

    def _predict_learned_world(self, game, index, features, parameters=None):
        count = game.world_action_samples[index]
        if game.world_network is None or game.world_network_steps < 28 or count < 5:
            return None
        weights = game.ensure_world_network()
        values = self.world_input(features, index, parameters)
        if self.np is not None:
            x = self.np.asarray(values, dtype=self.np.float32)
            hidden = self.np.tanh(weights['w1'] @ x + weights['b1'])
            alt_hidden = self.np.tanh(weights['w1_alt'] @ x + weights['b1_alt'])
            output = (weights['w2'] @ hidden + weights['b2']).tolist()
            alt_output = (weights['w2_alt'] @ alt_hidden + weights['b2_alt']).tolist()
        else:
            hidden = [math.tanh(sum(a * b for a, b in zip(row, values)) + weights['b1'][i]) for i, row in enumerate(weights['w1'])]
            alt_hidden = [math.tanh(sum(a * b for a, b in zip(row, values)) + weights['b1_alt'][i]) for i, row in enumerate(weights['w1_alt'])]
            output = [sum(a * b for a, b in zip(row, hidden)) + weights['b2'][i] for i, row in enumerate(weights['w2'])]
            alt_output = [sum(a * b for a, b in zip(row, alt_hidden)) + weights['b2_alt'][i] for i, row in enumerate(weights['w2_alt'])]
        if not all(math.isfinite(float(value)) for value in output + alt_output):
            return None
        disagreement = sum(abs(a - b) for a, b in zip(output, alt_output)) / len(output)
        calibrated = math.sqrt(max(0.00001, game.world_action_error_variance[index]))
        verified = game.world_validation_samples[index]
        epistemic = min(1.0, 0.35 / math.sqrt(1.0 + count) + disagreement * 5.0)
        aleatoric = min(1.0, game.world_action_errors[index] + calibrated)
        estimated_error = min(1.0, (0.12 * game.world_network_error + 0.45 * game.world_action_errors[index]
                                    + 0.20 * disagreement + 0.10 * calibrated + 0.13 * epistemic))
        confidence = min(0.80, count / (count + 18.0)) * min(1.0, game.world_network_steps / 110.0)
        confidence *= 0.12 + 0.88 * verified / (verified + 7.0)
        confidence /= 1.0 + estimated_error * 10.0 + disagreement * 10.0 + 1.5 * epistemic
        output = [(a + b) * 0.5 for a, b in zip(output, alt_output)]
        return ([max(-0.8, min(0.8, float(value))) for value in output[:WORLD_FEATURE_COUNT]],
                max(-1.0, min(1.0, float(output[-1]))), confidence,
                min(1.0, 0.48 * estimated_error + 0.32 * epistemic + 0.20 * aleatoric))

    def validate_world_prediction(self, game, index, before, after, parameters=None, reliable=True, context=None):
        if not reliable:
            return None
        forecast = self._predict_learned_world(game, index, before, parameters)
        if forecast is None:
            return None
        observed = [b - a for a, b in zip(self.world_state(before), self.world_state(after))]
        error = min(1.0, self.world_error(forecast[0], observed))
        n = game.world_validation_samples[index] + 1
        prior = game.world_action_errors[index]
        rate = min(0.14, 1.0 / n)
        game.world_action_errors[index] = prior * (1.0 - rate) + error * rate
        game.world_action_error_variance[index] = max(0.00001, min(1.0,
            (1.0 - rate) * game.world_action_error_variance[index] + rate * (error - prior) ** 2))
        game.world_validation_samples[index] = min(100000000, n)
        for key in self.world_condition_keys(index, context, parameters):
            record = game.world_condition_errors.get(key, [0, 0.11, 0.0009])
            count = min(1000000, max(0, int(record[0])) + 1)
            rate = min(0.12, 1.0 / count)
            deviation = error - float(record[1])
            record[1] = min(1.0, max(0.0, float(record[1]) + deviation * rate))
            record[2] = max(0.00001, min(1.0, (1.0 - rate) * float(record[2]) + rate * deviation * deviation))
            record[0] = count
            game.world_condition_errors[key] = record
            game.world_condition_errors.move_to_end(key)
        while len(game.world_condition_errors) > 3000:
            game.world_condition_errors.popitem(last=False)
        game.diagnostics['condition_error_updates'] += 1
        game.diagnostics['world_holdout_evaluations'] += 1
        return error

    def passive_world_keys(self, observation):
        if hasattr(observation, 'signature'):
            return ('context:' + self.experiment_context(observation), 'global')
        return ('global',)

    def passive_world_prediction(self, game, observation):
        for key in self.passive_world_keys(observation):
            record = game.passive_world.get(key)
            if record is None or record[1] < (2 if key != 'global' else 4):
                continue
            count, error = max(0, int(record[1])), max(0.0, float(record[2]))
            trust = min(0.76, count / (count + (8.0 if key != 'global' else 24.0)))
            trust /= 1.0 + 4.0 * error
            return record[0][:], trust, error
        return [0.0] * WORLD_FEATURE_COUNT, 0.0, 0.25

    def learn_passive_world(self, game, observation, differences):
        target = [max(-0.8, min(0.8, float(value))) for value in differences[:WORLD_FEATURE_COUNT]]
        if len(target) != WORLD_FEATURE_COUNT or not all(math.isfinite(value) for value in target):
            return False
        for key in self.passive_world_keys(observation):
            record = game.passive_world.get(key)
            if record is None:
                game.passive_world[key] = [target[:], 1, 0.12]
            else:
                sample_error = self.world_error(record[0], target)
                rate = 1.0 / min(48, max(1, int(record[1]) + 1))
                record[0] = [a + (b - a) * rate for a, b in zip(record[0], target)]
                record[1] = min(1000000, int(record[1]) + 1)
                record[2] = min(1.0, max(0.0, 0.94 * float(record[2]) + 0.06 * sample_error))
            game.passive_world.move_to_end(key)
        while len(game.passive_world) > 256:
            game.passive_world.popitem(last=False)
        game.diagnostics['passive_world_updates'] += 1
        return True

    def world_prediction(self, game, index, features, parameters=None):
        if parameters is None:
            signature = getattr(features, 'signature', None)
            hint = game.world_parameters.get(str(signature) + ':' + str(index)) if signature else None
            if hint is None:
                hint = game.world_parameters.get(str(index))
            if isinstance(hint, dict) and hint.get('count', 0) >= 3:
                parameters = hint
        record = self._world_record(game, index, features, parameters)
        learned = self._predict_learned_world(game, index, features, parameters)
        local = None
        if record is not None and record[1] >= 3:
            confidence = min(0.90, record[1] / 25.0) / (1.0 + record[2] * 8.0)
            if game.world_validation_samples[index] < 2:
                confidence *= 0.70
            local = (record[0][:WORLD_FEATURE_COUNT], float(record[3]) if len(record) > 3 else game.action_effect[index],
                     confidence, record[2])
        if local is None and learned is None:
            probability, certainty, uncertainty = self.effect_prediction(game, features, index, parameters)
            passive, passive_trust, passive_error = self.passive_world_prediction(game, features)
            if certainty >= 0.26 and probability <= 0.38:
                return (passive, -0.02 * (1.0 - probability),
                        min(0.42, certainty * (1.0 - probability) + passive_trust * 0.20),
                        min(1.0, uncertainty + 0.20 * passive_error))
            return None
        if local is None:
            base_prediction = learned
        elif learned is None or learned[2] < 0.08:
            base_prediction = local
        else:
            mixture = min(0.65, learned[2] / (local[2] + learned[2] + 1e-8))
            disagreement = sum(abs(a - b) for a, b in zip(local[0], learned[0])) / max(1, len(local[0]))
            confidence = min(0.92, max(local[2], learned[2])) / (1.0 + disagreement * 9.0)
            delta = [a * (1.0 - mixture) + b * mixture for a, b in zip(local[0], learned[0])]
            reward = local[1] * (1.0 - mixture) + learned[1] * mixture
            uncertainty = min(1.0, local[3] * (1.0 - mixture) + learned[3] * mixture + disagreement)
            base_prediction = delta, reward, confidence, uncertainty
        probability, effect_confidence, effect_variance = self.effect_prediction(game, features, index, parameters)
        if effect_confidence < 0.07:
            return self.calibrated_world_prediction(game, index, base_prediction, features, parameters)
        delta, expected_reward, model_confidence, uncertainty = base_prediction
        adjusted = 1.0 - effect_confidence * (1.0 - probability)
        passive, passive_trust, passive_error = self.passive_world_prediction(game, features)
        next_delta = [a * adjusted + b * (1.0 - adjusted) * passive_trust
                      for a, b in zip(delta, passive)]
        confidence = model_confidence * (1.0 - 0.4 * effect_confidence * (1.0 - probability))
        if passive_trust:
            confidence = max(confidence, (1.0 - adjusted) * passive_trust * 0.65)
        return self.calibrated_world_prediction(game, index,
            (next_delta,
             expected_reward * adjusted - 0.018 * (1.0 - adjusted),
             min(0.90, max(0.0, confidence)),
             min(1.0, uncertainty + 0.36 * effect_confidence * effect_variance
                 + 0.14 * (1.0 - adjusted) * passive_error)), features, parameters)
    def train_world_network(self, game, index, features, parameters, changes, reward, confidence):
        if (len(features) < WORLD_FEATURE_COUNT or len(changes) < WORLD_FEATURE_COUNT or confidence < 0.2
                or not math.isfinite(float(reward))
                or not all(math.isfinite(float(value)) for value in changes[:WORLD_FEATURE_COUNT])):
            return None
        weights = game.ensure_world_network()
        values = self.world_input(features, index, parameters)
        target = [max(-0.8, min(0.8, float(change))) for change in changes[:WORLD_FEATURE_COUNT]]
        target.append(max(-1.0, min(1.0, float(reward))))
        rate = min(0.90, max(0.20, confidence))
        sample_number = game.world_network_steps + 1
        primary_update = ((sample_number * 17 + index * 7) % 11) != 0
        alternate_update = ((sample_number * 13 + index * 5) % 11) != 1
        if self.np is not None:
            x = self.np.asarray(values, dtype=self.np.float32)
            y = self.np.asarray(target, dtype=self.np.float32)
            hidden = self.np.tanh(weights['w1'] @ x + weights['b1'])
            alt_hidden = self.np.tanh(weights['w1_alt'] @ x + weights['b1_alt'])
            output = weights['w2'] @ hidden + weights['b2']
            alt_output = weights['w2_alt'] @ alt_hidden + weights['b2_alt']
            importance = self.np.asarray(WORLD_IMPORTANCE, dtype=self.np.float32)
            error = float(self.np.sum(importance * self.np.abs(y[:WORLD_FEATURE_COUNT]
                                   - 0.5 * (output[:WORLD_FEATURE_COUNT] + alt_output[:WORLD_FEATURE_COUNT]))) / WORLD_IMPORTANCE_SUM)
            if primary_update:
                residual = self.np.clip(y - output, -0.5, 0.5)
                residual[:WORLD_FEATURE_COUNT] *= importance / (WORLD_IMPORTANCE_SUM / WORLD_FEATURE_COUNT)
                gradient = self.np.clip((weights['w2'].T @ residual) * (1.0 - hidden * hidden), -0.5, 0.5)
                weights['w2'] += self.np.outer(residual, hidden) * (0.014 * rate)
                weights['b2'] += residual * (0.014 * rate)
                weights['w1'] += self.np.outer(gradient, x) * (0.0011 * rate)
                weights['b1'] += gradient * (0.0011 * rate)
            if alternate_update:
                residual = self.np.clip(y - alt_output, -0.5, 0.5)
                residual[:WORLD_FEATURE_COUNT] *= importance / (WORLD_IMPORTANCE_SUM / WORLD_FEATURE_COUNT)
                gradient = self.np.clip((weights['w2_alt'].T @ residual) * (1.0 - alt_hidden * alt_hidden), -0.5, 0.5)
                weights['w2_alt'] += self.np.outer(residual, alt_hidden) * (0.012 * rate)
                weights['b2_alt'] += residual * (0.012 * rate)
                weights['w1_alt'] += self.np.outer(gradient, x) * (0.0010 * rate)
                weights['b1_alt'] += gradient * (0.0010 * rate)
            for name in weights:
                self.np.clip(weights[name], -1.0, 1.0, out=weights[name])
        else:
            hidden = [math.tanh(sum(a * b for a, b in zip(row, values)) + weights['b1'][j]) for j, row in enumerate(weights['w1'])]
            alt_hidden = [math.tanh(sum(a * b for a, b in zip(row, values)) + weights['b1_alt'][j]) for j, row in enumerate(weights['w1_alt'])]
            output = [sum(a * b for a, b in zip(row, hidden)) + weights['b2'][j] for j, row in enumerate(weights['w2'])]
            alt_output = [sum(a * b for a, b in zip(row, alt_hidden)) + weights['b2_alt'][j] for j, row in enumerate(weights['w2_alt'])]
            error = self.world_error(target[:WORLD_FEATURE_COUNT],
                                     [0.5 * (b + c) for b, c in zip(output[:WORLD_FEATURE_COUNT], alt_output[:WORLD_FEATURE_COUNT])])
            for enabled, suffix, representation, predictions, lr, hidden_lr in (
                    (primary_update, '', hidden, output, 0.014, 0.0011),
                    (alternate_update, '_alt', alt_hidden, alt_output, 0.012, 0.0010)):
                if not enabled:
                    continue
                w1, b1 = weights['w1' + suffix], weights['b1' + suffix]
                w2, b2 = weights['w2' + suffix], weights['b2' + suffix]
                residual = [max(-0.5, min(0.5, a - b)) * (WORLD_IMPORTANCE[i] / (WORLD_IMPORTANCE_SUM / WORLD_FEATURE_COUNT) if i < WORLD_FEATURE_COUNT else 1.0) for i, (a, b) in enumerate(zip(target, predictions))]
                gradient = [max(-0.5, min(0.5, sum(w2[i][j] * residual[i] for i in range(WORLD_FEATURE_COUNT + 1)) * (1.0 - representation[j] ** 2))) for j in range(WORLD_NETWORK_HIDDEN)]
                for i, row in enumerate(w2):
                    for j in range(WORLD_NETWORK_HIDDEN):
                        row[j] = max(-1.0, min(1.0, row[j] + lr * rate * residual[i] * representation[j]))
                    b2[i] = max(-1.0, min(1.0, b2[i] + lr * rate * residual[i]))
                for j, row in enumerate(w1):
                    for k, value in enumerate(values):
                        row[k] = max(-1.0, min(1.0, row[k] + hidden_lr * rate * gradient[j] * value))
                    b1[j] = max(-1.0, min(1.0, b1[j] + hidden_lr * rate * gradient[j]))
        game.world_network_steps = min(100000000, game.world_network_steps + 1)
        game.world_action_samples[index] = min(100000000, game.world_action_samples[index] + 1)
        adapt = min(0.12, 1.0 / max(1, game.world_network_steps))
        game.world_network_error = (1.0 - adapt) * game.world_network_error + adapt * max(0.0, min(1.0, error))
        return error

    def plan_error_estimate(self, game, index, scene=None):
        records = []
        for key in ((str(scene) + ':' + str(index)) if scene else None, str(index)):
            record = game.plan_error_stats.get(key) if key is not None else None
            if record is not None and record[0] >= 3:
                records.append(record)
        if not records:
            return game.prediction_error_mean, math.sqrt(max(0.00004, game.prediction_error_variance)), 0
        record = records[0]
        count = max(1, int(record[0]))
        return float(record[1]), math.sqrt(max(0.00004, float(record[2]))), count

    def plan_prediction_failed(self, expected, observed, action_index=None, origin_signature=None):
        if expected is None:
            return False
        if not observed.valid or not observed.quality.get('trainable', False):
            return True
        actual_state = self.world_state(observed)
        error = self.world_error(expected, actual_state)
        game = self.game
        if game.prediction_error_samples >= 6:
            spread = math.sqrt(max(0.0, game.prediction_error_variance))
            threshold = max(0.055, min(0.19, game.prediction_error_mean + 2.2 * spread + 0.02))
        else:
            threshold = 0.11
        if action_index is not None and 0 <= action_index < len(self.actions):
            local_mean, local_spread, local_count = self.plan_error_estimate(game, action_index, origin_signature)
            if local_count >= 4:
                threshold = max(0.055, min(0.19, 0.55 * threshold + 0.45 * (local_mean + 2.0 * local_spread + 0.01)))
        failed = error > threshold or error > 0.19
        if math.isfinite(error):
            n = game.prediction_error_samples + 1
            update = min(0.09, 1.0 / n)
            deviation = error - game.prediction_error_mean
            game.prediction_error_mean += update * deviation
            game.prediction_error_variance = max(0.00004, (1.0 - update) * game.prediction_error_variance + update * deviation * deviation)
            game.prediction_error_samples = min(n, 1000000)
            if action_index is not None and 0 <= action_index < len(self.actions):
                for key in dict.fromkeys((str(action_index), str(origin_signature) + ':' + str(action_index) if origin_signature else str(action_index))):
                    record = game.plan_error_stats.get(key, [0, 0.11, 0.0009])
                    count = max(0, int(record[0])) + 1
                    gain = min(0.12, 1.0 / count)
                    difference = error - record[1]
                    record[1] += gain * difference
                    record[2] = max(0.00004, (1.0 - gain) * record[2] + gain * difference * difference)
                    record[0] = min(1000000, count)
                    game.plan_error_stats[key] = record
                    game.plan_error_stats.move_to_end(key)
                while len(game.plan_error_stats) > 1200:
                    game.plan_error_stats.popitem(last=False)
                self.dirty_games.add(self.game_key)
                self.dirty_sequence += 1
        return failed

    @staticmethod
    def plan_feedback_mismatch(decision, evidence):
        if not isinstance(decision, dict) or not isinstance(evidence, dict):
            return False
        if evidence.get('action_effect_observation') != 0.0:
            return False
        try:
            confidence = float(evidence.get('action_effect_observation_confidence') or 0.0)
            expected = float(decision.get('effect_probability') or 0.0)
            reliability = float(decision.get('effect_confidence') or 0.0)
        except (ValueError, TypeError, OverflowError):
            return False
        return (all(math.isfinite(value) for value in (confidence, expected, reliability))
                and confidence >= 0.68 and expected >= 0.68 and reliability >= 0.42)

    def action_applicability(self, game, obs, index, state_key=None):
        record = self.applicability_record(game, obs, index)
        if record is None or record[0] < 2:
            return 1.0
        count, effect, reward, failure = record
        certainty = min(1.0, count / 9.0)
        desirability = max(-0.6, min(0.6, float(reward)))
        factor = 1.0 + certainty * (0.80 * effect + 1.20 * desirability - 0.85 * failure)
        return max(0.25, min(1.8, factor))

    @staticmethod
    def binary_information_gain(alpha, beta):
        alpha, beta = max(0.1, float(alpha)), max(0.1, float(beta))
        size = alpha + beta
        probability = alpha / size
        def entropy(value):
            value = max(1e-9, min(1.0 - 1e-9, value))
            return -value * math.log(value) - (1.0 - value) * math.log(1.0 - value)
        future_positive = (alpha + 1.0) / (size + 1.0)
        future_negative = alpha / (size + 1.0)
        return max(0.0, entropy(probability) - probability * entropy(future_positive)
                   - (1.0 - probability) * entropy(future_negative))

    @staticmethod
    def control_probability_interval(posterior):
        alpha, beta = max(1.0, float(posterior[0])), max(1.0, float(posterior[1]))
        total = alpha + beta
        mean = alpha / total
        deviation = math.sqrt(alpha * beta / (total * total * (total + 1.0)))
        return max(0.0, mean - 1.45 * deviation), min(1.0, mean + 1.45 * deviation)

    def transfer_intent_evidence(self, game, index):
        posterior = game.control_posteriors[index]
        if float(posterior[0]) + float(posterior[1]) >= 7.0:
            return 0.0
        intent = self.action_intents[index]
        if intent.startswith('keyboard:'):
            return 0.0
        source_evidence = []
        for other in self.games.values():
            if other is game or other.game_steps < 24:
                continue
            candidates = self.intent_actions.get(intent, ())
            samples = [(max(0.0, other.control_posteriors[i][0] + other.control_posteriors[i][1] - 2.0), i)
                       for i in candidates]
            if not samples:
                continue
            count, best = max(samples)
            if count < 8.0:
                continue
            alpha, beta = other.control_posteriors[best]
            probability = max(0.0, min(1.0, (alpha - 1.0) / count))
            source_evidence.append((probability, min(1.0, count / 32.0)))
        if not source_evidence:
            return 0.0
        total_weight = sum(weight for _, weight in source_evidence)
        center = sum(probability * weight for probability, weight in source_evidence) / max(0.001, total_weight)
        disagreement = sum(weight * (probability - center) ** 2 for probability, weight in source_evidence) / max(0.001, total_weight)
        trust = min(1.0, total_weight / 2.5) * max(0.0, 1.0 - disagreement * 4.0)
        return max(-0.065, min(0.065, 0.13 * trust * (center - 0.5)))

    def exploration_stage(self, game, obs):
        context = self.experiment_context(obs)
        family_attempts = {family: 0 for family in self.action_families}
        intent_evidence = {}
        family_seen = set()
        local_attempts = 0
        reliable_intents = set()
        unresolved = 0
        measured = 0
        for index, family in enumerate(self.family_for_action):
            record = game.action_applicability.get(context + ':' + str(index))
            if record is None:
                continue
            count, effect, _, failure = record
            count = max(0, int(count))
            family_attempts[family] += count
            local_attempts += count
            if count:
                family_seen.add(family)
            posterior = game.control_posteriors[index]
            observed = max(0.0, float(posterior[0]) + float(posterior[1]) - 2.0)
            if observed < 1.5 or count < 2:
                unresolved += 1
                continue
            lower, upper = self.control_probability_interval(posterior)
            intent = self.action_intents[index]
            existing = intent_evidence.get(intent)
            estimate = (lower, upper, count)
            if existing is None or lower > existing[0]:
                intent_evidence[intent] = estimate
            measured += 1
            if lower > 0.48 and effect >= 0.18 and failure <= 0.52:
                reliable_intents.add(intent)
        if len(family_seen) < 2 or (not measured and local_attempts < 12):
            return 'discovery', family_attempts
        uncertain = sum(1 for low, high, n in intent_evidence.values()
                        if high - low > 0.42 and n < 16)
        if (len(reliable_intents) < 2 or len(family_seen) < 3
                or (uncertain > max(2, len(reliable_intents)) and local_attempts < 90)
                or (game.stagnation >= 15 and unresolved > 0)):
            return 'causal', family_attempts
        return 'policy', family_attempts

    def discovery_guidance(self, game, obs, phase, family_attempts):
        context = self.experiment_context(obs)
        kind_evidence = {}
        family_evidence = {}
        confirmed_intents = set()
        for index, action in enumerate(self.actions):
            local = game.action_applicability.get(context + ':' + str(index))
            posterior = game.control_posteriors[index]
            attempts = max(0.0, float(posterior[0]) + float(posterior[1]) - 2.0)
            if local is not None:
                attempts = max(attempts, float(local[0]))
            probability = ((float(posterior[0]) - 1.0) / max(1.0, attempts)) if attempts >= 2.0 else 0.5
            if local is not None and local[0] >= 2:
                probability = 0.55 * probability + 0.45 * max(0.0, min(1.0, float(local[1])))
            confidence = min(1.0, attempts / 9.0)
            if attempts >= 4 and probability >= 0.62:
                confirmed_intents.add(self.action_intents[index])
            for mapping, label in ((kind_evidence, action.kind), (family_evidence, self.family_for_action[index])):
                row = mapping.setdefault(label, [0.0, 0.0, 0.0])
                row[0] += confidence * (probability - 0.5)
                row[1] += confidence
                row[2] += min(10.0, attempts)
        guided = []
        for index, action in enumerate(self.actions):
            family = self.family_for_action[index]
            group = family_evidence.get(family, [0.0, 0.0, 0.0])
            kind = kind_evidence.get(action.kind, [0.0, 0.0, 0.0])
            local = game.action_applicability.get(context + ':' + str(index))
            local_count = max(0, int(local[0])) if local else 0
            intent = self.action_intents[index]
            basics = action.kind in ('key', 'hold', 'click', 'focus_click', 'touch_tap', 'move', 'wheel')
            compound = action.kind in ('chord', 'pair_hold', 'move_fire', 'dual_touch', 'pinch', 'combat')
            known = len(confirmed_intents)
            score = (0.12 if phase == 'discovery' and basics else
                     -0.14 if phase == 'discovery' and compound else 0.0)
            if phase == 'causal':
                score += 0.08 if basics else 0.045 if compound and known else 0.0
            if phase != 'policy' and compound and not known:
                score -= 0.045
            if phase != 'policy' and intent in confirmed_intents:
                score += 0.10 if local_count <= 3 else 0.0
            if group[1] >= 1.0:
                score += 0.12 * (group[0] / group[1]) * min(1.0, group[1] / 4.0)
            if kind[1] >= 1.0:
                score += 0.08 * (kind[0] / kind[1]) * min(1.0, kind[1] / 4.0)
            score += 0.08 / math.sqrt(1.0 + family_attempts.get(family, 0))
            if local_count >= 3 and local is not None and local[3] > 0.70 and local[1] < 0.08:
                score -= 0.18 * min(1.0, local_count / 8.0)
            if phase != 'policy' and action.kind in ('chord', 'pair_hold', 'move_fire'):
                for key in (action.a, action.b):
                    if key and ('keyboard:' + action.kind + ':' + str(key)) in confirmed_intents:
                        score += 0.025
            guided.append(score)
        return guided

    def contrastive_probe_bonus(self, game, obs, index, phase):
        if phase == 'policy':
            return 0.0
        action = self.actions[index]
        context = self.experiment_context(obs)
        local = game.action_applicability.get(context + ':' + str(index))
        local_trials = int(local[0]) if local else 0
        bonus = 0.0
        if index in self.probe_representatives:
            bonus += (0.16 if phase == 'discovery' else 0.07) / math.sqrt(1.0 + local_trials)
        reverse = {87: 83, 83: 87, 65: 68, 68: 65, 38: 40, 40: 38,
                   37: 39, 39: 37}
        if action.kind not in ('key', 'hold') or action.a not in reverse:
            return bonus
        opposite_index = self.action_index.get(f'{action.kind}:{reverse[action.a]}')
        if opposite_index is None:
            return bonus
        other = game.action_applicability.get(context + ':' + str(opposite_index))
        other_trials = int(other[0]) if other else 0
        if other_trials >= 2 and local_trials < other_trials:
            posterior = game.control_posteriors[opposite_index]
            evidence = max(0.0, float(posterior[0]) + float(posterior[1]) - 2.0)
            bonus += 0.19 * min(1.0, evidence / 6.0) / math.sqrt(1.0 + local_trials)
        profile_a = game.control_profiles.get(action.id)
        profile_b = game.control_profiles.get(self.actions[opposite_index].id)
        if profile_a and profile_b and min(profile_a[5], profile_b[5]) >= 3:
            magnitude_a = math.hypot(profile_a[0], profile_a[1])
            magnitude_b = math.hypot(profile_b[0], profile_b[1])
            if min(magnitude_a, magnitude_b) >= 0.004:
                directional = (profile_a[0] * profile_b[0] + profile_a[1] * profile_b[1]) / (magnitude_a * magnitude_b)
                if directional > 0.35:
                    bonus += 0.05 / math.sqrt(1.0 + local_trials)
        return min(0.35, bonus)

    def experiment_scores(self, game, obs, phase, family_attempts):
        state_key = self.experiment_context(obs)
        trials = max(1, int(game.visits.get(obs.signature, 1)))
        familiar_scene = math.log1p(trials + 1.0)
        menu = max(min(1.0, sum(float(item.get('temporal_confidence', item.get('confidence', 0.0)))
                            for item in obs.ui_text[:8]) / 2.5),
                   obs.phase_confidence if obs.phase == 'menu' else 0.0)
        movement = max(min(1.0, sum(float(item.get('activity', 0.0)) for item in obs.objects[:12]) / 3.0),
                       0.65 * obs.phase_confidence if obs.phase == 'playing' else 0.0)
        scores = []
        guidance = self.discovery_guidance(game, obs, phase, family_attempts)
        for i, action in enumerate(self.actions):
            record = game.action_applicability.get(state_key + ':' + str(i))
            count, effect, reward, failure = record if record is not None else (0, 0.0, 0.0, 0.0)
            uncertain = math.sqrt(familiar_scene / (1.0 + 1.8 * count + 0.12 * game.counts[i]))
            family = self.family_for_action[i]
            family_diversity = 1.0 / math.sqrt(1.0 + family_attempts.get(family, 0) / 4.0)
            learned = game.world_action_samples[i]
            model_disagreement = game.world_action_errors[i] if learned else 0.13
            effect_prob, effect_confidence, outcome_variance = self.effect_prediction(game, obs, i)
            alpha, beta = game.control_posteriors[i]
            effect_information = self.binary_information_gain(alpha, beta)
            information_value = (0.22 * math.sqrt(max(0.0, outcome_variance)) * (1.0 - 0.6 * effect_confidence)
                                 + 0.42 * effect_information)
            action_seconds = max(0.07, min(1.5, float(action.duration) + 0.08 + game.feedback_delay))
            information_value *= 0.55 + 0.45 * math.sqrt(0.32 / action_seconds)
            if count < 4:
                neighbor_evidence = 0.0
                for other in self.experiment_relatives[i]:
                    alpha, beta = game.control_posteriors[other]
                    evidence_count = max(0.0, alpha + beta - 2.0)
                    if evidence_count >= 3:
                        success = max(0.0, alpha - 1.0) / evidence_count
                        neighbor_evidence = max(neighbor_evidence, min(1.0, evidence_count / 8.0)
                                                * (0.30 + 0.70 * abs(success - 0.5) * 2.0))
                information_value += (0.062 if phase == 'discovery' else 0.035) * neighbor_evidence / (1.0 + count)
            reliable_effect = min(1.0, count / 5.0) * (0.82 * effect + 0.18 * max(-1.0, min(1.0, reward)))
            directional_gain = (0.24 * game.action_goal[i] * min(1.0, game.action_goal_samples[i] / 7.0))
            context = (0.14 * menu if family == 'pointer' else 0.10 * movement if family in ('keyboard', 'navigation') else 0.04 * movement)
            result = (0.16 * math.log1p(max(0.001, action.prior)) + 0.30 * uncertain
                      + 0.17 * family_diversity + 0.13 * reliable_effect + directional_gain + context + information_value
                      + 0.07 * min(1.0, model_disagreement * 4.0) / math.sqrt(1 + learned)
                      - 0.31 * failure * min(1.0, count / 4.0)
                      - 0.07 * count / (count + 3.0)
                      - 0.018 * min(1.0, max(0.0, float(action.duration)) / 0.9))
            if phase == 'causal':
                result += 0.12 * reliable_effect + 0.03 * max(-0.5, reward)
            if count >= 4 and effect_confidence >= 0.22:
                result -= 0.12 * (1.0 - effect_prob) * effect_confidence
            if count < 3:
                intent = self.action_intents[i]
                related = self.intent_actions.get(intent, [])
                peer = 0.0
                peer_samples = 0.0
                for relative in related:
                    if relative == i:
                        continue
                    local_peer = game.action_applicability.get(state_key + ':' + str(relative))
                    if local_peer is not None and local_peer[0] >= 2:
                        quantity = min(12.0, float(local_peer[0]))
                        peer += quantity * (max(0.0, min(1.0, float(local_peer[1])))
                                            - 0.65 * max(0.0, min(1.0, float(local_peer[3]))))
                        peer_samples += quantity
                if peer_samples >= 2.0:
                    result += 0.085 * min(1.0, peer_samples / 10.0) * (peer / peer_samples)
            posterior = game.control_posteriors[i]
            proven_count = max(0.0, posterior[0] + posterior[1] - 2.0)
            if proven_count >= 2.0:
                proven_effect = (posterior[0] - 1.0) / max(0.001, proven_count)
                result += 0.18 * min(1.0, proven_count / 10.0) * (proven_effect - 0.50)
            if count >= 3 and failure >= 0.65 and effect <= 0.06:
                result -= 0.11 * min(1.0, count / 9.0) * failure
            family_probability, family_trust = self.hierarchical_control_prediction(game, obs, i)
            result += 0.19 * family_trust * (family_probability - 0.5)
            result += 0.035 * self.inverse_intent_confidence(game, i)
            result += self.transfer_intent_evidence(game, i)
            result += self.intent_value(game, state_key, i)
            if phase != 'policy' and count < 6 and self.experiment_relatives[i]:
                neighboring = [game.action_applicability.get(state_key + ':' + str(j)) for j in self.experiment_relatives[i]]
                comparisons = sum(record is not None and record[0] >= 3 for record in neighboring)
                result += 0.042 * min(1.0, comparisons / 2.0) / math.sqrt(1.0 + count)
            if family == 'pointer' and (obs.ui_text or obs.phase == 'menu'):
                result += 0.07 * menu
            scores.append(result + guidance[i] + self.contrastive_probe_bonus(game, obs, i, phase))
        return scores

    def select_experiment(self, game, obs, phase, family_attempts):
        estimates = self.experiment_scores(game, obs, phase, family_attempts)
        state_key = self.experiment_context(obs)
        candidates = set(sorted(range(len(estimates)), key=estimates.__getitem__, reverse=True)[:84])
        if phase == 'discovery':
            for representative in self.probe_representatives:
                prior = game.action_applicability.get(state_key + ':' + str(representative))
                if prior is None or int(prior[0]) < 3:
                    candidates.add(representative)
        elif phase == 'causal':
            candidates.update(sorted(self.probe_representatives,
                                     key=lambda i: estimates[i], reverse=True)[:12])
        for family, indices in self.action_families.items():
            candidates.add(max(indices, key=estimates.__getitem__))
        for (family, kind), indices in self.action_kinds.items():
            candidates.add(max(indices, key=estimates.__getitem__))
            if phase == 'discovery' and kind in ('key', 'hold', 'click', 'focus_click', 'move', 'wheel', 'touch_tap', 'swipe'):
                unexplored = [i for i in indices if game.action_effect_samples[i] < 2]
                if unexplored:
                    representative = max(unexplored, key=lambda i: estimates[i]
                        + 0.10 * math.log1p(max(0.0, self.actions[i].prior))
                        - 0.07 * game.action_attempts[i])
                    candidates.add(representative)
                    game.diagnostics['active_experiment_families'] += 1
        top = max(estimates)
        winner, best = None, -1e20
        for index in candidates:
            alpha, beta = game.control_posteriors[index]
            global_draw = self.rng.betavariate(max(0.1, alpha), max(0.1, beta))
            local = game.action_applicability.get(state_key + ':' + str(index))
            if local is not None and local[0] > 0:
                count, effect, _, failure = local
                successes = max(0.0, min(float(count), float(count) * (1.0 - failure) * max(0.0, effect)))
                local_draw = self.rng.betavariate(1.0 + successes, 1.0 + max(0.0, count - successes))
                sampled = (0.57 * local_draw + 0.43 * global_draw) if count >= 3 else 0.30 * local_draw + 0.70 * global_draw
            else:
                sampled = global_draw
            curiosity = 0.31 if phase == 'discovery' else 0.20 if phase == 'causal' else 0.11
            effect_p, effect_c, effect_v = self.effect_prediction(game, obs, index)
            diagnostic = self.rng.betavariate(1.0 + effect_p * effect_c * 5.0,
                                             1.0 + (1.0 - effect_p) * effect_c * 5.0)
            related = self.experiment_relatives[index]
            proven_alternatives = sum(1 for other in related
                                      if game.action_applicability.get(state_key + ':' + str(other), [0])[0] >= 3)
            local_visits = 0 if local is None else int(local[0])
            comparison = min(0.055, 0.015 * proven_alternatives) / (1.0 + local_visits * 0.7)
            action = self.actions[index]
            latency = game.feedback_latency_by_kind.get(action.kind, [game.feedback_delay])[0]
            estimated_seconds = max(0.07, min(2.5, float(action.duration) + float(latency) + 0.06))
            information = (self.binary_information_gain(alpha, beta) + 0.7 * math.sqrt(max(0.0, effect_v)))
            information_per_second = min(0.35, information / math.sqrt(estimated_seconds + 0.12))
            learned_goal = max(-1.0, min(1.0, game.action_goal[index]))
            goal_trust = min(1.0, game.action_goal_samples[index] / 9.0)
            family = self.family_for_action[index]
            representative = (family_attempts.get(family, 0) < 5
                              and action.kind in ('key', 'hold', 'click', 'focus_click', 'move', 'wheel', 'touch_tap', 'swipe'))
            risk = max(0.0, game.world_action_errors[index] - 0.10) if game.world_action_samples[index] >= 5 else 0.0
            utility = (estimates[index] + comparison + curiosity * (sampled - 0.5)
                       + 0.10 * (diagnostic - 0.5) + (0.25 if phase == 'discovery' else 0.12) * information_per_second
                       + 0.13 * goal_trust * learned_goal * (0.30 + 0.70 * effect_p)
                       + (0.085 if phase == 'discovery' else 0.025) * float(representative)
                       + self.rng.random() * 0.015)
            utility -= 0.06 * max(0.0, top - estimates[index] - 0.08)
            utility -= 0.065 * math.log1p(estimated_seconds / 0.25) + 0.05 * risk
            if utility > best:
                winner, best = index, utility
        return winner if winner is not None else max(range(len(estimates)), key=estimates.__getitem__)

    def decision_diagnostics(self, obs, index, parameters=None, plan_length=1, predicted=False):
        game = self.game
        action = self.actions[index]
        phase, attempts = self.exploration_stage(game, obs)
        probability, confidence, variance = self.effect_prediction(game, obs, index, parameters)
        goal_samples = game.action_goal_samples[index]
        goal_value = max(-1.0, min(1.0, game.action_goal[index]))
        expected_seconds = max(0.07, min(3.0, action.duration + game.feedback_latency_by_kind.get(action.kind, [game.feedback_delay])[0] + 0.06))
        model = None
        if (game.world_action_samples[index] >= 2 or game.world_network_steps >= 25 or game.world) and self.step % 4 == 0:
            model = self.world_prediction(game, index, obs, parameters)
        source = ('transfer_skill' if self.last_skill_source is not None and self.last_skill_source != self.game_key
                  else 'learned_skill' if self.last_skill_source is not None
                  else 'world_model_plan' if predicted else 'adaptive_exploration')
        evidence = ('trusted_effect' if confidence >= 0.55
                    else 'uncertain_effect' if confidence >= 0.15 else 'cold_start')
        return {'selection': source, 'phase': phase, 'action_family': self.family_for_action[index],
                'action_kind': action.kind, 'evidence': evidence,
                'effect_probability': round(probability, 4), 'effect_confidence': round(confidence, 4),
                'effect_uncertainty': round(variance, 4),
                'goal_estimate': round(goal_value, 4), 'goal_samples': goal_samples,
                'estimated_feedback_seconds': round(expected_seconds, 3),
                'family_trials': attempts.get(self.family_for_action[index], 0),
                'planned_steps': plan_length,
                'world_confidence': round(float(model[2]), 4) if model else None,
                'world_uncertainty': round(float(model[3]), 4) if model else None,
                'skill_source': self.last_skill_source if self.last_skill_source != self.game_key else None}

    def adaptive_exploration(self, game, obs):
        phase, family_attempts = self.exploration_stage(game, obs)
        coverage = sum(count >= 3 for count in game.counts) / max(1, len(game.counts))
        success_rate = game.plan_success[1] / max(1, game.plan_success[0])
        uncertainty = min(1.0, max(0.0, self.td_error_ema * 3.0))
        stagnation = min(1.0, game.stagnation / 28.0)
        rate = (0.10 + 0.14 * obs.novelty + 0.16 * stagnation + 0.11 * uncertainty
                + 0.08 * (1.0 - coverage) - 0.07 * success_rate)
        rate += 0.12 if phase == 'discovery' else 0.055 if phase == 'causal' else -0.025
        return max(0.035, min(0.58, rate))

    def update_action_applicability(self, game, obs, index, reward):
        signal = self.reward_info
        if not (signal.get('input_was_sent') and int(signal.get('feedback_samples') or 0) >= 2
                and float(signal.get('observation_confidence') or 0.0) >= 0.53
                and float(signal.get('scene_stability') or 0.0) >= 0.48):
            return
        observation = signal.get('action_effect_observation')
        control_known = observation == 0.0 or observation == 1.0
        objective_known = (bool(signal.get('goal_direction_evidence')) and
                           float(signal.get('objective_evidence_confidence') or 0.0) >= 0.28)
        if not control_known and not objective_known:
            return
        causal = max(0.0, min(1.0, float(signal.get('causal_confidence') or 0.0)))
        weight = max(0.1, min(1.0, float(signal.get('action_effect_observation_confidence') or 0.0)))
        posterior = game.control_posteriors[index]
        if observation == 1.0:
            posterior[0] = min(1000000.0, posterior[0] + weight)
        elif observation == 0.0:
            posterior[1] = min(1000000.0, posterior[1] + weight)
        if control_known:
            family, kind = self.family_for_action[index], self.actions[index].kind
            context = self.experiment_context(obs)
            for key in (context + ':f:' + family, context + ':k:' + kind,
                        'f:' + family, 'k:' + family + ':' + kind):
                record = game.hierarchical_controls.get(key, [1.0, 1.0, 0])
                record[0 if observation == 1.0 else 1] = min(1000000.0,
                    record[0 if observation == 1.0 else 1] + weight)
                record[2] = min(1000000, int(record[2]) + 1)
                game.hierarchical_controls[key] = record
                game.hierarchical_controls.move_to_end(key)
            while len(game.hierarchical_controls) > 2800:
                game.hierarchical_controls.popitem(last=False)
            game.diagnostics['hierarchical_effect_updates'] += 1
        failure = float(observation == 0.0)
        for key in (self.state_signature(obs) + ':' + str(index),
                    self.experiment_context(obs) + ':' + str(index)):
            old = game.action_applicability.get(key, [0, 0.0, 0.0, 0.0])
            count = min(1000000, old[0] + 1)
            rate = 1.0 / min(24, count)
            if control_known:
                old[1] += rate * ((causal if observation == 1.0 else 0.0) - old[1])
                old[3] += rate * (failure - old[3])
            if objective_known:
                directional = max(-1.0, min(1.0, float(signal.get('goal_signal') or 0.0)))
                old[2] += rate * (directional - old[2])
            old[0] = count
            game.action_applicability[key] = old
            game.action_applicability.move_to_end(key)
        while len(game.action_applicability) > 8000:
            game.action_applicability.popitem(last=False)

    @staticmethod
    def dual_value_input(observation):
        features = observation.features if hasattr(observation, 'features') else observation
        return [max(-1.0, min(1.0, float(features[index]))) for index in DUAL_VALUE_INDICES]

    def update_dual_values(self, game, observation, index, effect=None, control_confidence=0.0,
                           objective=None, objective_confidence=0.0):
        values = self.dual_value_input(observation)
        norm = 1.0 + sum(value * value for value in values) / 8.0
        changed = False
        for kind, target, confidence in (('control', effect, control_confidence),
                                         ('objective', objective, objective_confidence)):
            if target is None or not math.isfinite(float(target)) or confidence < 0.22:
                continue
            matrix = getattr(game, kind + '_head')
            biases = getattr(game, kind + '_head_bias')
            samples = getattr(game, kind + '_head_samples')
            previous = matrix[index]
            if self.np is not None:
                inputs = self.np.asarray(values, dtype=self.np.float32)
                prediction = math.tanh(float(previous @ inputs + biases[index]))
            else:
                prediction = math.tanh(sum(a * b for a, b in zip(previous, values)) + biases[index])
            rate = 0.22 * min(1.0, confidence) / (1.0 + samples[index] / 4500.0)
            residual = max(-1.5, min(1.5, float(target) - prediction))
            gradient = rate * residual * (1.0 - prediction * prediction) / norm
            if self.np is not None:
                matrix[index] = self.np.clip(previous + inputs * gradient, -1.0, 1.0)
            else:
                matrix[index] = [max(-1.0, min(1.0, a + b * gradient)) for a, b in zip(previous, values)]
            biases[index] = max(-1.0, min(1.0, float(biases[index]) + gradient * 0.48))
            samples[index] = min(1000000000, samples[index] + 1)
            game.diagnostics[kind + '_head_updates'] += 1
            changed = True
        if changed:
            self.dirty_games.add(self.game_key)
            self.dirty_sequence += 1
        return changed

    def dual_value_scores(self, game, observation):
        values = self.dual_value_input(observation)
        if self.np is not None:
            x = self.np.asarray(values, dtype=self.np.float32)
            control = self.np.tanh(game.control_head @ x + game.control_head_bias).tolist()
            objective = self.np.tanh(game.objective_head @ x + game.objective_head_bias).tolist()
        else:
            control = [math.tanh(sum(a * b for a, b in zip(row, values)) + game.control_head_bias[i])
                       for i, row in enumerate(game.control_head)]
            objective = [math.tanh(sum(a * b for a, b in zip(row, values)) + game.objective_head_bias[i])
                         for i, row in enumerate(game.objective_head)]
        mature = min(1.0, (game.goal_value_samples + sum(game.objective_head_samples) / max(1, len(self.actions))) / 12.0)
        objective_weight = 0.08 + 0.30 * mature
        control_weight = 0.21 - 0.11 * mature
        quality = getattr(observation, 'quality', {'confidence': 1.0})
        visual_confidence = max(0.15, min(1.0, float(quality.get('confidence', 1.0))))
        return [(control_weight * min(1.0, game.control_head_samples[i] / 7.0) * control[i]
                 + objective_weight * min(1.0, game.objective_head_samples[i] / 5.0) * objective[i]) * visual_confidence
                for i in range(len(self.actions))]

    def intent_value(self, game, context, index):
        intent = self.action_intents[index]
        local = game.intent_values.get('c:' + context + ':' + intent)
        global_record = game.intent_values.get('i:' + intent)
        total = 0.0
        for record, weight in ((local, 0.72), (global_record, 0.28)):
            if record is None or len(record) != 4:
                continue
            success, failure, objective, objective_weight = map(float, record)
            observations = success + failure
            trust = min(1.0, observations / (observations + (5.0 if weight > 0.5 else 18.0)))
            probability = (success + 1.0) / (observations + 2.0)
            total += 0.14 * weight * trust * (probability - 0.5)
            if objective_weight >= 0.8:
                certainty = min(1.0, objective_weight / (objective_weight + 6.0))
                total += 0.22 * weight * certainty * max(-1.0, min(1.0, objective / objective_weight))
        return max(-0.16, min(0.16, total))

    def update_intent_values(self, game, obs, index, effect=None, effect_confidence=0.0,
                             objective=None, objective_confidence=0.0):
        if (effect is None or effect_confidence < 0.35) and (objective is None or objective_confidence < 0.36):
            return False
        intent = self.action_intents[index]
        context = self.experiment_context(obs)
        for key, weight in (('i:' + intent, 0.55), ('c:' + context + ':' + intent, 1.0)):
            record = game.intent_values.get(key, [0.0, 0.0, 0.0, 0.0])
            if effect is not None and effect_confidence >= 0.35:
                probability = max(0.0, min(1.0, (float(effect) + 1.0) * 0.5))
                credit = weight * effect_confidence
                record[0] = min(1000000.0, record[0] + credit * probability)
                record[1] = min(1000000.0, record[1] + credit * (1.0 - probability))
            if objective is not None and objective_confidence >= 0.36:
                credit = weight * objective_confidence
                record[2] = max(-1000000.0, min(1000000.0, record[2] + credit * max(-1.0, min(1.0, float(objective)))))
                record[3] = min(1000000.0, record[3] + credit)
            game.intent_values[key] = record
            game.intent_values.move_to_end(key)
        while len(game.intent_values) > 2000:
            game.intent_values.popitem(last=False)
        game.diagnostics['intent_shared_updates'] += 1
        return True

    def predicted_state_scores(self, game, features, roots, root_q, root_dual, observation):
        predicted_q = self._values(features, game)
        if self.np is not None:
            predicted_q = predicted_q.tolist()
        predicted_dual = self.dual_value_scores(game, features)
        context = self.experiment_context(observation)
        scores = [max(-1.5, min(1.5, float(base) + 0.88 * (float(q) - float(root_q[i]))
                  + 0.88 * (float(dual) - float(root_dual[i]))))
                  for i, (base, q, dual) in enumerate(zip(roots, predicted_q, predicted_dual))]
        original_goal = self.goal_value(game, self.goal_value_input(observation.features))
        predicted_goal = self.goal_value(game, self.goal_value_input(features))
        goal_trust = min(1.0, game.goal_value_samples / 9.0)
        goal_delta = max(-0.4, min(0.4, predicted_goal - original_goal))
        for i in range(len(scores)):
            scores[i] += 0.07 * goal_trust * goal_delta * min(1.0, game.action_goal_samples[i] / 5.0)
            scores[i] += self.intent_value(game, context, i) * 0.35
        game.diagnostics['predictive_state_evaluations'] += 1
        return scores

    def scores(self, obs, spatial=True):
        with self.lock:
            game = self.game
            state_key = self.state_signature(obs)
            intent_context = self.experiment_context(obs)
            values = self._values(obs.features, game)
            values = values.tolist() if self.np is not None else values
            if spatial:
                if game.recent:
                    recent = list(game.recent)[-6:]
                    for action_id, previous_features, achieved, signature, detail, semantic, *_ in recent:
                        if signature == obs.signature:
                            similarity = sum(abs(a - b) for a, b in zip(previous_features, obs.features[:18])) / 18.0
                            if achieved <= 0.025 and similarity < 0.08:
                                values[action_id] -= min(0.18, 0.028 + max(0.0, -achieved) * 0.25)
                    if len(recent) >= 3:
                        tail = recent[-3:]
                        if len({record[3] for record in tail}) == 1 and tail[-1][3] == obs.signature:
                            for action_id, _, achieved, _, _, *_ in tail:
                                if achieved < 0.04:
                                    values[action_id] -= 0.035
                visits = max(0, game.visits.get(obs.signature, 0))
                contextual_bonus = math.log1p(visits + 2)
                for i, action in enumerate(self.actions):
                    local_record = self.applicability_record(game, obs, i)
                    attempts = int(local_record[0]) if local_record is not None else 0
                    failure = float(local_record[3]) if local_record is not None and attempts >= 2 else 0.0
                    exploration = 0.073 * math.sqrt(contextual_bonus / (1.0 + 2.2 * attempts + 0.25 * game.counts[i]))
                    exploration *= max(0.15, 1.0 - failure * min(1.0, attempts / 5.0) * 0.84)
                    exploration *= 0.55 + 0.45 * min(1.0, obs.novelty + game.stagnation / 35.0)
                    values[i] += exploration + 0.028 * math.log1p(action.prior)
                    values[i] += 0.16 * (self.action_applicability(game, obs, i, state_key) - 1.0)
                    alpha, beta = game.control_posteriors[i]
                    evidence = max(0.0, alpha + beta - 2.0)
                    if evidence > 0:
                        values[i] += 0.075 * min(1.0, evidence / 8.0) * (alpha / (alpha + beta) - 0.5)
                    statistics = game.category_score.get(action.category)
                    if statistics:
                        values[i] += 0.05 * statistics[1]
                    if game.action_effect_samples[i]:
                        certainty = min(1.0, game.action_effect_samples[i] / 12.0)
                        values[i] += 0.055 * certainty * game.action_effect[i]
                    if game.action_goal_samples[i]:
                        certainty = min(1.0, game.action_goal_samples[i] / 7.0)
                        values[i] += 0.36 * certainty * game.action_goal[i]
                    hierarchy_probability, hierarchy_trust = self.hierarchical_control_prediction(game, obs, i)
                    values[i] += 0.11 * hierarchy_trust * (hierarchy_probability - 0.5)
                    values[i] += 0.025 * self.inverse_intent_confidence(game, i)
                    values[i] += self.transfer_intent_evidence(game, i)
                    values[i] += self.intent_value(game, intent_context, i)
                    repeated = game.repeat_effects.get(self.experiment_context(obs) + ':' + action.id)
                    if repeated is not None and repeated[3] >= 3:
                        attempts = max(0.0, float(repeated[0]) + float(repeated[1]))
                        effectiveness = (float(repeated[0]) + 1.0) / (attempts + 2.0)
                        values[i] += 0.10 * attempts / (attempts + 8.0) * (effectiveness - 0.5)
                    if action.kind in ('click', 'double', 'right', 'middle', 'move'):
                        col = min(GW - 1, max(0, int(action.x * GW)))
                        row = min(GH - 1, max(0, int(action.y * GH)))
                        values[i] += 0.115 * obs.salience[row * GW + col]
                        target = game.targets.get(f'{col}:{row}')
                        if target:
                            values[i] += 0.075 * max(0.0, float(target[0])) * min(1.0, float(target[1]) / 8.0)
                    context = game.context_action.get(state_key + ':' + str(i))
                    if context is not None:
                        n, mean, variance = context
                        values[i] += 0.15 * mean * min(1.0, n / 7.0)
                        values[i] += 0.018 * min(1.0, math.sqrt(max(0.0, variance / max(1, n - 1))) / math.sqrt(n))
                    world = self._world_record(game, i, obs)
                    if world and world[1] >= 4:
                        reliability = min(1.0, world[1] / 25.0) / (1.0 + world[2] * 8.0)
                        expected_effect = max(-0.7, min(0.7, game.action_effect[i]))
                        values[i] += 0.055 * reliability * expected_effect - 0.025 * min(1.0, world[2] * 4.0)
            differentiated = self.dual_value_scores(game, obs)
            return [float(value) + differentiated[i] for i, value in enumerate(values)]

    def choose(self, obs):
        with self.lock:
            game = self.game
            state_key = self.state_signature(obs)
            epsilon = self.adaptive_exploration(game, obs)
            exploration_phase, family_attempts = self.exploration_stage(game, obs)
            menu_evidence = max(min(1.0, sum(float(item.get('temporal_confidence', 0.0)) for item in obs.ui_text[:10]) / 3.0),
                                obs.phase_confidence if obs.phase == 'menu' else 0.0)
            movement_evidence = max(min(1.0, sum(float(item.get('activity', 0.0)) for item in obs.objects[:12]) / 4.0),
                                    0.65 * obs.phase_confidence if obs.phase == 'playing' else 0.0)
            if exploration_phase != 'policy' and self.rng.random() < (0.63 if exploration_phase == 'discovery' else 0.28):
                return self.select_experiment(game, obs, exploration_phase, family_attempts)
            if self.rng.random() < epsilon:
                families = list(self.action_families)
                family_weights = []
                for family in families:
                    indices = self.action_families[family]
                    trials = sum(game.counts[i] for i in indices)
                    effectiveness = game.family_score.get(family, (0, 0.0))[1]
                    contextual = (1.0 + 0.65 * menu_evidence if family == 'pointer' else
                                  1.0 + 0.38 * movement_evidence if family in ('keyboard', 'navigation') else
                                  1.0 + 0.20 * movement_evidence)
                    local_trials = family_attempts[family]
                    diversity = 1.0 + (2.1 if exploration_phase == 'discovery' else 0.85 if exploration_phase == 'causal' else 0.20) / (1.0 + local_trials / 4.0)
                    learned_control = [self.hierarchical_control_prediction(game, obs,
                        self.action_kinds[(family, kind)][0]) for fam, kind in self.action_kinds if fam == family]
                    probability = sum(a * b for a, b in learned_control) / max(0.001, sum(b for _, b in learned_control)) if learned_control else 0.5
                    trust = max((b for _, b in learned_control), default=0.0)
                    family_weights.append(contextual * diversity * max(0.15, 1.0 + effectiveness * 3.0)
                                          * (0.85 + 0.30 * (1.0 - trust + trust * probability))
                                          * (1.0 + math.log1p(len(indices))) / (1.0 + trials / len(indices)) ** 0.55)
                family = self.rng.choices(families, weights=family_weights, k=1)[0]
                kinds = [kind for fam, kind in self.action_kinds if fam == family]
                kind_weights = []
                for kind in kinds:
                    indices = self.action_kinds[(family, kind)]
                    attempts = sum(game.counts[i] for i in indices)
                    effective = sum(game.action_effect[i] for i in indices if game.action_effect_samples[i]) / max(1, sum(bool(game.action_effect_samples[i]) for i in indices))
                    seen = sum((game.action_applicability.get(state_key + ':' + str(i)) or [0])[0] for i in indices)
                    breadth = (1.0 + 1.4 / (1.0 + seen)) if exploration_phase == 'discovery' else 1.0
                    kind_weights.append(breadth * max(0.1, 1.0 + effective * 3.0)
                                        * (1.0 + math.log1p(len(indices))) / (1.0 + attempts / len(indices)) ** 0.5)
                kind = self.rng.choices(kinds, weights=kind_weights, k=1)[0]
                indices = self.action_kinds[(family, kind)]
                weights = []
                for i in indices:
                    action = self.actions[i]
                    factor = 1.0
                    if action.kind in ('click', 'double', 'right', 'middle', 'move'):
                        col = min(GW - 1, max(0, int(action.x * GW)))
                        row = min(GH - 1, max(0, int(action.y * GH)))
                        factor += 2.5 * obs.salience[row * GW + col]
                    effect = max(-0.25, min(0.5, game.action_effect[i]))
                    context = game.context_action.get(state_key + ':' + str(i))
                    n, mean, dispersion = context if context is not None else (0, 0.0, 0.0)
                    uncertainty_bonus = math.sqrt(math.log1p(game.visits.get(obs.signature, 0) + 1) / (1 + n))
                    context_factor = max(0.2, 1.0 + 1.6 * mean + min(1.5, 0.65 * uncertainty_bonus)
                                         + 0.25 * math.sqrt(max(0.0, dispersion / max(1, n - 1))))
                    applicability = self.action_applicability(game, obs, i, state_key)
                    local = self.applicability_record(game, obs, i)
                    local_attempts = int(local[0]) if local is not None else 0
                    ineffective = float(local[3]) if local is not None and local_attempts >= 2 else 0.0
                    repeat_penalty = max(0.12, 1.0 - 0.82 * ineffective * min(1.0, local_attempts / 5.0))
                    novelty_bonus = (1.0 + 0.75 / (1.0 + local_attempts)) if exploration_phase != 'policy' else 1.0
                    weights.append(max(0.001, action.prior * factor * context_factor * applicability * repeat_penalty
                                       * novelty_bonus * (1.0 + 2.0 * effect) / math.sqrt(1.0 + game.counts[i] * 0.20)))
                return self.rng.choices(indices, weights=weights, k=1)[0]
            values = self.scores(obs)
            for family, indices in self.action_families.items():
                contextual = (0.018 * menu_evidence if family == 'pointer' else
                              0.014 * movement_evidence if family in ('keyboard', 'navigation') else
                              0.008 * movement_evidence)
                for index in indices:
                    values[index] += contextual
            if game.world or game.world_network_steps >= 28:
                candidates = sorted(range(len(values)), key=values.__getitem__, reverse=True)[:6]
                for index in candidates:
                    model = self.world_prediction(game, index, obs)
                    if model is None or model[2] < 0.10:
                        continue
                    next_state = self.apply_world_delta(obs.features, model[0])
                    model_goal_gain = (self.goal_value(game, self.goal_value_input(next_state))
                                       - self.goal_value(game, self.goal_value_input(obs.features)))
                    goal_trust = min(1.0, game.goal_value_samples / 8.0)
                    values[index] += (0.09 * model[2] * goal_trust * max(-1.0, min(1.0, model_goal_gain))
                                      + 0.12 * model[2] * model[1] - 0.035 * model[3])
            family_scores = {}
            for family, indices in self.action_families.items():
                kinds = [kind for fam, kind in self.action_kinds if fam == family]
                kind_peaks = [max(values[i] for i in self.action_kinds[(family, kind)]) for kind in kinds]
                family_scores[family] = max(kind_peaks) + 0.012 * sum(kind_peaks) / len(kind_peaks)
            winner = max(family_scores.values())
            families = [key for key, value in family_scores.items() if value >= winner - 0.045]
            family = self.rng.choice(families)
            kind_scores = {}
            for fam, kind in self.action_kinds:
                if fam == family:
                    indices = self.action_kinds[(family, kind)]
                    kind_scores[kind] = max(values[i] for i in indices) + 0.01 / math.sqrt(1 + sum(game.counts[i] for i in indices) / len(indices))
            winner = max(kind_scores.values())
            kinds = [kind for kind, score in kind_scores.items() if score >= winner - 0.025]
            kind = self.rng.choice(kinds)
            indices = self.action_kinds[(family, kind)]
            top = max(values[i] for i in indices)
            options = [i for i in indices if values[i] >= top - 0.018]
            return self.rng.choice(options)

    @staticmethod
    def parameter_head_key(action):
        return f'{action.kind}|{action.a}|{action.b}'

    def predicted_parameters(self, game, action, features, prefix=''):
        general = game.parameter_heads.get(prefix + action.kind)
        specific = game.parameter_heads.get(prefix + self.parameter_head_key(action))
        if (general is None or general['samples'] < 8) and (specific is None or specific['samples'] < 5):
            return None, 0
        hidden = self._encode(features)
        def output(head):
            if self.np is not None:
                result = (0.5 + 0.5 * self.np.tanh(head['w'] @ hidden + head['b'])).tolist()
            else:
                result = [0.5 + 0.5 * math.tanh(sum(a * b for a, b in zip(row, hidden)) + head['b'][i]) for i, row in enumerate(head['w'])]
            return [min(1.0, max(0.0, float(value))) for value in result]
        if specific is not None and specific['samples'] >= 5:
            specific_values = output(specific)
            if general is not None and general['samples'] >= 8:
                base = output(general)
                strength = min(0.90, specific['samples'] / (specific['samples'] + 18.0))
                return [a * (1 - strength) + b * strength for a, b in zip(base, specific_values)], specific['samples'] + 0.15 * general['samples']
            return specific_values, specific['samples']
        return output(general), general['samples'] * 0.33

    @staticmethod
    def action_target_anchor(obs, x, y):
        if obs is None:
            return None
        matches = []
        for item in getattr(obs, 'interaction_targets', []):
            if float(item.get('confidence', 0.0)) < 0.48 or float(item.get('priority', 0.0)) < 0.14:
                continue
            cx, cy = float(item['x']), float(item['y'])
            radius_x, radius_y = 0.065, 0.09
            text_match = min((entry for entry in obs.ui_text if abs(float(entry['x']) - cx) < 0.018
                              and abs(float(entry['y']) - cy) < 0.018
                              and len(entry.get('bounds', [])) == 4),
                             key=lambda entry: abs(float(entry['x']) - cx) + abs(float(entry['y']) - cy), default=None)
            if text_match is not None:
                x0, y0, x1, y1 = map(float, text_match['bounds'])
                radius_x = max(0.025, min(0.16, (x1 - x0) * 0.75))
                radius_y = max(0.025, min(0.14, (y1 - y0) * 0.90))
            distance = math.hypot((x - cx) / radius_x, (y - cy) / radius_y)
            if distance <= 1.6:
                matches.append((float(item['confidence']) * (1.0 + float(item['priority'])) / (1.0 + distance),
                                [cx, cy, radius_x, radius_y]))
        return max(matches, key=lambda entry: entry[0])[1] if matches else None

    def blend_action_parameters(self, game, action, features, proposed, obs=None):
        prediction, evidence = self.predicted_parameters(game, action, features)
        col = min(GW - 1, max(0, int(float(proposed[0]) * GW)))
        row = min(GH - 1, max(0, int(float(proposed[1]) * GH)))
        local = game.parameter_stats.get(f'{action.kind}:{col}:{row}', [0.0, 0, 0.0])
        contextual = (game.spatial_context_stats.get(self.experiment_context(obs) + ':' + action.id + f':{col}:{row}')
                      if obs is not None else None)
        local_confidence = min(0.90, local[1] / (local[1] + 8.0) * max(0.0, min(1.0, local[0] * 3.0 + local[2] * 0.5)))
        if contextual is not None:
            local_confidence = max(local_confidence, min(0.92, contextual[0] / (contextual[0] + 5.0)
                                        * max(0.0, contextual[1] * 2.0 + contextual[2] * 0.6)))
        if prediction is None or self.rng.random() < 0.12:
            return (*proposed[:3], 1.0, local_confidence)
        influence = min(0.72, max(0.0, (evidence - 3.0) / 90.0))
        learned_duration = 0.04 + 1.46 * prediction[2]
        spatial = action.kind in ('click', 'right', 'double', 'middle', 'focus_click', 'focus_right',
                                  'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap',
                                  'touch_swipe', 'pinch', 'dual_touch')
        x = proposed[0] if spatial else max(0.01, min(0.99, proposed[0] * (1.0 - influence) + prediction[0] * influence))
        y = proposed[1] if spatial else max(0.01, min(0.99, proposed[1] * (1.0 - influence) + prediction[1] * influence))
        if spatial and action.kind in ('click', 'right', 'double', 'middle', 'focus_click', 'focus_right',
                                       'focus_double', 'press', 'touch_tap'):
            anchor = self.action_target_anchor(obs, proposed[0], proposed[1])
            offset, offset_samples = self.predicted_parameters(game, action, features, 'target:') if anchor else (None, 0)
            if offset is not None and offset_samples >= 8 and local_confidence >= 0.08:
                cx, cy, rx, ry = anchor
                suggested_x = cx + (2.0 * offset[0] - 1.0) * rx
                suggested_y = cy + (2.0 * offset[1] - 1.0) * ry
                trust = min(0.55, max(0.0, (offset_samples - 5.0) / (offset_samples + 30.0)))
                trust *= 0.45 + 0.55 * min(1.0, local_confidence / 0.25)
                x = max(0.01, min(0.99, proposed[0] * (1.0 - trust) + suggested_x * trust))
                y = max(0.01, min(0.99, proposed[1] * (1.0 - trust) + suggested_y * trust))
        duration = max(0.025, proposed[2] * (1.0 - influence) + learned_duration * influence)
        extent = 1.0 - influence * 0.5 + influence * prediction[3]
        model_confidence = min(0.88, max(0.0, (evidence - 3.0) / 90.0))
        return (x, y, duration, max(0.5, min(1.5, extent)),
                local_confidence if spatial else min(0.95, max(local_confidence, model_confidence)))

    def recommend_action_parameters(self, index, obs):
        with self.lock:
            game = self.game
            action = self.actions[index]
            spatial_kinds = ('click', 'right', 'double', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch')
            context = self.experiment_context(obs)
            durations = (0.065, 0.12, 0.24, 0.48, 0.9, 1.45) if action.kind in ('key', 'hold', 'pair_hold', 'chord') else (0.12, 0.28, 0.55, 0.95, 1.4) if action.kind in ('press', 'swipe', 'right_swipe', 'combat', 'move_fire', 'aim', 'look', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch') else (action.duration,)
            ranked = []
            for duration in durations:
                label = f'{action.kind}:{action.a}:{action.b}:{round(duration, 3)}'
                score, count = game.duration_stats.get(label, (0.0, 0))
                explore = 0.11 / math.sqrt(1 + count)
                local = game.duration_context_stats.get(context + ':' + action.id + ':' + str(round(duration, 3)))
                contextual = (0.50 * local[1] + 0.20 * local[2] - 0.22 * local[3]) * min(1.0, local[0] / 6.0) if local is not None else 0.0
                ranked.append(score * min(1.0, count / 7.0) + contextual + explore
                              + self.rng.random() * (0.12 if game.game_steps < 300 else 0.045))
            duration = durations[max(range(len(durations)), key=ranked.__getitem__)]
            if action.kind not in spatial_kinds:
                return self.blend_action_parameters(game, action, obs.features, (action.x, action.y, duration), obs)
            ranked_cells = sorted(range(GW * GH), key=lambda i: obs.salience[i] + 0.035 * obs.edges[i], reverse=True)
            candidates = ranked_cells[:40] + self.rng.sample(range(GW * GH), 24)
            candidates.extend(min(GW - 1, int(u * GW)) + GW * min(GH - 1, int(v * GH)) for u, v, _ in obs.attention_points[:24])
            candidates.extend(min(GW - 1, int(item['x'] * GW)) + GW * min(GH - 1, int(item['y'] * GH))
                              for item in obs.objects[:24] if item['confidence'] >= 0.18)
            candidates.extend(min(GW - 1, int(item['x'] * GW)) + GW * min(GH - 1, int(item['y'] * GH))
                              for item in obs.ui_text[:16] if item.get('temporal_confidence', 0.0) >= 0.35)
            candidates.extend(min(GW - 1, int(item['x'] * GW)) + GW * min(GH - 1, int(item['y'] * GH))
                              for item in obs.interaction_targets)
            if action.kind in ('click', 'double', 'focus_click', 'focus_double', 'touch_tap', 'press'):
                for item in obs.ui_text[:12]:
                    if item.get('temporal_confidence', 0.0) < 0.35:
                        continue
                    bounds = item.get('bounds', [])
                    if len(bounds) == 4:
                        for x, y in ((item['x'], item['y']), (item['x'], min(0.98, bounds[3] + 0.025)),
                                     (item['x'], max(0.02, bounds[1] - 0.025))):
                            candidates.append(min(GW - 1, int(x * GW)) + GW * min(GH - 1, int(y * GH)))
            for key, entry in list(game.spatial_context_stats.items())[-500:]:
                prefix = context + ':' + action.id + ':'
                if str(key).startswith(prefix) and entry[0] >= 2:
                    try:
                        col, row = map(int, str(key)[len(prefix):].split(':'))
                        if 0 <= col < GW and 0 <= row < GH:
                            candidates.append(row * GW + col)
                    except ValueError:
                        continue
            for key, entry in list(game.parameter_stats.items())[-350:]:
                parts = str(key).split(':')
                if len(parts) == 3 and parts[0] == action.kind and entry[1] >= 2:
                    try:
                        col, row = int(parts[1]), int(parts[2])
                        if 0 <= col < GW and 0 <= row < GH:
                            candidates.append(row * GW + col)
                    except ValueError:
                        continue
            best_cell = None
            best_score = -1e10
            for cell in set(candidates):
                col, row = cell % GW, cell // GW
                key = f'{action.kind}:{col}:{row}'
                record = game.parameter_stats.get(key, (0.0, 0, 0.0))
                count = record[1]
                score = 0.43 * obs.salience[cell] + 0.17 * obs.edges[cell] + 0.08 * obs.motion[cell]
                score += 0.52 * record[0] * min(1.0, count / 6.0) + 0.12 * record[2] * min(1.0, count / 5.0)
                contextual = game.spatial_context_stats.get(context + ':' + action.id + f':{col}:{row}')
                if contextual is not None:
                    trials, performance, success, misses = contextual
                    score += (0.67 * performance + 0.24 * success - 0.28 * misses) * min(1.0, trials / 5.0)
                    score += 0.12 / math.sqrt(1 + trials)
                score += 0.13 / math.sqrt(1 + count)
                score += max((0.0,) + tuple(0.13 * item['confidence'] for item in obs.objects[:24]
                          if abs(item['x'] - (col + 0.5) / GW) <= 0.05
                          and abs(item['y'] - (row + 0.5) / GH) <= 0.07))
                score += max((0.0,) + tuple(0.12 * item.get('temporal_confidence', 0.0) for item in obs.ui_text[:16]
                          if abs(item['x'] - (col + 0.5) / GW) <= 0.045
                          and abs(item['y'] - (row + 0.5) / GH) <= 0.06))
                if action.kind in ('click', 'double', 'focus_click', 'focus_double', 'press', 'touch_tap'):
                    score += max((0.0,) + tuple((item['priority'] + 0.16 * item['confidence'])
                          for item in obs.interaction_targets
                          if abs(item['x'] - (col + 0.5) / GW) <= 0.043
                          and abs(item['y'] - (row + 0.5) / GH) <= 0.065))
                score -= 0.11 * sum(recent == cell for recent in game.focus_recent)
                score += self.rng.random() * (0.26 if game.game_steps < 250 else 0.08)
                if score > best_score:
                    best_score, best_cell = score, cell
            if best_cell is None:
                return self.blend_action_parameters(game, action, obs.features, (0.5, 0.5, duration), obs)
            game.focus_recent.append(best_cell)
            col, row = best_cell % GW, best_cell // GW
            nearby = [(u, v, salience) for u, v, salience in obs.attention_points if int(u * GW) == col and int(v * GH) == row]
            if nearby and self.rng.random() < 0.72:
                u, v, _ = max(nearby, key=lambda entry: entry[2])
                return self.blend_action_parameters(game, action, obs.features, (u, v, duration), obs)
            return self.blend_action_parameters(game, action, obs.features, ((col + 0.5) / GW, (row + 0.5) / GH, duration), obs)

    @staticmethod
    def skill_object_summary(obs):
        ranked = sorted(getattr(obs, 'objects', []),
                        key=lambda item: (float(item.get('control_probability', 0.0)) * 1.5
                                          + float(item.get('confidence', 0.0)) * 0.6
                                          + float(item.get('activity', 0.0)) * 0.2), reverse=True)
        values = []
        for item in ranked[:3]:
            values.extend((max(0.0, min(1.0, float(item.get('x', 0.5)))),
                           max(0.0, min(1.0, float(item.get('y', 0.5)))),
                           min(1.0, math.hypot(float(item.get('vx', 0.0)), float(item.get('vy', 0.0))) * 8.0),
                           max(0.0, min(1.0, float(item.get('control_probability', 0.0))))))
        return values + [0.0] * (12 - len(values))

    @staticmethod
    def skill_object_gap(saved, current):
        if not isinstance(saved, list) or len(saved) != 12 or not any(saved):
            return 0.0
        return sum(abs(a - b) for a, b in zip(saved, current)) / 12.0

    @staticmethod
    def skill_relation_summary(obs):
        objects = [item for item in getattr(obs, 'objects', []) if float(item.get('confidence', 0.0)) >= 0.35]
        if len(objects) < 2:
            return [0.0] * 12
        controlled = max(objects, key=lambda item: float(item.get('control_probability', 0.0)) * 1.5
                         + float(item.get('confidence', 0.0)) * 0.3)
        others = sorted((item for item in objects if item is not controlled),
                        key=lambda item: math.hypot(float(item['x']) - float(controlled['x']),
                                                    float(item['y']) - float(controlled['y'])))
        values = []
        for item in others[:3]:
            dx = max(-1.0, min(1.0, float(item['x']) - float(controlled['x'])))
            dy = max(-1.0, min(1.0, float(item['y']) - float(controlled['y'])))
            distance = math.hypot(dx, dy)
            speed_x = float(item.get('vx', 0.0)) - float(controlled.get('vx', 0.0))
            speed_y = float(item.get('vy', 0.0)) - float(controlled.get('vy', 0.0))
            closing = -(dx * speed_x + dy * speed_y) / max(0.025, distance)
            values.extend((dx, dy, max(-1.0, min(1.0, closing * 8.0)),
                           1.0 / (1.0 + distance * 6.0)))
        return values + [0.0] * (12 - len(values))

    @staticmethod
    def skill_relation_gap(saved, current):
        if not isinstance(saved, list) or len(saved) != 12 or not any(saved):
            return 0.0
        return sum(abs(a - b) for a, b in zip(saved, current)) / 12.0

    @staticmethod
    def skill_history_similarity(expected, recent):
        if not isinstance(expected, list) or not expected:
            return 1.0
        count = min(3, len(expected), len(recent))
        if not count:
            return 0.5
        return sum(a == b for a, b in zip(expected[-count:], recent[-count:])) / count

    def choose_plan(self, obs):
        with self.lock:
            game = self.game
            known_skills = sum(1 for item in game.skills.values() if float(item.get('quality', 0.0)) > 0.05 and int(item.get('attempts', 0)) >= 3)
            model_samples = sum(game.world_validation_samples)
            prediction_reliability = max(0.0, min(1.0, 1.0 - game.prediction_error_mean * 4.0)) if game.prediction_error_samples >= 6 else 0.0
            planning_probability = min(0.78, 0.12 + 0.32 * min(1.0, known_skills / 3.0)
                                       + 0.30 * min(1.0, model_samples / 60.0) * prediction_reliability
                                       + 0.10 * (1.0 - max(0.0, min(1.0, obs.state_uncertainty))))
            if self.rng.random() >= planning_probability:
                self.last_skill_source = None
                self.last_transfer_key = None
                self.last_skill_reference = None
                self.last_plan_parameters = []
                self.last_plan_predictions = []
                return [self.choose(obs)]
            candidates = []
            pools = [(self.game_key, game, 1.0)]
            pools.extend((key, other, 0.45) for key, other in self.games.items() if key != self.game_key and other.game_steps >= 100)
            for source_key, source, transfer_discount in pools:
                for key, info in source.skills.items():
                    ids = [self.action_index.get(a) for a in key.split('|')]
                    if len(ids) < 2 or any(index is None for index in ids):
                        continue
                    quality = max(0.0, float(info.get('quality', 0.0)))
                    phase = info.get('start_phase', 'unknown')
                    if (phase != 'unknown' and obs.phase != 'unknown'
                            and obs.phase_confidence >= 0.56 and phase != obs.phase):
                        continue
                    if quality <= 0.01:
                        continue
                    context = info.get('context', [])
                    goal_features = info.get('goal_features', [])
                    if len(context) != 18 or info.get('goal_signature') == obs.signature:
                        continue
                    if len(goal_features) == 18:
                        goal_distance = sum((a - b) ** 2 for a, b in zip(goal_features, obs.features[:18])) / 18
                        if goal_distance < 0.002:
                            continue
                    distance = sum((a - b) ** 2 for a, b in zip(context, obs.features[:18])) / 18
                    if distance >= (0.016 if source is game else 0.009):
                        continue
                    attempts = max(0, int(info.get('attempts', 0)))
                    successes = max(0, min(attempts, int(info.get('successes', 0))))
                    confidence = (successes + 1.5) / (attempts + 3)
                    lower_success = max(0.0, confidence - 1.28 * math.sqrt((successes + 1.5)
                        * (attempts - successes + 1.5) / ((attempts + 3) ** 2 * (attempts + 4))))
                    failure_rate = max(0.0, min(1.0, float(info.get('failure_rate', 1.0 - confidence))))
                    semantic_context = info.get('semantic_context')
                    semantic_gap = 0.0
                    if isinstance(semantic_context, list) and len(semantic_context) == 16:
                        semantic_gap = sum(abs(a - b) for a, b in zip(semantic_context, obs.features[SEMANTIC_START:SEMANTIC_START + 16])) / 16.0
                        if semantic_gap > (0.32 if source is game else 0.23):
                            continue
                    goal_successes = max(0, int(info.get('objective_successes', 0)))
                    navigation_successes = max(0, int(info.get('navigation_successes', 0)))
                    if source is not game:
                        if (attempts < 10 or lower_success < 0.47 or float(info.get('causal_reliability', 0.0)) < 0.24
                                or navigation_successes < 4 or goal_successes < 2
                                or not isinstance(semantic_context, list) or len(semantic_context) != 16):
                            continue
                    object_gap = self.skill_object_gap(info.get('object_context'), self.skill_object_summary(obs))
                    if object_gap > (0.34 if source is game else 0.23):
                        continue
                    relative_context = info.get('relation_context')
                    relation_gap = self.skill_relation_gap(relative_context, self.skill_relation_summary(obs))
                    if relation_gap > (0.30 if source is game else 0.15):
                        continue
                    if source is not game and not isinstance(relative_context, list):
                        continue
                    previous_actions = [self.actions[row[0]].id for row in list(game.recent)[-3:]]
                    history_match = self.skill_history_similarity(info.get('history_context'), previous_actions)
                    expected_gain = max(-0.5, min(1.0, float(info.get('expected_reward', quality))))
                    expected_time = max(0.05, min(8.0, float(info.get('average_duration', 0.6))))
                    known_goal = min(1.0, max(0.0, float(info.get('goal_evidence_samples', 0.0))) / 4.0)
                    purpose_confidence = (goal_successes + 1.0) / (navigation_successes + 3.0)
                    score = quality * (0.30 * confidence + 0.70 * lower_success) * (1.0 - 0.55 * failure_rate) * transfer_discount
                    score *= (0.76 + 0.24 * known_goal + 0.15 * purpose_confidence) if source is game else (0.46 + 0.30 * known_goal + 0.24 * purpose_confidence)
                    if info.get('purpose') == 'outcome':
                        score *= 0.80 + 0.20 * max(0.0, min(1.0, float(info.get('purpose_confidence', 0.0))))
                    score *= (0.65 + 0.35 * max(0.0, expected_gain)) * (0.70 + 0.30 * history_match)
                    score *= 0.62 + 0.38 * max(0.0, min(1.0, float(info.get('causal_reliability', 0.0))))
                    score /= 1.0 + distance * 30.0 + semantic_gap * 3.0 + object_gap * 2.0 + relation_gap * 3.0 + expected_time * 0.06
                    if source is not game:
                        transfer = game.transfer_skill_stats.get(source_key + ':' + key, [0, 0, 0])
                        checked, useful, useless = transfer
                        trust = (useful + 1.0) / (useful + useless + 2.0)
                        lower_trust = max(0.0, trust - 1.2 * math.sqrt((useful + 1.0) *
                                       (useless + 1.0) / ((useful + useless + 2.0) ** 2 *
                                                          (useful + useless + 3.0))))
                        target_support = []
                        for action_index in ids[:3]:
                            known = game.control_posteriors[action_index]
                            n = max(0.0, known[0] + known[1] - 2.0)
                            if n >= 4.0:
                                target_support.append((known[0] - 1.0) / n)
                        baseline = sum(target_support) / len(target_support) if target_support else 0.45
                        relative_value = max(0.30, min(1.25, 0.72 + 0.85 *
                                                (lower_trust - max(0.25, baseline * 0.45))))
                        score *= max(0.06, min(1.15, trust * 1.65 * relative_value /
                                                  (1.0 + useless * 0.25)))
                    details = info.get('parameters', [])
                    params = []
                    if source is game and isinstance(details, list) and len(details) == len(ids):
                        for detail in details:
                            if isinstance(detail, dict):
                                try:
                                    values = [float(detail.get('start_x', detail.get('x', 0.5))), float(detail.get('start_y', detail.get('y', 0.5))), float(detail.get('requested_duration', detail.get('duration', 0.2))), float(detail.get('extent', 1.0))]
                                except (TypeError, ValueError):
                                    values = []
                                certainty = min(0.95, attempts / (attempts + 12.0) * confidence)
                                params.append(tuple(values + [certainty]) if len(values) == 4 and all(math.isfinite(value) for value in values) else None)
                            else:
                                params.append(None)
                    candidates.append((max(0.001, score), ids, source_key, params))
            if candidates:
                indices, source_key, params = self.rng.choices([(ids, key, params) for _, ids, key, params in candidates], weights=[score for score, _, _, _ in candidates], k=1)[0]
                reference = '|'.join(self.actions[i].id for i in indices)
                self.last_transfer_key = (source_key + ':' + reference if source_key != self.game_key else None)
                self.last_skill_reference = reference
                if source_key != self.game_key:
                    counts = game.transfer_skill_stats.get(self.last_transfer_key, [0, 0, 0])
                    tested, successes, failures = [int(value) for value in counts]
                    reliability = (successes + 1.0) / (successes + failures + 2.0)
                    length = (min(len(indices), 5) if successes >= 10 and reliability >= 0.65
                              else min(len(indices), 3) if successes >= 5 and reliability >= 0.58
                              else min(len(indices), 2) if successes >= 2 and failures <= successes
                              else 1)
                    indices = indices[:length]
                    params = []
                    if length >= 2:
                        game.diagnostics['transfer_multistep_trials'] += 1
                self.last_skill_source = source_key
                self.last_plan_parameters = params
                self.last_plan_predictions = []
                return indices
            self.last_skill_source = None
            self.last_transfer_key = None
            self.last_skill_reference = None
            self.last_plan_parameters = []
            plan, predictions = self.plan_with_world_model(obs)
            self.last_plan_predictions = predictions
            return plan

    def skill_should_continue(self, obs, indices, next_position):
        if self.last_skill_source is None or next_position >= len(indices):
            return True
        source = self.games.get(self.last_skill_source)
        if source is None:
            return False
        info = source.skills.get(self.last_skill_reference or '|'.join(self.actions[i].id for i in indices))
        cross_game = self.last_skill_source != self.game_key
        if info is None or not obs.valid or not obs.quality.get('trainable', False):
            return False
        if info.get('goal_signature') == obs.signature:
            return False
        belief = getattr(obs, 'belief_state', {})
        if (info.get('purpose') == 'outcome' and belief.get('frames', 0) >= 3
                and belief.get('confidence', 0.0) >= 0.62 and belief.get('relative')
                and belief['relative'][5] >= 0.52 and belief['relative'][4] < -0.16):
            relations = info.get('relation_waypoints', [])
            if isinstance(relations, list) and next_position < len(relations):
                if self.skill_relation_gap(relations[next_position], self.skill_relation_summary(obs)) > 0.22:
                    return False
        if (info.get('start_phase', 'unknown') != 'unknown' and obs.phase != 'unknown'
                and obs.phase_confidence >= 0.65 and info['start_phase'] != obs.phase):
            return False
        goal = info.get('goal_features', [])
        if len(goal) == 18 and sum((a - b) ** 2 for a, b in zip(goal, obs.features[:18])) / 18.0 < 0.0025:
            return False
        positions = info.get('waypoints', [])
        if isinstance(positions, list) and next_position < len(positions):
            expected = positions[next_position]
            if isinstance(expected, list) and len(expected) == 18:
                gap = sum((a - b) ** 2 for a, b in zip(expected, obs.features[:18])) / 18.0
                if gap > (0.090 if cross_game else 0.055):
                    return False
        semantics = info.get('semantic_waypoints', [])
        if isinstance(semantics, list) and next_position < len(semantics):
            target = semantics[next_position]
            if isinstance(target, list) and len(target) == 16:
                gap = sum(abs(a - b) for a, b in zip(target, obs.features[SEMANTIC_START:SEMANTIC_START + 16])) / 16.0
                if gap > (0.46 if cross_game else 0.38):
                    return False
        objects = info.get('object_waypoints', [])
        if isinstance(objects, list) and next_position < len(objects):
            gap = self.skill_object_gap(objects[next_position], self.skill_object_summary(obs))
            if gap > (0.44 if cross_game else 0.38):
                return False
        relations = info.get('relation_waypoints', [])
        if isinstance(relations, list) and next_position < len(relations):
            gap = self.skill_relation_gap(relations[next_position], self.skill_relation_summary(obs))
            if gap > (0.39 if cross_game else 0.32):
                return False
        return True

    def preview_action_parameters(self, game, index, obs, future_features=None):
        action = self.actions[index]
        hint = game.world_parameters.get(str(index))
        count = int(hint.get('count', 0)) if isinstance(hint, dict) else 0
        x, y, duration, extent = float(action.x), float(action.y), float(action.duration), 1.0
        spatial = action.kind in ('click', 'right', 'double', 'middle', 'focus_click', 'focus_right',
                  'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap',
                  'touch_swipe', 'pinch', 'dual_touch')
        if spatial:
            targets = getattr(obs, 'interaction_targets', ())
            attention = getattr(obs, 'attention_points', ())
            if targets and action.kind in ('click', 'right', 'double', 'focus_click', 'focus_right',
                                            'focus_double', 'press', 'touch_tap'):
                target = max(targets, key=lambda item: float(item.get('priority', 0.0)) *
                             float(item.get('confidence', 0.0)))
                x, y = float(target['x']), float(target['y'])
            elif attention:
                x, y = float(attention[0][0]), float(attention[0][1])
            else:
                x, y = (0.5, 0.5)
        if future_features is not None and spatial:
            tracked = []
            for slot in range(4):
                offset = SEMANTIC_START + 24 + slot * 4
                prior_x, prior_y = float(obs.features[offset]), float(obs.features[offset + 1])
                future_x, future_y = float(future_features[offset]), float(future_features[offset + 1])
                if (0.0 <= prior_x <= 1.0 and 0.0 <= prior_y <= 1.0
                        and 0.0 <= future_x <= 1.0 and 0.0 <= future_y <= 1.0
                        and math.hypot(x - prior_x, y - prior_y) < 0.16):
                    tracked.append((math.hypot(x - prior_x, y - prior_y), future_x - prior_x, future_y - prior_y))
            if tracked:
                nearest = min(tracked, key=lambda entry: entry[0])
                x = max(0.01, min(0.99, x + max(-0.18, min(0.18, nearest[1]))))
                y = max(0.01, min(0.99, y + max(-0.18, min(0.18, nearest[2]))))
        if count >= 3:
            alpha = min(0.80, (count - 2.0) / (count + 9.0))
            hx = float(hint.get('start_x', hint.get('x', x)))
            hy = float(hint.get('start_y', hint.get('y', y)))
            if math.isfinite(hx) and math.isfinite(hy):
                x = x * (1.0 - alpha) + hx * alpha
                y = y * (1.0 - alpha) + hy * alpha
            hd = float(hint.get('duration', action.duration))
            he = float(hint.get('extent', 1.0))
            if math.isfinite(hd):
                duration = duration * (1.0 - alpha) + hd * alpha
            if math.isfinite(he):
                extent = extent * (1.0 - alpha) + he * alpha
        candidates = []
        for key, value in game.duration_stats.items():
            if not (key.startswith(f'{action.kind}:{action.a}:{action.b}:')
                    and isinstance(value, (list, tuple)) and len(value) >= 2):
                continue
            try:
                trial = (float(value[0]), int(value[1]), float(key.rsplit(':', 1)[-1]))
            except (TypeError, ValueError, OverflowError):
                continue
            if trial[1] >= 3 and math.isfinite(trial[0]) and math.isfinite(trial[2]):
                candidates.append(trial)
        if candidates:
            best_duration = max(candidates, key=lambda row: row[0] * min(1.0, row[1] / 8.0))
            duration = 0.65 * duration + 0.35 * best_duration[2]
        certainty = min(0.90, count / (count + 9.0)) if count >= 3 else 0.10
        return (max(0.01, min(0.99, x)), max(0.01, min(0.99, y)),
                max(0.025, min(1.5, duration)), max(0.5, min(1.5, extent)), certainty, 'world_plan')

    @staticmethod
    def parameter_dictionary(parameters, action=None, stagnation=0):
        x, y = float(parameters[0]), float(parameters[1])
        kind = action.kind if action is not None else ''
        if kind in ('swipe', 'right_swipe'):
            x -= action.a * float(parameters[3]) * min(0.5, 0.25 + stagnation * 0.008) * 0.5
            y -= action.b * float(parameters[3]) * min(0.5, 0.25 + stagnation * 0.008) * 0.5
            x, y = max(0.0, min(1.0, x)), max(0.0, min(1.0, y))
        if kind == 'dual_touch':
            x, y = max(0.08, min(0.42, x)), max(0.55, min(0.93, y))
        spatial = kind in ('click', 'double', 'right', 'middle', 'focus_click', 'focus_right',
                            'focus_double', 'press', 'move', 'swipe', 'right_swipe', 'touch_tap',
                            'touch_swipe', 'pinch', 'dual_touch')
        return {'start_x': x, 'start_y': y, 'requested_duration': float(parameters[2]),
                'duration': float(parameters[2]), 'extent': float(parameters[3]), 'spatial': spatial}

    def plan_with_world_model(self, obs):
        game = self.game
        estimates = self.scores(obs)
        root_q = self._values(obs.features, game)
        root_q = root_q.tolist() if self.np is not None else root_q
        root_dual = self.dual_value_scores(game, obs.features)
        if not (game.world or game.world_network_steps >= 28):
            return [self.choose(obs)], []
        precision = game.prediction_error_mean + 1.5 * math.sqrt(max(0.0, game.prediction_error_variance))
        horizon = (5 if self.np is not None and game.prediction_error_samples >= 60 and precision < 0.045
                   else 4 if self.np is not None and game.prediction_error_samples >= 20 and precision < 0.065
                   else 3 if game.prediction_error_samples >= 10 and precision < 0.10 else 2)
        if game.prediction_error_samples < 6 or precision > 0.16:
            horizon = 2
        if obs.state_uncertainty > 0.68 or getattr(obs, 'belief_state', {}).get('confidence', 0.0) < 0.20:
            horizon = min(horizon, 2)
        elif obs.state_uncertainty > 0.48:
            horizon = min(horizon, 3)
        heldout_count = sum(game.world_validation_samples)
        heldout_good = sum(game.world_action_errors[i] * count for i, count in enumerate(game.world_validation_samples)) / max(1, heldout_count)
        if heldout_count < 12 or heldout_good > 0.14:
            horizon = min(horizon, 2)
        if self.vision_cost_ema > 0.55 and self.np is None:
            horizon = min(horizon, 2)
        elif heldout_count < 35 or heldout_good > 0.09:
            horizon = min(horizon, 3)
        elif heldout_count < 90 or heldout_good > 0.055:
            horizon = min(horizon, 4)
        beam = [(0.0, [], obs.features[:], [], 1.0, [], 0.0)]
        completed = []
        for depth in range(horizon):
            advanced = []
            for utility, path, features, predicted, trust, selected_params, elapsed in beam:
                values = (estimates if not path else
                          self.predicted_state_scores(game, features, estimates, root_q, root_dual, obs))
                ranks = sorted(range(len(values)),
                               key=lambda i: values[i] + 0.16 * game.action_effect[i]
                               - (0.09 if path and path[-1] == i else 0.0), reverse=True)[:(38 if not path else 22)]
                for family, indices in self.action_families.items():
                    peak = max(indices, key=lambda i: values[i] + 0.10 * game.action_effect[i])
                    if peak not in ranks:
                        ranks.append(peak)
                reliable = 0
                for index in ranks:
                    proposed_params = self.preview_action_parameters(game, index, obs, features if path else None)
                    model_parameters = self.parameter_dictionary(proposed_params, self.actions[index], game.stagnation)
                    model = self.world_prediction(game, index, obs if not path else features, model_parameters)
                    if model is None or model[2] < (0.14 if not path else 0.12) or model[3] >= 0.20:
                        continue
                    action_validation = game.world_validation_samples[index]
                    if path and action_validation < 2 and game.world_action_samples[index] >= 4:
                        continue
                    delta, expected_reward, confidence, uncertainty = model
                    if path:
                        confidence *= max(0.42, 1.0 - 0.12 * len(path))
                        uncertainty = min(1.0, uncertainty + 0.035 * len(path))
                    error_mean, error_spread, error_count = self.plan_error_estimate(game, index, obs.signature if not path else None)
                    if error_count >= 4 and error_mean + error_spread > 0.19:
                        continue
                    if error_count >= 4:
                        confidence *= max(0.25, 1.0 - max(0.0, error_mean + error_spread - 0.055) * 3.0)
                    if confidence < 0.10:
                        continue
                    reliable += 1
                    changed = self.apply_world_delta(features, delta)
                    repetition = 0.15 if len(path) > 1 and path[-1] == path[-2] == index else 0.055 if path and path[-1] == index else 0.0
                    risk = (0.16 * uncertainty + 0.04 * max(0.0, 0.5 - confidence)
                            + (0.08 * min(1.0, error_mean + error_spread) if error_count >= 3 else 0.0)
                            + 0.012 * (depth + 1) * max(0.0, min(1.0, float(getattr(obs, 'state_uncertainty', 0.5)))))
                    learned_goal = min(1.0, game.goal_value_samples / 7.0)
                    predicted_goal_change = (self.goal_value(game, self.goal_value_input(changed))
                                             - self.goal_value(game, self.goal_value_input(features)))
                    goal_support = (min(1.0, game.action_goal_samples[index] / 7.0)
                                    * game.action_goal[index])
                    event_outcome, event_confidence = self.predict_world_event(game, obs, index) if not path else (0.0, 0.0)
                    event_information, event_information_confidence = self.event_forecast(game, obs, index) if not path else (0.0, 0.0)
                    estimated_duration = proposed_params[2]
                    elapsed_to_step = elapsed
                    score = utility + temporal_discount(elapsed_to_step) * (max(-0.3, min(0.3, values[index])) * 0.40
                              + max(-0.3, min(0.75, expected_reward)) * 0.14
                              + 0.21 * learned_goal * max(-0.4, min(0.4, predicted_goal_change))
                              + 0.16 * goal_support + 0.12 * event_outcome * event_confidence
                              + 0.035 * event_information * event_information_confidence
                              + confidence * 0.055 - repetition - risk - 0.025 * estimated_duration)
                    path2 = path + [index]
                    future_states = predicted + [self.world_state(changed)]
                    confidence2 = trust * confidence
                    if confidence2 < (0.015 if depth == 0 else 0.045):
                        continue
                    advanced.append((score, path2, changed, future_states, confidence2,
                                     selected_params + [proposed_params], elapsed + estimated_duration))
            if not advanced:
                break
            advanced.sort(key=lambda item: item[0] + 0.11 * item[4], reverse=True)
            beam_width = 3 if self.vision_cost_ema > 0.35 and self.np is None else 4
            beam = advanced[:beam_width]
            completed.extend(beam)
        completed = [row for row in completed if len(row[1]) >= 2 and row[4] >= (0.028 if precision < 0.09 else 0.055)]
        if not completed:
            return [self.choose(obs)], []
        best = max(completed, key=lambda item: item[0] / max(1.0, len(item[1]) ** 0.65) + 0.06 * item[4])
        game.diagnostics['validated_world_plans'] += 1
        self.last_plan_parameters = best[5]
        return best[1], best[3]

    def mark_plan_result(self, indices, finish, feedback=None, steps_completed=None):
        if self.last_transfer_key and self.last_skill_source != self.game_key:
            evidence = feedback if isinstance(feedback, dict) else self.reward_info
            if not finish.valid or not finish.quality.get('trainable', False):
                return
            with self.lock:
                entry = self.game.transfer_skill_stats.get(self.last_transfer_key, [0, 0, 0])
                entry[0] += 1
                result = evidence.get('screen_result_confirmation')
                causal = float(evidence.get('causal_confidence') or 0.0)
                stable = float(evidence.get('scene_stability') or 0.0)
                goal = float(evidence.get('objective_evidence_confidence') or 0.0)
                complete = steps_completed is None or int(steps_completed) >= len(indices)
                positive = (result in ('win', 'task') or (causal >= 0.42 and stable >= 0.60
                            and goal >= 0.32 and evidence.get('goal_direction_evidence')
                            and float(evidence.get('goal_signal') or 0.0) > 0.012))
                if complete and positive:
                    entry[1] += 1
                    self.game.diagnostics['transfer_successes'] += 1
                    if len(indices) >= 2:
                        self.game.diagnostics['transfer_multistep_successes'] += 1
                elif (evidence.get('action_effect_observation') == 0.0 and stable >= 0.55
                      or result == 'loss'):
                    entry[2] += 1
                self.game.transfer_skill_stats[self.last_transfer_key] = entry
                self.game.transfer_skill_stats.move_to_end(self.last_transfer_key)
                while len(self.game.transfer_skill_stats) > 800:
                    self.game.transfer_skill_stats.popitem(last=False)
                self.game.diagnostics['transfer_trials'] += 1
                self.dirty_games.add(self.game_key)
                self.dirty_sequence += 1
                self.last_transfer_key = None
            return
        if len(indices) < 2:
            return
        key = '|'.join(self.actions[i].id for i in indices)
        with self.lock:
            game = self.game
            source = self.games.get(self.last_skill_source or self.game_key, game)
            info = source.skills.get(key)
            if info is None:
                return
            info['attempts'] = info.get('attempts', 0) + 1
            goal = info.get('goal_features', [])
            succeeded = info.get('goal_signature') == finish.signature
            if not succeeded and len(goal) == 18:
                distance = sum((a - b) ** 2 for a, b in zip(goal, finish.features[:18])) / 18
                succeeded = distance < 0.0025 and finish.quality.get('trainable', False)
            goal_semantic = info.get('goal_semantic_features')
            goal_objects = info.get('goal_object_features')
            goal_relations = info.get('goal_relation_features')
            if not succeeded and isinstance(goal_semantic, list) and len(goal_semantic) == 16:
                semantic_gap = sum(abs(a - b) for a, b in zip(goal_semantic, finish.features[SEMANTIC_START:SEMANTIC_START + 16])) / 16
                object_gap = self.skill_object_gap(goal_objects, self.skill_object_summary(finish))
                relation_gap = self.skill_relation_gap(goal_relations, self.skill_relation_summary(finish))
                succeeded = bool(semantic_gap < 0.075 and object_gap < 0.10
                                 and relation_gap < 0.12 and finish.quality.get('trainable', False))
            evidence = feedback if isinstance(feedback, dict) else self.reward_info
            causal = max(0.0, min(1.0, float(evidence.get('causal_confidence') or 0.0)))
            persistent = max(0.0, min(1.0, float(evidence.get('persistent_visual_change') or 0.0)))
            stable = max(0.0, min(1.0, float(evidence.get('scene_stability') or 0.0)))
            objective = max(0.0, float(evidence.get('learned_hud_trend_signal') or 0.0))
            landmark = max(0.0, float(evidence.get('persistent_landmark_evidence') or 0.0))
            outcome = evidence.get('screen_result_confirmation') in ('win', 'task')
            reliable_transition = (causal >= 0.32 and persistent >= 0.42 and stable >= 0.54
                                   and (objective >= 0.012 or landmark >= 0.004
                                        or (info.get('goal_signature') == finish.signature
                                            and float(info.get('quality', 0.0)) >= 0.015)))
            semantic_goal_progress = bool(evidence.get('goal_direction_evidence')
                                          and objective >= 0.012
                                          and float(evidence.get('objective_evidence_confidence') or 0.0) >= 0.30)
            succeeded = bool(succeeded and finish.quality.get('trainable', False)
                             and (outcome or reliable_transition or semantic_goal_progress))
            game.plan_success[0] += 1
            info['causal_reliability'] = min(1.0, 0.90 * float(info.get('causal_reliability', 0.0))
                                              + 0.10 * causal * persistent * stable)
            observed_reward = max(-1.0, min(1.0, float(evidence.get('proxy_reward') or 0.0)))
            previous_attempts = max(1, int(info['attempts']))
            info['expected_reward'] = max(-1.0, min(1.0, float(info.get('expected_reward', 0.0)) * 0.9 + observed_reward * 0.1))
            recent_steps = list(game.recent)[-len(indices):]
            elapsed = sum(max(0.01, min(1.5, float(item[4].get('duration', item[4].get('requested_duration', 0.2)))))
                          for item in recent_steps if isinstance(item[4], dict))
            if elapsed > 0:
                info['average_duration'] = float(info.get('average_duration', elapsed)) * 0.88 + elapsed * 0.12
            info['last_attempt_step'] = game.game_steps
            if succeeded:
                info['successes'] = info.get('successes', 0) + 1
                if outcome or semantic_goal_progress:
                    info['purpose'] = 'outcome'
                    info['purpose_confidence'] = min(1.0, 0.80 * float(info.get('purpose_confidence', 0.0)) + 0.20)
                    game.diagnostics['skill_purpose_confirmations'] += 1
                info['navigation_successes'] = min(1000000, int(info.get('navigation_successes', 0)) + 1)
                if outcome or (evidence.get('goal_direction_evidence') and objective >= 0.012
                               and float(evidence.get('objective_evidence_confidence') or 0.0) >= 0.30):
                    info['objective_successes'] = min(1000000, int(info.get('objective_successes', 0)) + 1)
                info['last_success_step'] = game.game_steps
                game.plan_success[1] += 1
                info['quality'] = min(2.0, float(info.get('quality', 0.0)) * 0.92 + 0.08)
            elif info['attempts'] >= 3:
                info['quality'] = max(0.0, float(info.get('quality', 0.0)) * 0.985)
            info['failure_rate'] = max(0.0, min(1.0, 1.0 - int(info.get('successes', 0)) / previous_attempts))

    def _update_world(self, game, key, differences):
        differences = differences[:WORLD_FEATURE_COUNT]
        record = game.world.get(key)
        if record is None:
            error = sum(abs(v) for v in differences) / max(1, len(differences))
            game.world[key] = [differences[:], 1, error, 0.0]
            progress = 0.0
        else:
            average, count, last_error = record[:3]
            if len(average) < len(differences):
                average.extend(differences[len(average):])
            if len(record) < 4:
                record.append(0.0)
            error = sum(abs(v - avg) for v, avg in zip(differences, average)) / max(1, len(differences))
            progress = max(0.0, last_error - error) if count >= 4 else 0.0
            rate = 1.0 / min(45, count + 1)
            for i, value in enumerate(differences):
                average[i] = average[i] * (1 - rate) + value * rate
            record[1] += 1
            record[2] = last_error * 0.94 + error * 0.06
            game.world.move_to_end(key)
        while len(game.world) > 12500:
            game.world.popitem(last=False)
        return error, progress

    @staticmethod
    def goal_hypothesis_score(record, direction):
        if not isinstance(record, (list, tuple)) or len(record) != 4:
            return 0.0, 0.0
        up_good, up_bad, down_good, down_bad = [max(0.0, float(value)) for value in record]
        total = up_good + up_bad + down_good + down_bad
        if total < 1.5:
            return 0.0, 0.0
        up = (up_good - up_bad) / (up_good + up_bad + 2.0)
        down = (down_good - down_bad) / (down_good + down_bad + 2.0)
        direction = 1 if direction >= 0 else -1
        balance = (up - down) * direction
        evidence = min(0.92, total / (total + 5.0))
        return max(-1.0, min(1.0, balance)), evidence

    @staticmethod
    def calibrated_goal_count(game):
        amount = 0
        for key, record in game.goal_hypotheses.items():
            if not isinstance(record, list) or len(record) != 4:
                continue
            total = sum(max(0.0, float(value)) for value in record)
            if total < 1.5:
                continue
            difference = max(abs(record[0] - record[1]), abs(record[2] - record[3]))
            contexts = max((entry[0] | entry[1]).bit_count()
                           for label, entry in game.goal_context_support.items()
                           if label.startswith(key + '|')) if any(label.startswith(key + '|') for label in game.goal_context_support) else 1
            outcome_agreement = max(float(record[0]), float(record[2]))
            outcome_contradiction = max(float(record[1]), float(record[3]))
            if (difference >= 0.25 and contexts >= 2 and total >= 2.0
                    and outcome_agreement > outcome_contradiction * 1.25):
                amount += 1
        return amount

    def objective_signal(self, game, old, new, causal, persistence, stability, semantic=None, confirmed=None):
        reliability = max(0.0, min(1.0, causal * persistence * stability))
        game.goal_signal_conflict = 0.0
        if reliability < 0.19 and confirmed is None:
            return 0.0, []
        if confirmed in ('win', 'task', 'loss'):
            reliability = max(reliability, 0.55 * max(0.0, min(1.0, stability)))
        semantic = semantic or {}
        signals = []
        if len(old.hud_readouts) == len(new.hud_readouts) == 48:
            for index, (before, after) in enumerate(zip(old.hud_readouts, new.hud_readouts)):
                difference = after - before
                if abs(difference) >= 0.12:
                    signals.append((str(index), 1 if difference > 0 else -1,
                                    min(1.0, abs(difference) * 2.0), 'hud'))
        for item in semantic.get('numeric_readout_changes', []):
            delta = int(item.get('delta', 0))
            if delta and abs(delta) <= 10000:
                x, y = float(item.get('x', 0.5)), float(item.get('y', 0.5))
                key = f'number:{max(0, min(15, int(x * 16)))}:{max(0, min(9, int(y * 10)))}'
                signals.append((key, 1 if delta > 0 else -1, min(1.0, math.log1p(abs(delta)) / 5.0), 'number'))
        for item in semantic.get('relation_events', [])[:12]:
            kind = str(item.get('kind', ''))
            if kind in ('contact', 'approaching', 'receding', 'separated', 'object_disappeared'):
                strength = max(0.0, min(1.0, float(item.get('magnitude', 0.0))
                                                * float(item.get('confidence', 0.0))))
                if strength >= 0.08:
                    signals.append(('relation:' + kind, 1, strength, 'relation'))
        for item in semantic.get('meter_changes', []):
            region = str(item.get('region', ''))
            delta = float(item.get('relative_delta', 0.0))
            if region and len(region) <= 30 and abs(delta) >= 0.03:
                signals.append(('meter:' + region, 1 if delta > 0 else -1,
                                min(1.0, abs(delta) * 2.0), 'meter'))
        recent = OrderedDict()
        for key, direction, strength, signal_type in signals:
            if (key, direction) not in recent or strength > recent[(key, direction)][0]:
                recent[(key, direction)] = (strength, signal_type)
        positive, negative = 0.0, 0.0
        detected = []
        for (key, direction), (strength, signal_type) in recent.items():
            hypothesis = game.goal_hypotheses.get(key)
            support, confidence = self.goal_hypothesis_score(hypothesis, direction)
            calibration = game.goal_context_support.get(key + ('|+' if direction > 0 else '|-'))
            if calibration is not None:
                independent = (int(calibration[0]) | int(calibration[1])).bit_count()
                support_conflict = min(int(calibration[0]).bit_count(), int(calibration[1]).bit_count())
                confidence *= (0.22 + 0.78 * min(1.0, independent / 3.0))
                if independent < 2:
                    confidence *= 0.50
                confidence *= max(0.30, 1.0 - 0.16 * support_conflict)
            if confidence >= 0.12:
                contribution = min(0.085, 0.13 * strength * confidence * reliability * abs(support))
                if support >= 0:
                    positive += contribution
                else:
                    negative += contribution
            if confirmed is None and reliability >= 0.30 and strength >= 0.06:
                if not game.numeric_recent or game.numeric_recent[-1] != (key, direction, self.step):
                    game.numeric_recent.append((key, direction, self.step))
        if confirmed in ('win', 'task', 'loss'):
            observations = list(game.numeric_recent)[-64:]
            observations.extend((key, direction, self.step) for key, direction in recent)
            unique = OrderedDict()
            for key, direction, step in reversed(observations):
                if (key, direction) not in unique:
                    unique[(key, direction)] = min(40, max(0, self.step - int(step)))
            for (key, direction), age in list(unique.items())[:32]:
                strength = max(0.06, 0.94 ** age) * reliability
                record = game.goal_hypotheses.get(key, [0.0, 0.0, 0.0, 0.0])
                category = key + ('|+' if direction > 0 else '|-')
                support = game.goal_context_support.get(category, [0, 0, 0])
                source = (str(getattr(old, 'scene_identity', '') or getattr(old, 'scene_key', ''))
                          + ':' + str(getattr(new, 'scene_identity', '') or getattr(new, 'scene_key', ''))
                          + ':' + str(self.step // 24))
                context_bit = 1 << (int.from_bytes(hashlib.blake2b(source.encode('utf-8'), digest_size=2).digest(), 'big') % 64)
                side = 1 if confirmed == 'loss' else 0
                independent = not bool(int(support[side]) & context_bit)
                support[side] = int(support[side]) | context_bit
                support[2] = min(1000000, int(support[2]) + int(independent))
                game.goal_context_support[category] = support
                game.goal_context_support.move_to_end(category)
                if not independent:
                    game.diagnostics['objective_duplicate_confirmations'] += 1
                    continue
                game.diagnostics['objective_context_checks'] += 1
                if support[0] and support[1]:
                    game.diagnostics['objective_contradictions'] += 1
                slot = (0 if direction > 0 else 2) + side
                record[slot] = min(1000000.0, record[slot] + strength)
                game.goal_hypotheses[key] = record
                game.goal_hypotheses.move_to_end(key)
                positive_outcome = confirmed != 'loss'
                trend = game.hud_trends.get(key, [0, 0.0, 0.0, 0.0])
                trend[0] = min(1000000, int(trend[0]) + 1)
                trend[1 if (direction > 0) == positive_outcome else 2] += strength
                trend[3] = min(1.0, 0.88 * float(trend[3]) + 0.12 * strength)
                game.hud_trends[key] = trend
                game.hud_trends.move_to_end(key)
                detected.append({'region': key, 'direction': 'up' if direction > 0 else 'down',
                                 'type': 'outcome_calibrated', 'examples': trend[0]})
            game.numeric_recent.clear()
        while len(game.goal_hypotheses) > 160:
            game.goal_hypotheses.popitem(last=False)
        while len(game.goal_context_support) > 320:
            game.goal_context_support.popitem(last=False)
        while len(game.hud_trends) > 160:
            game.hud_trends.popitem(last=False)
        total = positive + negative
        conflict = (2.0 * min(positive, negative) / total) if total >= 0.002 else 0.0
        game.goal_signal_conflict = max(0.0, min(1.0, conflict))
        signal = (positive - negative) * (1.0 - 0.65 * game.goal_signal_conflict)
        return max(-0.18, min(0.18, signal)), detected[:12]

    def discover_goal_candidates(self, game, old, new, semantic, causal, persistence, stability, seen):
        confidence = max(0.0, min(1.0, causal * persistence * stability))
        if confidence < 0.25 or old.phase not in ('playing', 'unknown') or new.phase == 'menu':
            return 0.0, []
        candidates = []
        for event in semantic.get('relation_events', []):
            if event.get('kind') in ('approaching', 'contact', 'separated', 'receding', 'object_disappeared'):
                candidates.append(('relation:' + event['kind'], float(event.get('magnitude', 0.0))
                                   * float(event.get('confidence', 0.0))))
        for item in semantic.get('meter_changes', [])[:8]:
            direction = '+' if float(item.get('relative_delta', 0.0)) > 0 else '-'
            candidates.append(('meter:' + str(item.get('region', ''))[:34] + direction,
                               min(1.0, abs(float(item.get('relative_delta', 0.0))))))
        for item in semantic.get('numeric_readout_changes', [])[:8]:
            direction = '+' if int(item.get('delta', 0)) > 0 else '-'
            x, y = float(item.get('x', 0.5)), float(item.get('y', 0.5))
            candidates.append((f'number:{int(x * 16)}:{int(y * 10)}{direction}',
                               min(1.0, math.log1p(abs(int(item.get('delta', 0)))) / 6.0)))
        if old.signature != new.signature and new.novelty > 0.30 and persistence >= 0.60:
            candidates.append(('scene:transition', min(1.0, new.novelty)))
        if not candidates:
            return 0.0, []
        context = self.experiment_context(old)
        observations, total = [], 0.0
        for key, magnitude in candidates:
            if not key or magnitude < 0.05 or seen >= 5:
                continue
            record = game.goal_proposals.get(key, [0.0, 0.0, 0.0, '', ''])
            previous_context = str(record[3])
            context_bit = 1 << (int.from_bytes(hashlib.blake2b(context.encode('utf-8'), digest_size=2).digest(), 'big') % 32)
            context_mask = int(record[4]) if isinstance(record[4], int) else 0
            context_new = bool(context_mask & context_bit == 0)
            reverse_key = key[:-1] + ('-' if key.endswith('+') else '+') if key[-1:] in '+-' else ''
            reversals = float(game.goal_proposals.get(reverse_key, [0.0, 0.0])[0]) if reverse_key else 0.0
            record[0] = min(1000000.0, float(record[0]) + confidence * magnitude)
            record[1] = min(1000000.0, float(record[1]) + (1.0 if context_new else 0.0))
            record[2] = min(1000000.0, float(record[2]) + (confidence * magnitude if seen < 3 else 0.0))
            record[3], record[4] = context, context_mask | context_bit
            game.goal_proposals[key] = record
            game.goal_proposals.move_to_end(key)
            if reversals > 0.75:
                game.diagnostics['goal_candidate_reversals'] += 1
            if context_new and record[1] >= 3 and record[2] >= 1.2:
                gain = 0.003 * confidence * min(1.0, magnitude) * min(1.0, record[1] / 6.0)
                gain /= 1.0 + reversals * 0.20
                total += gain
                observations.append({'type': 'unverified_goal_hypothesis', 'event': key,
                                     'independent_contexts': int(record[1]),
                                     'confidence': round(min(0.30, confidence * record[1] / 20.0), 4)})
            game.diagnostics['goal_candidate_observations'] += 1
        while len(game.goal_proposals) > 240:
            game.goal_proposals.popitem(last=False)
        return min(0.008, total), observations[:12]

    def terminal_feedback_support(self, feedback, label, point):
        if not label or not isinstance(feedback, dict):
            return 0
        evidence = feedback.get('result_check_frames', [])
        normalized = ''.join(c for c in str(label).upper() if c.isalnum())
        matches = 0
        for frame in evidence[-3:]:
            if not isinstance(frame, bytes) or len(frame) != W * H * 4:
                continue
            try:
                recognized = self.read_ui_symbols(frame)
            except Exception:
                continue
            if any(''.join(c for c in str(item.get('text', '')).upper() if c.isalnum()) == normalized
                   and float(item.get('confidence', 0.0)) >= 0.86
                   and (point is None or (abs(float(item.get('x', -1.0)) - point[0]) < 0.06
                                          and abs(float(item.get('y', -1.0)) - point[1]) < 0.07))
                   for item in recognized):
                matches += 1
        return matches

    @staticmethod
    def relation_events(old, new):
        previous = {item.get('track_id'): item for item in getattr(old, 'objects', [])
                    if item.get('track_id') is not None and item.get('age', 0) >= 3
                    and float(item.get('confidence', 0.0)) >= 0.5}
        current = {item.get('track_id'): item for item in getattr(new, 'objects', [])
                   if item.get('track_id') is not None and item.get('age', 0) >= 3
                   and float(item.get('confidence', 0.0)) >= 0.5}
        common = previous.keys() & current.keys()
        actors = [key for key in common
                  if min(float(previous[key].get('control_probability', 0.0)),
                         float(current[key].get('control_probability', 0.0))) >= 0.34]
        if not actors:
            return []
        actor = max(actors, key=lambda key: float(current[key].get('control_probability', 0.0)))
        before, after = previous[actor], current[actor]
        events = []
        for key in common:
            if key == actor:
                continue
            old_item, new_item = previous[key], current[key]
            old_distance = math.hypot(old_item['x'] - before['x'], old_item['y'] - before['y'])
            new_distance = math.hypot(new_item['x'] - after['x'], new_item['y'] - after['y'])
            change = old_distance - new_distance
            confidence = min(float(before['confidence']), float(after['confidence']),
                             float(old_item['confidence']), float(new_item['confidence']))
            event_type = ('contact' if new_distance < 0.045 and old_distance >= 0.075 else
                          'separated' if old_distance < 0.045 and new_distance >= 0.085 else
                          'approaching' if change > 0.035 else
                          'receding' if change < -0.035 else None)
            if event_type and confidence >= 0.55:
                events.append({'kind': event_type, 'target': int(key),
                               'magnitude': round(min(1.0, abs(change) * 5.0), 4),
                               'confidence': round(confidence, 4)})
        if float(getattr(new, 'camera_motion', (0, 0, 0))[2]) < 0.45:
            for key in previous.keys() - current.keys():
                if key != actor and previous[key].get('age', 0) >= 4 and previous[key]['confidence'] >= 0.75:
                    events.append({'kind': 'object_disappeared', 'target': int(key),
                                   'magnitude': 0.20, 'confidence': round(float(previous[key]['confidence']) * 0.7, 4)})
        events.sort(key=lambda event: event['confidence'] * event['magnitude'], reverse=True)
        return events[:12]

    def progress_evidence(self, old, new, causal, persistence, stability):
        reliability = max(0.0, min(1.0, causal * persistence * stability))
        changes = []
        for key, previous in old.hud_meters.items():
            current = new.hud_meters.get(key)
            if current is None or previous < 0.055 or abs(current - previous) < 0.012:
                continue
            movement = max(-1.0, min(1.0, (current - previous) / max(0.07, previous)))
            changes.append({'region': key, 'relative_delta': round(movement, 3)})
        observed_results = [item for item in new.ui_text if min(float(item.get('confidence', 0.0)),
                             float(item.get('temporal_confidence', item.get('confidence', 0.0)))) >= 0.76]
        win_words = ('VICTORY', 'YOUWIN', 'WIN', 'WON', '获胜', '胜利', '通关')
        loss_words = ('DEFEAT', 'FAILED', 'GAMEOVER', 'YOULOSE', 'LOSE', 'LOSS', '失败', '战败', '游戏结束')
        task_words = ('SUCCESS', 'CLEAR', '任务完成', '完成任务', '挑战成功', '达标', '成功')
        result = None
        result_confidence = 0.0
        result_text = None
        result_classes = set()
        def matched(text, words):
            return any((word in text if not word.isascii() else text == word or (len(word) >= 5 and text.endswith(word) and len(text) <= len(word) + 4)) for word in words)
        for item in observed_results:
            label = ''.join(c for c in item['text'].upper() if c.isalnum())
            candidate = None
            if matched(label, loss_words):
                candidate = 'loss_candidate'
            elif matched(label, win_words):
                candidate = 'win_candidate'
            elif matched(label, task_words):
                candidate = 'task_candidate'
            if candidate:
                result_classes.add(candidate)
                candidate_confidence = min(float(item.get('confidence', 0.0)),
                                           float(item.get('temporal_confidence', item.get('confidence', 0.0))))
                if candidate_confidence > result_confidence:
                    result, result_confidence, result_text = candidate, candidate_confidence, item['text']
        number_changes = []
        for item in new.ui_numbers:
            if min(float(item.get('confidence', 0.0)), float(item.get('temporal_confidence', 0.0))) < 0.69:
                continue
            old_match = next((prior for prior in old.ui_numbers if min(float(prior.get('confidence', 0.0)), float(prior.get('temporal_confidence', 0.0))) >= 0.65
                              and abs(prior['x'] - item['x']) < 0.025 and abs(prior['y'] - item['y']) < 0.025), None)
            if old_match is None:
                continue
            difference = int(item['text']) - int(old_match['text'])
            if difference and abs(difference) < 100000:
                number_changes.append({'x': item['x'], 'y': item['y'], 'delta': difference})
        information_gain = 0.0
        if reliability >= 0.38 and new.novelty > 0.12:
            evidence = ([('meter:' + entry['region'], abs(entry['relative_delta'])) for entry in changes[:10]]
                        + [('number:' + str(max(0, min(15, int(item['x'] * 16)))) + ':' + str(max(0, min(9, int(item['y'] * 10)))),
                            min(1.0, math.log1p(abs(item['delta'])) / 6.0)) for item in number_changes[:10]])
            for key, magnitude in evidence:
                if magnitude < 0.05:
                    continue
                tag = 'probe:' + key
                record = self.game.candidate_events.get(tag, [0, 0.0])
                if record[0] == 0 or self.step > record[0] + 1:
                    information_gain += (0.006 * reliability * min(1.0, magnitude * 2.0)
                                         / math.sqrt(1.0 + max(0.0, record[1]) * 10.0))
                record[0] = self.step
                record[1] = min(10.0, float(record[1]) + reliability * 0.12)
                self.game.candidate_events[tag] = record
                self.game.candidate_events.move_to_end(tag)
            while len(self.game.candidate_events) > 350:
                self.game.candidate_events.popitem(last=False)
        information_gain = min(0.016, max(0.0, information_gain))
        return information_gain, {
            'candidate_information_gain': round(information_gain, 5),
            'meter_changes': changes[:10], 'numeric_readout_changes': number_changes[:10],
            'result_text_candidate': result, 'result_text_confidence': round(result_confidence, 3), 'result_text': result_text,
            'recognized_text_candidates': [item['text'] for item in observed_results[:8]],
            'conflicting_screen_outcomes': len(result_classes) > 1,
            'semantic_confidence': round(reliability, 3),
        }

    @staticmethod
    def aligned_visual_change(old, new):
        start, end = 1, GH - 1
        baseline = sum(abs(old.lum[y * GW + x] - new.lum[y * GW + x])
                       for y in range(start, end) for x in range(GW)) / max(1, (end - start) * GW)
        texture = sum(abs(old.lum[y * GW + x] - old.lum[y * GW + x - 1])
                      for y in range(start, end) for x in range(1, GW)) / max(1, (end - start) * (GW - 1))
        if baseline < 0.018 or texture < 0.012:
            return baseline, (0, 0), 0.0
        def alignment_error(dx, dy, stride):
            total, count = 0.0, 0
            for y in range(start, end, stride):
                py = y - dy
                if not start <= py < end:
                    continue
                for x in range(0, GW, stride):
                    px = x - dx
                    if 0 <= px < GW:
                        total += abs(new.lum[y * GW + x] - old.lum[py * GW + px])
                        count += 1
            coverage = count * stride * stride / max(1, (end - start) * GW)
            if coverage < 0.45 or count < 5:
                return float('inf')
            return total / count + 0.014 * max(0.0, 1.0 - min(1.0, coverage))
        candidates = []
        for dy in range(-5, 6):
            for dx in range(-8, 9):
                if dx == dy == 0:
                    continue
                estimate = alignment_error(dx, dy, 2)
                if math.isfinite(estimate):
                    candidates.append((estimate, dx, dy))
        candidates.sort()
        best_error, shift = baseline, (0, 0)
        for _, dx, dy in candidates[:12]:
            exact = alignment_error(dx, dy, 1)
            if exact < best_error:
                best_error, shift = exact, (dx, dy)
        improvement = max(0.0, (baseline - best_error) / max(0.018, baseline))
        if shift == (0, 0) or improvement < 0.20:
            return baseline, (0, 0), 0.0
        return max(0.0, best_error), shift, min(1.0, (improvement - 0.14) * 2.2)

    @staticmethod
    def goal_value_input(features):
        indices = ([1, 2, 3, 4, 5, 7, 8, 9]
                   + [18 + 7 * i for i in range(12)]
                   + list(range(SEMANTIC_START, SEMANTIC_START + 24))
                   + list(range(SEMANTIC_START + 56, SEMANTIC_START + 60)))
        values = features.features if hasattr(features, 'features') else features
        return [max(-1.0, min(1.0, float(values[i]))) for i in indices]

    @staticmethod
    def goal_value(game, values):
        return math.tanh(game.goal_value_bias + sum(a * b for a, b in zip(game.goal_value_weights, values)))

    def update_goal_value(self, game, old, new, confirmed, elapsed_seconds=TIME_REFERENCE_SECONDS):
        old_input = self.goal_value_input(old)
        new_input = self.goal_value_input(new)
        previous = self.goal_value(game, old_input)
        current = self.goal_value(game, new_input)
        seconds = max(0.03, min(8.0, float(elapsed_seconds)))
        evidence = min(1.0, game.goal_value_samples / (game.goal_value_samples + 7.0))
        confidence = max(0.0, 1.0 - min(1.0, game.goal_value_error))
        shaping = max(-0.055, min(0.055, 0.10 * evidence * confidence
                                  * (long_goal_discount(seconds) * current - previous)))
        game.goal_recent.append((old_input, seconds))
        if confirmed in ('win', 'task', 'loss'):
            trajectory = list(game.goal_recent)[-120:]
            direction = -1.0 if confirmed == 'loss' else 1.0 if confirmed == 'win' else 0.82
            errors, age_seconds = [], 0.0
            for item, duration in [(new_input, 0.0)] + list(reversed(trajectory)):
                age_seconds += max(0.0, min(8.0, float(duration)))
                target = direction * long_goal_discount(age_seconds)
                predicted = self.goal_value(game, item)
                residual = max(-1.2, min(1.2, target - predicted))
                errors.append(abs(residual))
                rate = 0.10 / (1.0 + 0.10 * age_seconds / TIME_REFERENCE_SECONDS)
                norm = 1.0 + 0.16 * sum(value * value for value in item)
                gradient = rate * residual * (1.0 - predicted * predicted) / norm
                for i, value in enumerate(item):
                    game.goal_value_weights[i] = max(-0.8, min(0.8, game.goal_value_weights[i] + gradient * value))
                game.goal_value_bias = max(-0.6, min(0.6, game.goal_value_bias + gradient * 0.35))
            error = sum(errors) / max(1, len(errors))
            game.goal_value_error = (0.85 * game.goal_value_error + 0.15 * error) if game.goal_value_samples else error
            game.goal_value_samples = min(1000000, game.goal_value_samples + 1)
            game.goal_recent.clear()
        return shaping, previous, current

    def reward_for(self, old, new, idx, effect=None, feedback=None):
        with self.lock:
            game = self.game
            self.dirty_games.add(self.game_key)
            self.dirty_sequence += 1
            delta = sum(abs(a - b) for a, b in zip(old.lum, new.lum)) / (GW * GH)
            low_information = bool(old.quality.get('low_information') or new.quality.get('low_information'))
            if not old.valid or not new.valid or old.game != new.game or low_information:
                self.reward_info = {'proxy_reward': 0.0, 'reward_basis': 'insufficient_visual_information' if low_information else 'capture_integrity_failed', 'visual_change': round(delta, 5), 'control_signal': 0.0, 'progress_signal': 0.0, 'outcome_signal': 0.0, 'verified_win': None, 'verified_task_progress': None, 'input_effect_is_causal': None}
                return 0.0, delta
            aligned_delta, camera_shift, camera_confidence = self.aligned_visual_change(old, new)
            center_old_change = sum(abs(old.lum[i] - new.lum[i]) for i in
                                    (r * GW + c for r in range(2, GH - 2) for c in range(GW))) / ((GH - 4) * GW)
            local_ratio = min(1.0, aligned_delta / max(0.012, center_old_change)) if camera_confidence else 1.0
            motion_factor = max(0.20, 1.0 - camera_confidence * (1.0 - local_ratio) * 0.80)
            signals = feedback or {}
            samples = [float(value) for value in signals.get('frame_deltas', []) if isinstance(value, (int, float)) and math.isfinite(value)]
            peak = max([delta] + samples)
            settled = float(signals.get('settled_change', delta))
            passive = game.passive_change if game.passive_samples else 0.0
            scene_passive = (game.passive_scenes.get('context:' + self.experiment_context(old))
                             or game.passive_scenes.get(old.signature))
            if scene_passive is not None:
                scene_mean, scene_m2, scene_samples = scene_passive
                natural_variance = math.sqrt(max(0.0, scene_m2 / max(1, scene_samples - 1))) if scene_samples >= 2 else 0.0
                passive = max(passive * 0.65, scene_mean + 1.65 * natural_variance)
            else:
                passive = max(passive, game.baseline_change * 0.18)
            elapsed_for_feedback = action_elapsed_seconds(effect)
            timed_context = 'context:' + self.experiment_context(old)
            duration_band = 'short' if elapsed_for_feedback < 0.12 else 'medium' if elapsed_for_feedback < 0.42 else 'long'
            timed_record = (game.passive_timed.get(timed_context + ':time:' + duration_band)
                            or game.passive_timed.get(old.signature + ':time:' + duration_band))
            if timed_record is not None and timed_record[2] >= 2:
                rate, rate_variance, quantity, reference = timed_record
                observed_window = min(1.5, max(0.04, elapsed_for_feedback))
                duration_scale = min(4.0, max(0.35, observed_window / max(0.012, reference)))
                natural_change = (rate + 1.20 * math.sqrt(max(0.0, rate_variance))) * observed_window
                passive = max(passive * 0.40, min(0.30, natural_change)
                              * min(1.0, quantity / 6.0) * (0.80 + 0.20 * min(1.0, duration_scale)))
            post_drift = max(0.0, float(signals.get('post_action_drift', 0.0)))
            interval_deltas = [float(value) for value in signals.get('interval_deltas', [])
                               if isinstance(value, (int, float)) and math.isfinite(value) and value >= 0.0]
            if len(interval_deltas) >= 2 and game.passive_samples >= 2:
                passive = max(passive, sorted(interval_deltas)[len(interval_deltas) // 2] * 0.34)
            background = max(passive * 1.65, game.baseline_change * 0.28,
                             min(peak * 0.35, post_drift * 0.55), 0.0025)
            effective = max(0.0, peak - background)
            causal = max(0.0, min(1.0, effective / max(0.012, peak)))
            causal *= max(0.0, min(1.0, peak / 0.045))
            if game.passive_samples == 0:
                causal *= 0.65
            persistence = max(0.0, min(1.0, settled / max(0.015, peak)))
            causal *= 0.7 + 0.3 * persistence
            observed_regions = self.regional_rgb_motion(old.rgb, new.rgb)
            motion_profile = (game.passive_motion_profiles.get('context:' + self.experiment_context(old))
                              or game.passive_motion_profiles.get(old.signature))
            region_causal_fraction = None
            if motion_profile is not None and motion_profile[1] >= 2:
                game.diagnostics['causal_profile_samples'] += 1
                expected_regions = motion_profile[0]
                total_regional = sum(observed_regions)
                unexplained = sum(max(0.0, value - 1.35 * baseline)
                                  for value, baseline in zip(observed_regions, expected_regions))
                region_causal_fraction = max(0.0, min(1.0, unexplained / max(0.012, total_regional)))
                causal *= 0.45 + 0.55 * region_causal_fraction
                regional_outliers = sum(value > 1.45 * baseline + 0.006 for value, baseline in zip(observed_regions, expected_regions))
                if regional_outliers == 0 and game.passive_samples >= 3:
                    causal *= 0.50
            response_times = signals.get('frame_times', [])
            if (len(samples) >= 3 and isinstance(response_times, list)
                    and len(response_times) == len(samples) and all(isinstance(t, (float, int)) and math.isfinite(t) for t in response_times)):
                peak_position = max(range(len(samples)), key=samples.__getitem__)
                time_span = max(0.001, float(response_times[-1]) - float(response_times[0]))
                if peak_position == 0 and samples[-1] >= samples[0] * 0.92 and post_drift > max(0.012, peak * 0.35):
                    causal *= 0.63
                if peak_position > 0 and float(response_times[peak_position]) > float(response_times[0]) + time_span * 0.92 and persistence < 0.40:
                    causal *= 0.78
            causal *= max(0.45, motion_factor)
            if len(samples) >= 2 and post_drift > peak * 0.65:
                causal *= max(0.15, 1.0 - min(1.0, post_drift / max(0.015, peak)) * 0.55)
            game.baseline_change = game.baseline_change * 0.975 + delta * 0.025
            control_trace_valid = bool(isinstance(effect, dict) and effect.get('input_sent')
                                       and effect.get('feedback_valid', True) and len(samples) >= 2
                                       and float(signals.get('frame_stability', 0.0)) >= 0.42)
            controllability = self.infer_controllability(old, new, idx, causal if control_trace_valid else 0.0,
                                                        camera_shift, camera_confidence)
            differences = [b - a for a, b in zip(self.world_state(old), self.world_state(new))]
            world_keys = [idx, self._world_key(idx, old)]
            if effect is not None and effect.get('input_sent'):
                world_keys.append(self._world_key(idx, old, effect))
            stable_scene_hint = max(0.0, min(1.0, float(signals.get('frame_stability', 0.0))))
            quality = min(float(old.quality.get('confidence', 1.0)), float(new.quality.get('confidence', 1.0)))
            world_trustworthy = bool(causal >= 0.20 and persistence >= 0.25 and stable_scene_hint >= 0.38
                                     and quality >= 0.50 and len(samples) >= 2
                                     and post_drift <= max(0.09, peak * 0.95)
                                     and control_trace_valid)
            holdout_segment = game.game_steps // 24
            independent_scene_split = len(game.scene_centers) >= 5
            if independent_scene_split:
                holdout_key = f'{self.game_key}:scene:{old.scene_identity}:{self.experiment_context(old)}'.encode('utf-8')
            else:
                holdout_key = f'{self.game_key}:segment:{self.experiment_context(old)}:{holdout_segment}'.encode('utf-8')
            world_holdout = bool(world_trustworthy and hashlib.blake2b(holdout_key, digest_size=2).digest()[0] % 6 == 0)
            effect_information, effect_observation, effect_sample_confidence = self.observe_action_effect(
                game, old, idx, effect, causal, effective, persistence, quality, stable_scene_hint,
                peak, background, post_drift, len(samples))
            effect_probability, effect_confidence, effect_uncertainty = self.effect_prediction(game, old, idx, effect)
            if effect_observation == 1.0:
                game.diagnostics['effective_controls'] += 1
                if game.diagnostics['first_effect_action'] == 0:
                    game.diagnostics['first_effect_action'] = game.game_steps + 1
            elif effect_observation == 0.0 and game.action_attempts[idx] >= 2:
                game.diagnostics['repeated_ineffective_controls'] += 1
            passive_trustworthy = bool(effect_observation == 0.0 and control_trace_valid
                                       and effect_sample_confidence >= 0.45 and quality >= 0.53
                                       and stable_scene_hint >= 0.48 and len(samples) >= 2)
            passive_holdout = bool(passive_trustworthy and
                                   hashlib.blake2b(holdout_key, digest_size=2).digest()[0] % 6 == 0)
            world_trustworthy = world_trustworthy and effect_observation == 1.0
            world_holdout = world_holdout and world_trustworthy
            passive_validation_error = None
            if passive_trustworthy:
                if passive_holdout:
                    passive_delta, passive_confidence, _ = self.passive_world_prediction(game, old)
                    if passive_confidence >= 0.12:
                        passive_validation_error = self.world_error(passive_delta, differences)
                        game.diagnostics['passive_world_holdouts'] += 1
                else:
                    self.learn_passive_world(game, old, differences)
            prediction_error, conditional_error, learning_progress = 0.0, 0.0, 0.0
            if world_trustworthy and not world_holdout:
                prediction_error, first_progress = self._update_world(game, world_keys[0], differences)
                conditional_error, conditional_progress = self._update_world(game, world_keys[1], differences)
                parameter_progress = 0.0
                if len(world_keys) > 2 and world_keys[2] != world_keys[1]:
                    _, parameter_progress = self._update_world(game, world_keys[2], differences)
                learning_progress = max(first_progress * 0.5, conditional_progress, parameter_progress)
            if effective < max(0.008, passive * 0.4):
                game.stagnation += 1
            else:
                game.stagnation = max(0, game.stagnation - 2)
            trajectory = f'{self.state_signature(old)}:{idx}:{self.state_signature(new)}'
            seen = game.trajectories.get(trajectory, 0)
            game.trajectories[trajectory] = seen + 1
            game.trajectories.move_to_end(trajectory)
            if len(game.trajectories) > 12000:
                game.trajectories.popitem(last=False)
            hud_indices = [r * GW + c for r in (0, 1, GH - 2, GH - 1) for c in range(GW)]
            center_indices = [r * GW + c for r in range(3, GH - 3) for c in range(GW)]
            hud_change = sum(abs(old.lum[i] - new.lum[i]) for i in hud_indices) / len(hud_indices)
            center_change = sum(abs(old.lum[i] - new.lum[i]) for i in center_indices) / max(1, len(center_indices))
            event = None
            event_strength = 0.0
            stable_hud = float(signals.get('hud_stability', 1.0))
            stable_scene = max(0.0, min(1.0, float(signals.get('frame_stability', 0.0))))
            if hud_change > background + 0.038 and hud_change > center_change * 1.35 and causal > 0.28 and stable_hud > 0.55 and stable_scene > 0.55 and len(samples) >= 3:
                sections = []
                for rows in ((0, 1), (GH - 2, GH - 1)):
                    for left in (0, GW // 2):
                        indices = [r * GW + c for r in rows for c in range(left, left + GW // 2)]
                        sections.append(min(9, int(sum(abs(old.lum[i] - new.lum[i]) for i in indices) * 28 / len(indices))))
                signature = ':'.join(map(str, sections))
                record = game.candidate_events.get(signature, [0, 0.0])
                record[0] += 1
                record[1] = record[1] * 0.82 + causal * stable_hud * 0.18
                game.candidate_events[signature] = record
                game.candidate_events.move_to_end(signature)
                while len(game.candidate_events) > 350:
                    game.candidate_events.popitem(last=False)
                event = 'persistent_action_correlated_hud_change'
                event_strength = min(1.0, hud_change * 3.5) * min(0.80, 0.12 + 0.06 * record[0]) * record[1] * stable_scene
            discovery = min(1.0, effective * 9.0) * max(0.0, new.novelty - 0.20) * causal
            novelty_reliability = max(0.0, min(1.0, (stable_scene - 0.30) / 0.70))
            discovery *= novelty_reliability * motion_factor * max(0.0, 1.0 - min(1.0, post_drift * 8.0))
            mastery = min(1.0, learning_progress * 7.0) * (0.3 + 0.7 * causal)
            mastery *= max(0.0, min(1.0, (effective - passive * 0.25) / max(0.012, effective)))
            mastery *= novelty_reliability * motion_factor * max(0.0, 1.0 - min(1.0, passive * 7.0))
            no_effect = effect_observation == 0.0
            loop_count = seen + 1
            repeated = min(0.095, 0.019 * math.log1p(seen))
            meaningful_event = event_strength * min(1.0, persistence * 1.4) * max(0.0, 1.0 - min(0.85, seen * 0.16))
            object_motion = 0.0
            object_matches = 0
            for item in new.objects[:18]:
                matches = [prior for prior in old.objects[:18]
                           if ((item.get('track_id') is not None and prior.get('track_id') == item.get('track_id'))
                               or (abs(prior['x'] - item['x']) < 0.18 and abs(prior['y'] - item['y']) < 0.20
                                   and sum(abs(a - b) for a, b in zip(prior['color'], item['color'])) < 0.35))]
                if matches:
                    prior = min(matches, key=lambda candidate: abs(candidate['x'] - item['x']) + abs(candidate['y'] - item['y']))
                    object_motion += min(1.0, math.hypot(prior['x'] - item['x'], prior['y'] - item['y']) * 7.0)
                    object_matches += 1
            object_motion = object_motion / object_matches if object_matches else 0.0
            new_scene_persistent = new.signature != old.signature and settled >= max(0.025, peak * 0.6) and causal > 0.25 and stable_scene > 0.65
            scene_progress = min(1.0, persistence * 1.2) * new.novelty * causal * stable_scene * (0.40 + 0.60 * motion_factor) * (1.0 - 0.65 * new.camera_motion[2]) if new_scene_persistent and loop_count < 3 else 0.0
            goal_candidate = max(meaningful_event * 0.65, scene_progress * 0.14)
            progress_landmark = 0.0
            landmark = old.signature + '>' + new.signature
            if old.signature != new.signature and causal > 0.40 and stable_scene > 0.62 and persistence > 0.42 and loop_count <= 3:
                item = game.goal_landmarks.get(landmark, [0, 0.0, 0.0])
                item[0] += 1
                item[1] = item[1] * 0.84 + 0.16 * causal * stable_scene
                item[2] = item[2] * 0.84 + 0.16 * persistence
                game.goal_landmarks[landmark] = item
                game.goal_landmarks.move_to_end(landmark)
                while len(game.goal_landmarks) > 800:
                    game.goal_landmarks.popitem(last=False)
                progress_landmark = min(0.12, 0.04 * item[1] * item[2] / math.sqrt(max(1, item[0])))
            candidate_information, semantic_evidence = self.progress_evidence(old, new, causal, persistence, stable_scene)
            relation_events = self.relation_events(old, new) if world_trustworthy else []
            semantic_evidence['relation_events'] = relation_events
            goal_candidate_bonus, candidate_goals = self.discover_goal_candidates(
                game, old, new, semantic_evidence, causal, persistence, stable_scene, loop_count)
            semantic_evidence['unverified_goal_hypotheses'] = candidate_goals
            explicit_proxy = 0.0
            result_label = semantic_evidence['result_text_candidate']
            result_confidence = float(semantic_evidence['result_text_confidence'])
            result_key = new.signature + ':' + str(result_label) + ':' + str(self.step)
            if result_label and result_confidence >= 0.86:
                game.result_misses = 0
                previous_labels = {''.join(c for c in item['text'].upper() if c.isalnum()) for item in old.ui_text if item.get('confidence', 0) >= 0.84}
                new_result_words = semantic_evidence.get('result_text') or ''
                normalized_result = ''.join(c for c in new_result_words.upper() if c.isalnum())
                appeared = bool(normalized_result and normalized_result not in previous_labels)
                result_item = next((item for item in new.ui_text if item.get('text') == new_result_words), None)
                point = (float(result_item['x']), float(result_item['y'])) if result_item else None
                aligned = bool(point and game.result_position and abs(point[0] - game.result_position[0]) < 0.045
                               and abs(point[1] - game.result_position[1]) < 0.05)
                if game.result_label == result_label and game.result_scene == new.signature and aligned:
                    game.result_streak += 1
                else:
                    if game.result_label is not None and game.result_label != result_label:
                        game.result_active = False
                    game.result_label, game.result_scene, game.result_streak = result_label, new.signature, 1
                    game.result_appeared = appeared
                    game.result_position = point
            else:
                game.result_misses += 1
                game.result_streak = 0
                if game.result_misses >= 3:
                    game.result_label = None
                    game.result_scene = None
                    game.result_active = False
                    game.result_appeared = False
                    game.result_position = None
            confirmed_result = None
            result_frames = self.terminal_feedback_support(signals, semantic_evidence.get('result_text'), game.result_position) if result_label and not game.result_active else 0
            contextual_result = (new.phase == 'result' and new.phase_confidence >= 0.18
                                 or (old.phase == 'playing' and new.phase != 'menu'
                                     and (new.signature != old.signature or result_frames >= 2)))
            if ((game.result_streak >= 3 or result_frames >= 2) and game.result_appeared and not game.result_active and result_confidence >= 0.89
                    and stable_scene >= 0.58 and len(samples) >= 2 and persistence >= 0.60
                    and contextual_result and not semantic_evidence.get('conflicting_screen_outcomes')
                    and old.frame_uid != new.frame_uid and new.quality.get('trainable', False)):
                confirmed_result = 'loss' if result_label == 'loss_candidate' else 'win' if result_label == 'win_candidate' else 'task'
                game.result_active = True
                game.confirmed_results[result_key] = confirmed_result
                game.confirmed_results.move_to_end(result_key)
                while len(game.confirmed_results) > 96:
                    game.confirmed_results.popitem(last=False)
                game.screen_outcomes[confirmed_result] += 1
                explicit_proxy += (-0.92 if confirmed_result == 'loss' else 0.90 if confirmed_result == 'win' else 0.72) * result_confidence
            semantic_evidence['independent_result_frames'] = result_frames
            semantic_evidence['result_streak'] = game.result_streak
            semantic_evidence['result_first_appeared_after_action'] = game.result_appeared
            semantic_evidence['screen_result_context_correlated'] = bool(contextual_result)
            semantic_evidence['screen_result_confirmed'] = confirmed_result
            semantic_evidence['screen_result_is_game_truth'] = False
            goal_candidate = max(goal_candidate * 0.55, max(0.0, explicit_proxy))
            task_signal, hud_signals = self.objective_signal(game, old, new, causal, persistence, stable_scene,
                                                            semantic_evidence, confirmed_result)
            goal_signal_conflict = game.goal_signal_conflict
            goal_shaping, goal_before, goal_after = self.update_goal_value(game, old.features, new.features, confirmed_result, action_elapsed_seconds(effect))
            if confirmed_result is None and not game.goal_value_samples:
                goal_shaping = 0.0
            if world_trustworthy:
                self.record_world_event(game, old, idx, new, confirmed_result, quality * causal * stable_scene)
            game.goal_evidence.append((new.signature, goal_candidate, causal))
            if task_signal > 0.014:
                game.stagnation = max(0, game.stagnation - 3)
            discovery *= min(1.0, persistence * 1.7) if peak > 0.02 else 0.0
            mastery *= causal if not no_effect else 0.0
            learned_goals = min(1.0, game.goal_value_samples / 5.0)
            exploration_weight = max(0.25, 1.0 - 0.60 * learned_goals)
            intrinsic_reward = (0.010 * discovery + 0.008 * mastery + candidate_information + effect_information
                                + 0.005 * object_motion * causal * persistence * novelty_reliability * motion_factor
                                * max(0.0, 1.0 - min(1.0, post_drift * 8.0))) * (0.15 if explicit_proxy < -0.02 else 1.0)
            relational_information = (min(0.004, 0.0015 * sum(item['magnitude'] * item['confidence'] for item in relation_events))
                                      * causal * persistence * stable_scene if world_trustworthy else 0.0)
            unverified_bonus = (min(0.0025, goal_candidate_bonus) * max(0.0, min(1.0, causal * stable_scene))
                                / math.sqrt(1.0 + max(0, seen)))
            intrinsic_reward = intrinsic_reward * exploration_weight + relational_information + unverified_bonus
            calibrated_goals = self.calibrated_goal_count(game)
            outcome_score = explicit_proxy
            progress_score = max(-0.12, min(0.12, task_signal)) + (goal_shaping if game.goal_value_samples >= 2 else 0.0)
            if calibrated_goals == 0 and game.goal_value_samples < 2 and confirmed_result is None:
                progress_score = 0.0
            if confirmed_result is None and goal_signal_conflict > 0.0:
                progress_score *= max(0.10, 1.0 - 0.75 * goal_signal_conflict)
            objective_proxy = progress_score + outcome_score
            if confirmed_result in ('win', 'task'):
                game.diagnostics['credible_goal_progress'] += 1
            elif calibrated_goals and abs(task_signal) >= 0.006 and causal >= 0.27:
                game.diagnostics['credible_goal_progress'] += 1
            else:
                game.diagnostics['uncertain_goal_events'] += int(goal_candidate > 0.018)
            calibrated_goals = self.calibrated_goal_count(game)
            goal_reliability = max(0.32, min(1.0, 0.32 + 0.68 * learned_goals
                                             + 0.42 * float(bool(confirmed_result))
                                             + 0.20 * min(1.0, calibrated_goals / 12.0)))
            objective_proxy *= goal_reliability
            if learned_goals >= 0.6 or confirmed_result:
                intrinsic_reward = min(intrinsic_reward, max(0.0015, 0.020 * (1.0 - learned_goals) + 0.006))
            control_reward = 0.003 * causal * persistence if world_trustworthy and game.stagnation < 24 else 0.0
            proxy_exploration = min(0.008, 0.004 * meaningful_event + 0.003 * progress_landmark)
            if confirmed_result is None and not calibrated_goals:
                proxy_exploration *= 0.45
            recurring_without_progress = (loop_count >= 3 and causal < 0.30 and confirmed_result is None
                                           and max(0.0, task_signal) < 0.008 and meaningful_event < 0.03)
            if recurring_without_progress:
                intrinsic_reward *= 0.30
                proxy_exploration *= 0.20
            repetition_penalty = repeated * (0.60 if recurring_without_progress else 0.35)
            reward = (control_reward + intrinsic_reward + objective_proxy + proxy_exploration - repetition_penalty
                      - (0.018 if no_effect else 0.0) - (0.012 if game.stagnation > 24 else 0.0))
            if self.state_signature(new) == self.state_signature(old) and causal < 0.24:
                reward -= 0.018
            if loop_count >= 4 and causal < 0.28 and meaningful_event < 0.03 and new.novelty < 0.36:
                reward -= min(0.045, 0.009 * (loop_count - 3))
            if confirmed_result == 'win':
                reward = 0.92 + min(0.04, max(-0.04, reward * 0.05))
            elif confirmed_result == 'task':
                reward = 0.74 + min(0.04, max(-0.04, reward * 0.05))
            elif confirmed_result == 'loss':
                reward = -0.94 + min(0.04, max(-0.04, reward * 0.05))
            quality = min(float(old.quality.get('confidence', 1.0)), float(new.quality.get('confidence', 1.0)))
            reward = max(-1.0, min(1.0, reward * quality))
            action_evidence_confidence = (min(1.0, effect_sample_confidence * (0.35 + 0.65 * persistence))
                                          if effect_observation is not None else
                                          min(0.30, quality * causal * persistence * stable_scene)
                                          if control_trace_valid and effect_observation == 1.0 else 0.0)
            objective_evidence_confidence = (min(0.92, 0.68 + 0.22 * stable_scene)
                                             if confirmed_result else
                                             min(0.68, abs(task_signal) * 5.0 +
                                                 (0.24 if game.goal_value_samples >= 3 else 0.0))
                                             * causal * max(0.0, min(1.0, stable_scene)))
            if confirmed_result is None:
                objective_evidence_confidence *= max(0.10, 1.0 - 0.80 * goal_signal_conflict)
            goal_evidence_trainable = (confirmed_result is not None or
                (calibrated_goals >= 1 and abs(task_signal) >= 0.006
                 and causal >= 0.27 and stable_scene >= 0.48 and persistence >= 0.35))
            if goal_evidence_trainable and (control_trace_valid or confirmed_result):
                prior_goals = game.action_goal_samples[idx]
                goal_gain = min(0.18, 1.0 / (prior_goals + 1.0))
                target_goal = max(-1.0, min(1.0, objective_proxy))
                game.action_goal[idx] += goal_gain * (target_goal - game.action_goal[idx])
                game.action_goal_samples[idx] = min(1000000000, prior_goals + 1)
            negative_evidence_confidence = (effect_sample_confidence
                                            if effect_observation == 0.0 and no_effect else 0.0)
            reward_learning_confidence = quality * max(action_evidence_confidence * 0.86,
                objective_evidence_confidence, negative_evidence_confidence * 0.80)
            if not control_trace_valid and not confirmed_result:
                reward_learning_confidence = 0.0
            if effect_observation is None and not goal_evidence_trainable:
                reward_learning_confidence = 0.0
            if control_trace_valid:
                game.diagnostics['feedback_actions'] += 1
            if effect_observation == 1.0:
                game.diagnostics['effect_verified'] += 1
            if effect_observation == 0.0:
                game.diagnostics['no_effect_verified'] += 1
            if control_trace_valid and effect_observation is None:
                game.diagnostics['uncertain_action_feedback'] += 1
            if objective_evidence_confidence >= 0.25:
                game.diagnostics['objective_evidence'] += 1
            learned_prediction_error = None
            if world_holdout:
                learned_prediction_error = self.validate_world_prediction(game, idx, old.features, new.features, effect, context=old)
                if learned_prediction_error is not None and independent_scene_split:
                    game.diagnostics['scene_group_holdout_evaluations'] += 1
            elif world_trustworthy:
                self._update_world_reward(game, world_keys, reward, quality * causal)
                self.train_world_network(game, idx, old.features, effect, differences, reward, quality * (0.35 + 0.65 * causal))
                self._remember_world_parameters(game, idx, old, effect, reward, quality * causal)
            terminal_confidence = (causal * stable_scene * min(1.0, persistence * 1.2)
                                   * min(1.0, (hud_change + center_change) * 3.2)
                                   * min(1.0, delta * 4.0)) if new_scene_persistent else 0.0
            result_boundary = bool(confirmed_result)
            episode_boundary = bool(result_boundary)
            measured_effect = max(-0.30, min(1.0, effective * 6.0 * causal - (0.12 if no_effect else 0.0)))
            if effect_observation is not None:
                prior_samples = game.action_effect_samples[idx]
                rate = 1.0 / min(24, prior_samples + 1)
                game.action_effect[idx] += (measured_effect - game.action_effect[idx]) * rate
                game.action_effect_samples[idx] = prior_samples + 1
                family = self.family_for_action[idx]
                family_stats = game.family_score.setdefault(family, [0, 0.0])
                family_stats[0] += 1
                family_stats[1] = family_stats[1] * 0.93 + measured_effect * 0.07
            if effect_observation is not None and effect is not None and effect.get('spatial'):
                u, v = float(effect.get('start_x', effect.get('x', 0.5))), float(effect.get('start_y', effect.get('y', 0.5)))
                key = f'{min(GW - 1, max(0, int(u * GW)))}:{min(GH - 1, max(0, int(v * GH)))}'
                target = game.targets.get(key, [0.0, 0])
                target[0] = target[0] * 0.87 + max(0.0, measured_effect) * 0.13
                target[1] += 1
                game.targets[key] = target
                game.targets.move_to_end(key)
                while len(game.targets) > 720:
                    game.targets.popitem(last=False)
            times = signals.get('frame_times', [])
            if (world_trustworthy and isinstance(times, list) and len(times) == len(samples)
                    and all(isinstance(value, (int, float)) and math.isfinite(value) for value in times)):
                threshold = max(background + 0.006, peak * 0.52)
                observed = [max(0.035, float(moment)) for moment, value in zip(times, samples) if value >= threshold]
                if observed:
                    elapsed = min(1.30, min(observed))
                    kind = self.actions[idx].kind
                    record = game.feedback_latency_by_kind.get(kind, [game.feedback_delay, 0])
                    rate = min(0.22, 1.0 / (record[1] + 1))
                    record[0] = max(0.035, min(1.30, record[0] * (1.0 - rate) + elapsed * rate))
                    record[1] = min(1000000, record[1] + 1)
                    game.feedback_latency_by_kind[kind] = record
                    game.feedback_latency_by_kind.move_to_end(kind)
                    while len(game.feedback_latency_by_kind) > 96:
                        game.feedback_latency_by_kind.popitem(last=False)
                    game.feedback_delay = max(0.035, min(1.30, 0.94 * game.feedback_delay + 0.06 * elapsed))
            self.reward_info = {
                'proxy_reward': round(reward, 5),
                'action_evidence_confidence': round(action_evidence_confidence, 4),
                'objective_evidence_confidence': round(objective_evidence_confidence, 4),
                'goal_direction_evidence': bool(goal_evidence_trainable),
                'goal_action_estimate': round(game.action_goal[idx], 5),
                'reward_learning_confidence': round(reward_learning_confidence, 4),
                'reward_basis': 'persistent_screen_result_unverified_by_game' if confirmed_result else 'weak_self_supervised_exploration_not_game_verified',
                'visual_change': round(delta, 5),
                'camera_aligned_visual_change': round(aligned_delta, 5),
                'camera_shift': list(camera_shift),
                'camera_motion_confidence': round(camera_confidence, 4),
                'non_camera_event_fraction': round(local_ratio, 4),
                'passive_visual_change': round(passive, 5),
                'post_action_background_drift': round(post_drift, 5),
                'tracked_object_motion': round(object_motion, 5),
                'estimated_controllable_object': round(controllability, 5),
                'camera_control_profile': [round(value, 5) for value in game.control_profiles.get(self.actions[idx].id, [0.0] * 5 + [0])],
                'peak_action_visual_change': round(peak, 5),
                'estimated_action_effect': round(effective, 5),
                'causal_confidence': round(causal, 4),
                'control_signal': round(quality * causal * persistence, 5),
                'control_effect_confidence': round(action_evidence_confidence, 5),
                'progress_signal': round(progress_score * quality, 5),
                'progress_confidence': round(objective_evidence_confidence if calibrated_goals else 0.0, 5),
                'outcome_signal': round(outcome_score * quality, 5),
                'outcome_confidence': round(result_confidence if confirmed_result else 0.0, 5),
                'regional_causal_fraction': round(region_causal_fraction, 5) if region_causal_fraction is not None else None,
                'input_accepted_by_os': bool(isinstance(effect, dict) and effect.get('input_sent')),
                'game_input_received_verified': None,
                'control_learning_verified': world_trustworthy,
                'passive_world_feedback_verified': passive_trustworthy,
                'passive_world_holdout': passive_holdout,
                'passive_world_validation_error': round(passive_validation_error, 5) if passive_validation_error is not None else None,
                'action_effect_observation': effect_observation,
                'action_effect_observation_confidence': round(effect_sample_confidence, 4),
                'action_effect_prediction': round(effect_probability, 4),
                'action_effect_prediction_confidence': round(effect_confidence, 4),
                'action_effect_prediction_variance': round(effect_uncertainty, 5),
                'action_effect_information_gain': round(effect_information, 5),
                'goal_signal': round(objective_proxy * quality, 5),
                'information_signal': round((intrinsic_reward + proxy_exploration) * quality, 5),
                'feedback_samples': len(samples),
                'input_was_sent': bool(isinstance(effect, dict) and effect.get('input_sent')),
                'scene_phase_before': old.phase,
                'scene_phase_after': new.phase,
                'feedback_latency': round(game.feedback_latency_by_kind.get(self.actions[idx].kind, [game.feedback_delay])[0], 4),
                'novelty': round(new.novelty, 4),
                'visual_discovery': round(discovery, 5),
                'hud_proxy': round(new.hud - old.hud, 5),
                'hud_visual_change': round(hud_change, 5),
                'candidate_event': event,
                'goal_progress_candidate': round(goal_candidate, 5),
                'recurring_without_confirmed_progress': recurring_without_progress,
                'objective_evidence': semantic_evidence,
                'intrinsic_reward_component': round(intrinsic_reward * quality, 5),
                'candidate_information_gain': round(candidate_information * quality, 5),
                'objective_reward_proxy': round(objective_proxy * quality, 5),
                'learned_goal_value_shaping': round(goal_shaping * quality, 5),
                'goal_value_before': round(goal_before, 5),
                'goal_value_after': round(goal_after, 5),
                'goal_value_outcome_samples': game.goal_value_samples,
                'learned_hud_trend_signal': round(task_signal * quality, 5),
                'goal_signal_conflict': round(goal_signal_conflict, 4),
                'relational_event_count': len(relation_events),
                'calibrated_goal_hypotheses': calibrated_goals,
                'unverified_goal_hypotheses': len(game.goal_proposals),
                'unverified_goal_exploration_bonus': round(unverified_bonus, 5),
                'hud_readout_changes': hud_signals,
                'task_reward_basis': 'screen-outcome-calibrated-hud-number-meter-signals-not-game-verified',
                'persistent_landmark_evidence': round(progress_landmark, 5),
                'learned_landmark_count': len(game.goal_landmarks),
                'goal_evidence': 'unverified_persistent_hud_or_scene_change' if goal_candidate > 0.025 else 'no_verifiable_goal_signal',
                'reward_components': {'control': round(control_reward, 5), 'progress': round(progress_score, 5), 'outcome': round(outcome_score, 5), 'goal': round(objective_proxy, 5), 'exploration': round(intrinsic_reward + proxy_exploration, 5), 'persistent_hud_proxy': round(task_signal, 5), 'scene_proxy': round(proxy_exploration, 5), 'visual_semantic_proxy': round(explicit_proxy, 5), 'learned_hud_trend': round(task_signal, 5), 'learned_goal_value': round(goal_shaping, 5), 'repetition_penalty': round(repetition_penalty, 5)},
                'scene_stability': round(stable_scene, 4),
                'episode_boundary_candidate_confidence': round(terminal_confidence, 4),
                'episode_boundary': episode_boundary,
                'episode_boundary_reason': 'persistent_locally_recognized_result_text_not_game_verified' if result_boundary else None,
                'scene_before': old.quality.get('scene'),
                'scene_after': new.quality.get('scene'),
                'scene_loop_visits': loop_count,
                'persistent_visual_change': round(persistence, 5),
                'prediction_error': round(prediction_error, 5) if world_trustworthy else None,
                'conditional_prediction_error': round(conditional_error, 5) if world_trustworthy else None,
                'learning_progress': round(learning_progress, 5),
                'world_null_action_samples': sum(1 for value in game.world_effects.values() if value[1] > 1.0),
                'passive_world_sample_count': sum(int(row[1]) for key, row in game.passive_world.items() if key != 'global'),
                'learned_world_prediction_error': round(learned_prediction_error, 5) if learned_prediction_error is not None else None,
                'world_prediction_error_basis': 'training_excluded_holdout_observation' if learned_prediction_error is not None else 'insufficient_separate_validation',
                'world_validation_holdout': world_holdout,
                'world_validation_split': 'scene_group' if independent_scene_split else 'temporal_segment',
                'world_holdout_segment': holdout_segment,
                'world_phase_transition_samples': len(game.world_events),
                'world_network_steps': game.world_network_steps,
                'scene_background_baseline': round(passive, 5),
                'repeated_transition': seen,
                'observation_confidence': round(quality, 3),
                'verified_win': None,
                'screen_outcome_totals': dict(game.screen_outcomes),
                'screen_result_confirmation': confirmed_result,
                'verified_task_progress': None,
                'input_effect_is_causal': None,
                'input_effect_causality_proxy': round(causal, 4),
                'action_feedback_undetermined': effect_observation is None,
                'natural_motion_sample_count': game.passive_samples,
                'regional_natural_motion_profiles': len(game.passive_motion_profiles),
                'effective_action_seconds': round(action_elapsed_seconds(effect), 5),
            }
            return reward, delta

    def record_action_result(self, index, detail, reward):
        if not detail or not detail.get('input_sent'):
            return
        if float(self.reward_info.get('reward_learning_confidence') or 0.0) < 0.19:
            return
        action = self.actions[index]
        game = self.game
        if detail.get('input_sent') and (detail.get('spatial') or action.kind in ('key', 'hold', 'chord', 'combat', 'aim', 'look', 'wheel')):
            game.ensure_parameter_head(action.kind, self.hidden_size)
            game.ensure_parameter_head(self.parameter_head_key(action), self.hidden_size)
        visual_interruption = detail.get('interruption_reason') == 'visual_change' and detail.get('input_sent')
        duration = float(detail.get('duration', action.duration)) if visual_interruption else float(detail.get('requested_duration', action.duration))
        if (detail.get('finished', True) or visual_interruption) and math.isfinite(duration) and math.isfinite(reward):
            choices = (0.065, 0.12, 0.24, 0.48, 0.9, 1.45) if action.kind in ('key', 'hold', 'pair_hold', 'chord') else (0.12, 0.28, 0.55, 0.95, 1.4) if action.kind in ('press', 'swipe', 'right_swipe', 'combat', 'move_fire', 'aim', 'look', 'touch_tap', 'touch_swipe', 'pinch', 'dual_touch') else (action.duration,)
            selected = min(choices, key=lambda value: abs(value - duration))
            label = f'{action.kind}:{action.a}:{action.b}:{round(selected, 3)}'
            prior = game.duration_stats.get(label, [0.0, 0])
            count = int(prior[1]) + 1
            prior[0] += (max(-1.0, min(1.0, reward)) - prior[0]) / min(24, count)
            prior[1] = count
            game.duration_stats[label] = prior
            context = detail.get('learning_state_context')
            if isinstance(context, str) and context.startswith('c:') and len(context) < 40:
                scoped = context + ':' + action.id + ':' + str(round(selected, 3))
                record = game.duration_context_stats.get(scoped, [0, 0.0, 0.0, 0.0])
                number = min(1000000, record[0] + 1)
                rate = 1.0 / min(24, number)
                success = max(0.0, min(1.0, float(detail.get('learning_causality') or 0.0)))
                failed = float(detail.get('learning_effect_observation') == 0.0)
                record[1] += (max(-1.0, min(1.0, reward)) - record[1]) * rate
                record[2] += (success - record[2]) * rate
                record[3] += (failed - record[3]) * rate
                record[0] = number
                game.duration_context_stats[scoped] = record
                game.duration_context_stats.move_to_end(scoped)
                while len(game.duration_context_stats) > 1800:
                    game.duration_context_stats.popitem(last=False)
        if not detail.get('spatial'):
            return
        if (float(self.reward_info.get('reward_learning_confidence') or 0.0) < 0.25
                or self.reward_info.get('action_effect_observation') is None):
            return
        x = float(detail.get('start_x', detail.get('x', 0.5)))
        y = float(detail.get('start_y', detail.get('y', 0.5)))
        duration = float(detail.get('duration', action.duration))
        if not all(map(math.isfinite, (x, y, duration, reward))):
            return
        col = min(GW - 1, max(0, int(x * GW)))
        row = min(GH - 1, max(0, int(y * GH)))
        key = f'{action.kind}:{col}:{row}'
        old = game.parameter_stats.get(key, [0.0, 0, 0.0])
        count = int(old[1]) + 1
        rate = 1.0 / min(24, count)
        quality = 0.3 if detail.get('interrupted') else 1.0
        old[0] += (max(-1.0, min(1.0, reward)) - old[0]) * rate * quality
        old[2] += (max(0.0, float(self.reward_info.get('causal_confidence', 0.0))) - old[2]) * rate
        old[1] = count
        game.parameter_stats[key] = old
        game.parameter_stats.move_to_end(key)
        context = detail.get('learning_state_context')
        if isinstance(context, str) and context.startswith('c:') and len(context) < 40:
            scoped = context + ':' + action.id + f':{col}:{row}'
            record = game.spatial_context_stats.get(scoped, [0, 0.0, 0.0, 0.0])
            count_scoped = min(1000000, record[0] + 1)
            gain = (1.0 / min(24, count_scoped)) * quality
            record[1] += (max(-1.0, min(1.0, reward)) - record[1]) * gain
            record[2] += (max(0.0, float(detail.get('learning_causality') or 0.0)) - record[2]) * gain
            record[3] += (float(detail.get('learning_effect_observation') == 0.0) - record[3]) * gain
            record[0] = count_scoped
            game.spatial_context_stats[scoped] = record
            game.spatial_context_stats.move_to_end(scoped)
            while len(game.spatial_context_stats) > 6500:
                game.spatial_context_stats.popitem(last=False)
        while len(game.parameter_stats) > 3200:
            game.parameter_stats.popitem(last=False)

    def update_parameter_baselines(self, game, index, features, reward):
        kind = self.actions[index].kind
        for key in (kind, self.parameter_baseline_key(kind, features)):
            entry = game.parameter_baselines.get(key, [0, 0.0])
            entry[0] = min(10000000, entry[0] + 1)
            entry[1] += (max(-1.0, min(1.0, reward)) - entry[1]) / min(80, entry[0])
            game.parameter_baselines[key] = entry
            game.parameter_baselines.move_to_end(key)
        while len(game.parameter_baselines) > 2400:
            game.parameter_baselines.popitem(last=False)

    def recover_backend(self):
        with self.lock:
            previous = self.np
            if previous is None:
                return False
            target = None
            if getattr(previous, '__name__', '') == 'cupy':
                try:
                    cpu = importlib.import_module('numpy')
                    if validate_learning_backend(cpu):
                        target = cpu
                except Exception:
                    target = None
            def convert(value):
                if getattr(value, 'get', None) is not None:
                    value = value.get()
                if hasattr(value, 'tolist'):
                    value = value.tolist()
                return target.asarray(value, dtype=target.float32) if target is not None else value
            encoder = convert(self.encoder)
            encoder_bias = convert(self.encoder_bias)
            decoder = convert(self.decoder)
            decoder_bias = convert(self.decoder_bias)
            target_encoder = convert(self.target_encoder)
            target_encoder_bias = convert(self.target_encoder_bias)
            converted = {}
            for key, game in self.games.items():
                converted[key] = (convert(game.q), convert(game.bias), convert(game.target_q), convert(game.target_bias),
                                  convert(game.control_head), convert(game.objective_head),
                                  convert(game.control_head_bias), convert(game.objective_head_bias),
                                  {kind: (convert(head['w']), convert(head['b']), head['samples']) for kind, head in game.parameter_heads.items()},
                                  {name: convert(value) for name, value in game.world_network.items()} if game.world_network is not None else None)
            self.np = target
            try:
                self.cv_np = importlib.import_module('numpy') if target is None else target
            except ImportError:
                self.cv_np = None
            self.encoder, self.encoder_bias = encoder, encoder_bias
            self.decoder, self.decoder_bias = decoder, decoder_bias
            self.target_encoder, self.target_encoder_bias = target_encoder, target_encoder_bias
            for key, values in converted.items():
                game = self.games[key]
                game.np = target
                game.q, game.bias, game.target_q, game.target_bias = values[:4]
                game.control_head, game.objective_head, game.control_head_bias, game.objective_head_bias = values[4:8]
                game.parameter_heads = {kind: {'w': w, 'b': b, 'samples': samples} for kind, (w, b, samples) in values[8].items()}
                game.world_network = values[9]
            self.backend_generation += 1
            self.backend_recoveries += 1
            self.dirty_games.update(self.games)
            self.dirty_sequence += 1
            self.training_problem = None
            self.training_failures = 0
            return True

    def ensure_workers(self):
        if not self.storage_stop.is_set() and not self.storage_thread.is_alive():
            self.storage_thread = threading.Thread(target=self.storage_loop, name='AgentStorage', daemon=True)
            self.storage_thread.start()
            with self.storage_condition:
                self.storage_force = True
                self.storage_condition.notify_all()
        if not self.training_stop.is_set() and not self.trainer.is_alive():
            self.trainer = threading.Thread(target=self.training_loop, name='AgentLearner', daemon=True)
            self.trainer.start()

    def _training_snapshot(self, samples):
        snapshot = {
            'backend_generation': self.backend_generation,
            'encoder': self.encoder.copy() if self.np is not None else [row[:] for row in self.encoder],
            'encoder_bias': self.encoder_bias.copy() if self.np is not None else self.encoder_bias[:],
            'decoder': self.decoder.copy() if self.np is not None else [row[:] for row in self.decoder],
            'decoder_bias': self.decoder_bias.copy() if self.np is not None else self.decoder_bias[:],
            'target_encoder': self.target_encoder,
            'target_encoder_bias': self.target_encoder_bias,
            'games': {},
            'contrastive_examples': [],
            'contrastive_updates': {},
        }
        contrast_indices = (1, 3, 8, 18, 25, 40, 70, 115, SEMANTIC_START + 3, SEMANTIC_START + 28)
        for sample in samples[-72:]:
            if (len(sample) > 9 and isinstance(sample[9], dict)
                    and len(sample[1]) == FEATURE_COUNT and float(sample[8]) >= 0.45):
                visual = sample[1]
                if all(math.isfinite(float(visual[i])) for i in contrast_indices):
                    snapshot['contrastive_examples'].append((sample[0], sample[9].get('learning_state_context'), visual))
        for sample in samples:
            if len(sample) > 9 and isinstance(sample[9], dict) and sample[9].get('input_sent'):
                owner = self.games.get(sample[0])
                if owner is not None and isinstance(sample[2], int) and 0 <= sample[2] < len(self.actions):
                    action = self.actions[sample[2]]
                    owner.ensure_parameter_head(action.kind, self.hidden_size)
                    owner.ensure_parameter_head(self.parameter_head_key(action), self.hidden_size)
                    if isinstance(sample[9].get('learning_target_anchor'), list):
                        owner.ensure_parameter_head('target:' + action.kind, self.hidden_size)
                        owner.ensure_parameter_head('target:' + self.parameter_head_key(action), self.hidden_size)
        for key in {sample[0] for sample in samples}:
            game = self.games.get(key)
            if game is None:
                continue
            snapshot['games'][key] = {
                'q': game.q.copy() if self.np is not None else [row[:] for row in game.q],
                'bias': game.bias.copy() if self.np is not None else game.bias[:],
                'target_q': game.target_q,
                'target_bias': game.target_bias,
                'counts': game.counts[:],
                'parameter_heads': {kind: {'w': head['w'].copy() if self.np is not None else [row[:] for row in head['w']],
                                           'b': head['b'].copy() if self.np is not None else head['b'][:],
                                           'samples': int(head.get('samples', 0))} for kind, head in game.parameter_heads.items()},
                'parameter_baselines': {key: value[:] for key, value in game.parameter_baselines.items()},
            }
        return snapshot

    def _training_values(self, features, snapshot, game, target=False, include_hidden=False):
        encoder = snapshot['target_encoder'] if target else snapshot['encoder']
        encoder_bias = snapshot['target_encoder_bias'] if target else snapshot['encoder_bias']
        matrix = game['target_q'] if target else game['q']
        bias = game['target_bias'] if target else game['bias']
        if self.np is not None:
            x = self.np.asarray(features, dtype=self.np.float32)
            hidden = self.np.tanh(encoder @ x + encoder_bias)
            values = matrix @ hidden + bias
        else:
            hidden = [math.tanh(sum(w * x for w, x in zip(row, features)) + encoder_bias[j]) for j, row in enumerate(encoder)]
            values = [sum(w * value for w, value in zip(row, hidden)) + bias[i] for i, row in enumerate(matrix)]
        return (values, hidden) if include_hidden else values

    def _train_parameter(self, transition, snapshot, game):
        if len(transition) < 10 or transition[7] != 1 or not isinstance(transition[9], dict):
            return
        detail = transition[9]
        if detail.get('outcome_credit'):
            return
        if not detail.get('input_sent'):
            return
        early_feedback = detail.get('interruption_reason') == 'visual_change' and detail.get('early_visual_feedback')
        if (not detail.get('finished') or detail.get('interrupted')) and not early_feedback:
            return
        reward = float(transition[3])
        confidence = max(0.0, min(1.0, float(transition[8]))) if len(transition) > 8 else 0.65
        if not math.isfinite(reward) or confidence < 0.25:
            return
        if 'learning_causality' in detail and (float(detail.get('learning_causality') or 0.0) < 0.16
                                               or not math.isfinite(float(detail.get('learning_causality') or 0.0))):
            return
        action = self.actions[transition[2]] if 0 <= transition[2] < len(self.actions) else None
        if action is None:
            return
        kind = action.kind
        heads = [game['parameter_heads'].get(kind), game['parameter_heads'].get(self.parameter_head_key(action))]
        heads = [head for head in heads if head is not None]
        if not heads:
            return
        try:
            x = float(detail.get('start_x', detail.get('x', 0.5)))
            y = float(detail.get('start_y', detail.get('y', 0.5)))
            duration = float(detail.get('duration', 0.2)) if early_feedback else float(detail.get('requested_duration', detail.get('duration', 0.2)))
            extent = float(detail.get('extent', 1.0))
        except (ValueError, TypeError):
            return
        if not all(math.isfinite(v) for v in (x, y, duration, extent)):
            return
        target = [min(1.0, max(0.0, x)), min(1.0, max(0.0, y)),
                  min(1.0, max(0.0, (duration - 0.04) / 1.46)),
                  min(1.0, max(0.0, extent - 0.5))]
        spatial = bool(detail.get('spatial'))
        moving = kind in ('swipe', 'right_swipe', 'look', 'touch_swipe', 'pinch', 'dual_touch')
        mask = [False, False, True, moving]
        anchor = detail.get('learning_target_anchor')
        anchored = (spatial and isinstance(anchor, list) and len(anchor) == 4
                    and all(isinstance(value, (float, int)) and math.isfinite(value) for value in anchor)
                    and min(anchor[2:]) >= 0.01 and reward > 0.005 and confidence >= 0.38
                    and float(detail.get('learning_causality') or 0.0) >= 0.35
                    and detail.get('learning_effect_observation') == 1.0)
        if anchored:
            cx, cy, rx, ry = anchor
            target[0] = min(1.0, max(0.0, 0.5 + (x - cx) / (2.0 * rx)))
            target[1] = min(1.0, max(0.0, 0.5 + (y - cy) / (2.0 * ry)))
            heads = [(head, mask) for head in heads]
            for key in ('target:' + kind, 'target:' + self.parameter_head_key(action)):
                head = game['parameter_heads'].get(key)
                if head is not None:
                    heads.append((head, [True, True, False, False]))
        else:
            heads = [(head, mask) for head in heads]
        baseline_key = self.parameter_baseline_key(kind, transition[1])
        baseline = game['parameter_baselines'].get(baseline_key)
        fallback = game['parameter_baselines'].get(kind)
        if baseline is None or baseline[0] < 3:
            baseline = fallback
        expectation = float(baseline[1]) if baseline is not None and baseline[0] >= 3 else -0.035
        advantage = max(-1.0, min(1.0, reward - expectation))
        if abs(advantage) < 0.009:
            return
        force = (min(1.0, advantage * 4.5) if advantage > 0 else max(-0.28, advantage * 1.25))
        force *= confidence * (0.65 if early_feedback else 1.0)
        for head, mask in heads:
            if self.np is not None:
                before = self.np.asarray(transition[1], dtype=self.np.float32)
                hidden = self.np.tanh(snapshot['encoder'] @ before + snapshot['encoder_bias'])
                output = 0.5 + 0.5 * self.np.tanh(head['w'] @ hidden + head['b'])
                residual = (self.np.asarray(target, dtype=self.np.float32) - output) * self.np.asarray(mask, dtype=self.np.float32)
                old_logits = self.np.clip(2.0 * output - 1.0, -0.99, 0.99)
                update = residual * (1.0 - old_logits * old_logits) * (0.10 * force)
                head['w'] += self.np.outer(update, hidden)
                head['b'] += update
                self.np.clip(head['w'], -1.5, 1.5, out=head['w'])
                self.np.clip(head['b'], -3.0, 3.0, out=head['b'])
            else:
                hidden = [math.tanh(sum(weight * v for weight, v in zip(row, transition[1])) + snapshot['encoder_bias'][i]) for i, row in enumerate(snapshot['encoder'])]
                for i in range(4):
                    if not mask[i]:
                        continue
                    projected = sum(w * v for w, v in zip(head['w'][i], hidden)) + head['b'][i]
                    tanh_value = math.tanh(projected)
                    update = (target[i] - 0.5 - 0.5 * tanh_value) * (1.0 - tanh_value * tanh_value) * 0.10 * force
                    for j, value in enumerate(hidden):
                        head['w'][i][j] = max(-1.5, min(1.5, head['w'][i][j] + update * value))
                    head['b'][i] = max(-3.0, min(3.0, head['b'][i] + update))
            head['samples'] = min(10000000, head['samples'] + 1)

    @staticmethod
    def parameter_baseline_key(kind, features):
        bins = [max(0, min(7, int(float(features[i]) * 5.0 + 1.0))) for i in (1, 2, 3, 4, 5, 8)]
        return kind + ':' + ''.join(str(v) for v in bins)

    @staticmethod
    def stable_temporal_pair(transition):
        if len(transition) < 10 or int(transition[7]) != 1 or bool(transition[6]):
            return False
        before, after, detail = transition[1], transition[4], transition[9]
        if len(before) != FEATURE_COUNT or len(after) != FEATURE_COUNT or not isinstance(detail, dict):
            return False
        if not detail.get('input_sent') or detail.get('learning_effect_observation') != 0.0:
            return False
        if (float(transition[8]) < 0.50 or float(detail.get('learning_effect_confidence') or 0.0) < 0.55
                or abs(float(transition[3])) >= 0.12):
            return False
        if (detail.get('outcome_credit') or detail.get('learning_screen_result')
                or detail.get('learning_goal_direction')):
            return False
        return sum(abs(float(before[i]) - float(after[i])) for i in STABLE_TEMPORAL_INDICES) <= 0.035 * len(STABLE_TEMPORAL_INDICES)

    def _train_temporal_snapshot(self, transition, snapshot):
        if not self.stable_temporal_pair(transition):
            return False
        before, after = transition[1], transition[4]
        rate = 0.00003 * max(0.5, min(1.0, float(transition[8])))
        source_context = transition[9].get('learning_state_context')
        contrast_indices = (1, 3, 8, 18, 25, 40, 70, 115, SEMANTIC_START + 3, SEMANTIC_START + 28)
        negative = None
        for origin, context, candidate in snapshot.get('contrastive_examples', ()):
            if origin == transition[0] and context == source_context:
                continue
            difference = sum(abs(float(before[i]) - float(candidate[i])) for i in contrast_indices) / len(contrast_indices)
            if difference >= 0.095:
                negative = candidate
                break
        if self.np is not None:
            x_before = self.np.asarray(before, dtype=self.np.float32)
            x_after = self.np.asarray(after, dtype=self.np.float32)
            teacher = self.np.tanh(snapshot['target_encoder'] @ x_before + snapshot['target_encoder_bias'])
            student = self.np.tanh(snapshot['encoder'] @ x_after + snapshot['encoder_bias'])
            update = self.np.clip((teacher - student) * (1.0 - student * student), -0.18, 0.18)
            if negative is not None:
                x_negative = self.np.asarray(negative, dtype=self.np.float32)
                alternative = self.np.tanh(snapshot['target_encoder'] @ x_negative + snapshot['target_encoder_bias'])
                separate = float(self.np.mean((teacher - alternative) ** 2))
                distance_pos = float(self.np.mean((student - teacher) ** 2))
                distance_neg = float(self.np.mean((student - alternative) ** 2))
                if separate >= 0.00015 and distance_neg < distance_pos + min(0.015, 0.5 * separate):
                    update += self.np.clip((teacher - alternative) * (1.0 - student * student), -0.12, 0.12) * 0.30
                    counts = snapshot['contrastive_updates']
                    counts[transition[0]] = counts.get(transition[0], 0) + 1
            snapshot['encoder'] += rate * self.np.outer(update, x_after)
            snapshot['encoder_bias'] += rate * update
            self.np.clip(snapshot['encoder'], -1.2, 1.2, out=snapshot['encoder'])
            self.np.clip(snapshot['encoder_bias'], -1.2, 1.2, out=snapshot['encoder_bias'])
        else:
            target_neg = None
            if negative is not None:
                target_neg = [math.tanh(sum(w * x for w, x in zip(row, negative)) + snapshot['target_encoder_bias'][i])
                              for i, row in enumerate(snapshot['target_encoder'])]
            target_pos = [math.tanh(sum(w * x for w, x in zip(row, before)) + snapshot['target_encoder_bias'][i])
                          for i, row in enumerate(snapshot['target_encoder'])]
            current = [math.tanh(sum(w * x for w, x in zip(row, after)) + snapshot['encoder_bias'][i])
                       for i, row in enumerate(snapshot['encoder'])]
            contrast = False
            if target_neg is not None:
                separate = sum((a - b) ** 2 for a, b in zip(target_pos, target_neg)) / len(target_pos)
                distance_pos = sum((a - b) ** 2 for a, b in zip(current, target_pos)) / len(target_pos)
                distance_neg = sum((a - b) ** 2 for a, b in zip(current, target_neg)) / len(target_pos)
                contrast = separate >= 0.00015 and distance_neg < distance_pos + min(0.015, 0.5 * separate)
                if contrast:
                    counts = snapshot['contrastive_updates']
                    counts[transition[0]] = counts.get(transition[0], 0) + 1
            for i, row in enumerate(snapshot['encoder']):
                gradient = (target_pos[i] - current[i]) * (1.0 - current[i] * current[i])
                if contrast:
                    gradient += 0.30 * (target_pos[i] - target_neg[i]) * (1.0 - current[i] * current[i])
                gradient = max(-0.22, min(0.22, gradient))
                for j, value in enumerate(after):
                    row[j] = max(-1.2, min(1.2, row[j] + rate * gradient * value))
                snapshot['encoder_bias'][i] = max(-1.2, min(1.2, snapshot['encoder_bias'][i] + rate * gradient))
        return True

    def _train_one(self, transition, snapshot):
        game_key, before, index, reward, after, _, done, horizon = transition[:8]
        confidence = max(0.0, min(1.0, float(transition[8]))) if len(transition) > 8 else 0.65
        if confidence < 0.15 or len(before) != FEATURE_COUNT or len(after) != FEATURE_COUNT:
            return None
        game = snapshot['games'].get(game_key)
        if game is None:
            return None
        future = 0.0
        if not done:
            online_future = self._training_values(after, snapshot, game)
            if self.np is not None:
                best = int(self.np.argmax(online_future))
                future = float(self._training_values(after, snapshot, game, target=True)[best])
            else:
                best = max(range(len(online_future)), key=online_future.__getitem__)
                future = self._training_values(after, snapshot, game, target=True)[best]
        target_value = max(-3.0, min(3.0, reward + temporal_discount(transition_elapsed_seconds(transition)) * future))
        prediction, hidden = self._training_values(before, snapshot, game, include_hidden=True)
        error = max(-1.5, min(1.5, target_value - float(prediction[index])))
        if confidence < 0.15:
            return None
        importance = max(0.15, min(1.0, snapshot.get('sample_weights', {}).get(id(transition), 1.0)))
        learn_rate = 0.018 * (0.22 + 0.78 * confidence) * importance / (1.0 + game['counts'][index] / 14000.0)
        encoder_rate = 0.00085 * (0.22 + 0.78 * confidence) * importance
        encoder_rate /= 1.0 + 0.30 * max(0, len(snapshot['games']) - 1)
        encoder = snapshot['encoder']
        encoder_bias = snapshot['encoder_bias']
        if self.np is not None:
            old_head = game['q'][index].copy()
            game['q'][index] += hidden * (learn_rate * error)
            game['bias'][index] += learn_rate * error
            for neighbor, similarity in self.action_neighbors[index]:
                rate = learn_rate * 0.12 * similarity / (1.0 + game['counts'][neighbor] / 30.0)
                game['q'][neighbor] += hidden * (rate * error)
                game['bias'][neighbor] += rate * error
            gradient = old_head * (1.0 - hidden * hidden) * error
            encoder += encoder_rate * self.np.outer(gradient, self.np.asarray(before, dtype=self.np.float32))
            encoder_bias += encoder_rate * gradient
            self.np.clip(game['q'][index], -2.5, 2.5, out=game['q'][index])
            self.np.clip(encoder, -1.2, 1.2, out=encoder)
        else:
            old_head = game['q'][index][:]
            for j, value in enumerate(hidden):
                game['q'][index][j] = max(-2.5, min(2.5, old_head[j] + learn_rate * error * value))
            game['bias'][index] = max(-3.0, min(3.0, game['bias'][index] + learn_rate * error))
            for neighbor, similarity in self.action_neighbors[index]:
                rate = learn_rate * 0.12 * similarity / (1.0 + game['counts'][neighbor] / 30.0)
                game['q'][neighbor] = [max(-2.5, min(2.5, weight + rate * error * feature))
                                       for weight, feature in zip(game['q'][neighbor], hidden)]
                game['bias'][neighbor] = max(-3.0, min(3.0, game['bias'][neighbor] + rate * error))
            for j, value in enumerate(hidden):
                derivative = encoder_rate * old_head[j] * (1 - value * value) * error
                if abs(derivative) < 1e-10:
                    continue
                row = encoder[j]
                for k, feature in enumerate(before):
                    row[k] = max(-1.2, min(1.2, row[k] + derivative * feature))
                encoder_bias[j] = max(-1.2, min(1.2, encoder_bias[j] + derivative))
        if horizon == 1 and confidence >= 0.35:
            decoder = snapshot['decoder']
            decoder_bias = snapshot['decoder_bias']
            targets = [float(before[i]) for i in RECONSTRUCTION_INDICES]
            if self.np is not None:
                latent = self.np.asarray(hidden, dtype=self.np.float32)
                residual = self.np.clip(self.np.asarray(targets, dtype=self.np.float32) - (decoder @ latent + decoder_bias), -0.8, 0.8)
                prior_decoder = decoder.copy()
                decoder += self.np.outer(residual, latent) * 0.0007
                decoder_bias += residual * 0.0007
                derivative = (prior_decoder.T @ residual) * (1.0 - latent * latent)
                snapshot['encoder'] += 0.000015 * self.np.outer(derivative, self.np.asarray(before, dtype=self.np.float32))
            else:
                feature_gradient = [0.0] * len(hidden)
                for pos, desired in enumerate(targets):
                    row = decoder[pos]
                    difference = max(-0.8, min(0.8, desired - decoder_bias[pos] - sum(w * v for w, v in zip(row, hidden))))
                    for j, value in enumerate(hidden):
                        old_weight = row[j]
                        feature_gradient[j] += difference * old_weight * (1.0 - value * value)
                        row[j] = max(-1.2, min(1.2, row[j] + 0.0007 * difference * value))
                    decoder_bias[pos] = max(-1.2, min(1.2, decoder_bias[pos] + 0.0007 * difference))
                for j, derivative in enumerate(feature_gradient):
                    derivative = max(-0.1, min(0.1, derivative)) * 0.000015
                    if abs(derivative) < 1e-10:
                        continue
                    row = snapshot['encoder'][j]
                    for k, feature in enumerate(before):
                        row[k] = max(-1.2, min(1.2, row[k] + derivative * feature))
                    snapshot['encoder_bias'][j] = max(-1.2, min(1.2, snapshot['encoder_bias'][j] + derivative))
        self._train_temporal_snapshot(transition, snapshot)
        self._train_parameter(transition, snapshot, game)
        return abs(error)

    def _train_batch(self, samples, snapshot):
        if self.np is None:
            return [(transition, error) for transition in samples if (error := self._train_one(transition, snapshot)) is not None]
        np = self.np
        grouped = {}
        for transition in samples:
            if transition[0] in snapshot['games']:
                grouped.setdefault(transition[0], []).append(transition)
        results = []
        for game_key, batch in grouped.items():
            batch = [item for item in batch if len(item[1]) == FEATURE_COUNT and len(item[4]) == FEATURE_COUNT
                     and len(item) > 8 and float(item[8]) >= 0.15 and math.isfinite(float(item[3]))]
            if not batch:
                continue
            game = snapshot['games'][game_key]
            before = np.asarray([item[1] for item in batch], dtype=np.float32)
            after = np.asarray([item[4] for item in batch], dtype=np.float32)
            actions = np.asarray([item[2] for item in batch], dtype=np.int32)
            rewards = np.asarray([item[3] for item in batch], dtype=np.float32)
            horizons = np.asarray([item[7] for item in batch], dtype=np.float32)
            dones = np.asarray([bool(item[6]) for item in batch], dtype=np.float32)
            confidence = np.asarray([max(0.0, min(1.0, float(item[8]) if len(item) > 8 else 0.65)) for item in batch], dtype=np.float32)
            importance = np.asarray([max(0.15, min(1.0, snapshot.get('sample_weights', {}).get(id(item), 1.0)))
                                     for item in batch], dtype=np.float32)
            hidden = np.tanh(before @ snapshot['encoder'].T + snapshot['encoder_bias'])
            next_online = np.tanh(after @ snapshot['encoder'].T + snapshot['encoder_bias'])
            best = np.argmax(next_online @ game['q'].T + game['bias'], axis=1)
            next_target = np.tanh(after @ snapshot['target_encoder'].T + snapshot['target_encoder_bias'])
            future = np.sum(next_target * game['target_q'][best], axis=1) + game['target_bias'][best]
            discounted = np.asarray([temporal_discount(transition_elapsed_seconds(item)) for item in batch], dtype=np.float32)
            targets = np.clip(rewards + (1.0 - dones) * discounted * future, -3.0, 3.0)
            old_head = game['q'][actions].copy()
            predicted = np.sum(hidden * old_head, axis=1) + game['bias'][actions]
            errors = np.clip(targets - predicted, -1.5, 1.5)
            weights = importance * (0.22 + 0.78 * confidence)
            count = np.asarray([game['counts'][item[2]] for item in batch], dtype=np.float32)
            rates = np.float32(0.018) * weights / (1.0 + count / 14000.0)
            corrections = rates * errors / max(1.0, math.sqrt(len(batch) / 4.0))
            np.add.at(game['q'], actions, corrections[:, None] * hidden)
            np.add.at(game['bias'], actions, corrections)
            for position, transition in enumerate(batch):
                for neighbor, similarity in self.action_neighbors[transition[2]]:
                    rate = corrections[position] * (0.12 * similarity / (1.0 + game['counts'][neighbor] / 30.0))
                    game['q'][neighbor] += rate * hidden[position]
                    game['bias'][neighbor] += rate
            derivative = (old_head * (1.0 - hidden * hidden)) * (errors * weights)[:, None]
            scale = np.float32(0.00085 / (max(1.0, len(batch)) * (1.0 + 0.55 * max(0, len(snapshot['games']) - 1))))
            snapshot['encoder'] += scale * (derivative.T @ before)
            snapshot['encoder_bias'] += scale * np.sum(derivative, axis=0)
            selected = (horizons == 1) & (confidence >= 0.45)
            if bool(np.any(selected)):
                visual_hidden = hidden[selected]
                visual_before = before[selected]
                target_columns = visual_before[:, list(RECONSTRUCTION_INDICES)]
                decoder = snapshot['decoder']
                decoder_bias = snapshot['decoder_bias']
                residual = np.clip(target_columns - (visual_hidden @ decoder.T + decoder_bias), -0.8, 0.8)
                old_decoder = decoder.copy()
                divisor = max(1.0, float(visual_hidden.shape[0]))
                decoder += np.float32(0.0007 / divisor) * (residual.T @ visual_hidden)
                decoder_bias += np.float32(0.0007 / divisor) * np.sum(residual, axis=0)
                derivative = (residual @ old_decoder) * (1.0 - visual_hidden * visual_hidden)
                snapshot['encoder'] += np.float32(0.000015 / divisor) * (derivative.T @ visual_before)
                np.clip(decoder, -1.2, 1.2, out=decoder)
                np.clip(decoder_bias, -1.2, 1.2, out=decoder_bias)
            np.clip(game['q'], -2.5, 2.5, out=game['q'])
            np.clip(game['bias'], -3.0, 3.0, out=game['bias'])
            np.clip(snapshot['encoder'], -1.2, 1.2, out=snapshot['encoder'])
            np.clip(snapshot['encoder_bias'], -1.2, 1.2, out=snapshot['encoder_bias'])
            for transition in batch:
                self._train_temporal_snapshot(transition, snapshot)
                self._train_parameter(transition, snapshot, game)
            error_values = np.asnumpy(np.abs(errors)).tolist() if getattr(np, '__name__', '') == 'cupy' else np.abs(errors).tolist()
            results.extend((item, float(error)) for item, error in zip(batch, error_values))
        return results

    def _commit_training(self, snapshot, results):
        with self.lock:
            if snapshot.get('backend_generation', self.backend_generation) != self.backend_generation:
                self.training_stale_batches += 1
                return False
            arrays = [snapshot['encoder'], snapshot['encoder_bias'], snapshot['decoder'], snapshot['decoder_bias']]
            for state in snapshot['games'].values():
                arrays.extend((state['q'], state['bias']))
                for head in state['parameter_heads'].values():
                    arrays.extend((head['w'], head['b']))
            if self.np is not None:
                if not all(bool(self.np.all(self.np.isfinite(array))) for array in arrays):
                    raise ArithmeticError('学习批次出现非有限参数，拒绝提交模型')
            else:
                for array in arrays:
                    if not all(math.isfinite(float(value)) for entry in array for value in (entry if isinstance(entry, list) else (entry,))):
                        raise ArithmeticError('学习批次出现非有限参数，拒绝提交模型')
            self.encoder = snapshot['encoder']
            self.encoder_bias = snapshot['encoder_bias']
            self.decoder = snapshot['decoder']
            self.decoder_bias = snapshot['decoder_bias']
            for key, state in snapshot['games'].items():
                game = self.games.get(key)
                if game is not None:
                    game.diagnostics['contrastive_visual_updates'] += snapshot.get('contrastive_updates', {}).get(key, 0)
                    game.q = state['q']
                    game.bias = state['bias']
                    game.parameter_heads = state['parameter_heads']
                    self.dirty_games.add(key)
                    self.dirty_sequence += 1
            prior = self.updates // 160
            for transition, error in results:
                if isinstance(transition, list):
                    transition[5] = max(0.025, min(2.5, error + 0.04))
                self.updates += 1
                self.td_error_ema = 0.975 * self.td_error_ema + 0.025 * error
            if self.updates // 160 != prior:
                self.sync_target()
            return True

    @staticmethod
    def control_transition(transition):
        detail = transition[9] if len(transition) > 9 and isinstance(transition[9], dict) else {}
        return bool(detail.get('learning_action_effect', 0.0) >= 0.015
                    and detail.get('learning_causality', 0.0) >= 0.38
                    and detail.get('input_sent'))

    @staticmethod
    def failure_transition(transition):
        detail = transition[9] if len(transition) > 9 and isinstance(transition[9], dict) else {}
        return bool(detail.get('input_sent') and detail.get('feedback_valid')
                    and detail.get('learning_action_effect', 1.0) < 0.006
                    and detail.get('learning_causality', 1.0) < 0.10)

    @staticmethod
    def surprise_transition(transition):
        detail = transition[9] if len(transition) > 9 and isinstance(transition[9], dict) else {}
        error = detail.get('learning_world_prediction_error')
        try:
            return bool(detail.get('input_sent') and detail.get('feedback_valid', True)
                        and error is not None and math.isfinite(float(error)) and float(error) >= 0.07
                        and float(transition[8]) >= 0.48)
        except (ValueError, TypeError, OverflowError):
            return False

    @staticmethod
    def rare_transition(transition):
        detail = transition[9] if len(transition) > 9 and isinstance(transition[9], dict) else {}
        return bool(transition[6] or abs(float(transition[3])) >= 0.24
                    or detail.get('outcome_credit') or detail.get('screen_result_confirmation'))

    def enqueue_training(self, transition):
        self.memory.append(transition)
        if self.rare_transition(transition):
            self.rare_memory.append(transition)
        if self.control_transition(transition):
            self.control_memory.append(transition)
        if self.failure_transition(transition):
            self.failure_memory.append(transition)
        if self.surprise_transition(transition):
            self.surprise_memory.append(transition)
        if self.goal_transition(transition):
            self.goal_memory.append(transition)
        if len(self.training_queue) >= self.training_queue.maxlen:
            self.training_queue_evictions += 1
        self.training_queue.append(transition)
        self.training_condition.notify()

    def _connect_store(self):
        if self.store is not None:
            return True
        if time.monotonic() < self.store_reconnect_at:
            return False
        try:
            self.store = ReplayStore(self.folder)
            self.db_preflight_verified = self.store.verify_roundtrip()
            self.store_failures = 0
            self.store_reconnect_at = 0.0
            self.db_transitions_last_known = self.store.total_transitions
            self.store_roundtrip_verified = self.store.first_commit_verified
            return True
        except Exception as exc:
            if self.store is not None:
                try:
                    self.store.close()
                except Exception:
                    try:
                        self.store.db.close()
                    except Exception:
                        pass
                self.store = None
            if quarantine_corrupt_store(self.folder, exc):
                try:
                    self.store = ReplayStore(self.folder)
                    self.db_preflight_verified = self.store.verify_roundtrip()
                    self.store_problem = '已隔离损坏的经验数据库，原数据文件保存在工作目录内'
                    self.store_failures = 0
                    self.store_reconnect_at = 0.0
                    self.db_transitions_last_known = self.store.total_transitions
                    self.store_roundtrip_verified = self.store.first_commit_verified
                    return True
                except Exception as recovery:
                    exc = recovery
            self.store_failures += 1
            self.store_reconnect_at = time.monotonic() + min(60.0, 2.0 ** min(self.store_failures, 6))
            self.store_problem = f'经验数据库初始化或重连失败：{type(exc).__name__}: {exc}'
            if self.store is not None:
                try:
                    self.store.close()
                except Exception:
                    pass
                self.store = None
            return False

    def _store_failure(self, exc):
        self.store_problem = f'经验数据库写入失败，将重试：{type(exc).__name__}: {exc}'
        self.store_failures += 1
        self.store_reconnect_at = time.monotonic() + min(60.0, 2.0 ** min(self.store_failures, 6))
        if self.store is not None:
            self.db_transitions_last_known = self.store.total_transitions
            try:
                self.store.db.rollback()
                self.store.db.close()
            except Exception:
                pass
            self.store = None

    def _journal_event(self, entry, identity=None):
        try:
            encoded = (json.dumps(entry, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
            with self.spool_lock:
                with self.spool_path.open('ab') as stream:
                    stream.write(encoded)
                    stream.flush()
                    os.fsync(stream.fileno())
                if identity is not None:
                    self.journal_unwritten.pop(identity, None)
                self.journaled_transitions += int(isinstance(entry, (tuple, list)))
            return True
        except (OSError, ValueError, TypeError, OverflowError) as exc:
            with self.spool_lock:
                if identity is not None:
                    self.journal_unwritten[identity] = entry
                self.journal_failures += 1
            self.store_problem = f'经验日志落盘失败，内存队列保留并等待重试：{type(exc).__name__}: {exc}'
            return False

    def _retry_journal(self):
        with self.storage_condition:
            pending = list(self.journal_unwritten.items())[:160]
            for identity, entry in pending:
                self._journal_event(entry, identity)

    def _append_persist(self, transition, change=0.0):
        detail = transition[9].copy() if len(transition) > 9 and isinstance(transition[9], dict) else {}
        if not isinstance(detail.get('uid'), str):
            detail['uid'] = uuid.uuid4().hex
        if len(transition) > 9 and isinstance(transition[9], dict):
            transition[9]['uid'] = detail['uid']
        row = (canonical_game_key(transition[0]), self.actions[transition[2]].id, float(transition[3]), transition[1][:], transition[4][:], float(change), bool(transition[6]), int(transition[7]), float(transition[5]), float(transition[8]) if len(transition) > 8 else 0.65, detail)
        self._journal_event(row, detail['uid'])
        while len(self.persist_backlog) >= 12000:
            oldest = self.persist_backlog[0]
            old_uid = oldest[10].get('uid')
            if old_uid in self.journal_unwritten:
                self._journal_event(oldest, old_uid)
            if old_uid in self.journal_unwritten:
                self.journal_unwritten.pop(old_uid, None)
                self.dropped_unpersisted += 1
                self.store_problem = '经验日志所在磁盘不可写，达到内存上限后有未落盘记录被丢弃；请检查工作目录磁盘空间和权限'
            else:
                self.spilled_transitions += 1
            self.persist_backlog.popleft()
        self.persist_backlog.append(row)

    def _drain_spool(self):
        with self.spool_lock:
            if not self.spool_path.exists() or self.spool_path.stat().st_size == 0:
                return
            temp = self.folder / 'experience_overflow.jsonl.tmp'
            valid_rows = []
            terminal_rows = []
            invalid = []
            with self.spool_path.open('rb') as source:
                for _ in range(128):
                    data = source.readline()
                    if not data:
                        break
                    try:
                        row = json.loads(data)
                        if (isinstance(row, list) and len(row) == 11 and isinstance(row[0], str)
                                and row[1] in self.action_index and isinstance(row[3], list) and isinstance(row[4], list)
                                and len(row[3]) in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)
                                and len(row[4]) in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)):
                            row[0] = canonical_game_key(row[0])
                            row[3] = row[3][:FEATURE_COUNT] + [0.0] * max(0, FEATURE_COUNT - len(row[3]))
                            row[4] = row[4][:FEATURE_COUNT] + [0.0] * max(0, FEATURE_COUNT - len(row[4]))
                            valid_rows.append(row)
                        elif isinstance(row, dict) and isinstance(row.get('terminal_uid'), str) and 12 <= len(row['terminal_uid']) <= 80:
                            terminal_rows.append(row)
                        else:
                            invalid.append(data)
                    except (json.JSONDecodeError, UnicodeDecodeError, TypeError, ValueError):
                        invalid.append(data)
                if valid_rows:
                    inserted = self.store.add_many(valid_rows)
                    self.spool_recovered += inserted
                    self.persisted_transitions += inserted
                    self.db_transitions_last_known = self.store.total_transitions
                    self.store_roundtrip_verified = self.store.first_commit_verified
                unresolved = [row for row in terminal_rows if not self.store.mark_terminal_uid(row['terminal_uid'])]
                with temp.open('wb') as destination:
                    shutil.copyfileobj(source, destination, length=1024 * 1024)
                    for item in unresolved:
                        destination.write((json.dumps(item, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8'))
                    destination.flush()
                    os.fsync(destination.fileno())
            if invalid:
                corrupt = self.folder / 'experience_journal_corrupt.jsonl'
                with corrupt.open('ab') as destination:
                    destination.writelines(invalid)
                    destination.flush()
                    os.fsync(destination.fileno())
            if temp.stat().st_size:
                os.replace(temp, self.spool_path)
            else:
                temp.unlink(missing_ok=True)
                self.spool_path.unlink(missing_ok=True)
            if invalid:
                self.store_problem = f'经验日志存在 {len(invalid)} 条无法解码的记录，已保留到损坏日志文件'

    def persist_initial_frame(self, obs):
        if not obs.valid or obs.quality.get('low_information') or obs.game in self.initial_frame_games:
            return
        with self.lock:
            if obs.game not in self.initial_frame_games:
                self.initial_frame_games.add(obs.game)
                self.initial_frames[obs.game] = (self.games[obs.game].game_steps, obs)
            self._drain_persist(force=True)

    def _drain_persist(self, frame=None, force=False):
        with self.storage_condition:
            if frame is not None:
                if len(self.frame_backlog) >= 96:
                    self.frame_backlog.popleft()
                    self.keyframes_skipped += 1
                self.frame_backlog.append(frame)
            if force:
                self.storage_force = True
            self.storage_condition.notify_all()

    def storage_loop(self):
        ending_since = None
        try:
            while True:
                self.storage_last_tick = time.monotonic()
                self._retry_journal()
                with self.storage_condition:
                    stopping = self.storage_stop.is_set()
                    if stopping and ending_since is None:
                        ending_since = time.monotonic()
                    force = self.storage_force or stopping
                    pending = bool(self.initial_frames or self.frame_backlog or self.persist_backlog or self.terminal_updates or self.journal_unwritten)
                    checkpoint = self.checkpoint_requested or (stopping and not self.checkpoint_verified)
                    if not pending and not checkpoint and not force:
                        self.storage_condition.wait(0.45)
                        continue
                    initial = list(self.initial_frames.items())[:10]
                    frames = list(self.frame_backlog)[:12]
                    should_write = (force or self.persisted_transitions == 0 or len(self.persist_backlog) >= 16
                                    or time.monotonic() - self.persist_last_batch >= 2.0)
                    batch = list(self.persist_backlog)[:160] if should_write else []
                    terminal = list(self.terminal_updates)[:64]
                    sequence = self.checkpoint_sequence
                    if pending and not (initial or frames or batch or terminal or checkpoint or force):
                        self.storage_condition.wait(0.35)
                        continue
                try:
                    connected = self._connect_store() if (pending or force) else self.store is not None
                    if connected:
                        self._drain_spool()
                        for key, (step, observation) in initial:
                            self.store.frame(key, step, 'initial', observation, force=True)
                        for frame in frames:
                            game_key, step, index, observation = frame
                            self.store.frame(game_key, step + 1, self.actions[index].id, observation)
                        inserted = self.store.add_many(batch) if batch else 0
                        unresolved = False
                        resolved_terminal = []
                        for uid in terminal:
                            if self.store.mark_terminal_uid(uid):
                                resolved_terminal.append(uid)
                            else:
                                unresolved = True
                        self.store.flush()
                        with self.storage_condition:
                            for key, (step, observation) in initial:
                                if key in self.initial_frames and self.initial_frames[key][1] is observation:
                                    del self.initial_frames[key]
                            for frame in frames:
                                if self.frame_backlog and self.frame_backlog[0] is frame:
                                    self.frame_backlog.popleft()
                            for entry in batch:
                                if self.persist_backlog and self.persist_backlog[0][10].get('uid') == entry[10].get('uid'):
                                    self.persist_backlog.popleft()
                            for uid in resolved_terminal:
                                if self.terminal_updates and self.terminal_updates[0] == uid:
                                    self.terminal_updates.popleft()
                            if batch:
                                for entry in batch:
                                    self.journal_unwritten.pop(entry[10].get('uid'), None)
                                self.persisted_transitions += inserted
                                self.persist_last_batch = time.monotonic()
                            self.db_transitions_last_known = self.store.total_transitions
                            self.store_roundtrip_verified = self.store.first_commit_verified
                            self.keyframes_this_session = self.store.frames_saved
                            self.storage_force = False
                            self.storage_problem = None
                            self.storage_failures = 0
                    if checkpoint:
                        self._write_checkpoint()
                        with self.storage_condition:
                            if self.checkpoint_sequence == sequence:
                                self.checkpoint_requested = False
                    if stopping:
                        with self.storage_condition:
                            completed = not (self.persist_backlog or self.initial_frames or self.frame_backlog or self.terminal_updates or self.checkpoint_requested)
                        if completed or time.monotonic() - ending_since > 8.0:
                            if self.journal_unwritten:
                                self.storage_problem = f'仍有 {len(self.journal_unwritten)} 条数据无法写入经验日志，已请求检查点保留待写队列'
                            break
                    if not connected and pending:
                        self.storage_stop.wait(0.4)
                    elif connected and unresolved:
                        self.storage_stop.wait(0.35)
                except Exception as exc:
                    with self.storage_condition:
                        self.storage_problem = f'后台持久化失败，将重试：{type(exc).__name__}: {str(exc)[:160]}'
                        self.storage_failures += 1
                    disconnected = False
                    if self.store is not None:
                        try:
                            self.store.db.rollback()
                            self.store.frame_step.clear()
                            self.store.pending = 0
                            count = int(self.store.db.execute('SELECT COUNT(*) FROM keyframes').fetchone()[0])
                            self.store.frames_saved = max(0, count - self.store.start_frame_count)
                        except sqlite3.Error as rollback_exc:
                            self._store_failure(rollback_exc)
                            disconnected = True
                    if isinstance(exc, sqlite3.Error) and not disconnected:
                        self._store_failure(exc)
                    if stopping and time.monotonic() - ending_since > 8.0:
                        try:
                            self._write_checkpoint()
                        except Exception:
                            pass
                        if self.journal_unwritten:
                            self.storage_problem = f'仍有 {len(self.journal_unwritten)} 条数据无法写入经验日志，已尝试保存待写检查点'
                        break
                    self.storage_stop.wait(min(0.65, 0.05 * self.storage_failures))
        finally:
            if self.store is not None:
                try:
                    self.store.close()
                except Exception as exc:
                    self.storage_problem = f'存储连接关闭失败：{type(exc).__name__}: {exc}'
                self.store = None

    def _combine_pending(self, horizon):
        batch = list(self.pending_n)[:min(N_STEP, horizon)]
        for index, item in enumerate(batch):
            if item[6]:
                batch = batch[:index + 1]
                break
        discounted = 0.0
        elapsed = 0.0
        for row in batch:
            discounted += temporal_discount(elapsed) * float(row[3])
            elapsed += transition_elapsed_seconds(row)
        first, last = batch[0], batch[-1]
        confidence = min(float(row[8]) if len(row) > 8 else 0.65 for row in batch)
        detail = first[9].copy() if len(first) > 9 and isinstance(first[9], dict) else {}
        if detail.get('uid'):
            detail['origin_uid'] = detail.pop('uid')
        detail['cumulative_elapsed_seconds'] = round(elapsed, 6)
        return [first[0], first[1][:], first[2], discounted, last[4][:], max(0.025, abs(discounted) + 0.02), bool(last[6]), len(batch), confidence, detail]

    def flush_pending(self, done=True):
        with self.training_condition:
            if done and self.pending_n:
                newest = self.pending_n[-1]
                newest[6] = True
                uid = newest[9].get('uid') if len(newest) > 9 and isinstance(newest[9], dict) else None
                if uid:
                    updated = False
                    for pos in range(len(self.persist_backlog)-1, -1, -1):
                        row = self.persist_backlog[pos]
                        if row[10].get('uid') == uid:
                            replacement = list(row)
                            replacement[6] = True
                            self.persist_backlog[pos] = tuple(replacement)
                            updated = True
                            break
                    if uid not in self.terminal_updates:
                        if len(self.terminal_updates) >= 12000:
                            evicted = self.terminal_updates.popleft()
                            self.journal_unwritten.pop('terminal:' + evicted, None)
                            self.dropped_unpersisted += 1
                            self.store_problem = '存储失效期间终止状态积压达到内存上限，已有记录无法保全'
                        self.terminal_updates.append(uid)
                    self._journal_event({'terminal_uid': uid}, 'terminal:' + uid)
            while self.pending_n:
                combined = self._combine_pending(len(self.pending_n))
                if combined[7] > 1:
                    self.enqueue_training(combined)
                    self._append_persist(combined)
                    self.nstep_generated += 1
                self.pending_n.popleft()
            self._drain_persist(force=done)

    def credit_long_outcome(self, new, reward, confidence, outcome, change):
        if outcome not in ('win', 'task', 'loss') or not math.isfinite(float(reward)):
            return 0
        history = [item for item in self.outcome_trace if item[0] == self.game_key and item[7] == 1]
        recent = history[-min(LONG_GOAL_HORIZON, len(history)):-1]
        elapsed = transition_elapsed_seconds(history[-1]) if history else TIME_REFERENCE_SECONDS
        credited = 0
        for distance, prior in enumerate(reversed(recent), 2):
            elapsed += transition_elapsed_seconds(prior)
            if not math.isfinite(float(prior[8])) or float(prior[8]) < 0.15:
                continue
            credit_weight = long_goal_discount(elapsed) * (0.55 / (1.0 + 0.018 * distance))
            shaped = max(-1.0, min(1.0, float(reward) * credit_weight))
            trust = min(0.90, float(prior[8]), confidence) * (0.98 ** (distance - 1))
            if trust < 0.15 or abs(shaped) < 0.003:
                continue
            details = prior[9].copy() if isinstance(prior[9], dict) else {}
            origin_uid = details.pop('uid', None)
            details.update({'outcome_credit': outcome, 'origin_uid': origin_uid,
                            'cumulative_elapsed_seconds': round(elapsed, 6),
                            'credit_confidence': round(trust, 4),
                            'source': 'persistent_local_result_text_not_game_verified'})
            reinforced = [self.game_key, prior[1][:], prior[2], shaped,
                          new.features[:], max(0.025, abs(shaped) * trust),
                          True, distance, trust, details]
            self.enqueue_training(reinforced)
            self._append_persist(reinforced, change)
            credited += 1
        self.terminal_credit_samples += credited
        self.game.diagnostics['long_horizon_credits'] += credited
        self.reward_info['credited_prior_actions'] = credited
        return credited

    def learn_boundary(self, old, index, reason, effect=None, terminal=False):
        self.reward_info = {
            'proxy_reward': None,
            'reward_basis': 'unobserved_action_result_at_' + str(reason),
            'input_effect_is_causal': None,
            'verified_win': None,
            'verified_task_progress': None,
            'episode_boundary': bool(terminal),
            'episode_boundary_reason': reason,
            'action_detail': effect.copy() if isinstance(effect, dict) else {},
        }
        self.flush_pending(done=terminal)
        if terminal:
            self.outcome_trace.clear()
        return False

    def learn(self, old, index, new, reward, change, done=False, confidence_override=None, effect=None):
        with self.training_condition:
            game = self.game
            self.dirty_games.add(self.game_key)
            self.dirty_sequence += 1
            valid = bool(old.valid and new.valid and old.game == new.game == self.game_key
                         and not old.quality.get('low_information', False)
                         and not new.quality.get('low_information', False)
                         and len(old.features) == FEATURE_COUNT and len(new.features) == FEATURE_COUNT)
            confidence = min(float(old.quality.get('confidence', 1.0)), float(new.quality.get('confidence', 1.0)))
            if old.rect != new.rect:
                confidence = min(confidence, 0.52)
            if confidence_override is not None:
                confidence = min(confidence, max(0.0, min(1.0, float(confidence_override))))
            evidence_confidence = self.reward_info.get('reward_learning_confidence')
            if evidence_confidence is not None:
                confidence = min(confidence, max(0.0, min(1.0, float(evidence_confidence))))
                if confidence < 0.15:
                    game.diagnostics['low_confidence_learning'] += 1
            if (valid and isinstance(effect, dict) and effect.get('input_sent')
                    and effect.get('feedback_valid', True)
                    and self.reward_info.get('action_effect_observation') == 1.0
                    and float(self.reward_info.get('scene_stability') or 0.0) >= 0.52):
                inverse_quality = min(confidence,
                    float(self.reward_info.get('action_effect_observation_confidence') or 0.0))
                self.learn_inverse_dynamics(game, old, new, index, inverse_quality)
            if isinstance(effect, dict):
                if effect.get('interrupted'):
                    completion = max(0.0, min(1.0, float(effect.get('completion_ratio', 0.0))))
                    confidence *= (0.55 + 0.45 * completion) if effect.get('interruption_reason') == 'visual_change' else (0.15 + 0.55 * completion)
                if effect.get('feedback_valid') is False or not effect.get('input_sent', False):
                    valid = False
                if effect.get('emulated_touch') and effect.get('kind') in ('pinch', 'dual_touch'):
                    confidence *= 0.5
            prediction_error = self.reward_info.get('learned_world_prediction_error')
            try:
                surprise = (min(0.32, max(0.0, float(prediction_error))) if prediction_error is not None
                            and math.isfinite(float(prediction_error))
                            and self.reward_info.get('control_learning_verified') else 0.0)
            except (TypeError, ValueError, OverflowError):
                surprise = 0.0
            priority = max(0.025, (abs(reward) + 0.045 + 0.13 * max(0.0, new.novelty - old.novelty)
                                     + 0.34 * surprise) * (0.25 + 0.75 * confidence))
            if valid:
                context_key = self.state_signature(old) + ':' + str(index)
                record = game.context_action.get(context_key, [0, 0.0, 0.0])
                count_context = record[0] + 1
                delta_context = reward - record[1]
                if confidence >= 0.19:
                    record[1] += delta_context / min(80, count_context)
                if confidence >= 0.19:
                    record[2] = min(20.0, record[2] * (0.99 if count_context > 80 else 1.0)
                                    + delta_context * (reward - record[1]))
                    record[0] = min(10000000, count_context)
                    game.context_action[context_key] = record
                    game.context_action.move_to_end(context_key)
                while len(game.context_action) > 8000:
                    game.context_action.popitem(last=False)
                self.valid_transitions += 1
                self.update_action_applicability(game, old, index, reward)
                control_result = self.reward_info.get('action_effect_observation')
                control_target = (1.0 if control_result == 1.0 else -1.0
                                  if control_result == 0.0 else None)
                goal_confirmed = self.reward_info.get('screen_result_confirmation')
                goal_known = (goal_confirmed in ('win', 'task', 'loss') or
                              self.reward_info.get('goal_direction_evidence'))
                goal_target = (1.0 if goal_confirmed in ('win', 'task') else -1.0
                               if goal_confirmed == 'loss' else
                               max(-1.0, min(1.0, float(self.reward_info.get('goal_signal') or 0.0) * 3.5))
                               if goal_known else None)
                self.update_dual_values(game, old, index, effect=control_target,
                                        control_confidence=float(self.reward_info.get('action_effect_observation_confidence') or 0.0),
                                        objective=goal_target,
                                        objective_confidence=float(self.reward_info.get('objective_evidence_confidence') or 0.0))
                self.update_intent_values(game, old, index, effect=control_target,
                                          effect_confidence=float(self.reward_info.get('action_effect_observation_confidence') or 0.0),
                                          objective=goal_target if goal_known else None,
                                          objective_confidence=float(self.reward_info.get('objective_evidence_confidence') or 0.0))
                action_detail = effect.copy() if isinstance(effect, dict) else {}
                action_detail.update({'learning_causality': float(self.reward_info.get('causal_confidence') or 0.0),
                                      'learning_progress_confidence': float(self.reward_info.get('progress_confidence') or 0.0),
                                      'learning_outcome_confidence': float(self.reward_info.get('outcome_confidence') or 0.0),
                                      'learning_progress_signal': float(self.reward_info.get('progress_signal') or 0.0),
                                      'learning_outcome_signal': float(self.reward_info.get('outcome_signal') or 0.0),
                                      'learning_causal_regional': self.reward_info.get('regional_causal_fraction'),
                                      'learning_action_effect': float(self.reward_info.get('estimated_action_effect') or 0.0),
                                      'learning_candidate_information': float(self.reward_info.get('candidate_information_gain') or 0.0),
                                      'learning_screen_result': self.reward_info.get('screen_result_confirmation'),
                                      'learning_effect_observation': self.reward_info.get('action_effect_observation'),
                                      'learning_effect_information': float(self.reward_info.get('action_effect_information_gain') or 0.0),
                                      'learning_state_context': self.experiment_context(old),
                                      'learning_step': int(game.game_steps),
                                      'learning_world_prediction_error': self.reward_info.get('learned_world_prediction_error'),
                                      'learning_effect_confidence': float(self.reward_info.get('action_evidence_confidence') or 0.0),
                                      'learning_goal_confidence': float(self.reward_info.get('objective_evidence_confidence') or 0.0),
                                      'learning_goal_direction': bool(self.reward_info.get('goal_direction_evidence')),
                                      'learning_control_target': control_target,
                                      'learning_objective_target': goal_target,
                                      'learning_belief_confidence': float(getattr(old, 'belief_state', {}).get('confidence', 0.0)),
                                      'learning_passive_calibration': bool(game.passive_samples >= 2),
                                      'learning_signal_quality': max(float(self.reward_info.get('action_effect_observation_confidence') or 0.0),
                                                                     float(self.reward_info.get('objective_evidence_confidence') or 0.0))})
                if action_detail.get('spatial') and self.actions[index].kind in ('click', 'right', 'double', 'middle', 'focus_click', 'focus_right', 'focus_double', 'press', 'touch_tap'):
                    try:
                        x = float(action_detail.get('start_x', action_detail.get('x', 0.5)))
                        y = float(action_detail.get('start_y', action_detail.get('y', 0.5)))
                        anchor = self.action_target_anchor(old, x, y)
                        if anchor is not None:
                            action_detail['learning_target_anchor'] = anchor
                            if (self.reward_info.get('action_effect_observation') == 1.0
                                    and self.reward_info.get('action_evidence_confidence', 0.0) >= 0.35):
                                game.diagnostics['spatial_anchor_samples'] += 1
                    except (TypeError, ValueError):
                        pass
                transition = [self.game_key, old.features[:], index, float(reward), new.features[:], priority, bool(done), 1, confidence, action_detail]
                if len(game.exemplars) < game.exemplars.maxlen:
                    game.exemplars.append(transition)
                elif self.rng.randrange(max(1, game.game_steps + 1)) < game.exemplars.maxlen:
                    game.exemplars[self.rng.randrange(len(game.exemplars))] = transition
                self.enqueue_training(transition)
                self._append_persist(transition, change)
                self.outcome_trace.append(transition)
                self.record_action_result(index, action_detail, reward)
                if action_detail.get('input_sent') and self.reward_info.get('control_learning_verified'):
                    self.update_parameter_baselines(game, index, old.features, reward)
                self.pending_n.append(transition)
                adaptive_horizon = min(N_STEP, 3 + int(game.feedback_delay >= 0.19)
                                       + int(game.feedback_delay >= 0.34)
                                       + int(game.goal_value_samples >= 4))
                if len(self.pending_n) >= adaptive_horizon:
                    combined = self._combine_pending(adaptive_horizon)
                    if combined[7] > 1:
                        self.enqueue_training(combined)
                        self._append_persist(combined, change)
                        self.nstep_generated += 1
                    self.pending_n.popleft()
                if done:
                    outcome = self.reward_info.get('screen_result_confirmation')
                    if outcome in ('win', 'task', 'loss'):
                        self.credit_long_outcome(new, reward, confidence, outcome, change)
                    self.outcome_trace.clear()
                    self.flush_pending(done=True)
            else:
                self.invalid_observations += 1
                self.outcome_trace.clear()
                self.flush_pending(done=False)
            self._drain_persist(frame=(self.game_key, game.game_steps, index, new) if valid else None)
            game.action_attempts[index] += 1
            if valid and action_detail.get('input_sent'):
                game.counts[index] += 1
            game.game_steps += 1
            game.total_reward += reward
            self.step += 1
            self.total_reward += reward
            history_before = [self.actions[row[0]].id for row in list(game.recent)[-3:]]
            game.recent.append((index, old.features[:18], reward, new.signature, action_detail if valid else {},
                                old.features[SEMANTIC_START:SEMANTIC_START + 16], self.skill_object_summary(old), history_before,
                                self.skill_relation_summary(old)))
            stats = game.category_score.setdefault(self.actions[index].category, [0, 0.0])
            stats[0] += 1
            stats[1] = stats[1] * 0.95 + reward * 0.05
            goal_progress = (self.reward_info.get('screen_result_confirmation') in ('win', 'task')
                             or (self.reward_info.get('goal_direction_evidence')
                                 and float(self.reward_info.get('learned_hud_trend_signal', 0.0)) > 0.012
                                 and float(self.reward_info.get('objective_evidence_confidence', 0.0)) >= 0.26))
            structured_progress = (goal_progress
                                   or float(self.reward_info.get('persistent_landmark_evidence', 0.0)) > 0.005)
            repeatable_transition = ((float(self.reward_info.get('persistent_landmark_evidence', 0.0)) > 0.001
                                     or (float(self.reward_info.get('estimated_action_effect', 0.0)) > 0.025
                                         and float(self.reward_info.get('estimated_controllable_object', 0.0)) > 0.15))
                                     and int(self.reward_info.get('scene_loop_visits', 99)) < 3
                                     and not self.reward_info.get('recurring_without_confirmed_progress', False))
            if (valid and reward > -0.02 and float(self.reward_info.get('causal_confidence', 0.0)) > 0.42
                    and float(self.reward_info.get('persistent_visual_change', 0.0)) > 0.46
                    and float(self.reward_info.get('scene_stability', 0.0)) > 0.54
                    and (structured_progress or repeatable_transition) and len(game.recent) >= 2):
                sequence_length = 10 if goal_progress else 6 if structured_progress else 4
                sequence = list(game.recent)[-min(sequence_length, len(game.recent)):]
                key = '|'.join(self.actions[item[0]].id for item in sequence)
                if key not in game.skills and len(game.skills) >= 128:
                    discard = min(game.skills, key=lambda k: game.skills[k].get('quality', 0.0))
                    del game.skills[discard]
                item = game.skills.setdefault(key, {'count': 0, 'quality': 0.0, 'context': sequence[0][1],
                                                       'goal_signature': new.signature, 'goal_features': new.features[:18],
                                                       'purpose': 'outcome' if goal_progress else 'navigation',
                                                       'purpose_confidence': 0.0,
                                                       'attempts': 0, 'successes': 0, 'failure_rate': 0.5,
                                                       'expected_reward': reward, 'average_duration': 0.0,
                                                       'start_phase': old.phase, 'causal_reliability': 0.0,
                                                       'waypoints': [t[1][:] for t in sequence],
                                                       'semantic_context': sequence[0][5][:],
                                                       'semantic_waypoints': [t[5][:] for t in sequence],
                                                       'object_context': sequence[0][6][:],
                                                       'object_waypoints': [t[6][:] for t in sequence],
                                                       'relation_context': sequence[0][8][:],
                                                       'relation_waypoints': [t[8][:] for t in sequence],
                                                       'history_context': sequence[0][7][:],
                                                       'intent_sequence': [self.action_intents[t[0]] for t in sequence],
                                                       'control_mapping': [self.actions[t[0]].id for t in sequence],
                                                       'goal_evidence_samples': 0, 'control_evidence_samples': 0,
                                                       'navigation_successes': 0, 'objective_successes': 0,
                                                       'goal_object_features': self.skill_object_summary(new),
                                                       'goal_relation_features': self.skill_relation_summary(new),
                                                       'goal_semantic_features': new.features[SEMANTIC_START:SEMANTIC_START + 16]})
                item['count'] += 1
                item['control_evidence_samples'] = min(1000000, int(item.get('control_evidence_samples', 0)) + 1)
                if goal_progress:
                    item['purpose'] = 'outcome'
                    item['purpose_confidence'] = min(1.0, float(item.get('purpose_confidence', 0.0)) + 0.15)
                    item['goal_evidence_samples'] = min(1000000, int(item.get('goal_evidence_samples', 0)) + 1)
                item['waypoints'] = [t[1][:] for t in sequence]
                item['semantic_context'] = sequence[0][5][:]
                item['semantic_waypoints'] = [t[5][:] for t in sequence]
                item['object_context'] = sequence[0][6][:]
                item['object_waypoints'] = [t[6][:] for t in sequence]
                item['relation_context'] = sequence[0][8][:]
                item['relation_waypoints'] = [t[8][:] for t in sequence]
                item['history_context'] = sequence[0][7][:]
                item['intent_sequence'] = [self.action_intents[t[0]] for t in sequence]
                item['control_mapping'] = [self.actions[t[0]].id for t in sequence]
                item['goal_object_features'] = self.skill_object_summary(new)
                item['goal_relation_features'] = self.skill_relation_summary(new)
                item['goal_semantic_features'] = new.features[SEMANTIC_START:SEMANTIC_START + 16]
                item['expected_reward'] = 0.9 * float(item.get('expected_reward', 0.0)) + 0.1 * float(reward)
                item['start_phase'] = old.phase if old.phase != 'unknown' else item.get('start_phase', 'unknown')
                item['causal_reliability'] = min(1.0, 0.78 * float(item.get('causal_reliability', 0.0))
                                              + 0.22 * float(self.reward_info.get('control_signal', 0.0)))
                duration_sum = sum(max(0.01, min(1.5, float(t[4].get('duration', t[4].get('requested_duration', 0.2))))) for t in sequence if isinstance(t[4], dict))
                item['average_duration'] = (duration_sum if not item.get('average_duration') else
                                            0.90 * float(item['average_duration']) + 0.10 * duration_sum)
                evidence_quality = (0.065 * float(self.reward_info.get('causal_confidence', 0.0))
                                    * float(self.reward_info.get('persistent_visual_change', 0.0)))
                goal_weight = (1.0 if goal_progress else 0.24)
                item['quality'] = min(2.0, 0.8 * item['quality'] + 0.2 * (max(0.0, sum(t[2] for t in sequence))
                                    * goal_weight + evidence_quality))
                if reward >= item['quality'] * 0.65:
                    item['parameters'] = [t[4].copy() for t in sequence]

    @staticmethod
    def goal_transition(transition):
        if not isinstance(transition, (list, tuple)) or len(transition) < 10:
            return False
        detail = transition[9] if isinstance(transition[9], dict) else {}
        return bool(detail.get('outcome_credit') or detail.get('learning_screen_result')
                    or (detail.get('learning_goal_direction')
                        and float(detail.get('learning_goal_confidence') or 0.0) >= 0.34))

    @staticmethod
    def replay_quality(transition):
        if not isinstance(transition, (list, tuple)) or len(transition) < 10:
            return 0.0
        detail = transition[9] if isinstance(transition[9], dict) else {}
        if detail.get('feedback_valid') is False or detail.get('input_sent') is False:
            return 0.0
        if detail.get('outcome_credit') or detail.get('learning_screen_result'):
            outcome_trust = max(0.0, min(1.0, float(detail.get('credit_confidence',
                detail.get('learning_outcome_confidence', 0.9)))))
            return 0.35 + 0.65 * outcome_trust
        effect = float(detail.get('learning_effect_confidence') or 0.0) if detail.get('learning_effect_observation') is not None else 0.0
        goal = float(detail.get('learning_goal_confidence') or 0.0) if detail.get('learning_goal_direction') else 0.0
        if not any(name in detail for name in ('learning_effect_confidence', 'learning_goal_confidence', 'learning_effect_observation')):
            return 0.22
        quality = max(effect, goal) * 0.90 + min(effect, goal) * 0.10
        if goal > effect and not detail.get('learning_screen_result'):
            quality *= 0.72
        if detail.get('learning_effect_observation') == 0.0 and effect >= 0.60:
            quality = max(quality, 0.78 * effect)
        if 'learning_belief_confidence' in detail:
            belief = max(0.0, min(1.0, float(detail['learning_belief_confidence'])))
            quality *= 0.72 + 0.28 * belief
        if detail.get('learning_effect_observation') is None and not detail.get('learning_goal_direction'):
            quality = 0.0
        return max(0.0, min(1.0, quality))

    @staticmethod
    def replay_signature(transition):
        if not isinstance(transition, (list, tuple)) or len(transition) < 9:
            return None
        state = transition[1]
        following = transition[4]
        if not isinstance(state, (list, tuple)) or not isinstance(following, (list, tuple)) or len(state) < FEATURE_COUNT or len(following) < FEATURE_COUNT:
            return None
        positions = (1, 2, 6, 8, 14, 15, 18, 25, 39, 53, 78, 116,
                     SEMANTIC_START + 3, SEMANTIC_START + 5, SEMANTIC_START + 28,
                     SEMANTIC_START + 36, SEMANTIC_START + 52, SEMANTIC_START + 58)
        selected = [float(state[i]) for i in positions]
        later = [float(following[i]) for i in (1, 6, 8, 18, 25, SEMANTIC_START + 3,
                                              SEMANTIC_START + 5, SEMANTIC_START + 28)]
        if not all(math.isfinite(value) for value in selected + later) or not math.isfinite(float(transition[3])):
            return None
        before_bins = tuple(max(-48, min(48, int(round(value * 18.0)))) for value in selected)
        after_bins = tuple(max(-48, min(48, int(round(value * 18.0)))) for value in later)
        detail = transition[9] if len(transition) > 9 and isinstance(transition[9], dict) else {}
        reward_class = max(-15, min(15, int(round(float(transition[3]) * 22.0))))
        return (transition[0], int(transition[2]), before_bins, after_bins, reward_class,
                bool(transition[6]), int(transition[7]), detail.get('learning_screen_result'),
                detail.get('outcome_credit'), detail.get('learning_state_context'),
                detail.get('learning_effect_observation'),
                round(transition_elapsed_seconds(transition), 1))

    def sample_replay(self, fresh, replay_count):
        samples = []
        weights = {}
        seen = set()
        def append(sample, importance=1.0):
            signature = self.replay_signature(sample)
            if signature is None or signature in seen:
                return False
            if not math.isfinite(float(sample[3])) or float(sample[8]) < 0.15:
                return False
            evidence_quality = self.replay_quality(sample)
            if evidence_quality < 0.13:
                return False
            seen.add(signature)
            samples.append(sample)
            weights[id(sample)] = max(0.10, min(1.0, float(importance) * (0.30 + 0.70 * evidence_quality)))
            return True
        for sample in fresh:
            append(sample)
        if len(self.memory) >= 10:
            memory = list(self.memory)
            pools = ((list(getattr(self, 'goal_memory', ())), max(1, int(replay_count * 0.21))),
                     (list(self.control_memory), max(1, int(replay_count * 0.19))),
                     (list(self.failure_memory), max(1, int(replay_count * 0.19))),
                     (memory[-min(1200, len(memory)):], max(1, int(replay_count * 0.14))),
                     (list(self.rare_memory), max(1, int(replay_count * 0.09))),
                     (list(self.surprise_memory), max(1, int(replay_count * 0.08))),
                     (memory[:min(1200, len(memory))], max(1, int(replay_count * 0.06))),
                     (memory, max(1, int(replay_count * 0.04))))
            beta = min(1.0, 0.4 + 0.6 * self.updates / 200000.0)
            for pool, quota in pools:
                if not pool:
                    continue
                probabilities = []
                for transition in pool:
                    confidence = max(0.0, min(1.0, float(transition[8])))
                    detail = transition[9] if len(transition) > 9 and isinstance(transition[9], dict) else {}
                    causal_trust = max(0.0, min(1.0, float(detail.get('learning_effect_confidence') or 0.0)))
                    goal_trust = (max(0.0, min(1.0, float(detail.get('learning_goal_confidence') or 0.0)))
                                  if detail.get('learning_goal_direction') else 0.0)
                    evidence_quality = self.replay_quality(transition)
                    chain = max(1, min(N_STEP, int(transition[7])))
                    outcome = float(bool(detail.get('outcome_credit') or detail.get('learning_screen_result')))
                    reliable_outcome = max(0.20, min(1.0, float(detail.get('credit_confidence', 1.0))))
                    source_game = self.games.get(str(transition[0]))
                    age = max(0, (source_game.game_steps - int(detail.get('learning_step', source_game.game_steps)))
                              if source_game is not None else 0)
                    recency = 0.52 + 0.48 / math.sqrt(1.0 + age / 600.0)
                    contradiction = 1.0
                    observed_effect = detail.get('learning_effect_observation')
                    index = int(transition[2])
                    if (source_game is not None and 0 <= index < len(source_game.control_posteriors)
                            and observed_effect in (0.0, 1.0)):
                        posterior = source_game.control_posteriors[index]
                        trials = max(0.0, float(posterior[0]) + float(posterior[1]) - 2.0)
                        if trials >= 10.0:
                            expected_effect = max(0.0, min(1.0, (float(posterior[0]) - 1.0) / trials))
                            disagreement = abs(float(observed_effect) - expected_effect)
                            certainty = min(1.0, trials / 25.0)
                            if causal_trust >= 0.55 and confidence >= 0.55:
                                contradiction = 1.0 + 1.10 * disagreement * certainty * causal_trust
                            else:
                                contradiction = max(0.55, 1.0 - 0.35 * disagreement * certainty)
                    importance = (recency * contradiction * max(0.025, float(transition[5])) ** 0.65
                                  * (0.18 + 0.82 * confidence)
                                  * (0.20 + 0.80 * evidence_quality)
                                  * (1.0 + 0.32 * causal_trust + 0.85 * goal_trust + 0.55 * outcome * reliable_outcome)
                                  * (1.0 + 0.045 * (chain - 1)))
                    probabilities.append(importance if confidence >= 0.15 and evidence_quality >= 0.13 else 0.0)
                total = sum(probabilities)
                if total <= 0.0:
                    continue
                choices = self.rng.choices(range(len(pool)), weights=probabilities,
                                            k=min(len(pool), max(quota * 8, quota + 12)))
                accepted = 0
                for j in choices:
                    if probabilities[j] <= 0.0:
                        continue
                    correction = max(0.001, (len(pool) * probabilities[j] / total)) ** (-beta)
                    if append(pool[j], min(1.0, correction)):
                        accepted += 1
                        detail = pool[j][9] if len(pool[j]) > 9 and isinstance(pool[j][9], dict) else {}
                        owner = self.games.get(str(pool[j][0]))
                        selected_index = int(pool[j][2])
                        if (owner is not None and 0 <= selected_index < len(owner.control_posteriors)
                                and detail.get('learning_effect_observation') in (0.0, 1.0)
                                and float(detail.get('learning_effect_confidence') or 0.0) >= 0.55):
                            posterior = owner.control_posteriors[selected_index]
                            trials = max(0.0, float(posterior[0]) + float(posterior[1]) - 2.0)
                            if trials >= 10.0:
                                predicted = (float(posterior[0]) - 1.0) / trials
                                if abs(float(detail['learning_effect_observation']) - predicted) >= 0.50:
                                    owner.diagnostics['replay_counterexamples'] += 1
                    if accepted >= quota:
                        break
        other_games = [(key, item) for key, item in self.games.items()
                       if key != self.game_key and len(item.exemplars) > 0]
        if other_games:
            for _, other in self.rng.sample(other_games, min(4, len(other_games))):
                candidates = list(other.exemplars)
                self.rng.shuffle(candidates)
                accepted = 0
                for sample in candidates:
                    if append(sample, 0.55):
                        accepted += 1
                    if accepted >= max(2, min(5, replay_count // 3)):
                        break
        return samples, weights

    def training_loop(self):
        while not self.training_stop.is_set():
            self.training_last_tick = time.monotonic()
            fresh = []
            try:
                with self.training_condition:
                    if not self.training_queue:
                        self.training_condition.wait(timeout=0.2)
                    if self.training_stop.is_set():
                        break
                    if not self.training_queue:
                        continue
                    backlog = len(self.training_queue)
                    if self.np is None:
                        capacity = 3 if backlog >= 48 and self.training_cost_ema < 0.15 else 2
                        replay_count = 3 if self.vision_cost_ema < 0.20 else 2
                    elif getattr(self.np, '__name__', '') == 'cupy':
                        capacity = 36 if backlog > 24 else 12
                        replay_count = 24
                    else:
                        capacity = 24 if backlog > 24 else 8
                        replay_count = 12
                    pressure = max(self.vision_cost_ema / 0.38, self.training_cost_ema / 0.65)
                    if pressure > 1.0:
                        scale = max(0.35, min(1.0, 1.0 / pressure))
                        capacity = max(1, int(capacity * scale))
                        replay_count = max(1, int(replay_count * scale))
                    if backlog >= 64 and pressure <= 0.75:
                        capacity = min(48 if self.np is not None else 4, capacity + 4)
                    fresh = [self.training_queue.popleft() for _ in range(min(capacity, len(self.training_queue)))]
                    samples, sample_weights = self.sample_replay(fresh, replay_count)
                    snapshot = self._training_snapshot(samples)
                    snapshot['sample_weights'] = sample_weights
                if self.training_stop.is_set():
                    break
                training_started = time.perf_counter()
                results = self._train_batch(samples, snapshot)
                training_cost = max(0.0, min(10.0, time.perf_counter() - training_started))
                self.training_cost_ema = (0.82 * self.training_cost_ema + 0.18 * training_cost
                                          if self.training_cost_ema else training_cost)
                self.training_last_tick = time.monotonic()
                if results:
                    if not self._commit_training(snapshot, results):
                        raise RuntimeError('学习后端在训练中发生切换，待重试当前批次')
                self.training_problem = None
                self.training_failures = 0
            except Exception as exc:
                self.training_failures += 1
                self.training_problem = f'学习线程训练失败：{type(exc).__name__}: {exc}'
                if self.training_failures >= 3 and self.np is not None:
                    try:
                        self.recover_backend()
                    except Exception as backend_exc:
                        self.training_problem = f'学习后端迁移失败：{type(backend_exc).__name__}: {backend_exc}'
                self.training_stop.wait(min(0.5, 0.05 * max(1, self.training_failures)))
            finally:
                if fresh and (self.training_stop.is_set() or self.training_problem is not None):
                    with self.training_condition:
                        for transition in reversed(fresh):
                            self.training_queue.appendleft(transition)
                        self.training_retried += len(fresh)
                        self.training_condition.notify_all()

    def stop_training(self):
        self.training_stop.set()
        with self.training_condition:
            self.training_condition.notify_all()
        if self.trainer.is_alive():
            self.trainer.join(timeout=3.0)

    def sync_target(self):
        with self.lock:
            self.target_encoder = self.encoder.copy() if self.np is not None else [row[:] for row in self.encoder]
            self.target_encoder_bias = self.encoder_bias.copy() if self.np is not None else self.encoder_bias[:]
            for game in self.games.values():
                game.sync_target()


    def checkpoint_payload(self):
        return {
            'format': MODEL_FORMAT,
            'feature_schema': 'spatiotemporal-object-relation-context-v7',
            'reward_schema': 'dual-value-time-aware-region-causal-calibrated-v10',
            'world_schema': 'scene-segment-holdout-relational-intent-v10',
            'goal_value_schema': 'dual-head-and-terminal-outcomes-v2',
            'feature_count': FEATURE_COUNT,
            'hidden_size': self.hidden_size,
            'step': self.step,
            'updates': self.updates,
            'td_error_ema': self.td_error_ema,
            'total_reward': self.total_reward,
            'valid_transitions': self.valid_transitions,
            'low_information_observations': self.low_information_observations,
            'nstep_generated': self.nstep_generated,
            'dropped_unpersisted': self.dropped_unpersisted,
            'spilled_transitions': self.spilled_transitions,
            'spool_recovered': self.spool_recovered,
            'journaled_transitions': self.journaled_transitions,
            'persist_backlog': list(self.persist_backlog),
            'terminal_updates': list(self.terminal_updates),
            'action_ids': [a.id for a in self.actions],
            'encoder': self.encoder.tolist() if self.np is not None else self.encoder,
            'encoder_bias': self.encoder_bias.tolist() if self.np is not None else self.encoder_bias,
            'decoder': self.decoder.tolist() if self.np is not None else self.decoder,
            'decoder_bias': self.decoder_bias.tolist() if self.np is not None else self.decoder_bias,
            'games': {key: game.export() for key, game in self.games.items()},
            'visual_routes': self.visual_routes,
            'adaptive_glyphs': {name: [sorted(shape) for shape in variants[-5:]] for name, variants in self.adaptive_glyphs.items()},
        }

    def save(self, force=False):
        with self.storage_condition:
            if not force and time.monotonic() - self.last_save < 34.0:
                return False
            self.checkpoint_requested = True
            self.checkpoint_sequence += 1
            if force:
                self.storage_force = True
            self.storage_condition.notify_all()
        return True

    def _write_checkpoint(self):
        now = time.monotonic()
        path = self.folder / 'learning_state.json.gz'
        delta_path = self.folder / 'learning_delta.json.gz'
        delta_mode = (path.exists() and self.delta_base_step is not None
                      and not self.storage_stop.is_set() and self.checkpoint_serial % 5 != 4)
        with self.lock:
            snapshot_revision = self.dirty_sequence
            if delta_mode:
                changed = {}
                for key in sorted(self.dirty_games):
                    game = self.games.get(key)
                    if game is None:
                        continue
                    changed[key] = game.export()
                complete = self.checkpoint_payload()
                payload = {name: value for name, value in complete.items() if name not in ('format', 'games')}
                payload.update({'format': 1, 'base_step': self.delta_base_step, 'games': changed})
            else:
                payload = self.checkpoint_payload()
            canonical = json.dumps(payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
        temp = self.folder / ('learning_delta.json.gz.tmp' if delta_mode else 'learning_state.json.gz.tmp')
        backup = self.folder / 'learning_state.json.gz.bak'
        backup_temp = self.folder / 'learning_state.json.gz.bak.tmp'
        digest = hashlib.sha256(canonical).hexdigest().encode('ascii')
        serialized = canonical[:-1] + b',"integrity_sha256":"' + digest + b'"}'
        try:
            with temp.open('wb') as raw_stream:
                with gzip.GzipFile(fileobj=raw_stream, mode='wb', compresslevel=4) as stream:
                    stream.write(serialized)
                raw_stream.flush()
                os.fsync(raw_stream.fileno())
            with gzip.open(temp, 'rb') as verify:
                if hashlib.sha256(verify.read()).digest() != hashlib.sha256(serialized).digest():
                    raise OSError('新建学习状态的回读校验失败')
            if delta_mode:
                os.replace(temp, delta_path)
            else:
                if path.exists() and (self.checkpoint_serial % 6 == 0 or not backup.exists()):
                    try:
                        if path.stat().st_size > 140_000_000:
                            raise ValueError('旧检查点容量超限')
                        with gzip.open(path, 'rb') as old_stream:
                            old_raw = old_stream.read(260_000_001)
                        if len(old_raw) > 260_000_000:
                            raise ValueError('旧检查点解压容量超限')
                        old_payload = json.loads(old_raw)
                        old_digest = old_payload.pop('integrity_sha256', None)
                        if old_digest is not None:
                            old_bytes = json.dumps(old_payload, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                            if hashlib.sha256(old_bytes).hexdigest() != old_digest:
                                raise ValueError('旧检查点哈希错误')
                        shutil.copyfile(path, backup_temp)
                        os.replace(backup_temp, backup)
                    except (OSError, ValueError, TypeError, EOFError, gzip.BadGzipFile):
                        pass
                os.replace(temp, path)
                delta_path.unlink(missing_ok=True)
            with self.lock:
                self.last_checkpoint_summary = {
                    'step': int(payload['step']), 'updates': int(payload['updates']),
                    'games': {key: {'steps': game.get('game_steps', 0), 'skills': len(game.get('skills', {}))}
                              for key, game in list(payload.get('games', {}).items())[-32:]},
                    'sha256': hashlib.sha256(serialized).hexdigest(),
                    'kind': 'delta' if delta_mode else 'full',
                }
                self.checkpoint_compressed_bytes = (delta_path if delta_mode else path).stat().st_size
                self.checkpoint_verified = True
                self.checkpoint_serial += 1
                self.last_save = now
                if not delta_mode:
                    self.delta_base_step = payload['step']
                    if self.dirty_sequence == snapshot_revision:
                        self.dirty_games.clear()
            return True
        finally:
            temp.unlink(missing_ok=True)
            backup_temp.unlink(missing_ok=True)

    def restore(self):
        primary = self.folder / 'learning_state.json.gz'
        backup = self.folder / 'learning_state.json.gz.bak'
        if not primary.exists() and not backup.exists():
            return
        def number(value, default=0.0, lower=-1000000000.0, upper=1000000000.0):
            try:
                value = float(value)
                return max(lower, min(upper, value)) if math.isfinite(value) else default
            except (TypeError, ValueError, OverflowError):
                return default
        def integer(value, default=0, limit=1000000000):
            return int(number(value, default, 0, limit))
        def vector(value, length, limit=3.0):
            if not isinstance(value, list) or len(value) != length:
                return None
            result = [number(item, float('nan'), -limit, limit) for item in value]
            return result if all(math.isfinite(item) for item in result) else None
        def records(value):
            if isinstance(value, dict):
                return value.items()
            return value if isinstance(value, list) else []
        saved = None
        last_error = None
        for filename in (primary, backup):
            if not filename.exists():
                continue
            try:
                if filename.stat().st_size > 140_000_000:
                    raise ValueError('学习状态压缩文件过大')
                with gzip.open(filename, 'rb') as stream:
                    raw = stream.read(260_000_001)
                if len(raw) > 260_000_000:
                    raise ValueError('学习状态解压内容过大')
                entry = json.loads(raw)
                if not isinstance(entry, dict):
                    raise ValueError('学习状态结构错误')
                signature = entry.pop('integrity_sha256', None)
                if not isinstance(signature, str) or len(signature) != 64:
                    raise ValueError('学习检查点缺少校验信息')
                canonical = json.dumps(entry, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                if hashlib.sha256(canonical).hexdigest() != signature:
                    raise ValueError('学习检查点校验失败')
                if (entry.get('format') not in (7, 8, 9, 10, 11, 12, 13, 14, 15, 16, MODEL_FORMAT)
                        or entry.get('feature_count') not in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)
                        or entry.get('hidden_size') not in (96, MODEL_HIDDEN_SIZE)):
                    raise ValueError('学习状态版本或维度不受支持')
                saved = entry
                self.checkpoint_verified = True
                if filename == backup:
                    self.store_problem = '主学习状态无法恢复，已从备份恢复'
                break
            except (ValueError, TypeError, OSError, EOFError, gzip.BadGzipFile) as exc:
                last_error = exc
        if saved is None:
            self.store_problem = f'学习状态恢复失败：{last_error}'
            return
        saved_width = int(saved['feature_count'])
        saved_format = int(saved['format'])
        saved_hidden = int(saved['hidden_size'])
        self.checkpoint_migrated = (saved_width != FEATURE_COUNT or saved_hidden != self.hidden_size or saved['format'] != MODEL_FORMAT)
        self.delta_base_step = int(saved.get('step', 0))
        delta_path = self.folder / 'learning_delta.json.gz'
        if delta_path.exists():
            try:
                if delta_path.stat().st_size > 80_000_000:
                    raise ValueError('增量学习文件过大')
                with gzip.open(delta_path, 'rb') as stream:
                    raw_delta = stream.read(150_000_001)
                if len(raw_delta) > 150_000_000:
                    raise ValueError('增量学习内容过大')
                delta = json.loads(raw_delta)
                digest = delta.pop('integrity_sha256', None)
                canonical = json.dumps(delta, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
                if (not isinstance(digest, str) or hashlib.sha256(canonical).hexdigest() != digest
                        or delta.get('format') != 1 or delta.get('base_step') != self.delta_base_step
                        or delta.get('feature_count') != saved_width or delta.get('hidden_size') != saved_hidden
                        or delta.get('action_ids') != saved.get('action_ids')
                        or not isinstance(delta.get('games'), dict)
                        or int(delta.get('step', -1)) < self.delta_base_step):
                    raise ValueError('增量学习状态与基础检查点不匹配')
                for key, value in delta.items():
                    if key not in ('format', 'base_step', 'games', 'integrity_sha256'):
                        saved[key] = value
                for key, data in delta['games'].items():
                    if isinstance(key, str) and isinstance(data, dict):
                        stored = saved.setdefault('games', {}).setdefault(key, {})
                        stored.update(data)
                        self.dirty_games.add(canonical_game_key(key))
            except (OSError, ValueError, TypeError, EOFError, gzip.BadGzipFile, KeyError, AttributeError) as exc:
                self.store_problem = f'增量学习状态未采用，继续使用完整检查点：{type(exc).__name__}: {exc}'
        def feature_vector(value, limit=3.0):
            length = len(value) if isinstance(value, list) else -1
            if length not in (saved_width, FEATURE_COUNT):
                return None
            values = vector(value, length, limit)
            if values is None or length > FEATURE_COUNT:
                return None
            converted = values + [0.0] * (FEATURE_COUNT - length)
            if saved_format < 10:
                converted[SEMANTIC_START:] = [0.0] * SEMANTIC_COUNT
            if saved_format < 11:
                converted[DETAIL_SCHEMA_START:DETAIL_META_START + 4] = [0.0] * 8
            return converted
        try:
            encoder = [vector(row, saved_width, 1.2) for row in saved.get('encoder', [])]
            bias = vector(saved.get('encoder_bias'), saved_hidden, 1.2)
            if len(encoder) != saved_hidden or any(row is None for row in encoder) or bias is None:
                raise ValueError('视觉编码器参数无效')
            expanded = self.encoder.tolist() if self.np is not None else [row[:] for row in self.encoder]
            for i in range(min(saved_hidden, self.hidden_size)):
                expanded[i][:saved_width] = encoder[i]
                if saved_width < FEATURE_COUNT:
                    expanded[i][saved_width:] = [0.0] * (FEATURE_COUNT - saved_width)
                if saved_format < 10:
                    expanded[i][SEMANTIC_START:] = [0.0] * SEMANTIC_COUNT
                if saved_format < 11:
                    expanded[i][DETAIL_SCHEMA_START:DETAIL_META_START + 4] = [0.0] * 8
                if saved_format < 16:
                    expanded[i][SEMANTIC_START + 56:SEMANTIC_START + 60] = [0.0] * 4
            expanded_bias = [0.0] * self.hidden_size
            expanded_bias[:min(saved_hidden, self.hidden_size)] = bias[:min(saved_hidden, self.hidden_size)]
            self.encoder = self.np.asarray(expanded, dtype=self.np.float32) if self.np is not None else expanded
            self.encoder_bias = self.np.asarray(expanded_bias, dtype=self.np.float32) if self.np is not None else expanded_bias
            decoded = saved.get('decoder')
            old_indices = RECONSTRUCTION_INDICES if saved_format >= 17 else LEGACY_RECONSTRUCTION_INDICES
            decoded_bias = vector(saved.get('decoder_bias'), len(old_indices), 1.5)
            if (saved_format >= 12 and isinstance(decoded, list) and len(decoded) == len(old_indices)
                    and decoded_bias is not None):
                parsed_decoder = [vector(row, saved_hidden, 1.2) for row in decoded]
                if all(row is not None for row in parsed_decoder):
                    decoder_full = self.decoder.tolist() if self.np is not None else [row[:] for row in self.decoder]
                    bias_full = self.decoder_bias.tolist() if self.np is not None else self.decoder_bias[:]
                    lookup = {target: pos for pos, target in enumerate(RECONSTRUCTION_INDICES)}
                    for pos, index in enumerate(old_indices):
                        destination = lookup[index]
                        decoder_full[destination] = parsed_decoder[pos] + [0.0] * (self.hidden_size - saved_hidden)
                        bias_full[destination] = decoded_bias[pos]
                    self.decoder = self.np.asarray(decoder_full, dtype=self.np.float32) if self.np is not None else decoder_full
                    self.decoder_bias = self.np.asarray(bias_full, dtype=self.np.float32) if self.np is not None else bias_full
            ids = saved.get('action_ids', [])
            if not isinstance(ids, list):
                raise ValueError('动作集合无效')
            mapping = [(old, self.action_index[name]) for old, name in enumerate(ids) if isinstance(name, str) and name in self.action_index]
            for key, stored in records(saved.get('games', {})):
                if not isinstance(key, str) or not isinstance(stored, dict) or not key or len(key) > 50:
                    continue
                game = GameData(len(self.actions), self.hidden_size, self.np)
                rows, biases, counts = stored.get('q', []), stored.get('bias', []), stored.get('counts', [])
                for old_idx, new_idx in mapping:
                    if old_idx >= len(rows) or old_idx >= len(biases) or old_idx >= len(counts):
                        continue
                    head = vector(rows[old_idx], saved_hidden, 2.5)
                    if head is None:
                        continue
                    head += [0.0] * (self.hidden_size - saved_hidden)
                    if self.np is not None:
                        game.q[new_idx] = self.np.asarray(head, dtype=self.np.float32)
                    else:
                        game.q[new_idx] = head
                    game.bias[new_idx] = number(biases[old_idx], 0.0, -3.0, 3.0)
                    game.counts[new_idx] = integer(counts[old_idx])
                    attempts = stored.get('action_attempts', [])
                    game.action_attempts[new_idx] = integer(attempts[old_idx]) if isinstance(attempts, list) and old_idx < len(attempts) else game.counts[new_idx]
                    for field, result, minimum, maximum in (('action_effect', game.action_effect, -0.3, 1.0), ('action_effect_samples', game.action_effect_samples, 0.0, 1000000000.0),
                                                            ('action_goal', game.action_goal, -1.0, 1.0), ('action_goal_samples', game.action_goal_samples, 0.0, 1000000000.0)):
                        values = stored.get(field, [])
                        if isinstance(values, list) and old_idx < len(values):
                            val = number(values[old_idx], 0.0, minimum, maximum)
                            result[new_idx] = int(val) if field.endswith('_samples') else val
                for name in ('control', 'objective'):
                    rows = stored.get(name + '_head', [])
                    biases = stored.get(name + '_head_bias', [])
                    sample_counts = stored.get(name + '_head_samples', [])
                    if isinstance(rows, list) and isinstance(biases, list) and isinstance(sample_counts, list):
                        for old_idx, new_idx in mapping:
                            if old_idx >= len(rows) or old_idx >= len(biases) or old_idx >= len(sample_counts):
                                continue
                            values = vector(rows[old_idx], DUAL_VALUE_FEATURES, 1.0)
                            if values is None:
                                continue
                            destination = getattr(game, name + '_head')
                            destination[new_idx] = self.np.asarray(values, dtype=self.np.float32) if self.np is not None else values
                            getattr(game, name + '_head_bias')[new_idx] = number(biases[old_idx], 0.0, -1.0, 1.0)
                            getattr(game, name + '_head_samples')[new_idx] = integer(sample_counts[old_idx])
                saved_posteriors = stored.get('control_posteriors', [])
                if isinstance(saved_posteriors, list):
                    for old_idx, new_idx in mapping:
                        if old_idx < len(saved_posteriors):
                            pair = saved_posteriors[old_idx]
                            if isinstance(pair, list) and len(pair) == 2:
                                game.control_posteriors[new_idx] = [number(pair[0], 1.0, 1.0, 1000000.0),
                                                                     number(pair[1], 1.0, 1.0, 1000000.0)]
                for phase_key, votes in list(records(stored.get('phase_votes', [])))[-800:]:
                    if isinstance(phase_key, str) and len(phase_key) == 16 and isinstance(votes, list) and len(votes) == 4:
                        game.phase_votes[phase_key] = [number(value, 0.0, 0.0, 100.0) for value in votes]
                for kind, latency in list(records(stored.get('feedback_latency_by_kind', [])))[-96:]:
                    if isinstance(kind, str) and len(kind) < 32 and isinstance(latency, list) and len(latency) == 2:
                        game.feedback_latency_by_kind[kind] = [number(latency[0], 0.09, 0.035, 1.30), integer(latency[1])]
                for signature, count in list(records(stored.get('visits', [])))[-15000:]:
                    if isinstance(signature, str) and len(signature) == 16:
                        game.visits[signature] = max(1, integer(count))
                for signature, center in list(records(stored.get('scene_centers', [])))[-2400:]:
                    if isinstance(signature, str) and len(signature) == 16 and isinstance(center, list) and len(center) == 2:
                        values = vector(center[0], 20, 12.0)
                        if values is not None:
                            game.scene_centers[signature] = [values, max(1, integer(center[1]))]
                for label, value in list(records(stored.get('world_effects', [])))[-14000:]:
                    if isinstance(label, str) and 1 <= len(label) <= 125 and isinstance(value, list) and len(value) == 3:
                        game.world_effects[label] = [number(value[0], 1.0, 1.0, 1000000.0),
                                                     number(value[1], 1.0, 1.0, 1000000.0), integer(value[2])]
                for label, record in list(records(stored.get('world_events', [])))[-1800:]:
                    if isinstance(label, str) and len(label) <= 92 and isinstance(record, list) and len(record) in (7, 12):
                        game.world_events[label] = [number(v, 0.0, 0.0, 1000000.0) for v in record] + [0.0] * (12 - len(record))
                for name, limit in (('spatial_context_stats', 6500), ('duration_context_stats', 1800)):
                    target = getattr(game, name)
                    for label, value in list(records(stored.get(name, [])))[-limit:]:
                        if isinstance(label, str) and 1 <= len(label) <= 125 and isinstance(value, list) and len(value) == 4:
                            target[label] = [integer(value[0])] + [number(entry, 0.0, -1.0, 1.0) for entry in value[1:]]
                for label, value in list(records(stored.get('control_profiles', [])))[-700:]:
                    if isinstance(label, str) and len(label) <= 80 and isinstance(value, list) and len(value) == 6:
                        game.control_profiles[label] = [number(v, 0.0, -1.0, 1.0) for v in value[:5]] + [integer(value[5])]
                inverse = dict(mapping)
                for name, record in (list(records(stored.get('world', {})))[-12500:] if saved_format >= 16 else []):
                    prefix, sep, suffix = str(name).partition('@')
                    try:
                        old = int(prefix)
                    except (TypeError, ValueError):
                        continue
                    if old not in inverse or not isinstance(record, list) or len(record) not in (3, 4):
                        continue
                    width = len(record[0]) if isinstance(record[0], list) else 0
                    change = vector(record[0], width, 2.0) if width in (32, 96, WORLD_FEATURE_COUNT) else None
                    if change is not None:
                        if sep and ':' in suffix:
                            old_scene, _, rest = suffix.partition(':')
                            if old_scene == str(key).rsplit(':', 1)[-1][:8]:
                                scene = hashlib.blake2b(str(key).encode('utf-8'), digest_size=3).hexdigest()
                                suffix = scene + ':' + rest
                        new_key = f'{inverse[old]}@{suffix}' if sep else inverse[old]
                        game.world[new_key] = [change, max(1, integer(record[1])), number(record[2], 0.0, 0.0, 2.0),
                                               number(record[3], 0.0, -1.0, 1.0) if len(record) > 3 else 0.0]
                network = stored.get('world_network')
                if isinstance(network, dict) and saved_width == FEATURE_COUNT and saved_format >= 16:
                    shapes = {'w1': (WORLD_NETWORK_HIDDEN, WORLD_FEATURE_COUNT + WORLD_ACTION_FEATURES),
                              'b1': (WORLD_NETWORK_HIDDEN,),
                              'w2': (WORLD_FEATURE_COUNT + 1, WORLD_NETWORK_HIDDEN),
                              'b2': (WORLD_FEATURE_COUNT + 1,)}
                    parsed = {}
                    for name, shape in shapes.items():
                        raw = network.get(name)
                        if len(shape) == 1:
                            values = vector(raw, shape[0], 1.0)
                        else:
                            values = [vector(row, shape[1], 1.0) for row in raw] if isinstance(raw, list) and len(raw) == shape[0] else None
                            if values is not None and any(row is None for row in values):
                                values = None
                        if values is None:
                            parsed = {}
                            break
                        parsed[name] = self.np.asarray(values, dtype=self.np.float32) if self.np is not None else values
                    if len(parsed) == 4:
                        extra = {'w1_alt': (WORLD_NETWORK_HIDDEN, WORLD_FEATURE_COUNT + WORLD_ACTION_FEATURES),
                                 'b1_alt': (WORLD_NETWORK_HIDDEN,),
                                 'w2_alt': (WORLD_FEATURE_COUNT + 1, WORLD_NETWORK_HIDDEN),
                                 'b2_alt': (WORLD_FEATURE_COUNT + 1,)}
                        for name, shape in extra.items():
                            raw = network.get(name)
                            if len(shape) == 1:
                                values = vector(raw, shape[0], 1.0)
                            else:
                                values = [vector(row, shape[1], 1.0) for row in raw] if isinstance(raw, list) and len(raw) == shape[0] else None
                                if values is not None and any(row is None for row in values):
                                    values = None
                            if values is not None:
                                parsed[name] = self.np.asarray(values, dtype=self.np.float32) if self.np is not None else values
                        game.world_network = parsed
                        game.world_network_steps = integer(stored.get('world_network_steps'))
                        game.world_network_error = number(stored.get('world_network_error'), 0.13, 0.0, 1.0)
                counts = stored.get('world_action_samples', [])
                if isinstance(counts, list) and saved_format >= 16:
                    for old_idx, new_idx in mapping:
                        if old_idx < len(counts):
                            game.world_action_samples[new_idx] = integer(counts[old_idx])
                    errors = stored.get('world_action_errors', [])
                    if isinstance(errors, list):
                        for old_idx, new_idx in mapping:
                            if old_idx < len(errors):
                                game.world_action_errors[new_idx] = number(errors[old_idx], 0.15, 0.0, 1.0)
                    validations = stored.get('world_validation_samples', [])
                    if isinstance(validations, list) and saved_format >= 14:
                        for old_idx, new_idx in mapping:
                            if old_idx < len(validations):
                                game.world_validation_samples[new_idx] = integer(validations[old_idx])
                    variances = stored.get('world_action_error_variance', [])
                    if isinstance(variances, list):
                        for old_idx, new_idx in mapping:
                            if old_idx < len(variances):
                                game.world_action_error_variance[new_idx] = number(variances[old_idx], 0.02, 0.00001, 1.0)
                game.prediction_error_mean = number(stored.get('prediction_error_mean'), 0.11, 0.0, 1.0) if saved_format >= 16 else 0.11
                game.prediction_error_variance = number(stored.get('prediction_error_variance'), 0.0009, 0.00004, 1.0) if saved_format >= 16 else 0.0009
                game.prediction_error_samples = integer(stored.get('prediction_error_samples')) if saved_format >= 16 else 0
                for name, values in (list(records(stored.get('plan_error_stats', [])))[-1200:] if saved_format >= 16 else []):
                    if not isinstance(name, str) or len(name) > 45 or not isinstance(values, list) or len(values) != 3:
                        continue
                    scene, sep, original = name.rpartition(':')
                    if not sep:
                        scene, original = '', name
                    if not original.isdecimal() or int(original) not in inverse or (scene and len(scene) != 16):
                        continue
                    mapped = (scene + ':' if scene else '') + str(inverse[int(original)])
                    game.plan_error_stats[mapped] = [integer(values[0]), number(values[1], 0.11, 0.0, 1.0),
                                                     number(values[2], 0.0009, 0.00004, 1.0)]
                weights = vector(stored.get('goal_value_weights'), GOAL_VALUE_FEATURES, 0.8)
                if weights is not None:
                    game.goal_value_weights = weights if saved_format >= 16 else weights[:44] + [0.0] * 4
                    game.goal_value_bias = number(stored.get('goal_value_bias'), 0.0, -0.6, 0.6)
                    game.goal_value_samples = integer(stored.get('goal_value_samples'))
                    game.goal_value_error = number(stored.get('goal_value_error'), 0.0, 0.0, 2.0)
                for scene, values in list(records(stored.get('passive_motion_profiles', [])))[-180:]:
                    if isinstance(scene, str) and len(scene) <= 32 and isinstance(values, list) and len(values) == 2:
                        profile = vector(values[0], 12, 1.0)
                        if profile is not None:
                            game.passive_motion_profiles[scene] = [profile, max(1, integer(values[1]))]
                for scene, values in list(records(stored.get('passive_timed', [])))[-300:]:
                    if isinstance(scene, str) and len(scene) <= 90 and isinstance(values, list) and len(values) == 4:
                        game.passive_timed[scene] = [number(values[0], 0.0, 0.0, 5.0),
                                                      number(values[1], 0.0, 0.0, 25.0),
                                                      integer(values[2]),
                                                      number(values[3], 0.06, 0.012, 4.0)]
                for scene, values in list(records(stored.get('passive_scenes', [])))[-180:]:
                    if isinstance(scene, str) and len(scene) <= 24 and isinstance(values, list) and len(values) == 3:
                        game.passive_scenes[scene] = [number(values[0], 0.0, 0.0, 1.0),
                                                     number(values[1], 0.0, 0.0, 10000.0), max(1, integer(values[2]))]
                diagnostics = stored.get('diagnostics', {})
                if isinstance(diagnostics, dict):
                    for label in game.diagnostics:
                        game.diagnostics[label] = integer(diagnostics.get(label, 0))
                for transfer_key, values in list(records(stored.get('transfer_skill_stats', [])))[-800:]:
                    if (isinstance(transfer_key, str) and len(transfer_key) <= 180 and isinstance(values, list)
                            and len(values) == 3 and all(isinstance(value, int) and value >= 0 for value in values)):
                        game.transfer_skill_stats[transfer_key] = [integer(value) for value in values]
                for label, entry in list(records(stored.get('world_parameters', [])))[-4800:]:
                    if not isinstance(label, str) or not isinstance(entry, dict) or len(label) > 32:
                        continue
                    prefix, sep, old_id = label.rpartition(':')
                    if not sep:
                        prefix, old_id = '', label
                    try:
                        old_id = int(old_id)
                    except ValueError:
                        continue
                    if old_id not in inverse or (prefix and len(prefix) != 16):
                        continue
                    record = {}
                    for field in ('start_x', 'start_y'):
                        record[field] = number(entry.get(field), 0.5, 0.0, 1.0)
                    record['duration'] = number(entry.get('duration'), 0.2, 0.025, 1.5)
                    record['spatial'] = bool(entry.get('spatial'))
                    record['count'] = max(1, integer(entry.get('count', 1)))
                    record['reward'] = number(entry.get('reward'), 0.0, -1.0, 1.0)
                    game.world_parameters[(prefix + ':' if prefix else '') + str(inverse[old_id])] = record
                for label, entry in list(records(stored.get('context_action', [])))[-8000:]:
                    if not isinstance(label, str) or ':' not in label or not isinstance(entry, list) or len(entry) != 3:
                        continue
                    prefix, _, old_id = label.rpartition(':')
                    if len(prefix) != 16:
                        continue
                    try:
                        old_id = int(old_id)
                    except ValueError:
                        continue
                    if old_id in inverse:
                        game.context_action[prefix + ':' + str(inverse[old_id])] = [max(1, integer(entry[0])), number(entry[1], 0.0, -1.0, 1.0), number(entry[2], 0.0, 0.0, 20.0)]
                for label, entry in list(records(stored.get('ui_history', [])))[-128:]:
                    if isinstance(label, str) and len(label) < 80 and isinstance(entry, list) and len(entry) in (4, 5):
                        clean_votes = [[str(v[0])[:24], number(v[1], 0.0, 0.0, 1.0)] for v in (entry[4][-5:] if len(entry) == 5 and isinstance(entry[4], list) else []) if isinstance(v, list) and len(v) == 2]
                        game.ui_history[label] = [str(entry[0])[:24], min(100, integer(entry[1])), integer(entry[2]), number(entry[3], 0.0, 0.0, 1.0), clean_votes]
                for label, value in list(records(stored.get('targets', {})))[-720:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 2:
                        game.targets[label] = [number(value[0], 0.0, 0.0, 1.0), integer(value[1])]
                for label, value in list(records(stored.get('candidate_events', {})))[-350:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 2:
                        game.candidate_events[label] = [integer(value[0]), number(value[1], 0.0, 0.0, 1.0)]
                for name, item in list(records(stored.get('skills', {})))[-128:]:
                    if isinstance(name, str) and isinstance(item, dict) and vector(item.get('context'), 18) is not None:
                        game.skills[name] = item
                for sample in stored.get('exemplars', [])[-48:]:
                    if not isinstance(sample, list) or len(sample) != 10 or not isinstance(sample[2], int) or sample[2] not in inverse:
                        continue
                    before = feature_vector(sample[1])
                    after = feature_vector(sample[4])
                    if before is not None and after is not None:
                        game.exemplars.append([canonical_game_key(key), before, inverse[sample[2]], number(sample[3], 0.0, -3.0, 3.0), after, number(sample[5], 0.1, 0.025, 2.5), bool(sample[6]), max(1, integer(sample[7])), number(sample[8], 0.65, 0.0, 1.0), sample[9].copy() if isinstance(sample[9], dict) else {}])
                for label, count in list(records(stored.get('trajectories', [])))[-12000:]:
                    if isinstance(label, str) and len(label) < 100:
                        game.trajectories[label] = integer(count)
                for label, target in (('category_score', game.category_score), ('family_score', game.family_score)):
                    for group, value in records(stored.get(label, {})):
                        known = self.action_groups if label == 'category_score' else self.action_families
                        if group in known and isinstance(value, list) and len(value) == 2:
                            target[group] = [integer(value[0]), number(value[1], 0.0, -1.0, 1.0)]
                for label, value in list(records(stored.get('parameter_stats', [])))[-3200:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 3:
                        game.parameter_stats[label] = [number(value[0], 0.0, -1.0, 1.0), integer(value[1]), number(value[2], 0.0, 0.0, 1.0)]
                for kind, state in list(records(stored.get('parameter_heads', {})))[:640]:
                    allowed = (self.action_kinds_for_parameter | self.action_parameter_keys
                               | {'target:' + label for label in self.action_kinds_for_parameter | self.action_parameter_keys})
                    if not isinstance(kind, str) or kind not in allowed or not isinstance(state, dict):
                        continue
                    rows = state.get('w', [])
                    biases = vector(state.get('b'), 4, 3.0)
                    weights = [vector(row, saved_hidden, 1.5) for row in rows] if isinstance(rows, list) else []
                    if len(weights) != 4 or any(row is None for row in weights) or biases is None:
                        continue
                    weights = [row + [0.0] * (self.hidden_size - saved_hidden) for row in weights]
                    game.parameter_heads[kind] = {'w': self.np.asarray(weights, dtype=self.np.float32) if self.np is not None else weights,
                                                  'b': self.np.asarray(biases, dtype=self.np.float32) if self.np is not None else biases,
                                                  'samples': integer(state.get('samples', 0), limit=10000000)}
                for label, value in list(records(stored.get('duration_stats', {})))[-1200:]:
                    if isinstance(label, str) and isinstance(value, list) and len(value) == 2:
                        game.duration_stats[label] = [number(value[0], 0.0, -1.0, 1.0), integer(value[1])]
                for label, value in list(records(stored.get('action_applicability', [])))[-8000:]:
                    if isinstance(label, str) and len(label) <= 96 and isinstance(value, list) and len(value) == 4:
                        game.action_applicability[label] = [integer(value[0]), number(value[1], 0.0, 0.0, 1.0),
                                                            number(value[2], 0.0, -1.0, 1.0), number(value[3], 0.0, 0.0, 1.0)]
                for label, value in list(records(stored.get('hierarchical_controls', [])))[-2800:]:
                    if (isinstance(label, str) and len(label) <= 110 and isinstance(value, list)
                            and len(value) == 3 and label.startswith(('f:', 'k:', 'c:'))):
                        game.hierarchical_controls[label] = [number(value[0], 1.0, 1.0, 1000000.0),
                                                              number(value[1], 1.0, 1.0, 1000000.0),
                                                              integer(value[2])]
                for label, value in list(records(stored.get('repeat_effects', [])))[-5000:]:
                    if (isinstance(label, str) and 3 <= len(label) <= 130 and isinstance(value, list)
                            and len(value) == 4):
                        game.repeat_effects[label] = [number(value[0], 0.0, 0.0, 1000000.0),
                                                       number(value[1], 0.0, 0.0, 1000000.0),
                                                       number(value[2], 0.0, 0.0, 1000000.0),
                                                       integer(value[3])]
                for label, value in list(records(stored.get('inverse_dynamics', [])))[-120:]:
                    if (isinstance(label, str) and len(label) <= 100 and isinstance(value, list)
                            and len(value) == 4):
                        centroid = vector(value[1], len(INVERSE_WORLD_INDICES), 2.0)
                        if centroid is not None:
                            game.inverse_dynamics[label] = [integer(value[0]), centroid,
                                                              number(value[2], 0.1, 0.0, 1.0), integer(value[3])]
                for label, value in list(records(stored.get('world_condition_errors', [])))[-3000:]:
                    if (isinstance(label, str) and len(label) <= 130 and isinstance(value, list)
                            and len(value) == 3):
                        game.world_condition_errors[label] = [integer(value[0]),
                                                               number(value[1], 0.11, 0.0, 1.0),
                                                               number(value[2], 0.0009, 0.00001, 1.0)]
                for label, value in list(records(stored.get('passive_world', [])))[-256:]:
                    if (isinstance(label, str) and len(label) <= 100 and isinstance(value, list) and len(value) == 3):
                        changes = vector(value[0], WORLD_FEATURE_COUNT, 0.8)
                        if changes is not None:
                            game.passive_world[label] = [changes, integer(value[1]), number(value[2], 0.1, 0.0, 1.0)]
                for label, value in list(records(stored.get('goal_context_support', [])))[-320:]:
                    if (isinstance(label, str) and len(label) <= 120 and isinstance(value, list) and len(value) == 3):
                        try:
                            masks = [int(value[0]), int(value[1])]
                            if all(0 <= mask < (1 << 64) for mask in masks):
                                game.goal_context_support[label] = [masks[0], masks[1], integer(value[2])]
                        except (TypeError, ValueError, OverflowError):
                            pass
                for label, value in list(records(stored.get('parameter_baselines', [])))[-2400:]:
                    if isinstance(label, str) and len(label) <= 90 and isinstance(value, list) and len(value) == 2:
                        game.parameter_baselines[label] = [integer(value[0]), number(value[1], 0.0, -1.0, 1.0)]
                game.game_steps = integer(stored.get('game_steps'))
                game.total_reward = number(stored.get('total_reward'))
                game.baseline_change = number(stored.get('baseline_change'), 0.0, 0.0, 1.0)
                game.passive_change = number(stored.get('passive_change'), 0.0, 0.0, 1.0)
                game.passive_samples = integer(stored.get('passive_samples'))
                game.stagnation = integer(stored.get('stagnation'))
                game.feedback_delay = number(stored.get('feedback_delay'), 0.09, 0.035, 1.30)
                for name, value in list(records(stored.get('hud_trends', [])))[-160:] if saved_width == FEATURE_COUNT else []:
                    allowed = isinstance(name, str) and ((name.isdecimal() and 0 <= int(name) < 48)
                                     or (name.startswith('number:') and len(name) <= 20)
                                     or (name.startswith('meter:') and len(name) <= 45))
                    if allowed and isinstance(value, list) and len(value) == 4:
                        game.hud_trends[name] = [integer(value[0]), number(value[1], 0.0, 0.0, 1000000.0), number(value[2], 0.0, 0.0, 1000000.0), number(value[3], 0.0, 0.0, 1.0)]
                for name, value in list(records(stored.get('intent_values', [])))[-2000:]:
                    if isinstance(name, str) and len(name) <= 140 and isinstance(value, list) and len(value) == 4:
                        game.intent_values[name] = [number(value[0], 0.0, 0.0, 1000000.0),
                                                    number(value[1], 0.0, 0.0, 1000000.0),
                                                    number(value[2], 0.0, -1000000.0, 1000000.0),
                                                    number(value[3], 0.0, 0.0, 1000000.0)]
                for name, value in list(records(stored.get('goal_proposals', [])))[-240:]:
                    if isinstance(name, str) and len(name) <= 90 and isinstance(value, list) and len(value) == 5:
                        game.goal_proposals[name] = [number(value[0], 0.0, 0.0, 1000000.0),
                                                     number(value[1], 0.0, 0.0, 1000000.0),
                                                     number(value[2], 0.0, 0.0, 1000000.0),
                                                     str(value[3])[:90], min(4294967295, integer(value[4]))]
                for name, value in list(records(stored.get('goal_hypotheses', [])))[-160:]:
                    if (isinstance(name, str) and 1 <= len(name) <= 60 and isinstance(value, list)
                            and len(value) == 4):
                        game.goal_hypotheses[name] = [number(v, 0.0, 0.0, 1000000.0) for v in value]
                for name, value in list(records(stored.get('goal_landmarks', [])))[-800:]:
                    if isinstance(name, str) and len(name) < 90 and isinstance(value, list) and len(value) == 3:
                        game.goal_landmarks[name] = [integer(value[0]), number(value[1], 0.0, 0.0, 1.0), number(value[2], 0.0, 0.0, 1.0)]
                if isinstance(stored.get('plan_success'), list) and len(stored['plan_success']) == 2:
                    game.plan_success = [integer(stored['plan_success'][0]), integer(stored['plan_success'][1])]
                outcome_totals = stored.get('screen_outcomes', {})
                if isinstance(outcome_totals, dict):
                    game.screen_outcomes = {name: integer(outcome_totals.get(name, 0)) for name in ('win', 'loss', 'task')}
                game.result_active = False
                for entry in stored.get('confirmed_results', [])[-96:]:
                    if isinstance(entry, (tuple, list)) and len(entry) == 2 and isinstance(entry[0], str) and len(entry[0]) < 96 and entry[1] in ('win', 'loss', 'task'):
                        game.confirmed_results[entry[0]] = entry[1]
                normalized = canonical_game_key(key)
                if normalized in self.games:
                    self.games[normalized].merge(game)
                else:
                    self.games[normalized] = game
            for name, masks in records(saved.get('adaptive_glyphs', {})):
                if not isinstance(name, str) or len(name) != 1 or not isinstance(masks, list):
                    continue
                shapes = []
                for mask in masks[:5]:
                    if (isinstance(mask, list) and 13 <= len(mask) <= 110 and
                            all(isinstance(i, int) and 0 <= i < 120 for i in mask)):
                        shapes.append(frozenset(mask))
                if shapes:
                    self.adaptive_glyphs[name] = shapes
            for base, profiles in records(saved.get('visual_routes', {})):
                if not isinstance(base, str) or len(base) > 35 or not isinstance(profiles, list):
                    continue
                accepted = []
                for entry in profiles[:12]:
                    if not isinstance(entry, dict) or not isinstance(entry.get('key'), str) or len(entry['key']) > 50:
                        continue
                    anchors = []
                    for item in entry.get('anchors', [])[:24]:
                        values = vector(item, 64, 1.0)
                        if values is not None and all(0.0 <= value <= 1.0 for value in values):
                            anchors.append(values)
                    if anchors:
                        legacy = entry['key']
                        suffix = legacy[len(base) + 1:] if legacy.startswith(base + ':') else ''
                        restored_key = f'{base}~g{suffix}' if suffix.isdecimal() else legacy
                        accepted.append({'key': restored_key, 'anchors': anchors, 'samples': max(1, integer(entry.get('samples', 1)))})
                if accepted:
                    self.visual_routes[base] = accepted
            self.step = integer(saved.get('step'))
            self.updates = integer(saved.get('updates'))
            self.td_error_ema = number(saved.get('td_error_ema'), 0.0, 0.0, 10.0)
            self.total_reward = number(saved.get('total_reward'))
            self.valid_transitions = integer(saved.get('valid_transitions'))
            self.low_information_observations = integer(saved.get('low_information_observations'))
            self.nstep_generated = integer(saved.get('nstep_generated'))
            self.dropped_unpersisted = integer(saved.get('dropped_unpersisted'))
            self.spilled_transitions = integer(saved.get('spilled_transitions'))
            self.spool_recovered = integer(saved.get('spool_recovered'))
            self.journaled_transitions = integer(saved.get('journaled_transitions'))
            saved_backlog = saved.get('persist_backlog', [])
            if isinstance(saved_backlog, list) and len(saved_backlog) > 12000:
                self.dropped_unpersisted += len(saved_backlog) - 12000
                self.store_problem = '旧版本学习检查点中待写队列超出内存上限，已截断并保留最新记录'
            for row in saved_backlog[-12000:] if isinstance(saved_backlog, list) else []:
                if not isinstance(row, list) or len(row) != 11 or not isinstance(row[0], str) or row[1] not in self.action_index:
                    continue
                before = feature_vector(row[3])
                after = feature_vector(row[4])
                if before is not None and after is not None:
                    self.persist_backlog.append((canonical_game_key(row[0]), row[1], number(row[2], 0.0, -3.0, 3.0), before, after, number(row[5], 0.0, 0.0, 1.0), bool(row[6]), max(1, integer(row[7])), number(row[8], 0.1, 0.025, 2.5), number(row[9], 0.65, 0.0, 1.0), row[10].copy() if isinstance(row[10], dict) else {}))
            for uid in saved.get('terminal_updates', [])[-1024:]:
                if isinstance(uid, str) and 12 <= len(uid) <= 80:
                    self.terminal_updates.append(uid)
            if self.checkpoint_migrated:
                self.delta_base_step = None
                self.checkpoint_requested = True
        except Exception as exc:
            self.store_problem = f'学习状态恢复不完整：{type(exc).__name__}: {exc}'

    def close(self):
        self.stop_training()
        self.flush_pending(done=False)
        with self.storage_condition:
            self.checkpoint_requested = True
            self.checkpoint_sequence += 1
            self.storage_force = True
            self.storage_stop.set()
            self.storage_condition.notify_all()
        self.storage_thread.join(timeout=12.0)
        if self.storage_thread.is_alive():
            self.storage_problem = '存储线程尚未结束；未确认最后一次写入成功'

class GameAgent:
    def __init__(self, native, folder, mode, stop_vk, own_hwnd, numpy_module):
        self.native, self.folder, self.mode, self.stop_vk, self.own_hwnd = native, folder, mode, stop_vk, own_hwnd
        self.np = numpy_module
        self.stop_event = threading.Event()
        self.stop_gate = StopKeyGate(native, stop_vk, self.stop_event)
        self.on_input_released = None
        self.input_release_verified = None
        self.window_hint = None
        self.events = deque(maxlen=350)
        self.last_decision = None
        self.errors = deque(maxlen=30)
        self.brain = None
        self.capture = None
        self.listener = None
        self.controller = None
        self.started = time.time()
        self.failure_count = 0
        self.last_rect = None
        self.last_error = None
        self.same_error_count = 0
        self.last_recorded_error = 0.0
        self.last_status_written = 0.0
        self.phase = 'starting'
        self.last_capture_at = None
        self.last_input_at = None
        self.last_experience_at = None
        self.last_capture_valid = None
        self.last_observation_quality = None
        self.last_signature = None
        self.completed_actions = 0
        self.partial_actions = 0
        self.capture_failures = 0
        self.input_failures = 0
        self.feedback_captures = 0
        self.visual_game_switches = 0
        self.visual_input_effects = 0
        self.episode_boundaries = 0
        self.sensor_condition = threading.Condition()
        self.sensor_thread = None
        self.sensor_stop = threading.Event()
        self.sensor_ready = threading.Event()
        self.sensor_frame = None
        self.sensor_sequence = 0
        self.last_sensor_sequence = 0
        self.sensor_error = None
        self.sensor_quality = None
        self.detail_requests = deque()
        self.capture_target_signature = None
        self.capture_target_pid = None
        self.capture_target_hwnd = None
        self.sensor_last_attempt = None
        self.sensor_last_success = None
        self.sensor_restarts = 0
        self.sensor_frames_total = 0
        self.monitor_breaks = 0
        self.last_visual_target_count = 0
        self.last_worker_check = 0.0

    def error(self, exc):
        self.failure_count += 1
        entry = {
            'at': round(time.time(), 3),
            'type': type(exc).__name__,
            'error': str(exc)[:350],
            'trace': traceback.format_exc(limit=5)[-1800:],
            'phase': self.phase,
        }
        self.errors.append(entry)
        if self.phase == 'capturing':
            self.capture_failures += 1
        elif self.phase == 'acting':
            self.input_failures += 1
        signature = (entry['type'], entry['error'])
        self.same_error_count = self.same_error_count + 1 if self.last_error == signature else 1
        self.last_error = signature
        now = time.monotonic()
        if self.same_error_count <= 2 or self.same_error_count % 30 == 0 or now - self.last_recorded_error > 15:
            try:
                with (self.folder / 'agent_errors.jsonl').open('a', encoding='utf-8') as stream:
                    stream.write(json.dumps({**entry, 'repeats': self.same_error_count}, ensure_ascii=False) + '\n')
                self.last_recorded_error = now
            except OSError:
                pass


    def write_status(self, force=False):
        now = time.monotonic()
        if not force and now - self.last_status_written < 8:
            return
        with self.brain.lock if self.brain is not None else threading.RLock():
            stats = {
                'game': self.brain.game_key if self.brain is not None else None,
                'steps': self.brain.step if self.brain is not None else 0,
                'replay_in_memory': len(self.brain.memory) if self.brain is not None else 0,
                'control_examples_in_memory': len(self.brain.control_memory) if self.brain is not None else 0,
                'failed_action_examples_in_memory': len(self.brain.failure_memory) if self.brain is not None else 0,
                'surprising_action_examples_in_memory': len(self.brain.surprise_memory) if self.brain is not None else 0,
                'valid_transitions': self.brain.valid_transitions if self.brain is not None else 0,
                'current_game_visual_profiles': len(self.brain.visual_routes.get(self.brain.visual_active_base, [])) if self.brain is not None else 0,
                'current_scene_profile': self.brain.visual_active_key if self.brain is not None else None,
                'fine_visual_targets': self.last_visual_target_count,
                'low_information_observations': self.brain.low_information_observations if self.brain is not None else 0,
                'invalid_observations': self.brain.invalid_observations if self.brain is not None else 0,
                'persisted_transitions_this_session': self.brain.persisted_transitions if self.brain is not None else 0,
                'transitions_in_database': self.brain.store.total_transitions if self.brain is not None and self.brain.store is not None else self.brain.db_transitions_last_known if self.brain is not None else None,
                'transitions_pending_write': len(self.brain.persist_backlog) if self.brain is not None else 0,
                'unpersisted_transitions_dropped': self.brain.dropped_unpersisted if self.brain is not None else 0,
                'overflow_records_spilled': self.brain.spilled_transitions if self.brain is not None else 0,
                'overflow_records_recovered': self.brain.spool_recovered if self.brain is not None else 0,
                'overflow_file_bytes': self.brain.spool_path.stat().st_size if self.brain is not None and self.brain.spool_path.exists() else 0,
                'sqlite_connected': bool(self.brain.store is not None) if self.brain is not None else False,
                'sqlite_reconnect_failures': self.brain.store_failures if self.brain is not None else 0,
                'nstep_generated': self.brain.nstep_generated if self.brain is not None else 0,
                'training_queue': len(self.brain.training_queue) if self.brain is not None else 0,
                'training_queue_evictions': self.brain.training_queue_evictions if self.brain is not None else 0,
                'training_retries': self.brain.training_retried if self.brain is not None else 0,
                'stale_training_batches': self.brain.training_stale_batches if self.brain is not None else 0,
                'terminal_credit_samples': self.brain.terminal_credit_samples if self.brain is not None else 0,
                'training_updates': self.brain.updates if self.brain is not None else 0,
                'mean_abs_td_error': round(self.brain.td_error_ema, 6) if self.brain is not None else 0.0,
                'total_proxy_reward': self.brain.total_reward if self.brain is not None else 0.0,
                'learning_evidence_diagnostics': dict(self.brain.game.diagnostics) if self.brain is not None else {},
                'passive_motion_profile_count': len(self.brain.game.passive_motion_profiles) if self.brain is not None else 0,
                'keyframes_this_session': self.brain.keyframes_this_session if self.brain is not None else 0,
                'last_reward': dict(self.brain.reward_info) if self.brain is not None else {},
                'last_decision': self.last_decision,
                'passive_world_contexts': len(self.brain.game.passive_world) if self.brain is not None else 0,
                'goal_context_supports': len(self.brain.game.goal_context_support) if self.brain is not None else 0,
                'training_failures': self.brain.training_failures if self.brain is not None else 0,
                'training_worker_heartbeat_age': round(time.monotonic() - self.brain.training_last_tick, 3) if self.brain is not None else None,
                'storage_worker_heartbeat_age': round(time.monotonic() - self.brain.storage_last_tick, 3) if self.brain is not None else None,
                'numeric_backend': 'pure_python' if self.brain is not None and self.brain.np is None else getattr(self.brain.np, '__name__', None) if self.brain is not None else None,
                'backend_recoveries': self.brain.backend_recoveries if self.brain is not None else 0,
                'training_problem': self.brain.training_problem if self.brain is not None else None,
                'storage_problem': self.brain.storage_problem if self.brain is not None else None,
                'storage_failures': self.brain.storage_failures if self.brain is not None else 0,
                'storage_queue_keyframes': len(self.brain.frame_backlog) if self.brain is not None else 0,
                'storage_keyframes_skipped': self.brain.keyframes_skipped if self.brain is not None else 0,
                'visual_game_switch_candidate': self.brain.visual_candidate_count if self.brain is not None else 0,
                'checkpoint_verified': self.brain.checkpoint_verified if self.brain is not None else False,
                'checkpoint_migrated': self.brain.checkpoint_migrated if self.brain is not None else False,
                'screen_outcome_totals': dict(self.brain.game.screen_outcomes) if self.brain is not None else {},
                'journaled_transitions': self.brain.journaled_transitions if self.brain is not None else 0,
                'journal_failures': self.brain.journal_failures if self.brain is not None else 0,
                'database_roundtrip_verified': self.brain.store_roundtrip_verified if self.brain is not None else False,
                'database_preflight_verified': self.brain.db_preflight_verified if self.brain is not None else False,
            }
        data = {
            'updated': time.time(),
            'running': not self.stop_event.is_set(),
            'phase': self.phase,
            'mode': self.mode,
            'stop_key': self.stop_vk,
            **stats,
            'failures': self.failure_count,
            'last_error': {'type': self.errors[-1]['type'], 'message': self.errors[-1]['error'], 'at': self.errors[-1]['at']} if self.errors else None,
            'completed_actions': self.completed_actions,
            'partially_executed_actions': self.partial_actions,
            'capture_failures': self.capture_failures,
            'input_failures': self.input_failures,
            'feedback_capture_batches': self.feedback_captures,
            'visually_observed_input_effects': self.visual_input_effects,
            'estimated_episode_boundaries': self.episode_boundaries,
            'visual_game_switches': self.visual_game_switches,
            'continuous_capture_frames': self.sensor_frames_total,
            'actions_cut_short_by_visual_feedback': self.monitor_breaks,
            'touch_injection_supported': self.controller.touch_available if self.controller is not None else None,
            'last_capture_at': self.last_capture_at,
            'last_input_at': self.last_input_at,
            'last_experience_at': self.last_experience_at,
            'last_capture_valid': self.last_capture_valid,
            'last_observation_quality': self.last_observation_quality,
            'capture_low_information_streak': self.capture.low_information_frames if self.capture is not None else None,
            'last_screen_signature': self.last_signature,
            'capture_backend': self.capture.backend if self.capture is not None else None,
            'capture_backend_problem': self.capture.backend_error if self.capture is not None else None,
            'sensor_thread_alive': bool(self.sensor_thread is not None and self.sensor_thread.is_alive()),
            'sensor_error': self.sensor_error,
            'sensor_last_success_age': round(time.monotonic() - self.sensor_last_success, 3) if self.sensor_last_success is not None else None,
            'sensor_restarts': self.sensor_restarts,
            'input_release_verified': self.input_release_verified,
            'stop_input_channels': self.listener.mode if self.listener is not None else None,
            'stop_raw_events': self.listener.raw_events if self.listener is not None else 0,
            'stop_hook_events': self.listener.hook_events if self.listener is not None else 0,
            'stop_hotkey_events': self.listener.hotkey_events if self.listener is not None else 0,
            'stop_poll_events': self.stop_gate.poll_stops,
            'stop_backup_poll_healthy': self.listener.poll_healthy() if self.listener is not None else False,
            'stop_event_listener_healthy': self.listener.event_healthy() if self.listener is not None else False,
            'stop_registered_channels': dict(self.listener.registered_channels) if self.listener is not None else {},
            'stop_registration_problem': self.listener.registration_error if self.listener is not None else None,
            'input_events_accepted_by_windows': self.controller.successful_inputs if self.controller is not None else 0,
            'game_received_input': None,
            'stop_detection': getattr(self.listener, 'mode', 'fallback_poll'),
            'first_run_checks': {
                'capture_ok': self.last_capture_valid is True and bool(self.last_signature),
                'capture_trainable': bool(self.last_observation_quality and self.last_observation_quality.get('trainable')),
                'feedback_captured': self.feedback_captures > 0,
                'completed_actions': self.completed_actions > 0,
                'input_effect_observed': self.visual_input_effects > 0,
                'valid_transitions': self.brain.valid_transitions > 0 if self.brain is not None else False,
                'experience_disk_roundtrip': self.brain.store_roundtrip_verified if self.brain is not None else False,
                'learning_updates': self.brain.updates > 0 if self.brain is not None else False,
                'sqlite_connected': bool(self.brain.store is not None) if self.brain is not None else False,
                'checkpoint_verified': self.brain.checkpoint_verified if self.brain is not None else False,
            },
        }
        path = self.folder / 'runtime_state.json'
        temp = self.folder / 'runtime_state.json.tmp'
        with temp.open('w', encoding='utf-8') as stream:
            json.dump(data, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        os.replace(temp, path)
        self.last_status_written = now

    def safe_status(self, force=False):
        try:
            self.write_status(force=force)
        except Exception as exc:
            self.error(exc)

    def check_stop_fallback(self):
        if self.stop_event.is_set():
            return True
        return self.stop_gate.poll(allow_press=True)

    def ensure_listener(self):
        if (self.listener is not None and self.listener.healthy()
                and (self.listener.event_healthy() or self.listener.mode == 'poll')):
            return
        if self.listener is not None:
            self.listener.close()
        self.listener = StopListener(self.native, self.stop_vk, self.stop_event, self.stop_gate)
        self.listener.start()
        if not self.listener.healthy() and not self.stop_event.is_set():
            raise OSError('停止键双通道监听无法正常运行')

    def sensor_loop(self):
        com_initialized = self.native.ole.CoInitializeEx(None, 2) in (0, 1)
        local_capture = None
        capture_owned = False
        last_report = 0.0
        consecutive_sensor_errors = 0
        try:
            while not self.sensor_stop.is_set() and not self.stop_event.is_set():
                if CAPTURE_OWNER_LOCK.acquire(timeout=0.2):
                    capture_owned = True
                    break
            if not capture_owned:
                return
            local_capture = Capture(self.native, self.mode, self.own_hwnd)
            if self.mode == '窗口':
                if self.capture_target_signature is not None:
                    local_capture.target_signature = self.capture_target_signature
                    local_capture.target_pid = self.capture_target_pid
                    if self.capture_target_hwnd and self.native.user.IsWindow(self.capture_target_hwnd) and local_capture._same_target(self.capture_target_hwnd):
                        local_capture.target = self.capture_target_hwnd
                elif self.window_hint is not None and self.native.user.IsWindow(self.window_hint):
                    identity = local_capture._window_identity(self.window_hint)
                    candidate_rect = RECT()
                    allowed = bool(identity is not None and self.native.user.GetForegroundWindow() == self.window_hint
                                   and self.native.user.IsWindowVisible(self.window_hint)
                                   and not self.native.user.IsIconic(self.window_hint)
                                   and self.native.user.GetClientRect(self.window_hint, ctypes.byref(candidate_rect))
                                   and local_capture._window_rank(self.window_hint, identity, candidate_rect.right - candidate_rect.left,
                                                                  candidate_rect.bottom - candidate_rect.top, self.native.user.GetForegroundWindow()) is not None)
                    if allowed:
                        local_capture._stable_window_candidate((0, self.window_hint, identity), 0.45)
            self.capture = local_capture
            self.sensor_ready.set()
            while not self.sensor_stop.is_set() and not self.stop_event.is_set():
                request = None
                with self.sensor_condition:
                    if self.detail_requests:
                        request = self.detail_requests.popleft()
                    quality = self.sensor_quality
                    self.sensor_quality = None
                if request is not None:
                    try:
                        request['value'] = local_capture.grab_detail(*request['args'])
                    except Exception as exc:
                        request['error'] = exc
                    finally:
                        request['done'].set()
                try:
                    if quality is not None:
                        local_capture.review_frame_quality(quality)
                    self.sensor_last_attempt = time.monotonic()
                    raw, rect = local_capture.grab()
                    captured_at = time.monotonic()
                    with self.sensor_condition:
                        self.sensor_sequence += 1
                        self.sensor_frames_total += 1
                        self.sensor_frame = (raw, rect, captured_at, self.sensor_sequence)
                        self.sensor_error = None
                        self.sensor_last_success = captured_at
                        self.sensor_condition.notify_all()
                    consecutive_sensor_errors = 0
                    self.capture_target_signature = local_capture.target_signature
                    self.capture_target_pid = local_capture.target_pid
                    self.capture_target_hwnd = local_capture.target
                    if self.mode == '窗口' and local_capture.target and local_capture.target_signature:
                        self.window_hint = local_capture.target
                    self.sensor_stop.wait(0.02)
                except Exception as exc:
                    if self.mode == '窗口' and ('原游戏窗口' in str(exc) or '输入焦点' in str(exc)):
                        consecutive_sensor_errors = 0
                    else:
                        consecutive_sensor_errors += 1
                    if consecutive_sensor_errors >= 12 and not self.sensor_stop.is_set():
                        try:
                            signature, pid, hwnd = local_capture.target_signature, local_capture.target_pid, local_capture.target
                            local_capture.close()
                            local_capture = Capture(self.native, self.mode, self.own_hwnd)
                            local_capture.target_signature = signature
                            local_capture.target_pid = pid
                            if hwnd and self.native.user.IsWindow(hwnd) and local_capture._same_target(hwnd):
                                local_capture.target = hwnd
                            self.capture = local_capture
                            consecutive_sensor_errors = 0
                        except Exception as renew_exc:
                            self.error(renew_exc)
                    with self.sensor_condition:
                        self.sensor_error = f'{type(exc).__name__}: {str(exc)[:180]}'
                        self.sensor_condition.notify_all()
                    if time.monotonic() - last_report > 4.0:
                        self.capture_failures += 1
                        self.error(exc)
                        last_report = time.monotonic()
                    self.sensor_stop.wait(0.12)
        except Exception as exc:
            with self.sensor_condition:
                self.sensor_error = f'{type(exc).__name__}: {str(exc)[:180]}'
                self.sensor_condition.notify_all()
            self.error(exc)
        finally:
            self.sensor_ready.set()
            if local_capture is not None:
                self.capture_target_signature = local_capture.target_signature
                self.capture_target_pid = local_capture.target_pid
                self.capture_target_hwnd = local_capture.target
                try:
                    local_capture.close()
                except Exception as exc:
                    self.error(exc)
            with self.sensor_condition:
                for request in self.detail_requests:
                    request['error'] = OSError('图像采集线程已终止')
                    request['done'].set()
                self.detail_requests.clear()
                self.sensor_condition.notify_all()
            if self.capture is local_capture:
                self.capture = None
            if capture_owned:
                CAPTURE_OWNER_LOCK.release()
            if com_initialized:
                self.native.ole.CoUninitialize()

    def start_sensor(self):
        if self.sensor_thread is not None and self.sensor_thread.is_alive():
            if self.sensor_stop.is_set():
                raise OSError('旧采集线程尚未退出，等待释放原 DXGI/GDI 设备')
            return
        self.sensor_stop.clear()
        self.sensor_ready.clear()
        with self.sensor_condition:
            self.sensor_frame = None
            self.sensor_error = None
        self.sensor_restarts += 1
        self.sensor_thread = threading.Thread(target=self.sensor_loop, name='AgentVision', daemon=True)
        self.sensor_thread.start()
        deadline = time.monotonic() + 12.0
        while not self.stop_event.is_set() and self.sensor_thread.is_alive() and time.monotonic() < deadline:
            if self.sensor_ready.wait(0.12):
                break
        if self.stop_event.is_set():
            return
        if self.capture is None:
            raise OSError(self.sensor_error or '图像采集线程未能初始化，请检查驱动和窗口状态')

    def sample_frame(self, min_sequence=None, timeout=1.7):
        start = time.monotonic()
        deadline = start + max(0.2, timeout)
        last_attempt = self.sensor_last_attempt
        with self.sensor_condition:
            while not self.stop_event.is_set():
                frame = self.sensor_frame
                if frame is not None and (min_sequence is None or frame[3] > min_sequence):
                    if time.monotonic() - frame[2] <= 2.0:
                        self.last_sensor_sequence = frame[3]
                        return frame[0], frame[1]
                if self.sensor_thread is None or not self.sensor_thread.is_alive():
                    break
                now = time.monotonic()
                if self.sensor_last_attempt is not None and self.sensor_last_attempt != last_attempt:
                    last_attempt = self.sensor_last_attempt
                    deadline = max(deadline, min(start + 8.0, now + max(0.2, timeout)))
                remaining = deadline - now
                if remaining <= 0:
                    break
                self.sensor_condition.wait(min(0.10, remaining))
        raise OSError('等待新的游戏画面超时：' + str(self.sensor_error or '采集设备无新帧'))

    def sample_detail(self, rect, u, v):
        event = threading.Event()
        request = {'args': (rect, u, v), 'done': event}
        with self.sensor_condition:
            self.detail_requests.append(request)
            self.sensor_condition.notify_all()
        deadline = time.monotonic() + 4.0
        while not self.stop_event.is_set() and not event.is_set():
            if not self.sensor_thread or not self.sensor_thread.is_alive():
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            event.wait(min(0.10, remaining))
        if not event.is_set():
            with self.sensor_condition:
                try:
                    self.detail_requests.remove(request)
                except ValueError:
                    pass
            raise OSError('精细画面采集超时或采集线程已失效')
        if 'error' in request:
            raise request['error']
        return request['value']

    def note_frame_quality(self, quality):
        with self.sensor_condition:
            self.sensor_quality = quality

    def capture_is_stale(self, max_age=1.5):
        with self.sensor_condition:
            frame = self.sensor_frame
        return bool(self.sensor_thread is None or not self.sensor_thread.is_alive()
                    or frame is None or time.monotonic() - frame[2] > max_age)

    def action_monitor(self, old):
        if self.stop_event.is_set():
            return 'stop_key'
        if self.listener is None or not self.listener.healthy():
            return 'stop_listener_unhealthy'
        if self.capture_is_stale():
            return 'capture_stale'
        if self.mode == '窗口' and self.capture is not None and not self.capture.is_target_focused():
            return 'focus_lost'
        with self.sensor_condition:
            frame = self.sensor_frame
        if frame is None or frame[3] <= self.last_sensor_sequence or old.raw is None or frame[1] != old.rect:
            return True
        data = frame[0]
        step = max(1, (W * H) // 150)
        magnitude = sum(abs(data[i * 4] - old.raw[i * 4]) + abs(data[i * 4 + 1] - old.raw[i * 4 + 1]) + abs(data[i * 4 + 2] - old.raw[i * 4 + 2]) for i in range(0, W * H, step))
        samples = len(range(0, W * H, step))
        natural = max(old.change, self.brain.game.passive_change if self.brain is not None else 0.0)
        threshold = max(0.23, min(0.52, 0.29 + natural * 1.6))
        if magnitude / max(1, samples * 3 * 255) > threshold:
            self.monitor_breaks += 1
            return 'visual_change'
        return True

    def cleanup_capture(self):
        self.sensor_stop.set()
        with self.sensor_condition:
            self.sensor_condition.notify_all()
        worker = self.sensor_thread
        if worker is not None and worker.is_alive() and worker is not threading.current_thread():
            worker.join(timeout=2.5)
        if worker is not None and worker.is_alive():
            with self.sensor_condition:
                self.sensor_frame = None
                self.sensor_error = '旧采集线程退出超时，保留线程引用并阻止同时开启第二个采集器'
            return False
        if self.sensor_thread is worker:
            self.sensor_thread = None
        with self.sensor_condition:
            self.sensor_frame = None
        return True

    def resync_after_interruption(self):
        if self.controller is not None:
            self.controller.release(retries=5)
        self.phase = 'capturing'
        if self.capture_is_stale():
            raise OSError('动作中断后画面采集已失效，需要重新初始化')
        raw, rect = self.sample_frame(min_sequence=self.last_sensor_sequence, timeout=3.0)
        self.last_capture_at = time.time()
        self.last_rect = rect
        game_key = self.brain.identify_game(self.capture.game_identity(), raw)
        if game_key != self.brain.game_key:
            self.brain.set_game(game_key)
            self.visual_game_switches += 1
        self.brain.previous_lum = None
        self.brain.previous_motion = None
        self.brain.temporal_luma.clear()
        self.brain.last_attention_tracks = []
        self.brain.last_detail_focus = (0.5, 0.5)
        observation = self.brain.observe(raw, rect)
        self.last_visual_target_count = len(observation.attention_points)
        self.last_capture_valid = observation.valid
        self.last_observation_quality = observation.quality
        self.last_signature = observation.signature
        self.note_frame_quality(observation.quality)
        self.brain.persist_initial_frame(observation)
        self.safe_status()
        return observation, rect

    def capture_action_feedback(self, old, rect, action):
        start = time.monotonic()
        with self.sensor_condition:
            current_sequence = self.sensor_sequence
        raw, newrect = self.sample_frame(min_sequence=current_sequence)
        self.last_capture_at = time.time()
        self.last_rect = newrect
        game = self.brain.game
        learned_delay = game.feedback_latency_by_kind.get(action.kind)
        delay = max(0.035, min(1.30, 0.75 * learned_delay[0] + 0.25 * game.feedback_delay)) if learned_delay else game.feedback_delay
        if action.kind in ('move', 'look', 'aim', 'combat', 'hold', 'swipe', 'right_swipe'):
            deadlines = (max(0.025, delay * 0.45), max(0.07, delay * 1.3))
        else:
            deadlines = (max(0.045, delay * 0.85), max(0.10, delay * 2.1))
        if self.brain.step % 7 == 0 or (learned_delay and learned_delay[0] > 0.22):
            deadlines = (*deadlines, min(1.30, max(0.32, delay * 3.5)))
        if self.brain.step % 23 == 0:
            deadlines = (*deadlines, max(deadlines[-1] + 0.07, 1.15))
        samples = [(raw, newrect)]
        frame_times = [max(0.0, time.monotonic() - start)]
        for deadline in deadlines:
            if newrect != rect or self.stop_event.wait(max(0.0, deadline - (time.monotonic() - start))):
                break
            with self.sensor_condition:
                current_sequence = self.sensor_sequence
            raw, newrect = self.sample_frame(min_sequence=current_sequence)
            self.last_capture_at = time.time()
            self.last_rect = newrect
            samples.append((raw, newrect))
            frame_times.append(max(0.0, time.monotonic() - start))
        deltas = []
        recent_lum = []
        self.feedback_captures += 1
        if any(item[1] != rect for item in samples):
            return raw, newrect, {'frame_deltas': [], 'frame_times': [], 'settled_change': 0.0, 'hud_stability': 0.0, 'frame_stability': 0.0}
        for data, _ in samples:
            pixels = self.brain.rgb_blocks(data)
            lum = [luminance_bgr(*pixel) for pixel in pixels]
            recent_lum.append(lum)
            deltas.append(sum(abs(a - b) for a, b in zip(old.lum, lum)) / (GW * GH))
        hud_indices = [r * GW + c for r in (0, 1, GH - 2, GH - 1) for c in range(GW)]
        final_change = sum(abs(old.lum[i] - recent_lum[-1][i]) for i in hud_indices) / len(hud_indices)
        drift = (sum(abs(recent_lum[-1][i] - recent_lum[-2][i]) for i in hud_indices) / len(hud_indices)) if len(recent_lum) > 1 else 0.0
        stability = max(0.0, min(1.0, 1.0 - drift / max(0.015, final_change * 1.4)))
        frame_drift = (sum(abs(a - b) for a, b in zip(recent_lum[-1], recent_lum[-2])) / (GW * GH)) if len(recent_lum) > 1 else 1.0
        frame_stability = max(0.0, min(1.0, 1.0 - frame_drift / max(0.025, deltas[-1] * 0.7)))
        interval_deltas = [sum(abs(a - b) for a, b in zip(prior, following)) / (GW * GH)
                           for prior, following in zip(recent_lum, recent_lum[1:])]
        return raw, newrect, {'frame_deltas': deltas, 'frame_times': frame_times, 'interval_deltas': interval_deltas, 'settled_change': deltas[-1], 'hud_stability': stability,
                              'frame_stability': frame_stability, 'post_action_drift': frame_drift,
                              'result_check_frames': [data for data, _ in samples[-3:]],
                              'feedback_started_monotonic': start, 'feedback_completed_monotonic': time.monotonic()}


    def run(self):
        try:
            try:
                self.safe_status(force=True)
            except Exception as exc:
                self.error(exc)
            while not self.check_stop_fallback():
                try:
                    self.phase = 'initializing'
                    self.ensure_listener()
                    if self.capture is None or self.sensor_stop.is_set():
                        self.start_sensor()
                    if self.controller is None:
                        self.controller = Controller(self.native, self.stop_vk, self.stop_event)
                        self.controller.stop_gate = self.stop_gate
                    if self.brain is None:
                        self.brain = Brain(self.folder, self.stop_vk, self.np)
                        if self.brain.store_problem:
                            self.error(OSError(self.brain.store_problem))
                            self.brain.store_problem = None
                    self.phase = 'capturing'
                    raw, rect = self.sample_frame(timeout=3.0)
                    self.last_capture_at = time.time()
                    self.last_rect = rect
                    game_key = self.brain.identify_game(self.capture.game_identity(), raw)
                    self.brain.set_game(game_key)
                    try:
                        passive_start = time.monotonic()
                        self.stop_event.wait(0.035)
                        passive, passive_rect = self.sample_frame(min_sequence=self.last_sensor_sequence)
                        if passive_rect == rect:
                            self.brain.record_passive_change(raw, passive, elapsed_seconds=time.monotonic() - passive_start)
                            raw = passive
                    except Exception as exc:
                        self.error(exc)
                    try:
                        detail = self.sample_detail(rect, 0.5, 0.5)
                    except Exception as exc:
                        self.error(exc)
                        detail = None
                    obs = self.brain.observe(raw, rect, detail)
                    self.last_visual_target_count = len(obs.attention_points)
                    self.last_capture_valid = obs.valid
                    self.last_observation_quality = obs.quality
                    self.last_signature = obs.signature
                    self.note_frame_quality(obs.quality)
                    self.brain.persist_initial_frame(obs)
                    self.safe_status(force=True)
                    plan = deque()
                    plan_parameters = deque()
                    plan_predictions = deque()
                    chosen_plan = []
                    while not self.check_stop_fallback():
                        now = time.monotonic()
                        if now - self.last_worker_check >= 0.75:
                            self.ensure_listener()
                            self.brain.ensure_workers()
                            self.last_worker_check = now
                        if self.capture_is_stale():
                            raise OSError('采集画面已过期或采集线程失效，需要重启采集器')
                        if not plan:
                            chosen_plan = self.brain.choose_plan(obs)
                            plan.extend(chosen_plan)
                            plan_parameters = deque(self.brain.last_plan_parameters)
                            plan_predictions = deque(self.brain.last_plan_predictions)
                        source_index = plan.popleft()
                        expected_state = plan_predictions.popleft() if plan_predictions else None
                        index = (self.brain.remap_skill_intent(self.brain.game, obs, source_index)
                                 if self.brain.last_skill_source is not None
                                 and self.brain.last_skill_source != self.brain.game_key else source_index)
                        action = self.brain.actions[index]
                        self.phase = 'acting'
                        saved_parameters = plan_parameters.popleft() if plan_parameters else None
                        parameters = saved_parameters if saved_parameters is not None else self.brain.recommend_action_parameters(index, obs)
                        model_parameters = self.brain.parameter_dictionary(parameters, action, self.brain.stagnation)
                        self.last_decision = self.brain.decision_diagnostics(
                            obs, index, model_parameters, len(chosen_plan), expected_state is not None)
                        self.controller.guard = self.capture.is_target_focused if self.capture is not None else None
                        completed = self.controller.execute(action, obs, rect, self.brain.stagnation, parameters,
                                                            monitor=(lambda previous=obs: self.action_monitor(previous)),
                                                            feedback_delay=self.brain.game.feedback_delay)
                        action_detail = self.controller.last_action_detail
                        self.last_input_at = time.time() if action_detail and action_detail.get('input_sent') else self.last_input_at
                        if self.check_stop_fallback():
                            break
                        if self.controller.interruption_reason == 'capture_stale':
                            raise OSError('动作期间画面采集停滞，释放输入并恢复采集')
                        if self.controller.interruption_reason == 'stop_listener_unhealthy':
                            raise OSError('停止键监听心跳失效，重新安装键盘钩子')
                        visual_feedback = bool(isinstance(action_detail, dict) and action_detail.get('input_sent')
                                               and action_detail.get('interruption_reason') == 'visual_change'
                                               and not self.stop_event.is_set())
                        if visual_feedback:
                            self.partial_actions += 1
                            action_detail['early_visual_feedback'] = True
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                        elif not completed or (isinstance(action_detail, dict) and action_detail.get('interrupted')):
                            if action_detail and action_detail.get('input_sent'):
                                self.partial_actions += 1
                            self.brain.learn_boundary(obs, index, 'action_interrupted', action_detail)
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                            obs, rect = self.resync_after_interruption()
                            continue
                        elif action_detail.get('finished'):
                            self.completed_actions += 1
                        else:
                            self.partial_actions += 1
                            self.brain.learn_boundary(obs, index, 'action_partially_finished', action_detail)
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                            obs, rect = self.resync_after_interruption()
                            continue
                        self.phase = 'capturing'
                        newraw, newrect, feedback = self.capture_action_feedback(obs, rect, action)
                        action_detail['feedback_valid'] = newrect == rect and bool(feedback.get('frame_deltas'))
                        action_detail['feedback_sample_count'] = len(feedback.get('frame_deltas', ()))
                        action_detail['feedback_elapsed_seconds'] = max(0.0, float(feedback.get('feedback_completed_monotonic', 0.0))
                            - float(feedback.get('feedback_started_monotonic', 0.0))) if 'feedback_completed_monotonic' in feedback else 0.0
                        times = feedback.get('frame_times', [])
                        if times and math.isfinite(float(times[-1])):
                            action_detail['effective_elapsed_seconds'] = max(0.03, min(8.0, float(action_detail.get('duration', 0.0)) + float(times[-1])))
                        if self.check_stop_fallback():
                            break
                        following_game = self.brain.identify_game(self.capture.game_identity(), newraw)
                        if following_game != self.brain.game_key:
                            learned = self.brain.learn_boundary(obs, index, 'game_process_switch', self.controller.last_action_detail, terminal=False)
                            if learned:
                                self.last_experience_at = time.time()
                            self.episode_boundaries += 1
                            self.events.append({'t': round(time.time(), 2), 'game': self.brain.game_key, 'step': self.brain.step, 'action': action.id, 'game_switch': following_game, 'reward_basis': 'terminal_with_unobserved_result_no_cross_game_training'})
                            self.brain.set_game(following_game)
                            self.visual_game_switches += 1
                            plan.clear()
                            plan_predictions.clear()
                            following = self.brain.observe(newraw, newrect)
                            self.last_visual_target_count = len(following.attention_points)
                            self.brain.persist_initial_frame(following)
                            obs, rect = following, newrect
                            self.last_capture_valid = following.valid
                            self.last_observation_quality = following.quality
                            self.last_signature = following.signature
                            self.note_frame_quality(following.quality)
                            self.brain.save(force=self.brain.step == 1)
                            self.safe_status(force=True)
                            continue
                        detail = None
                        if (self.brain.step % ((3 if obs.state_uncertainty >= 0.46 else 6)
                                                if self.brain.vision_cost_ema > 0.55 else
                                                (2 if obs.state_uncertainty >= 0.46 else 4)) == 0
                                or (obs.ui_text and any(0.45 < float(t.get('temporal_confidence', 0.0)) < 0.76 for t in obs.ui_text))
                                or (action.kind in ('click', 'right', 'double', 'focus_click', 'press', 'touch_tap', 'swipe', 'touch_swipe', 'combat', 'aim')
                                    and (obs.novelty >= 0.60 or self.brain.stagnation > 8 or self.brain.step % 2 == 0))):
                            try:
                                u, v = self.brain.detail_focus(obs, self.controller.last_action_detail)
                                detail = self.sample_detail(newrect, u, v)
                            except Exception as exc:
                                self.error(exc)
                        following = self.brain.observe(newraw, newrect, detail)
                        self.last_visual_target_count = len(following.attention_points)
                        self.last_capture_valid = following.valid
                        self.last_observation_quality = following.quality
                        self.last_signature = following.signature
                        self.note_frame_quality(following.quality)
                        self.phase = 'learning'
                        self.brain.persist_initial_frame(following)
                        if not action_detail.get('feedback_valid', False):
                            self.brain.learn_boundary(obs, index, 'unreliable_action_feedback', action_detail)
                            self.safe_status()
                            plan.clear()
                            plan_predictions.clear()
                            obs, rect = following, newrect
                            continue
                        reward, delta = self.brain.reward_for(obs, following, index, action_detail, feedback)
                        if float(self.brain.reward_info.get('causal_confidence', 0.0)) >= 0.32 and float(self.brain.reward_info.get('persistent_visual_change', 0.0)) >= 0.35:
                            self.visual_input_effects += 1
                        episode_boundary = bool(self.brain.reward_info.get('episode_boundary', False))
                        if episode_boundary:
                            self.episode_boundaries += 1
                        before_count = self.brain.valid_transitions
                        self.brain.learn(obs, index, following, reward, delta, done=episode_boundary, effect=action_detail)
                        if self.brain.valid_transitions > before_count:
                            self.last_experience_at = time.time()
                        self.events.append({
                            't': round(time.time(), 2),
                            'game': self.brain.game_key,
                            'step': self.brain.step,
                            'category': action.category,
                            'action': action.id,
                            'decision': self.last_decision,
                            'observation_valid': following.valid,
                            **self.brain.reward_info,
                            'screen': following.signature,
                        })
                        prediction_failed = self.brain.plan_prediction_failed(expected_state, following, index, obs.signature)
                        effect_mismatch = bool((expected_state is not None or plan) and self.brain.plan_feedback_mismatch(
                            self.last_decision, self.brain.reward_info))
                        if effect_mismatch:
                            prediction_failed = True
                            self.brain.game.diagnostics['plan_action_mismatches'] += 1
                        if not plan and action_detail.get('finished'):
                            self.brain.mark_plan_result(chosen_plan, following, self.brain.reward_info,
                                                        steps_completed=len(chosen_plan) - len(plan))
                        self.events[-1]['plan_replan_reason'] = ('effect_mismatch' if effect_mismatch
                                                                 else 'predicted_state_diverged' if prediction_failed else None)
                        skill_deviated = bool(plan and not self.brain.skill_should_continue(following, chosen_plan, len(chosen_plan) - len(plan)))
                        if skill_deviated and not episode_boundary:
                            self.brain.mark_plan_result(chosen_plan, following, self.brain.reward_info,
                                                        steps_completed=len(chosen_plan) - len(plan))
                        if episode_boundary or prediction_failed or skill_deviated or not following.quality.get('trainable', False):
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                        if (self.brain.step % 7 == 0 or self.brain.game.passive_samples < 4) and not self.check_stop_fallback():
                            try:
                                passive_start = time.monotonic()
                                self.stop_event.wait(0.04)
                                passive_raw, passive_rect = self.sample_frame(min_sequence=self.last_sensor_sequence)
                                if passive_rect == newrect:
                                    self.brain.record_passive_change(newraw, passive_raw, following, time.monotonic() - passive_start)
                                    following = self.brain.observe(passive_raw, passive_rect)
                                    self.last_visual_target_count = len(following.attention_points)
                                    self.last_capture_valid = following.valid
                                    self.last_observation_quality = following.quality
                                    self.last_signature = following.signature
                                    self.note_frame_quality(following.quality)
                            except Exception as exc:
                                self.error(exc)
                        self.brain.save(force=(self.brain.step == 1))
                        self.safe_status(force=(self.brain.step == 1))
                        if self.brain.store_problem:
                            self.error(OSError(self.brain.store_problem))
                            self.brain.store_problem = None
                        if self.brain.training_problem:
                            self.error(RuntimeError(self.brain.training_problem))
                            self.brain.training_problem = None
                        if self.brain.storage_problem:
                            self.error(OSError(self.brain.storage_problem))
                            self.brain.storage_problem = None
                        if delta > 0.38:
                            plan.clear()
                            plan_parameters.clear()
                            plan_predictions.clear()
                        obs, rect = following, newrect
                except Exception as exc:
                    failed_phase = self.phase
                    self.phase = 'recovering'
                    self.error(exc)
                    inputs_released = self.controller is None
                    try:
                        if self.controller is not None:
                            self.controller.release()
                            inputs_released = not (self.controller.down or self.controller.mouse_down or self.controller.touch_points)
                    except Exception as release_error:
                        self.error(release_error)
                    capture_failure = (failed_phase in ('initializing', 'capturing') or self.capture is None
                                       or self.capture_is_stale() or (self.sensor_thread is not None and not self.sensor_thread.is_alive()))
                    if failed_phase == 'acting' and self.controller is not None and inputs_released and not self.stop_event.is_set():
                        self.controller = None
                    if capture_failure:
                        try:
                            self.cleanup_capture()
                        except Exception as capture_error:
                            self.error(capture_error)
                    if self.brain is not None:
                        if failed_phase in ('initializing', 'learning', 'capturing') and self.brain.np is not None and self.same_error_count >= 2:
                            try:
                                if self.brain.recover_backend():
                                    self.np = self.brain.np
                            except Exception as backend_error:
                                self.error(backend_error)
                                try:
                                    self.brain.save(force=True)
                                    self.brain.close()
                                except Exception as closing_error:
                                    self.error(closing_error)
                                self.brain = None
                                try:
                                    self.np = importlib.import_module('numpy')
                                    validate_learning_backend(self.np)
                                except Exception:
                                    self.np = None
                        if self.brain is not None and capture_failure:
                            self.brain.previous_lum = None
                            self.brain.previous_motion = None
                            self.brain.temporal_luma.clear()
                            self.brain.temporal_observations.clear()
                            self.brain.last_attention_tracks = []
                            self.brain.visual_tracks.clear()
                        if self.brain is not None:
                            try:
                                self.brain.flush_pending(done=False)
                                self.brain.ensure_workers()
                            except Exception as storage_error:
                                self.error(storage_error)
                    try:
                        self.safe_status()
                    except Exception as status_error:
                        self.error(status_error)
                    if not self.check_stop_fallback():
                        self.stop_event.wait(min(0.8, 0.05 + self.same_error_count * 0.01))
        finally:
            self.phase = 'stopped' if self.stop_event.is_set() else 'recovering'
            self.input_release_verified = self.controller is None
            if self.controller is not None:
                try:
                    self.controller.release(retries=6)
                except Exception as exc:
                    self.error(exc)
                self.input_release_verified = not (self.controller.down or self.controller.mouse_down or self.controller.touch_points)
            if self.stop_event.is_set() and self.input_release_verified and self.on_input_released is not None:
                try:
                    self.on_input_released()
                except Exception as exc:
                    self.error(exc)
            if self.brain is not None:
                try:
                    self.brain.flush_pending(done=False)
                    self.brain.stop_training()
                    self.brain.save(force=True)
                except Exception as exc:
                    self.error(exc)
                try:
                    self.brain.close()
                except Exception as exc:
                    self.error(exc)
            try:
                self.safe_status(force=True)
            except Exception as exc:
                self.error(exc)
            try:
                self.cleanup_capture()
            except Exception as exc:
                self.error(exc)
            if self.listener is not None:
                self.listener.close()


def validate_learning_backend(module):
    worker = Brain.__new__(Brain)
    worker.np = module
    worker.actions = [Action('click', 'click'), Action('focus_click', 'focus_click'), Action('key:87', 'key', a=87)]
    worker.action_neighbors = [[(1, 1.0)], [(0, 1.0)], []]
    before = [0.15 + (i % 5) * 0.035 for i in range(FEATURE_COUNT)]
    after = [0.25 + (i % 7) * 0.021 for i in range(FEATURE_COUNT)]
    rows = [[0.002] * FEATURE_COUNT for _ in range(8)]
    zeros = [0.0] * 8
    head = [[0.0] * 8 for _ in range(3)]
    bias = [0.0] * 3
    if module is not None:
        rows = module.asarray(rows, dtype=module.float32)
        zeros = module.asarray(zeros, dtype=module.float32)
        head = module.asarray(head, dtype=module.float32)
        bias = module.asarray(bias, dtype=module.float32)
    def clone(value):
        return value.copy() if module is not None else [row[:] if isinstance(row, list) else row for row in value]
    snapshot = {
        'encoder': clone(rows), 'encoder_bias': clone(zeros),
        'decoder': clone([[0.002] * 8 for _ in RECONSTRUCTION_INDICES]) if module is None else module.full((len(RECONSTRUCTION_INDICES), 8), 0.002, dtype=module.float32),
        'decoder_bias': clone([0.0] * len(RECONSTRUCTION_INDICES)) if module is None else module.zeros(len(RECONSTRUCTION_INDICES), dtype=module.float32),
        'target_encoder': clone(rows), 'target_encoder_bias': clone(zeros),
        'games': {'verification': {
            'q': clone(head), 'bias': clone(bias),
            'target_q': clone(head), 'target_bias': clone(bias), 'counts': [0, 0, 0],
            'parameter_baselines': {},
            'parameter_heads': {'click': {'w': module.zeros((4, 8), dtype=module.float32) if module is not None else [[0.0] * 8 for _ in range(4)],
                                           'b': module.zeros(4, dtype=module.float32) if module is not None else [0.0] * 4,
                                           'samples': 0}},
        }},
    }
    transition = ['verification', before, 0, 0.32, after, 0.3, True, 1, 1.0,
                  {'kind': 'click', 'input_sent': True, 'finished': True, 'spatial': True, 'start_x': 0.78,
                   'start_y': 0.25, 'requested_duration': 0.18, 'extent': 1.0}]
    results = worker._train_batch([transition], snapshot)
    if len(results) != 1 or not math.isfinite(results[0][1]):
        raise ArithmeticError('学习后端未能产生有效训练结果')
    value = snapshot['games']['verification']['bias'][0]
    if not math.isfinite(float(value)) or float(value) <= 0.0:
        raise ArithmeticError('学习后端没有完成参数更新')
    neighbor_bias = snapshot['games']['verification']['bias'][1]
    if not math.isfinite(float(neighbor_bias)) or float(neighbor_bias) <= 0.0:
        raise ArithmeticError('兼容操作之间没有产生泛化学习')
    if float(snapshot['games']['verification']['bias'][2]) != 0.0:
        raise ArithmeticError('不同含义的操作出现错误价值传播')
    if not math.isfinite(float(snapshot['decoder_bias'][0])) or float(snapshot['decoder_bias'][0]) <= 0.0:
        raise ArithmeticError('自监督视觉解码器未能独立更新')
    parameter = snapshot['games']['verification']['parameter_heads']['click']
    if (parameter['samples'] != 1 or not math.isfinite(float(parameter['b'][2]))
            or abs(float(parameter['b'][2])) <= 1e-12 or float(parameter['b'][0]) != 0.0):
        raise ArithmeticError('学习后端没有完成时长学习或错误地平均空间坐标')
    multi = [transition[0], transition[1][:], transition[2], 0.72, transition[4][:], 0.4, True, 3, 1.0, dict(transition[9])]
    if len(worker._train_batch([multi], snapshot)) != 1 or parameter['samples'] != 1:
        raise ArithmeticError('多步经验不应更新单步动作参数')
    return True


def acceleration_for(folder, status):
    runtime = folder / '_runtime'
    gpu_runtime = folder / '_gpu_runtime'
    wheel_dir = folder / '_verified_wheels'
    for path in (gpu_runtime, runtime):
        if path.is_dir() and str(path) not in sys.path:
            sys.path.insert(0, str(path))
    def gpu_backend():
        try:
            module = importlib.import_module('cupy')
            if module.cuda.runtime.getDeviceCount() <= 0:
                return None
            values = module.asarray([[1.0, 2.0], [3.0, 4.0]], dtype=module.float32)
            if module.asnumpy(values @ values).shape != (2, 2):
                return None
            module.clip(values, -1.0, 1.0, out=values)
            return module
        except Exception:
            return None
    def verified_cpu(module):
        try:
            x = module.asarray([[0.1] * FEATURE_COUNT, [0.2] * FEATURE_COUNT], dtype=module.float32)
            weight = module.ones((12, FEATURE_COUNT), dtype=module.float32) * module.float32(0.004)
            hidden = module.tanh(x @ weight.T)
            head = module.zeros((3, 12), dtype=module.float32)
            actions = module.asarray([0, 2], dtype=module.int32)
            module.add.at(head, actions, hidden * module.float32(0.01))
            values = (head @ hidden.T).tolist()
            return len(values) == 3 and len(values[0]) == 2 and all(math.isfinite(float(v)) for row in values for v in row)
        except Exception:
            return False
    def command(args, timeout):
        try:
            proc = subprocess.run(args, capture_output=True, stdin=subprocess.DEVNULL, timeout=timeout,
                                  creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
            return proc.returncode == 0
        except (OSError, subprocess.TimeoutExpired):
            return False
    def wheel_compatible(filename):
        if not isinstance(filename, str) or not filename.endswith('.whl') or pathlib.PureWindowsPath(filename).name != filename or '/' in filename:
            return False
        parts = filename[:-4].split('-')
        if len(parts) not in (5, 6):
            return False
        interpreters, abis, platforms = (tag.split('.') for tag in parts[-3:])
        if not any(item in ('any', 'win_amd64') for item in platforms):
            return False
        version = sys.version_info.major * 100 + sys.version_info.minor
        free_threaded = bool(sysconfig.get_config_var('Py_GIL_DISABLED'))
        current_tag = f'cp{sys.version_info.major}{sys.version_info.minor}'
        current_abi = current_tag + ('t' if free_threaded else '')
        for interpreter in interpreters:
            if interpreter in ('py3', f'py{sys.version_info.major}{sys.version_info.minor}') and 'none' in abis:
                return True
            if interpreter == current_tag and any(abi in (current_abi, 'none') for abi in abis):
                return True
            if not free_threaded and interpreter.startswith('cp3') and interpreter[3:].isdigit() and int(interpreter[2:]) <= version and 'abi3' in abis:
                return True
        return False
    def cache_valid(package, requirement=None):
        manifest = wheel_dir / (package + '.json')
        try:
            info = json.loads(manifest.read_text(encoding='utf-8'))
            if (info.get('package') != package or not info.get('requirement')
                    or info.get('python') != f'{sys.version_info.major}.{sys.version_info.minor}' or info.get('platform') != sys.platform
                    or info.get('architecture') != 'x64' or info.get('implementation') != sys.implementation.cache_tag
                    or info.get('source') != 'pypi_release_sha256'
                    or (requirement is not None and info.get('requirement') != requirement)):

                return []
            selected = []
            for entry in info.get('wheels', []):
                if not isinstance(entry, dict):
                    return []
                name = entry.get('filename', '')
                path = wheel_dir / name
                if not wheel_compatible(name) or path.name != name or not path.is_file() or not zipfile.is_zipfile(path):
                    return []
                with path.open('rb') as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                if digest != entry.get('sha256'):
                    return []
                selected.append(path)
            return selected
        except (OSError, ValueError, TypeError, json.JSONDecodeError):
            return []

    def select_requirement(package, minimum_version, maximum_major, fallback=None, distribution=None):
        distribution = distribution or package
        cached = cache_valid(package)
        if cached:
            try:
                saved = json.loads((wheel_dir / (package + '.json')).read_text(encoding='utf-8'))
                return saved['requirement']
            except (OSError, ValueError, KeyError, TypeError):
                pass
        url = 'https://pypi.org/pypi/' + urllib.parse.quote(distribution, safe='') + '/json'
        try:
            request = urllib.request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'OfflineGameAgent/1'})
            with urllib.request.urlopen(request, timeout=7.0) as response:
                raw = response.read(16_000_001)
            if len(raw) > 16_000_000:
                return fallback
            releases = json.loads(raw).get('releases', {})
            minimum = tuple(int(piece) for piece in minimum_version.split('.'))
            candidates = []
            for version, files in releases.items():
                parts = version.split('.')
                if not (2 <= len(parts) <= 4 and all(piece.isdecimal() for piece in parts)):
                    continue
                numbers = tuple(map(int, parts))
                if numbers < minimum or numbers[0] >= maximum_major:
                    continue
                if any(item.get('packagetype') == 'bdist_wheel' and wheel_compatible(item.get('filename'))
                       and not item.get('yanked', False) for item in files):
                    candidates.append((numbers, version))
            return f'{distribution}=={max(candidates)[1]}' if candidates else None
        except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
            return fallback
    def authoritative_hash(filename):
        parts = filename[:-4].split('-')
        if len(parts) not in (5, 6):
            return None
        distribution, version = parts[0].replace('_', '-'), parts[1]
        url = ('https://pypi.org/pypi/' + urllib.parse.quote(distribution, safe='') + '/'
               + urllib.parse.quote(version, safe='') + '/json')
        request = urllib.request.Request(url, headers={'Accept': 'application/json', 'User-Agent': 'OfflineGameAgent/1'})
        with urllib.request.urlopen(request, timeout=10.0) as response:
            payload = response.read(12_000_001)
            if len(payload) > 12_000_000:
                raise ValueError('软件仓库发布元数据超过安全大小')
        release = json.loads(payload)
        for item in release.get('urls', []):
            if item.get('filename') == filename and item.get('packagetype') == 'bdist_wheel':
                value = item.get('digests', {}).get('sha256', '')
                return value.lower() if isinstance(value, str) and len(value) == 64 else None
        return None

    def download(package, requirement, timeout):
        cached = cache_valid(package, requirement)
        if cached:
            return cached
        online = False
        try:
            with socket.create_connection(('pypi.org', 443), timeout=2.0):
                online = True
        except OSError:
            pass
        if not online:
            return []
        stage_dir = folder / ('_wheel_download_' + uuid.uuid4().hex)
        stage_dir.mkdir(parents=True, exist_ok=True)
        try:
            cmd = [sys.executable, '-m', 'pip', 'download', requirement, '--dest', str(stage_dir),
                   '--only-binary=:all:', '--disable-pip-version-check', '--no-cache-dir', '--no-input', '--retries', '1' if online else '0', '--timeout', '7', '-q']
            if not command(cmd, timeout):
                return []
            wheels = sorted(stage_dir.glob('*.whl'))
            if not wheels:
                return []
            wheel_dir.mkdir(parents=True, exist_ok=True)
            info = {'package': package, 'requirement': requirement, 'python': f'{sys.version_info.major}.{sys.version_info.minor}', 'platform': sys.platform, 'architecture': 'x64', 'implementation': sys.implementation.cache_tag, 'source': 'pypi_release_sha256', 'wheels': []}
            paths = []
            for wheel in wheels:
                if not wheel_compatible(wheel.name) or not zipfile.is_zipfile(wheel):
                    return []
                with wheel.open('rb') as stream:
                    digest = hashlib.file_digest(stream, 'sha256').hexdigest()
                try:
                    published = authoritative_hash(wheel.name)
                except (OSError, ValueError, TypeError, json.JSONDecodeError):
                    return []
                if published is None or published != digest:
                    return []
                destination = wheel_dir / wheel.name
                if destination.exists() and destination.is_file():
                    with destination.open('rb') as stream:
                        previous = hashlib.file_digest(stream, 'sha256').hexdigest()
                    if previous != digest:
                        return []
                else:
                    os.replace(wheel, destination)
                paths.append(destination)
                info['wheels'].append({'filename': destination.name, 'sha256': digest})
            name = wheel_dir / (package + '.json')
            temp = wheel_dir / (package + '.json.tmp')
            with temp.open('w', encoding='utf-8') as stream:
                json.dump(info, stream, ensure_ascii=False, separators=(',', ':'))
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp, name)
            return paths
        finally:
            shutil.rmtree(stage_dir, ignore_errors=True)
    def install(package, requirement, destination, timeout, check):
        wheels = download(package, requirement, timeout)
        if not wheels:
            return False
        stage = folder / ('_runtime_stage_' + uuid.uuid4().hex)
        backup = folder / ('_runtime_old_' + uuid.uuid4().hex)
        try:
            stage.mkdir(parents=True, exist_ok=False)
            verified_wheel_dir = stage / '_wheels'
            verified_wheel_dir.mkdir()
            for wheel in wheels:
                shutil.copy2(wheel, verified_wheel_dir / wheel.name)
            cmd = [sys.executable, '-m', 'pip', 'install', requirement, '--target', str(stage),
                   '--no-index', '--find-links', str(verified_wheel_dir), '--only-binary=:all:',
                   '--disable-pip-version-check', '--no-cache-dir', '--no-input', '-q']
            if not command(cmd, timeout):
                return False
            check_code = ('import sys;sys.path.insert(0,' + repr(str(stage)) + ');'
                          + 'import numpy as n;assert n.__version__;a=n.ones((2,2));assert (a@a).shape==(2,2)'
                          if check == 'numpy' else
                          'import sys;sys.path.insert(0,' + repr(str(runtime)) + ');sys.path.insert(0,' + repr(str(stage)) + ');'
                          + 'import cupy as c;assert c.cuda.runtime.getDeviceCount()>0;assert c.asnumpy(c.ones((2,2))@c.ones((2,2))).shape==(2,2)')
            if not command([sys.executable, '-I', '-c', check_code], min(35, timeout)):
                return False
            shutil.rmtree(verified_wheel_dir)
            if destination.exists():
                os.replace(destination, backup)
            try:
                os.replace(stage, destination)
            except BaseException:
                if backup.exists() and not destination.exists():
                    os.replace(backup, destination)
                raise
            importlib.invalidate_caches()
            if str(destination) not in sys.path:
                sys.path.insert(0, str(destination))
            return True
        except (OSError, ValueError, RuntimeError):
            return False
        finally:
            shutil.rmtree(stage, ignore_errors=True)
            if backup.exists():
                shutil.rmtree(backup, ignore_errors=True)
    cpu = None
    try:
        imported = importlib.import_module('numpy')
        if verified_cpu(imported):
            cpu = imported
    except Exception:
        pass
    if cpu is None:
        status('智能下载：检查 Python 兼容的 NumPy wheel 与校验锁文件')
        requirement = select_requirement('numpy', '2.5.0', 3, 'numpy==2.5.5')
        if requirement is not None and install('numpy', requirement, runtime, 150, 'numpy'):
            try:
                imported = importlib.import_module('numpy')
                if verified_cpu(imported):
                    cpu = imported
            except Exception:
                pass
    if cpu is not None:
        status('CPU 数值库就绪；离线训练与本机图像采集可用')
    gpu = gpu_backend()
    if gpu is None and cpu is not None and os.name == 'nt':
        try:
            ctypes.WinDLL('nvcuda.dll')
            status('检测 NVIDIA 数值加速 wheel 的 Python 与 CUDA 兼容性')
            requirement = select_requirement('cupy', '14.2.0', 15, distribution='cupy-cuda12x')
            if requirement is not None and install('cupy', requirement, gpu_runtime, 150, 'cupy'):
                gpu = gpu_backend()
            elif requirement is None:
                status('当前 Python ABI 暂无已确认兼容的 GPU wheel，继续使用 CPU 离线后端')
        except Exception:
            pass
    if gpu is not None and cpu is not None:
        def measure(module):
            sample = [[(i + j) % 11 / 11.0 for j in range(FEATURE_COUNT)] for i in range(24)]
            weights = module.ones((96, FEATURE_COUNT), dtype=module.float32) * module.float32(0.012)
            heads = module.ones((len(actions_for(27)), 96), dtype=module.float32) * module.float32(0.012)
            def batch():
                x = module.asarray(sample, dtype=module.float32)
                hidden = module.tanh(x @ weights.T)
                logits = hidden @ heads.T
                indices = module.argmax(logits, axis=1)
                result = module.sum(hidden * heads[indices], axis=1)
                hidden.T @ x
                if getattr(module, '__name__', '') == 'cupy':
                    module.asnumpy(result)
                else:
                    result.tolist()
            for _ in range(3):
                batch()
            start = time.perf_counter()
            for _ in range(8):
                batch()
            if getattr(module, '__name__', '') == 'cupy':
                module.cuda.Stream.null.synchronize()
            return max(1e-8, (time.perf_counter() - start) / 8)
        try:
            cpu_time = measure(cpu)
            gpu_time = measure(gpu)
            if gpu_time < cpu_time * 0.90:
                status('GPU 已通过实际运算基准，使用 GPU 加速；可断网使用')
                return gpu
            status('CPU 在当前决策与学习负载下更快，使用 CPU 数值加速；可断网使用')
            return cpu
        except Exception:
            status('GPU 基准测试不可用，使用稳定的 CPU 数值加速；可断网使用')
            return cpu
    if gpu is not None:
        status('GPU 数值加速组件已就绪；可断网使用')
        return gpu
    if cpu is not None:
        status('CPU 数值加速组件已就绪；可断网使用')
        return cpu
    status('纯 Python 和 Windows GDI 离线后备方案可用；数值训练性能可能偏低')
    return None


def profile_runtime(folder, module, capture_seconds=None, stop_vk=27):
    probe = Brain.__new__(Brain)
    probe.np = module
    try:
        probe.cv_np = importlib.import_module('numpy') if module is not None and getattr(module, '__name__', '') == 'cupy' else module
    except ImportError:
        probe.cv_np = None
    probe.hidden_size = MODEL_HIDDEN_SIZE
    count = len(actions_for(stop_vk))
    features = [((i * 17) % 39) / 39 for i in range(FEATURE_COUNT)]
    if module is not None:
        probe.encoder = module.ones((MODEL_HIDDEN_SIZE, FEATURE_COUNT), dtype=module.float32) * module.float32(0.002)
        probe.encoder_bias = module.zeros(MODEL_HIDDEN_SIZE, dtype=module.float32)
        head = module.ones((count, MODEL_HIDDEN_SIZE), dtype=module.float32) * module.float32(0.002)
    else:
        probe.encoder = [[0.002] * FEATURE_COUNT for _ in range(MODEL_HIDDEN_SIZE)]
        probe.encoder_bias = [0.0] * MODEL_HIDDEN_SIZE
        head = [[0.002] * MODEL_HIDDEN_SIZE for _ in range(count)]
    raw = bytes((80, 130, 195, 255)) * (W * H)
    timings = {}
    for name, work in (
        ('visual_features', lambda: probe.rgb_blocks(raw)),
        ('encoder', lambda: probe._encode(features)),
    ):
        work()
        started = time.perf_counter()
        for _ in range(3):
            work()
        if module is not None and getattr(module, '__name__', '') == 'cupy':
            module.cuda.Stream.null.synchronize()
        timings[name + '_milliseconds'] = round((time.perf_counter() - started) * 1000 / 3, 3)
    probe.games = {'benchmark': GameData(count, MODEL_HIDDEN_SIZE, module)}
    probe.game_key = 'benchmark'
    probe.lock = threading.RLock()
    probe.previous_lum = None
    probe.previous_motion = None
    probe.temporal_luma = deque(maxlen=4)
    probe.last_change = 0.0
    probe.last_frame = None
    probe.last_detail = [0.0] * 20
    probe.last_detail_focus = (0.5, 0.5)
    probe.last_detail_location = (0.5, 0.5)
    probe.last_detail_step = None
    probe.last_attention_tracks = []
    probe.visual_tracks = OrderedDict()
    probe.control_scores = OrderedDict()
    probe.next_track_id = 1
    probe.local_glyphs = LocalGlyphTemplates()
    probe.adaptive_glyphs = {}
    probe.glyph_votes = OrderedDict()
    probe.visual_active_base = None
    probe.visual_active_key = None
    probe.step = 0
    probe.low_information_observations = 0
    probe.invalid_observations = 0
    textured = bytearray(raw)
    for index in range(0, W * H, 13):
        pos = index * 4
        textured[pos:pos + 3] = bytes((48 + (index % 83), 112 + (index % 67), 175 + (index % 53)))
    textured = bytes(textured)
    first = probe.observe(textured, (0, 0, 1280, 720))
    if len(first.features) != FEATURE_COUNT or len(probe.last_detail) != 20:
        raise ArithmeticError('首次视觉特征结构与正常推理不一致')
    started = time.perf_counter()
    for _ in range(3):
        frame = probe.observe(textured, (0, 0, 1280, 720))
        if len(frame.features) != FEATURE_COUNT:
            raise ArithmeticError('性能测试产生了不兼容的视觉特征')
    timings['complete_visual_observation_milliseconds'] = round((time.perf_counter() - started) * 1000 / 3, 3)
    hidden = probe._encode(features)
    def decision():
        if module is not None:
            result = head @ hidden
            return float(module.max(result))
        return max(sum(a * b for a, b in zip(row, hidden)) for row in head)
    decision()
    started = time.perf_counter()
    for _ in range(3):
        value = decision()
    timings['action_head_milliseconds'] = round((time.perf_counter() - started) * 1000 / 3, 3)
    if not math.isfinite(value):
        raise ArithmeticError('运行基准产生了非有限决策结果')
    result = {'backend': 'pure_python' if module is None else getattr(module, '__name__', 'numeric'),
              'python': sys.version.split()[0], 'offline_inference': True, 'offline_training': True,
              'capture_test_milliseconds': capture_seconds, 'action_count': count, **timings}
    result['estimated_single_decision_milliseconds'] = round(timings['complete_visual_observation_milliseconds'] + timings['encoder_milliseconds'] + timings['action_head_milliseconds'], 3)
    destination = folder / 'runtime_profile.json'
    temporary = folder / 'runtime_profile.json.tmp'
    with temporary.open('w', encoding='utf-8') as file:
        json.dump(result, file, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        file.flush()
        os.fsync(file.fileno())
    os.replace(temporary, destination)
    return result

def verify_local_storage(folder, native):
    actual = pathlib.Path(folder).resolve()
    if os.name == 'nt':
        root = pathlib.PureWindowsPath(str(actual)).anchor
        disk_type = native.kernel.GetDriveTypeW(root)
        if disk_type in (0, 1, 4, 5):
            raise OSError('所选工作目录不在可确认离线使用的本地磁盘上，请选择本地文件夹')
    probe = actual / '_agent_offline_rw.tmp'
    try:
        with probe.open('wb') as stream:
            stream.write(os.urandom(48))
            stream.flush()
            os.fsync(stream.fileno())
        if probe.stat().st_size != 48 or len(probe.read_bytes()) != 48:
            raise OSError('离线数据目录没有通过本地读写验证')
    finally:
        probe.unlink(missing_ok=True)
    return True



def synthetic_control_pair(agent):
    positive = next(agent.action_index[name] for name in ('key:87', 'key:38') if name in agent.action_index)
    negative = next(agent.action_index[name] for name in ('key:83', 'key:40') if name in agent.action_index)
    assert positive != negative and agent.action_intents[positive] == 'move_up' and agent.action_intents[negative] == 'move_down'
    return positive, negative


def verify_precision_regressions(agent, observation):
    assert len(WORLD_IMPORTANCE) == WORLD_FEATURE_COUNT and WORLD_IMPORTANCE_SUM > WORLD_FEATURE_COUNT
    blank = [0.0] * WORLD_FEATURE_COUNT
    visual_error, semantic_error = blank[:], blank[:]
    visual_error[30], semantic_error[WORLD_VISUAL_COUNT + 1] = 0.5, 0.5
    assert Brain.world_error(blank, semantic_error) > Brain.world_error(blank, visual_error) > 0
    assert len(agent.world_state(observation)) == WORLD_FEATURE_COUNT
    for digit in ('1', '8'):
        numeric = bytearray(bytes((12, 12, 12, 255)) * (W * H))
        for row, pattern in enumerate(GLYPH_ROWS[digit]):
            for column, active in enumerate(pattern):
                if active == '1':
                    for dy in range(3):
                        for dx in range(3):
                            point = ((12 + row * 3 + dy) * W + 60 + column * 3 + dx) * 4
                            numeric[point:point + 4] = bytes((244, 244, 244, 255))
        recognized = agent.read_ui_symbols(bytes(numeric))
        assert any(item['text'] == digit and item['confidence'] >= 0.89 for item in recognized)
    hud = bytearray(bytes((11, 11, 11, 255)) * (W * H))
    for y in range(75, 90):
        for x in range(44, 164):
            point = (y * W + x) * 4
            hud[point:point + 4] = bytes((30, 205, 30, 255))
    meters = agent.detect_hud_meters(bytes(hud))
    assert any(key.startswith('middle') and 'green' in key for key in meters)
    for stop in (27, 87, 83, 38, 40, 16, 17, 18, 65, 37):
        examples = actions_for(stop)
        keys = {item.id: i for i, item in enumerate(examples)}
        assert any(key in keys for key in ('key:87', 'key:38'))
        assert any(key in keys for key in ('key:83', 'key:40'))
        for item in examples:
            if item.kind in ('key', 'hold', 'pair_hold', 'chord', 'move_fire', 'combat'):
                assert not item.a or not stop_equivalent(item.a, stop)
                if item.kind in ('pair_hold', 'chord'):
                    assert not stop_equivalent(item.b, stop)
    return True


def verify_behavioral_learning(agent, observation):
    trial = GameData(len(agent.actions), agent.hidden_size, agent.np)
    trial.passive_samples = 6
    trial.passive_change = 0.003
    useful_index, noop_index = synthetic_control_pair(agent)
    screen = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                         observation.edges, observation.features[:], observation.signature,
                         observation.change, observation.novelty, observation.rect, observation.raw,
                         observation.hud, 'synthetic', quality=observation.quality.copy())
    screen.scene_key = 'synthetic_screen'
    screen.scene_identity = 'synthetic_world'
    screen.phase = 'playing'
    sent = {'kind': 'key', 'input_sent': True, 'feedback_valid': True, 'spatial': False}
    for _ in range(18):
        reward, outcome, trust = agent.observe_action_effect(trial, screen, noop_index, sent,
                                                             0.02, 0.0, 0.0, 0.94, 0.93,
                                                             0.003, 0.003, 0.002, 3)
        assert reward >= 0 and outcome == 0.0 and trust >= 0.75
        reward, outcome, trust = agent.observe_action_effect(trial, screen, useful_index, sent,
                                                             0.85, 0.082, 0.88, 0.94, 0.93,
                                                             0.090, 0.003, 0.001, 3)
        assert reward >= 0 and outcome == 1.0 and trust >= 0.75
    useless_probability, useless_confidence, _ = agent.effect_prediction(trial, screen, noop_index)
    useful_probability, useful_confidence, _ = agent.effect_prediction(trial, screen, useful_index)
    assert useless_probability < 0.25 < useful_probability and useful_probability > 0.75
    assert useless_confidence > 0.35 and useful_confidence > 0.35
    predicted_null = agent.world_prediction(trial, noop_index, screen)
    assert predicted_null is not None and predicted_null[2] > 0 and not any(predicted_null[0])
    prior_samples = sum(int(values[2]) for values in trial.world_effects.values())
    assert agent.observe_action_effect(trial, screen, noop_index,
                                       {**sent, 'feedback_valid': False}, 0.0, 0.0, 0.0,
                                       0.9, 0.9, 0.0, 0.002, 0.0, 3)[1] is None
    assert sum(int(values[2]) for values in trial.world_effects.values()) == prior_samples
    context_before = agent.experiment_context(screen)
    signature_before = agent.state_signature(screen)
    screen.hud_meters = {'top:1:green': 0.8}
    screen.ui_numbers = [{'text': '78', 'x': 0.15, 'y': 0.05, 'confidence': 0.92}]
    assert agent.experiment_context(screen) == context_before
    assert agent.state_signature(screen) != signature_before
    screen.phase = 'menu'
    screen.ui_text = [{'text': 'START', 'x': 0.42, 'y': 0.60, 'confidence': 0.98,
                       'temporal_confidence': 0.97, 'bounds': [0.32, 0.53, 0.52, 0.67]}]
    interactions = agent.build_interaction_targets(screen)
    screen.interaction_targets = interactions
    assert interactions and interactions[0]['priority'] > 0.2
    assert agent.action_target_anchor(screen, 0.42, 0.60) is not None
    assert agent.action_target_anchor(screen, 0.01, 0.01) is None
    assert abs(interactions[0]['x'] - 0.42) < 0.01
    click = agent.actions[agent.action_index['click']]
    head = trial.ensure_parameter_head('click', agent.hidden_size)
    head['samples'] = 100
    head['b'][0] = 4.0
    head['b'][1] = -4.0
    head['b'][2] = 1.0
    for x, y in ((0.15, 0.20), (0.81, 0.75)):
        selected = agent.blend_action_parameters(trial, click, screen.features, (x, y, 0.15), screen)
        assert abs(selected[0] - x) < 1e-7 and abs(selected[1] - y) < 1e-7
    synthetic_detail = {'kind': 'key', 'input_sent': True, 'feedback_valid': True,
                        'learning_world_prediction_error': 0.18}
    example = ['synthetic', screen.features, noop_index, 0.01, screen.features[:],
               0.35, False, 1, 0.86, synthetic_detail]
    assert agent.surprise_transition(example)
    assert len(trial.export()['world_effects']) >= 4
    assert len(trial.export()['action_attempts']) == len(agent.actions)
    assert len(trial.export()['world_validation_samples']) == len(agent.actions)
    assert all(value == 0 for value in trial.world_validation_samples)
    isolated = Brain.__new__(Brain)
    isolated.actions = agent.actions
    isolated.games = {'synthetic': trial}
    isolated.game_key = 'synthetic'
    isolated.control_scores = OrderedDict()
    past = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                       observation.edges, observation.features[:], observation.signature, 0.0, 0.0,
                       observation.rect, observation.raw, observation.hud, 'synthetic',
                       quality={'trainable': True, 'confidence': 0.95})
    future = Observation(past.lum, past.rgb, past.salience, past.motion, past.edges,
                         past.features[:], past.signature, 0.0, 0.0,
                         past.rect, past.raw, past.hud, 'synthetic',
                         quality={'trainable': True, 'confidence': 0.95})
    past.objects = [{'track_id': track, 'age': 4, 'x': x, 'y': y, 'vx': 0.0, 'vy': 0.0,
                     'confidence': 0.85, 'color': (0.3, 0.3, 0.3), 'activity': 0.04,
                     'control_probability': 0.0} for track, x, y in ((1, 0.4, 0.5), (2, 0.7, 0.4), (3, 0.1, 0.8))]
    future.objects = [{**item, 'x': item['x'] + (0.05 if item['track_id'] == 1 else 0.0)}
                      for item in past.objects]
    estimations = [isolated.infer_controllability(past, future, useful_index, 0.9) for _ in range(8)]
    assert estimations[-1] > 0.25 and trial.control_profiles[agent.actions[useful_index].id][5] >= 5
    assert 0.03 < trial.control_profiles[agent.actions[useful_index].id][0] < 0.07
    return True


def verify_intelligence_regressions(agent, observation):
    assert Brain.binary_information_gain(1.0, 1.0) > Brain.binary_information_gain(50.0, 50.0) > 0.0
    trial = GameData(len(agent.actions), agent.hidden_size, agent.np)
    action, ineffective = synthetic_control_pair(agent)
    trial.action_effect[action], trial.action_effect_samples[action] = 0.8, 9
    assert trial.action_goal[action] == 0.0 and trial.action_goal_samples[action] == 0
    trial.action_goal[action], trial.action_goal_samples[action] = 0.27, 4
    exported = trial.export()
    assert exported['action_goal'][action] == 0.27 and exported['action_goal_samples'][action] == 4
    candidate = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                            observation.edges, observation.features[:], observation.signature,
                            observation.change, observation.novelty, observation.rect, observation.raw,
                            observation.hud, observation.game, quality=observation.quality.copy())
    candidate.ui_text = [{'text': text, 'x': x, 'y': 0.4, 'confidence': 0.98,
                          'temporal_confidence': 0.97} for text, x in (('VICTORY', 0.2), ('DEFEAT', 0.7))]
    _, evidence = agent.progress_evidence(observation, candidate, 0.95, 0.95, 0.95)
    assert evidence['conflicting_screen_outcomes']
    assert evidence['result_text_candidate'] in ('win_candidate', 'loss_candidate')
    base = observation.features[:]
    other = base[:]
    sample = ['synthetic', base, action, 0.08, other, 0.5, False, 1, 0.94,
              {'learning_goal_direction': False}]
    assert Brain.replay_signature(sample) == Brain.replay_signature(sample[:])
    assert Brain.replay_signature(sample[:3] + [float('nan')] + sample[4:]) is None
    assert Brain.replay_signature(sample[:2] + [ineffective] + sample[3:]) != Brain.replay_signature(sample)
    isolated = Brain.__new__(Brain)
    isolated.rng = random.Random(113)
    isolated.updates = 200
    isolated.game_key = 'synthetic'
    memory = []
    for i in range(20):
        state = base[:]
        later = base[:]
        state[1] = 0.10 + i * 0.12
        later[1] = 0.14 + i * 0.12
        memory.append(['synthetic', state, action, 0.02 + i * 0.001, later,
                       0.30 + i * 0.005, False, 1, 0.90, {}])
    isolated.memory = deque(memory * 3)
    isolated.rare_memory = deque(memory[-6:])
    isolated.control_memory = deque(memory[:8])
    isolated.failure_memory = deque(memory[5:14])
    isolated.surprise_memory = deque(memory[3:10])
    foreign = GameData(len(agent.actions), agent.hidden_size, agent.np)
    foreign.exemplars.append(['other', base[:], action, 0.15, base[:],
                              0.45, False, 1, 0.92, {}])
    isolated.games = {'synthetic': trial, 'other': foreign}
    replay, weights = isolated.sample_replay([sample, sample[:],
        ['synthetic', base, action, 0.07, other, 0.5, False, 1, 0.02, {}]], 32)
    signatures = [Brain.replay_signature(item) for item in replay]
    assert len(signatures) == len(set(signatures))
    assert any(item[0] == 'other' for item in replay)
    assert len(replay) >= 4 and all(float(item[8]) >= 0.15 for item in replay)
    assert len(weights) == len(replay) and all(0 < value <= 1 for value in weights.values())
    assert abs(temporal_discount(TIME_REFERENCE_SECONDS) - DISCOUNT) < 1e-10
    assert temporal_discount(TIME_REFERENCE_SECONDS * 2.0) < temporal_discount(TIME_REFERENCE_SECONDS * 0.5)
    timer = Brain.__new__(Brain)
    timer.pending_n = deque([
        ['synthetic', base[:], action, 1.0, base[:], 0.2, False, 1, 0.9,
         {'effective_elapsed_seconds': TIME_REFERENCE_SECONDS}],
        ['synthetic', base[:], action, 2.0, base[:], 0.2, False, 1, 0.9,
         {'effective_elapsed_seconds': 2.0 * TIME_REFERENCE_SECONDS}]])
    combined = timer._combine_pending(2)
    assert combined[7] == 2
    assert abs(combined[3] - (1.0 + DISCOUNT * 2.0)) < 1e-8
    assert abs(combined[9]['cumulative_elapsed_seconds'] - 3.0 * TIME_REFERENCE_SECONDS) < 1e-6
    assert abs(transition_elapsed_seconds(combined) - 3.0 * TIME_REFERENCE_SECONDS) < 1e-6
    assert Brain.replay_signature(timer.pending_n[0]) != Brain.replay_signature(
        timer.pending_n[0][:9] + [{'effective_elapsed_seconds': 1.2}])
    return True


def verify_synthetic_closed_loop(agent, observation):
    trial = GameData(len(agent.actions), agent.hidden_size, agent.np)
    trial.passive_samples = 6
    trial.passive_change = 0.003
    useful, ineffective = synthetic_control_pair(agent)
    view = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                       observation.edges, observation.features[:], observation.signature,
                       observation.change, observation.novelty, observation.rect, observation.raw,
                       observation.hud, 'synthetic', quality={'trainable': True, 'confidence': 0.98})
    view.scene_key = 'closed_loop_simulation'
    view.scene_identity = 'closed_loop_simulation'
    view.phase = 'playing'
    view.phase_confidence = 0.92
    view.state_uncertainty = 0.25
    view.hud_readouts = [0.0] * 48
    future = Observation(view.lum, view.rgb, view.salience, view.motion, view.edges,
                         view.features[:], view.signature, view.change, view.novelty,
                         view.rect, view.raw, view.hud, 'synthetic', quality=view.quality.copy())
    future.scene_key = view.scene_key
    future.phase = 'result'
    future.phase_confidence = 0.96
    future.hud_readouts = [0.0] * 48
    effect = {'input_sent': True, 'feedback_valid': True, 'kind': 'key', 'spatial': False}
    baseline = agent.experiment_scores(trial, view, 'discovery', {family: 0 for family in agent.action_families})
    for episode in range(12):
        view.scene_identity = 'closed_loop_win_' + str(episode)
        future.scene_identity = view.scene_identity
        reward, outcome, reliability = agent.observe_action_effect(
            trial, view, useful, effect, 0.82, 0.075, 0.84, 0.94, 0.90,
            0.086, 0.003, 0.002, 4)
        assert outcome == 1.0 and reliability > 0.7
        reward, outcome, reliability = agent.observe_action_effect(
            trial, view, ineffective, effect, 0.025, 0.0, 0.0, 0.94, 0.90,
            0.003, 0.005, 0.002, 4)
        assert outcome == 0.0 and reliability > 0.7
        for index, success in ((useful, True), (ineffective, False)):
            result = agent.reward_info
            try:
                agent.reward_info = {'input_was_sent': True, 'feedback_samples': 4,
                                     'observation_confidence': 0.94, 'scene_stability': 0.90,
                                     'causal_confidence': 0.82 if success else 0.025,
                                     'estimated_action_effect': 0.075 if success else 0.0,
                                     'persistent_visual_change': 0.84 if success else 0.0,
                                     'action_effect_observation': 1.0 if success else 0.0,
                                     'action_effect_observation_confidence': 0.87,
                                     'objective_evidence_confidence': 0.0}
                agent.update_action_applicability(trial, view, index, 0.05 if success else -0.03)
            finally:
                agent.reward_info = result
        event = {'numeric_readout_changes': [{'x': 0.25, 'y': 0.12, 'delta': 2}],
                 'meter_changes': []}
        agent.objective_signal(trial, view, future, 0.95, 0.94, 0.94, event, 'win')
        trial.game_steps += 1
    changed = agent.experiment_scores(trial, view, 'discovery', {family: 0 for family in agent.action_families})
    assert changed[useful] > changed[ineffective]
    assert changed[useful] - changed[ineffective] > baseline[useful] - baseline[ineffective]
    positive = {'numeric_readout_changes': [{'x': 0.25, 'y': 0.12, 'delta': 2}], 'meter_changes': []}
    negative = {'numeric_readout_changes': [{'x': 0.25, 'y': 0.12, 'delta': -2}], 'meter_changes': []}
    for episode in range(6):
        view.scene_identity = 'closed_loop_loss_' + str(episode)
        future.scene_identity = view.scene_identity
        agent.objective_signal(trial, view, future, 0.95, 0.94, 0.94, negative, 'loss')
    good, evidence = agent.objective_signal(trial, view, future, 0.95, 0.94, 0.94, positive, None)
    bad, _ = agent.objective_signal(trial, view, future, 0.95, 0.94, 0.94, negative, None)
    assert good > 0.0 > bad and len(trial.goal_hypotheses) >= 1
    assert trial.export()['goal_hypotheses']
    for _ in range(8):
        agent.record_world_event(trial, view, useful, future, 'win', 0.88)
        agent.record_world_event(trial, view, ineffective, future, 'loss', 0.88)
    forecast_good, conf_good = agent.predict_world_event(trial, view, useful)
    forecast_bad, conf_bad = agent.predict_world_event(trial, view, ineffective)
    assert forecast_good > 0.0 > forecast_bad and conf_good > 0.0 and conf_bad > 0.0
    state = view.features[:]
    other = state[:]
    other[SEMANTIC_START + 58] = max(-1.0, min(1.0, other[SEMANTIC_START + 58] + 0.25))
    first = ['synthetic', state, useful, 0.12, state[:], 0.4, False, 1, 0.98, {'learning_effect_observation': 1.0}]
    second = ['synthetic', other, useful, 0.12, other[:], 0.4, False, 1, 0.98, {'learning_effect_observation': 1.0}]
    assert agent.replay_signature(first) != agent.replay_signature(second)
    assert agent.replay_signature(first[:7] + [2] + first[8:]) != agent.replay_signature(first)
    assert agent.world_event_key(view, useful) != agent.world_event_key(view, ineffective)
    return True


def verify_generalization_regressions(agent, observation):
    assert DUAL_VALUE_FEATURES == 32 and len(WORLD_SEMANTIC_SLOTS) == 32
    assert set((56, 57, 58, 59)).issubset(WORLD_SEMANTIC_SLOTS)
    assert len(agent.world_state(observation)) == WORLD_FEATURE_COUNT
    stable = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                         observation.edges, observation.features[:], 'synthetic_frame_jitter',
                         observation.change, observation.novelty, observation.rect, observation.raw,
                         observation.hud, observation.game, quality=observation.quality.copy())
    stable.scene_key = getattr(observation, 'scene_key', None)
    stable.scene_identity = getattr(observation, 'scene_identity', None)
    stable.phase = observation.phase
    stable.phase_confidence = observation.phase_confidence
    baseline = agent.state_signature(stable)
    stable.signature = 'another_synthetic_frame_jitter'
    assert agent.state_signature(stable) == baseline
    stable.hud_meters = {'top:1:green': 0.19}
    state_one = agent.state_signature(stable)
    stable.hud_meters['top:1:green'] = 0.89
    assert agent.state_signature(stable) != state_one
    def relative_objects(x, y, shift_x=0.0, shift_y=0.0):
        return [{'track_id': 1, 'age': 5, 'x': 0.25 + shift_x, 'y': 0.30 + shift_y,
                 'vx': 0.01, 'vy': 0.0, 'control_probability': 0.95, 'confidence': 0.96},
                {'track_id': 2, 'age': 4, 'x': x + shift_x, 'y': y + shift_y,
                 'vx': -0.01, 'vy': 0.0, 'control_probability': 0.03, 'confidence': 0.92}]
    stable.objects = relative_objects(0.55, 0.45)
    relation = agent.skill_relation_summary(stable)
    stable.objects = relative_objects(0.55, 0.45, 0.08, 0.04)
    shifted = agent.skill_relation_summary(stable)
    assert len(relation) == 12 and max(abs(a - b) for a, b in zip(relation, shifted)) < 1e-7
    stable.objects = relative_objects(0.79, 0.45)
    altered = agent.skill_relation_summary(stable)
    assert agent.skill_relation_gap(relation, altered) > 0.01
    action_good, action_bad = synthetic_control_pair(agent)
    trial = GameData(len(agent.actions), agent.hidden_size, agent.np)
    alternate = GameData(len(agent.actions), agent.hidden_size, agent.np)
    original = [float(value) for value in observation.features]
    for step in range(30):
        jittered = original[:]
        jittered[1] = max(-1.0, min(1.0, jittered[1] + (step % 5 - 2) * 0.005))
        jittered[SEMANTIC_START + 56] = -0.17 + step % 4 * 0.01
        assert agent.update_dual_values(trial, jittered, action_good, effect=1.0,
                                        control_confidence=0.95, objective=0.8,
                                        objective_confidence=0.93)
        assert agent.update_dual_values(trial, jittered, action_bad, effect=-1.0,
                                        control_confidence=0.95, objective=-0.8,
                                        objective_confidence=0.93)
    unseen = original[:]
    unseen[1] = max(-1.0, min(1.0, unseen[1] + 0.003))
    unseen[SEMANTIC_START + 56] = -0.165
    predicted = agent.dual_value_scores(trial, Observation(
        observation.lum, observation.rgb, observation.salience, observation.motion,
        observation.edges, unseen, observation.signature, observation.change, observation.novelty,
        observation.rect, observation.raw, observation.hud, observation.game,
        quality=observation.quality.copy()))
    assert predicted[action_good] > predicted[action_bad] + 0.12
    assert trial.control_head_samples[action_good] == 30
    assert trial.objective_head_samples[action_bad] == 30
    assert sum(alternate.control_head_samples) == 0 and sum(alternate.objective_head_samples) == 0
    assert len(trial.export()['control_head']) == len(agent.actions)
    assert len(trial.export()['objective_head']) == len(agent.actions)
    before_posterior = trial.control_posteriors[action_good][:]
    prior_signal = agent.reward_info
    try:
        agent.reward_info = {'input_was_sent': True, 'feedback_samples': 4,
                             'observation_confidence': 0.93, 'scene_stability': 0.94,
                             'action_effect_observation': None, 'causal_confidence': 0.0,
                             'objective_evidence_confidence': 0.0, 'goal_direction_evidence': False}
        agent.update_action_applicability(trial, observation, action_good, 0.0)
        assert trial.control_posteriors[action_good] == before_posterior
    finally:
        agent.reward_info = prior_signal
    unknown = ['synthetic', original, action_good, 0.15, original[:], 0.3,
               False, 1, 0.95, {'input_sent': True, 'feedback_valid': True,
                               'learning_effect_observation': None,
                               'learning_effect_confidence': 0.0,
                               'learning_goal_direction': False,
                               'learning_goal_confidence': 0.0}]
    assert agent.replay_quality(unknown) == 0.0
    proved = unknown[:]
    proved[-1] = {**unknown[-1], 'learning_effect_observation': 1.0,
                   'learning_effect_confidence': 0.88}
    assert agent.replay_quality(proved) > 0.7
    invalid = proved[:]
    invalid[-1] = {**proved[-1], 'feedback_valid': False}
    assert agent.replay_quality(invalid) == 0.0
    event_before = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                               observation.edges, original[:], observation.signature,
                               observation.change, observation.novelty, observation.rect,
                               observation.raw, observation.hud, 'synthetic',
                               quality=observation.quality.copy())
    event_before.scene_key = 'synthetic_event_world'
    event_before.phase = 'playing'
    event_before.phase_confidence = 0.92
    event_before.hud_meters = {'top:1:green': 0.28}
    event_after = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                              observation.edges, original[:], observation.signature,
                              observation.change, observation.novelty, observation.rect,
                              observation.raw, observation.hud, 'synthetic',
                              quality=observation.quality.copy())
    event_after.scene_key = 'synthetic_event_world'
    event_after.phase = 'result'
    event_after.phase_confidence = 0.94
    event_after.hud_meters = {'top:1:green': 0.81}
    for _ in range(9):
        agent.record_world_event(trial, event_before, action_good, event_after, 'win', 0.92)
    event_score, event_confidence = agent.event_forecast(trial, event_before, action_good)
    assert event_score > 0.05 and event_confidence > 0.0
    assert trial.diagnostics['event_transition_samples'] >= 9
    signed, trust = agent.predict_world_event(trial, event_before, action_good)
    assert signed > 0.0 and trust > 0.0
    unchanged_regions = agent.regional_rgb_motion(observation.rgb, observation.rgb)
    assert len(unchanged_regions) == 12 and max(unchanged_regions) == 0.0
    changed_rgb = list(observation.rgb)
    changed_rgb[0] = tuple(255 - max(0, min(255, int(value))) for value in changed_rgb[0])
    assert agent.regional_rgb_motion(observation.rgb, changed_rgb)[0] > 0.0
    trial.passive_motion_profiles['probe'] = [[0.025] * 12, 3]
    assert trial.export()['passive_motion_profiles'][-1][0] == 'probe'
    alternate.merge(trial)
    assert alternate.passive_motion_profiles['probe'][1] == 3
    move_up_alternative = next((agent.action_index[key] for key in ('key:38', 'key:87', 'hold:38', 'hold:87')
                                if key in agent.action_index and agent.action_index[key] != action_good), None)
    if move_up_alternative is not None:
        assert agent.action_intents[action_good] == agent.action_intents[move_up_alternative]
        assert agent.action_intents[action_good] != agent.action_intents[action_bad]
        test_game = GameData(len(agent.actions), agent.hidden_size, agent.np)
        test_game.control_posteriors[action_good] = [1.0, 9.0]
        test_game.control_posteriors[move_up_alternative] = [9.0, 1.0]
        assert agent.remap_skill_intent(test_game, observation, action_good) == move_up_alternative
        assert test_game.diagnostics['skill_intent_remaps'] >= 1
    return True


def verify_learning_upgrades(agent, observation):
    assert long_goal_discount(12.0) > temporal_discount(12.0) * 10.0
    assert long_goal_discount(TIME_REFERENCE_SECONDS) == LONG_GOAL_DISCOUNT
    game = GameData(len(agent.actions), agent.hidden_size, agent.np)
    view = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                       observation.edges, observation.features[:], observation.signature,
                       observation.change, observation.novelty, observation.rect, observation.raw,
                       observation.hud, 'synthetic', quality={'trainable': True, 'confidence': 0.96})
    view.scene_key = 'upgraded_control_test'
    view.scene_identity = 'upgraded_control_test'
    view.phase = 'playing'
    view.phase_confidence = 0.94
    view.objects = [{'track_id': 1, 'age': 7, 'x': 0.24, 'y': 0.38, 'vx': 0.01, 'vy': 0.0,
                     'confidence': 0.94, 'control_probability': 0.92},
                    {'track_id': 2, 'age': 7, 'x': 0.38, 'y': 0.43, 'vx': 0.0, 'vy': 0.01,
                     'confidence': 0.91, 'control_probability': 0.05}]
    original_state = agent.state_signature(view)
    original_context = agent.experiment_context(view)
    view.hud_meters = {'top:1:green': 0.83}
    assert original_state != agent.state_signature(view)
    assert original_context == agent.experiment_context(view)
    view.objects[1]['x'] = 0.91
    assert original_context != agent.experiment_context(view)
    view.objects[1]['x'] = 0.38
    good = agent.action_index['click']
    bad = synthetic_control_pair(agent)[0]
    stored_feedback = agent.reward_info
    try:
        for index, success in ((good, True), (bad, False)):
            agent.reward_info = {'input_was_sent': True, 'feedback_samples': 4,
                                 'observation_confidence': 0.96, 'scene_stability': 0.92,
                                 'causal_confidence': 0.88 if success else 0.02,
                                 'action_effect_observation': float(success),
                                 'action_effect_observation_confidence': 0.91,
                                 'goal_direction_evidence': False, 'objective_evidence_confidence': 0.0}
            for _ in range(16):
                agent.update_action_applicability(game, view, index, 0.04 if success else -0.04)
    finally:
        agent.reward_info = stored_feedback
    positive, positive_trust = agent.hierarchical_control_prediction(game, view, good)
    negative, negative_trust = agent.hierarchical_control_prediction(game, view, bad)
    assert positive > 0.60 and negative < 0.40 and positive_trust > 0.3 and negative_trust > 0.3
    assert game.diagnostics['hierarchical_effect_updates'] == 32
    sent = {'input_sent': True, 'feedback_valid': True, 'kind': 'click'}
    for _ in range(7):
        _, outcome, confidence = agent.observe_action_effect(game, view, good, sent,
            0.86, 0.08, 0.90, 0.96, 0.91, 0.08, 0.003, 0.001, 4)
        assert outcome == 1.0 and confidence > 0.7
    repeat = game.repeat_effects[agent.experiment_context(view) + ':' + agent.actions[good].id]
    assert repeat[3] == 7 and repeat[0] > 4.0
    assert game.diagnostics['repeatable_effects'] >= 3
    base = [0.0] * FEATURE_COUNT
    moves = base[:]
    moves[1] = 0.14
    clicks = base[:]
    clicks[25] = -0.19
    for _ in range(12):
        assert agent.learn_inverse_dynamics(game, base, moves, bad, 0.90) is not None
        assert agent.learn_inverse_dynamics(game, base, clicks, good, 0.90) is not None
    assert game.inverse_dynamics['move_up'][0] == 12
    assert game.inverse_dynamics['primary_select'][0] == 12
    assert agent.inverse_intent_confidence(game, good) > 0.0
    assert game.diagnostics['inverse_dynamics_updates'] == 24
    scene_key = agent.world_condition_keys(good, view, {'requested_duration': 0.14})[0]
    game.world_condition_errors[scene_key] = [32, 0.27, 0.003]
    proposal = ([0.01] * WORLD_FEATURE_COUNT, 0.1, 0.75, 0.03)
    reduced = agent.calibrated_world_prediction(game, good, proposal, view, {'requested_duration': 0.14})
    assert reduced[2] < proposal[2] and reduced[3] > proposal[3]
    bogus = ['synthetic', base, good, 0.12, moves, 0.4, False, 1, 0.93,
             {'input_sent': True, 'learning_effect_observation': None,
              'learning_effect_confidence': 0.0, 'learning_goal_confidence': 0.0}]
    assert agent.replay_quality(bogus) == 0.0
    quiet_after = base[:]
    quiet_after[1] = 0.012
    quiet_pair = ['synthetic', base[:], good, 0.0, quiet_after, 0.0, False, 1, 0.93,
                  {'input_sent': True, 'learning_effect_observation': 0.0,
                   'learning_effect_confidence': 0.91, 'learning_goal_direction': False}]
    assert agent.stable_temporal_pair(quiet_pair)
    quiet_snapshot = agent._training_snapshot([])
    assert agent._train_temporal_snapshot(quiet_pair, quiet_snapshot)
    assert not agent.stable_temporal_pair(bogus)
    uncertain_pair = quiet_pair[:]
    uncertain_pair[-1] = {'input_sent': True, 'learning_effect_observation': 0.0,
                          'learning_effect_confidence': 0.05}
    assert not agent.stable_temporal_pair(uncertain_pair)
    credited = bogus[:]
    credited[-1] = {'input_sent': True, 'outcome_credit': 'win', 'credit_confidence': 0.22}
    assert 0.35 < agent.replay_quality(credited) < 0.60
    dummy = object.__new__(Brain)
    dummy.game_key = 'synthetic'
    dummy.games = {'synthetic': game}
    dummy.outcome_trace = deque(maxlen=LONG_GOAL_HORIZON)
    dummy.terminal_credit_samples = 0
    dummy.reward_info = {}
    retained = []
    dummy.enqueue_training = lambda item: retained.append(item)
    dummy._append_persist = lambda item, change=0.0: None
    for i in range(45):
        dummy.outcome_trace.append(['synthetic', base[:], good, 0.02, moves[:],
                                   0.10, False, 1, 0.90,
                                   {'input_sent': True, 'feedback_valid': True,
                                    'effective_elapsed_seconds': TIME_REFERENCE_SECONDS}])
    count = dummy.credit_long_outcome(view, 0.90, 0.90, 'win', 0.02)
    assert count > 30 and len(retained) == count and dummy.terminal_credit_samples == count
    assert min(item[7] for item in retained) == 2 and max(item[7] for item in retained) > 20
    assert all(item[3] > 0.0 and item[9]['outcome_credit'] == 'win' for item in retained)
    assert game.diagnostics['long_horizon_credits'] == count
    merged = GameData(len(agent.actions), agent.hidden_size, agent.np)
    merged.merge(game)
    assert merged.hierarchical_controls and merged.repeat_effects and merged.inverse_dynamics
    assert merged.world_condition_errors
    saved = game.export()
    for field in ('hierarchical_controls', 'repeat_effects', 'inverse_dynamics', 'world_condition_errors'):
        assert saved[field]
    return True


def verify_adaptive_intelligence(agent, observation):
    a = synthetic_control_pair(agent)[0]
    game = GameData(len(agent.actions), agent.hidden_size, agent.np)
    view = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                       observation.edges, observation.features[:], observation.signature,
                       observation.change, observation.novelty, observation.rect, observation.raw,
                       observation.hud, 'synthetic', quality={'trainable': True, 'confidence': 0.95})
    view.phase = 'playing'
    view.phase_confidence = 0.92
    assert agent.exploration_stage(game, view)[0] == 'discovery'
    context = agent.experiment_context(view)
    for action_id in (agent.actions[a].id, 'click', 'swipe:-1:0'):
        index = agent.action_index[action_id]
        game.control_posteriors[index] = [22.0, 1.0]
        game.action_applicability[context + ':' + str(index)] = [25, 0.9, 0.1, 0.02]
    assert agent.exploration_stage(game, view)[0] == 'policy'
    previous = {'track_id': 1, 'age': 6, 'x': 0.2, 'y': 0.5,
                'confidence': 0.95, 'control_probability': 0.9}
    target = {'track_id': 2, 'age': 6, 'x': 0.7, 'y': 0.5,
              'confidence': 0.94, 'control_probability': 0.02}
    view.objects = [previous, target]
    after = Observation(view.lum, view.rgb, view.salience, view.motion, view.edges,
                        view.features[:], view.signature, view.change, view.novelty,
                        view.rect, view.raw, view.hud, view.game, quality=view.quality.copy())
    after.objects = [{**previous, 'x': 0.4}, target.copy()]
    assert any(event['kind'] == 'approaching' for event in agent.relation_events(view, after))
    game.goal_hypotheses['meter:score'] = [22.0, 1.0, 1.0, 18.0]
    game.goal_hypotheses['meter:health'] = [1.0, 18.0, 22.0, 1.0]
    good, _ = agent.objective_signal(game, view, after, 0.95, 0.94, 0.92,
                                     {'meter_changes': [{'region': 'score', 'relative_delta': 0.4},
                                                        {'region': 'health', 'relative_delta': -0.4}]})
    assert good > 0.0 and game.goal_signal_conflict < 0.05
    mixed, _ = agent.objective_signal(game, view, after, 0.95, 0.94, 0.92,
                                      {'meter_changes': [{'region': 'score', 'relative_delta': 0.4},
                                                         {'region': 'health', 'relative_delta': 0.4}]})
    assert abs(mixed) < good and game.goal_signal_conflict > 0.30
    source = GameData(len(agent.actions), agent.hidden_size, agent.np)
    source.game_steps = 50
    source.control_posteriors[a] = [24.0, 2.0]
    local_games = agent.games
    try:
        agent.games = {'source': source, 'target': game}
        assert agent.transfer_intent_evidence(game, a) == 0.0
        game.control_posteriors[a] = [1.0, 1.0]
        assert agent.transfer_intent_evidence(game, a) > 0.0
        game.control_posteriors[a] = [1.0, 15.0]
        assert agent.transfer_intent_evidence(game, a) == 0.0
    finally:
        agent.games = local_games
    for stop in (27, 16, 17, 18, 65, 160, 161, 162, 163, 164, 165):
        for action in actions_for(stop):
            if action.kind in ('key', 'hold', 'pair_hold', 'chord', 'move_fire', 'combat'):
                assert not stop_equivalent(action.a, stop) or not action.a
                if action.kind in ('pair_hold', 'chord'):
                    assert not stop_equivalent(action.b, stop)
    return True



def verify_upgraded_components(agent, observation):
    isolated = GameData(len(agent.actions), agent.hidden_size, agent.np)
    guidance = agent.discovery_guidance(isolated, observation, 'discovery', {name: 0 for name in agent.action_families})
    assert len(guidance) == len(agent.actions) and all(math.isfinite(value) for value in guidance)
    click = agent.action_index['click']
    compound = next((i for i, item in enumerate(agent.actions) if item.kind in ('chord', 'pair_hold')), None)
    if compound is not None:
        assert guidance[click] > guidance[compound]
    isolated.world_parameters[str(click)] = {'count': 12, 'start_x': 0.80, 'start_y': 0.75,
                                              'duration': 0.25, 'extent': 1.05}
    parameters = agent.preview_action_parameters(isolated, click, observation)
    assert len(parameters) == 6 and parameters[5] == 'world_plan'
    assert all(math.isfinite(float(value)) for value in parameters[:5])
    prepared = agent.parameter_dictionary(parameters, agent.actions[click], isolated.stagnation)
    assert prepared['spatial'] and abs(prepared['start_x'] - parameters[0]) < 1e-8
    assert abs(prepared['requested_duration'] - parameters[2]) < 1e-8
    first = agent.parameter_dictionary((0.85, 0.77, 0.22, 1.0, 0.85, 'world_plan'), agent.actions[click])
    second = dict(first, spatial=False)
    assert agent._world_key(click, observation, first) != agent._world_key(click, observation, second)
    moved = dict(first, start_x=0.15, start_y=0.12)
    assert agent.world_input(observation, click, first) != agent.world_input(observation, click, moved)
    assert agent._world_key(click, observation, dict(first, duration=0.81)) == agent._world_key(click, observation, first)
    swipe = next((i for i, action in enumerate(agent.actions) if action.kind == 'swipe'), None)
    if swipe is not None:
        swipe_parameters = (0.5, 0.5, 0.25, 1.0, 0.25, 'world_plan')
        mapped = agent.parameter_dictionary(swipe_parameters, agent.actions[swipe], 0)
        assert mapped['spatial']
        assert abs(mapped['start_x'] - max(0.0, min(1.0, 0.5 - agent.actions[swipe].a * 0.125))) < 1e-8
        assert abs(mapped['start_y'] - max(0.0, min(1.0, 0.5 - agent.actions[swipe].b * 0.125))) < 1e-8
    isolated.duration_stats['click:0:0:corrupted'] = ['invalid', 'invalid']
    assert len(agent.preview_action_parameters(isolated, click, observation)) == 6
    original_model = agent.world_prediction
    original_scores = agent.scores
    original_steps = agent.game.world_network_steps
    prior_planned = agent.last_plan_parameters
    plan_calls = []
    try:
        agent.game.world_network_steps = max(28, original_steps)
        agent.scores = lambda seen: [1.0 if i == click else -0.5 for i in range(len(agent.actions))]
        def mock_world(game, index, seen, executed=None):
            if index != click:
                return None
            assert isinstance(executed, dict) and executed['spatial']
            plan_calls.append(executed)
            return [0.002] * WORLD_FEATURE_COUNT, 0.12, 0.82, 0.04
        agent.world_prediction = mock_world
        plan, predictions = agent.plan_with_world_model(observation)
        assert len(plan) >= 2 and len(plan) == len(predictions) == len(agent.last_plan_parameters)
        assert all(index == click for index in plan)
        assert len(plan_calls) >= len(plan)
        assert all(item[5] == 'world_plan' for item in agent.last_plan_parameters)
        assert all(math.isfinite(value) for prediction in predictions for value in prediction)
    finally:
        agent.world_prediction = original_model
        agent.scores = original_scores
        agent.game.world_network_steps = original_steps
        agent.last_plan_parameters = prior_planned
    assert len(agent.temporal_observations) <= 5
    return True

def verify_autonomous_learning_fixes(agent, observation):
    assert canonical_game_key('browser~g3') == 'browser~g3'
    assert canonical_game_key('browser~g3') != canonical_game_key('browser')
    candidate = GameData(len(agent.actions), agent.hidden_size, agent.np)
    up, down = synthetic_control_pair(agent)
    peer = agent.action_index.get('key:38', up)
    if peer == up:
        peer = agent.action_index['key:87']
    view = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                       observation.edges, observation.features[:], observation.signature,
                       observation.change, observation.novelty, observation.rect, observation.raw,
                       observation.hud, 'test', quality={'confidence': 0.98, 'trainable': True})
    view.scene_key = 'intent_test'
    view.phase = 'playing'
    view.phase_confidence = 0.93
    for _ in range(12):
        assert agent.update_intent_values(candidate, view, up, effect=1.0,
                                          effect_confidence=0.91, objective=0.70, objective_confidence=0.79)
    context = agent.experiment_context(view)
    assert agent.intent_value(candidate, context, peer) > agent.intent_value(candidate, context, down)
    assert candidate.export()['intent_values']
    zero = [0.0] * FEATURE_COUNT
    changed = zero[:]
    changed[DUAL_VALUE_INDICES[0]] = 0.9
    candidate.control_head[up][0] = 1.0
    candidate.control_head_samples[up] = 12
    values = agent._values(zero, candidate)
    values = values.tolist() if agent.np is not None else values
    root_dual = agent.dual_value_scores(candidate, zero)
    root_scores = [float(a) + float(b) for a, b in zip(values, root_dual)]
    future_scores = agent.predicted_state_scores(candidate, changed, root_scores, values, root_dual, view)
    assert future_scores[up] > root_scores[up] + 0.025
    assert candidate.diagnostics['predictive_state_evaluations'] == 1
    view.features = zero[:]
    view.features[SEMANTIC_START + 24] = 0.5
    view.features[SEMANTIC_START + 25] = 0.5
    future = view.features[:]
    future[SEMANTIC_START + 24] = 0.63
    future[SEMANTIC_START + 25] = 0.65
    click = agent.action_index['click']
    old_parameters = agent.preview_action_parameters(candidate, click, view)
    future_parameters = agent.preview_action_parameters(candidate, click, view, future)
    assert future_parameters[0] > old_parameters[0] + 0.08
    assert future_parameters[1] > old_parameters[1] + 0.08
    candidate.goal_value_bias = 0.2
    candidate.goal_value_samples = 9
    short, _, _ = agent.update_goal_value(candidate, zero, zero, None, 0.08)
    longer, _, _ = agent.update_goal_value(candidate, zero, zero, None, 1.2)
    assert longer < short < 0.0
    event = {'relation_events': [{'kind': 'contact', 'confidence': 0.96, 'magnitude': 0.95}],
             'meter_changes': [], 'numeric_readout_changes': []}
    view.phase = 'playing'
    view.novelty = 0.7
    bonuses = []
    for i in range(5):
        view.scene_key = 'independent_case_' + str(i)
        gain, details = agent.discover_goal_candidates(candidate, view, view, event, 0.96, 0.93, 0.91, 0)
        bonuses.append(gain)
    assert max(bonuses) > 0.0
    assert candidate.goal_proposals['relation:contact'][1] >= 3
    assert not candidate.goal_hypotheses
    for i in range(5):
        view.scene_identity = 'independent_win_' + str(i)
        score, _ = agent.objective_signal(candidate, view, view, 0.96, 0.93, 0.91, event, 'win')
    evidence = candidate.goal_hypotheses['relation:contact'][0]
    score, _ = agent.objective_signal(candidate, view, view, 0.96, 0.93, 0.91, event, 'win')
    assert candidate.goal_hypotheses['relation:contact'][0] == evidence
    assert candidate.diagnostics['objective_duplicate_confirmations'] >= 1
    assert 'relation:contact' in candidate.goal_hypotheses
    score, _ = agent.objective_signal(candidate, view, view, 0.96, 0.93, 0.91, event, None)
    assert score > 0.0
    candidate_goal = candidate.export()['goal_proposals']
    assert candidate_goal and candidate_goal[0][1][4] > 0
    probe = Brain.__new__(Brain)
    probe.lock = threading.RLock()
    probe.games = {'desktop': candidate}
    probe.game_key = 'desktop'
    probe.visual_routes = {}
    probe.visual_active_base = None
    probe.visual_active_key = None
    probe.visual_candidate = None
    probe.visual_candidate_vector = None
    probe.visual_candidate_count = 0
    probe.visual_candidate_diversity = 0
    probe.dirty_sequence = 0
    probe.rgb_blocks = lambda shade: [(shade, shade, shade)] * (GW * GH)
    candidate.game_steps = 100
    assert probe.identify_game('browser', 20) == 'browser'
    profiles = []
    for i in range(52):
        profiles.append(probe.identify_game('browser', 200 if i % 2 else 220))
    assert 'browser~g1' in profiles
    assert canonical_game_key(profiles[-1]) == 'browser~g1'
    assert candidate.diagnostics['game_profile_switches'] >= 1
    for i in range(12):
        recovered = probe.identify_game('browser', 20)
    assert recovered == 'browser'
    assert 'goal_proposals' in candidate.export() and 'intent_values' in candidate.export()
    merged = GameData(len(agent.actions), agent.hidden_size, agent.np)
    merged.merge(candidate)
    assert merged.intent_values and merged.goal_proposals
    return True


def verify_intelligence_extension(agent, observation):
    isolated = GameData(len(agent.actions), agent.hidden_size, agent.np)
    control = agent.action_index['click']
    increments = [0.035] * WORLD_FEATURE_COUNT
    for _ in range(9):
        assert agent.learn_passive_world(isolated, observation, increments)
    natural_delta, natural_trust, natural_error = agent.passive_world_prediction(isolated, observation)
    assert 0.0 < natural_trust < 1.0 and natural_error >= 0.0
    assert all(abs(value - 0.035) < 1e-6 for value in natural_delta)
    for key in agent.effect_keys(observation, control):
        isolated.world_effects[key] = [1.0, 60.0, 60]
    fallback = agent.world_prediction(isolated, control, observation)
    assert fallback is not None and 0.0 < fallback[0][0] <= 0.0350001
    assert math.isfinite(fallback[2]) and math.isfinite(fallback[3])
    event = {'meter_changes': [{'region': 'synthetic_score', 'relative_delta': 0.36}]}
    before = len(isolated.goal_context_support)
    agent.objective_signal(isolated, observation, observation, 0.95, 0.95, 0.95, event, 'win')
    assert len(isolated.goal_context_support) > before
    item = isolated.goal_context_support['meter:synthetic_score|+']
    base_mask = int(item[0])
    agent.objective_signal(isolated, observation, observation, 0.95, 0.95, 0.95, event, 'win')
    assert int(item[0]) == base_mask
    agent.objective_signal(isolated, observation, observation, 0.95, 0.95, 0.95, event, 'loss')
    assert isolated.goal_context_support['meter:synthetic_score|+'][1] != 0
    assert isolated.diagnostics['objective_contradictions'] >= 1
    assert len(RECONSTRUCTION_INDICES) > len(LEGACY_RECONSTRUCTION_INDICES)
    assert all(0 <= index < FEATURE_COUNT for index in RECONSTRUCTION_INDICES)
    original = observation.features[:]
    contrasting = [min(1.5, max(-1.5, float(value) + (0.65 if index % 3 else -0.65)))
                   for index, value in enumerate(original)]
    positive = [agent.game_key, original, control, 0.0, original[:], 0.1, False, 1, 0.95,
                {'input_sent': True, 'learning_effect_observation': 0.0,
                 'learning_effect_confidence': 0.90, 'learning_state_context': 'stable_scene'}]
    negative = [agent.game_key, contrasting, control, 0.0, contrasting[:], 0.1, False, 1, 0.95,
                {'input_sent': False, 'learning_state_context': 'unrelated_scene'}]
    assert agent.stable_temporal_pair(positive)
    snapshot = agent._training_snapshot([positive, negative])
    assert len(snapshot['contrastive_examples']) == 2
    if agent.np is not None:
        snapshot['encoder_bias'] += 0.06
    else:
        snapshot['encoder_bias'] = [value + 0.06 for value in snapshot['encoder_bias']]
    assert agent._train_temporal_snapshot(positive, snapshot)
    if agent.np is not None:
        assert bool(agent.np.all(agent.np.isfinite(snapshot['encoder'])))
    else:
        assert all(math.isfinite(value) for row in snapshot['encoder'] for value in row)
    assert agent.plan_feedback_mismatch({'effect_probability': 0.86, 'effect_confidence': 0.72},
                                        {'action_effect_observation': 0.0,
                                         'action_effect_observation_confidence': 0.91})
    assert not agent.plan_feedback_mismatch({'effect_probability': 0.27, 'effect_confidence': 0.72},
                                            {'action_effect_observation': 0.0,
                                             'action_effect_observation_confidence': 0.91})
    summary = agent.decision_diagnostics(observation, control, plan_length=2)
    assert summary['action_kind'] == 'click' and summary['effect_probability'] >= 0.0
    assert json.loads(json.dumps(summary, ensure_ascii=False))['planned_steps'] == 2
    strong = [agent.game_key, original, control, -0.1, contrasting, 0.1, False, 1, 0.95,
              {'input_sent': True, 'learning_effect_observation': 0.0,
               'learning_effect_confidence': 0.95}]
    weak = [agent.game_key, original, control, 0.1, contrasting, 0.1, False, 1, 0.95,
            {'input_sent': True, 'learning_goal_direction': True, 'learning_goal_confidence': 0.80}]
    assert agent.replay_quality(strong) > agent.replay_quality(weak)
    old_game, old_source, old_key, old_ref = (agent.game_key, agent.last_skill_source,
                                             agent.last_transfer_key, agent.last_skill_reference)
    test_key = '_synthetic_transfer_extension'
    agent.games[test_key] = isolated
    agent.game_key = test_key
    try:
        sequence = [control, agent.action_index['key:65']]
        agent.last_skill_source = old_game
        agent.last_transfer_key = 'synthetic_source:sequence'
        agent.last_skill_reference = '|'.join(agent.actions[index].id for index in sequence)
        agent.mark_plan_result(sequence, observation, {'screen_result_confirmation': 'win'}, steps_completed=1)
        assert isolated.transfer_skill_stats['synthetic_source:sequence'][1] == 0
        agent.last_transfer_key = 'synthetic_source:sequence'
        agent.mark_plan_result(sequence, observation, {'screen_result_confirmation': 'win'}, steps_completed=2)
        assert isolated.transfer_skill_stats['synthetic_source:sequence'][1] == 1
        assert isolated.diagnostics['transfer_multistep_successes'] == 1
    finally:
        agent.game_key = old_game
        agent.last_skill_source = old_source
        agent.last_transfer_key = old_key
        agent.last_skill_reference = old_ref
        del agent.games[test_key]
    encoded = isolated.export()
    restored = GameData(len(agent.actions), agent.hidden_size, agent.np)
    restored.merge(isolated)
    assert 'passive_world' in encoded and 'goal_context_support' in encoded
    assert restored.passive_world and restored.goal_context_support
    return True



def verify_causal_intelligence_regressions(agent, observation):
    independent = GameData(len(agent.actions), agent.hidden_size, agent.np)
    probe = Brain.__new__(Brain)
    probe.games = {'synthetic_control': independent}
    probe.game_key = 'synthetic_control'
    probe.lock = threading.RLock()
    probe.dirty_games = set()
    probe.dirty_sequence = 0
    probe.rgb_blocks = lambda sample: [[int(sample)] * 3 for _ in range(GW * GH)]
    first = probe.record_passive_change(20, 38, elapsed_seconds=0.08)
    second = probe.record_passive_change(20, 38, elapsed_seconds=0.09)
    third = probe.record_passive_change(20, 50, elapsed_seconds=0.45)
    assert 0.0 < first == second < third
    assert independent.passive_timed['default:time:short'][2] == 2
    assert independent.passive_timed['default:time:long'][2] == 1
    saved = independent.export()
    assert any(name == 'default:time:short' for name, _ in saved['passive_timed'])
    joined = GameData(len(agent.actions), agent.hidden_size, agent.np)
    joined.merge(independent)
    assert joined.passive_timed['default:time:short'][2] == 2
    probe.belief_history = deque(maxlen=7)
    def snapshot(x, target, meter, scene='sequence'):
        view = Observation(observation.lum, observation.rgb, observation.salience, observation.motion,
                           observation.edges, observation.features[:], observation.signature,
                           observation.change, observation.novelty, observation.rect, observation.raw,
                           observation.hud, 'synthetic_control',
                           quality={'confidence': 0.96, 'trainable': True})
        view.scene_identity = scene
        view.scene_key = scene
        view.phase = 'playing'
        view.phase_confidence = 0.94
        view.objects = [{'track_id': 1, 'age': 4, 'x': x, 'y': 0.45, 'vx': 0.01,
                         'vy': 0.0, 'control_probability': 0.94, 'confidence': 0.96},
                        {'track_id': 2, 'age': 4, 'x': target, 'y': 0.45, 'vx': 0.0,
                         'vy': 0.0, 'control_probability': 0.01, 'confidence': 0.90}]
        view.hud_meters = {'life': meter}
        view.ui_text = []
        view.temporal_summary = {}
        return view
    a = snapshot(0.20, 0.70, 0.20)
    b = snapshot(0.26, 0.70, 0.60)
    c = snapshot(0.32, 0.70, 0.90)
    assert probe.update_belief_state(a)['frames'] == 1
    assert probe.update_belief_state(b)['relative'][4] > 0.0
    state = probe.update_belief_state(c)
    assert state['frames'] == 3 and state['relative'][3] < 0.40
    assert 0.20 < state['meters']['life'] < 0.90
    assert 0.0 < state['confidence'] <= 1.0
    assert probe.update_belief_state(snapshot(0.4, 0.7, 0.5, 'another_scene'))['frames'] == 1
    c.belief_state['player'] = (1, 0.32, 0.45, 0.05, 0.0, 0.95)
    state_right = Brain.state_signature(c)
    c.belief_state['player'] = (1, 0.32, 0.45, -0.05, 0.0, 0.95)
    assert state_right != Brain.state_signature(c)
    assert len(agent.probe_representatives) >= 8
    action_w = agent.action_index.get('key:87')
    action_s = agent.action_index.get('key:83')
    if action_w is not None and action_s is not None:
        early = agent.contrastive_probe_bonus(independent, observation, action_w, 'discovery')
        context = agent.experiment_context(observation)
        independent.action_applicability[context + ':' + str(action_s)] = [4, 0.6, 0.0, 0.0]
        independent.control_posteriors[action_s] = [7.0, 1.0]
        later = agent.contrastive_probe_bonus(independent, observation, action_w, 'discovery')
        assert later > early
    example = [agent.game_key, observation.features[:], 0, 0.0, observation.features[:],
               0.4, False, 1, 0.9, {'input_sent': True, 'feedback_valid': True,
                                      'learning_effect_observation': 1.0,
                                      'learning_effect_confidence': 0.90,
                                      'learning_belief_confidence': 0.90}]
    good = agent.replay_quality(example)
    example[9] = {'input_sent': True, 'feedback_valid': True,
                  'learning_effect_observation': 1.0,
                  'learning_effect_confidence': 0.15,
                  'learning_belief_confidence': 0.15}
    weak = agent.replay_quality(example)
    assert 0.0 < weak < good <= 1.0
    example[9]['feedback_valid'] = False
    assert agent.replay_quality(example) == 0.0
    return True


def verify_offline_cold_start(folder, module, stop_vk=27, mode='全屏'):
    workspace = pathlib.Path(tempfile.mkdtemp(prefix='_offline_preflight_', dir=folder))
    backend = getattr(module, '__name__', 'none') if module is not None else 'none'
    installed_paths = []
    for name in ('numpy', 'cupy'):
        imported = sys.modules.get(name)
        origin = getattr(imported, '__file__', None) if imported is not None else None
        if origin:
            installed_paths.append(str(pathlib.Path(origin).resolve().parent.parent))
    script = '''import importlib, importlib.util, pathlib, socket, sys, urllib.request
root, source, workspace, backend, stop_vk, mode = pathlib.Path(sys.argv[1]), pathlib.Path(sys.argv[2]), pathlib.Path(sys.argv[3]), sys.argv[4], int(sys.argv[5]), sys.argv[6]
assert mode in ('全屏', '窗口') and 1 <= stop_vk <= 255
sys.dont_write_bytecode = True
for installed in sys.argv[7:]:
    sys.path.insert(0, installed)
for name in ('_runtime', '_gpu_runtime'):
    location = root / name
    if location.is_dir():
        sys.path.insert(0, str(location))
def denied(*args, **kwargs):
    raise OSError('离线验证期间禁止访问网络')
socket.create_connection = denied
socket.socket.connect = denied
socket.socket.connect_ex = denied
socket.socket.sendto = denied
socket.getaddrinfo = denied
urllib.request.urlopen = denied
urllib.request.urlretrieve = denied
spec = importlib.util.spec_from_file_location('local_offline_agent_preflight', str(source))
engine = importlib.util.module_from_spec(spec)
spec.loader.exec_module(engine)
if sys.platform == 'win32':
    win = engine.Native()
    engine.verify_local_storage(root, win)
    vision = engine.Capture(win, '全屏', None)
    try:
        image, box = vision.grab()
        detailed = vision.grab_detail(box, 0.5, 0.5)
        assert len(image) == engine.W * engine.H * 4 and len(detailed) == engine.DW * engine.DH * 4
    finally:
        vision.close()
    if mode == '窗口':
        window_probe = engine.Capture(win, '窗口', None)
        try:
            assert isinstance(window_probe._candidates(), list)
        finally:
            window_probe.close()
    if win.com_initialized:
        win.ole.CoUninitialize()
class FakeUser:
    def __init__(self):
        self.pressed = False
        self.accepted = 0
        self.fail_release_count = 0
        self.touch_release_failures = 0
    def GetAsyncKeyState(self, vk):
        return 0x8000 if self.pressed else 0
    def MapVirtualKeyW(self, vk, method):
        return 0
    def SendInput(self, count, data, size):
        packet = engine.ctypes.cast(data, engine.ctypes.POINTER(engine.INPUT)).contents
        is_release = ((packet.type == 1 and packet.value.ki.dwFlags & engine.KEYEVENTF_KEYUP)
                      or (packet.type == 0 and packet.value.mi.dwFlags & (engine.MOUSEEVENTF_LEFTUP | engine.MOUSEEVENTF_RIGHTUP | engine.MOUSEEVENTF_MIDDLEUP)))
        if is_release and self.fail_release_count:
            self.fail_release_count -= 1
            return 0
        self.accepted += count
        return count
    def InjectTouchInput(self, count, infos):
        if infos[0].pressure != 512:
            return 0
        if infos[0].pointerInfo.pointerFlags & 0x40000 and self.touch_release_failures:
            self.touch_release_failures -= 1
            return 0
        return 1
    def GetSystemMetrics(self, code):
        return {76: 0, 77: 0, 78: 1280, 79: 720}[code]
class FakeNative:
    def __init__(self):
        self.user = FakeUser()
fake = FakeNative()
flag = engine.threading.Event()
control = engine.Controller(fake, stop_vk, flag)
control.stop_gate = engine.StopKeyGate(fake, stop_vk, flag)
assert control.key(stop_vk, True) is False and fake.user.accepted == 0
candidate = next(v for v in (65, 66, 67, 68, 70, 71, 72) if not engine.stop_equivalent(v, stop_vk))
assert control.key(candidate, True) and control.down == {candidate}
control.release()
assert not control.down and fake.user.accepted == 2
assert control.key(candidate, True)
fake.user.fail_release_count = 5
try:
    control.release(retries=2)
    raise AssertionError('释放失败不能被误报为成功')
except OSError:
    pass
assert candidate in control.down
fake.user.fail_release_count = 0
assert control.release() and not control.down
control.touch_available = True
assert control.touch([(0.5, 0.5)], 'down', (0, 0, 1280, 720))
fake.user.touch_release_failures = 1
assert control.release(retries=3) and not control.touch_points
control.stop_gate.note_injected(True)
fake.user.pressed = True
assert not control.stop_gate.poll() and not flag.is_set()
control.stop_gate.note_injected(False)
fake.user.pressed = False
control.stop_gate.poll()
control.stop_gate.injected_release_grace_until = 0
fake.user.pressed = True
assert control.stop_gate.poll() and flag.is_set()
assert not control.key(candidate, True)
assert not control.down
numeric = importlib.import_module(backend) if backend != 'none' else None
assert engine.validate_learning_backend(numeric)
store = engine.ReplayStore(workspace)
try:
    assert store.verify_roundtrip()
finally:
    store.close()
agent = engine.Brain(workspace, stop_vk, numeric)
try:
    raw = bytearray(bytes((40, 95, 170, 255)) * (engine.W * engine.H))
    for index in range(0, engine.W * engine.H, 13):
        pos = index * 4
        raw[pos:pos + 3] = bytes((30 + index % 101, 70 + index % 91, 95 + index % 121))
    before = agent.observe(bytes(raw), (0, 0, 1280, 720))
    for index in range(0, engine.W * engine.H, 17):
        raw[index * 4] = (raw[index * 4] + 71) % 256
    after = agent.observe(bytes(raw), (0, 0, 1280, 720))
    assert before.quality['trainable'] and after.quality['trainable']
    assert len(before.features) == engine.FEATURE_COUNT
    assert len(engine.ReplayStore.unpack(engine.ReplayStore.pack(before.features))) == engine.FEATURE_COUNT
    assert len(engine.ReplayStore.unpack(engine.struct.pack('<384f', *([0.0] * 384)))) == engine.FEATURE_COUNT
    assert len(agent.action_neighbors) == len(agent.actions)
    key_w, key_s = engine.synthetic_control_pair(agent)
    up_id = agent.actions[key_w].id
    assert key_s not in [neighbor for neighbor, _ in agent.action_neighbors[key_w]]
    assert agent.action_index['hold:' + str(agent.actions[key_w].a)] in [neighbor for neighbor, _ in agent.action_neighbors[key_w]]
    assert before.phase in ('unknown', 'menu', 'playing', 'transition', 'result')
    assert engine.verify_precision_regressions(agent, before)
    assert engine.verify_behavioral_learning(agent, before)
    assert engine.verify_intelligence_regressions(agent, before)
    assert engine.verify_synthetic_closed_loop(agent, before)
    assert engine.verify_generalization_regressions(agent, before)
    assert engine.verify_learning_upgrades(agent, before)
    assert engine.verify_adaptive_intelligence(agent, before)
    assert engine.verify_upgraded_components(agent, before)
    assert engine.verify_autonomous_learning_fixes(agent, before)
    assert engine.verify_intelligence_extension(agent, before)
    assert engine.verify_causal_intelligence_regressions(agent, before)
    def render_simulation(position, score):
        pixels = bytearray(bytes((30, 38, 43, 255)) * (engine.W * engine.H))
        for row in range(engine.H):
            tone = 27 if row // 15 % 2 else 18
            for col in range(0, engine.W, 8):
                offset = (row * engine.W + col) * 4
                pixels[offset:offset + 4] = bytes((tone, tone + 7, tone + 13, 255))
        left = max(3, min(engine.W - 39, int(position * engine.W)))
        for row in range(67, 98):
            for col in range(left, left + 32):
                offset = (row * engine.W + col) * 4
                pixels[offset:offset + 4] = bytes((40, 220, 250, 255))
        for row in range(4, 11):
            for col in range(5, 6 + score * 9):
                offset = (row * engine.W + col) * 4
                pixels[offset:offset + 4] = bytes((38, 206, 60, 255))
        return bytes(pixels)
    screen_first = agent.observe(render_simulation(0.18, 1), (0, 0, 1280, 720))
    screen_second = agent.observe(render_simulation(0.42, 2), (0, 0, 1280, 720))
    assert screen_first.attention_points and screen_second.attention_points
    assert screen_second.change > 0.001 and len(screen_second.features) == engine.FEATURE_COUNT
    assert all(0.0 <= x <= 1.0 and 0.0 <= y <= 1.0 for x, y, _ in screen_second.attention_points)
    assert len(agent.game.phase_votes) >= 1
    phase_probe = engine.Observation(before.lum, before.rgb, before.salience, before.motion, before.edges,
                                     before.features[:], before.signature, before.change, before.novelty,
                                     before.rect, before.raw, before.hud, before.game, quality=before.quality.copy())
    phase_probe.ui_text = [{'text': 'START', 'x': 0.5, 'y': 0.5, 'confidence': 0.99, 'temporal_confidence': 0.96}]
    phase_probe.temporal_summary = {'motion_energy': 0.0, 'active_objects': 0}
    assert agent.infer_scene_phase(phase_probe) == 'menu'
    import random as _random
    fake_lum = [_random.Random(i * 17 + 7).random() for i in range(engine.GW * engine.GH)]
    class VisualScreen:
        def __init__(self, lum):
            self.lum = lum
    translated = [fake_lum[y * engine.GW + x - 4] if x >= 4 else 0.10
                  for y in range(engine.GH) for x in range(engine.GW)]
    aligned_change, shift, confidence = agent.aligned_visual_change(VisualScreen(fake_lum), VisualScreen(translated))
    assert shift == (4, 0) and confidence > 0.3 and aligned_change < 0.03
    probe_scores = agent.experiment_scores(agent.game, before, 'discovery',
                                            {family: 0 for family in agent.action_families})
    assert len(probe_scores) == len(agent.actions) and all(engine.math.isfinite(score) for score in probe_scores)
    agent.reward_info = {'input_was_sent': True, 'feedback_samples': 3, 'observation_confidence': 1.0,
                         'scene_stability': 0.9, 'causal_confidence': 0.85, 'estimated_action_effect': 0.08,
                         'persistent_visual_change': 0.85, 'passive_visual_change': 0.005,
                         'action_effect_observation': 1.0, 'action_effect_observation_confidence': 0.89}
    click_index = agent.action_index['click']
    prior_alpha = agent.game.control_posteriors[click_index][0]
    agent.update_action_applicability(agent.game, before, click_index, 0.09)
    assert agent.game.control_posteriors[click_index][0] > prior_alpha
    agent.reward_info.update({'causal_confidence': 0.0, 'estimated_action_effect': 0.0,
                              'persistent_visual_change': 0.0, 'action_effect_observation': 0.0})
    prior_beta = agent.game.control_posteriors[click_index][1]
    agent.update_action_applicability(agent.game, before, click_index, -0.02)
    assert agent.game.control_posteriors[click_index][1] > prior_beta
    chosen = agent.choose(before)
    assert 0 <= chosen < len(agent.actions)
    parameters = agent.recommend_action_parameters(chosen, before)
    assert len(parameters) >= 3 and all(engine.math.isfinite(float(value)) for value in parameters)
    before.hud_meters = {'top:1:green': 0.21}
    after.hud_meters = {'top:1:green': 0.33}
    before.ui_numbers = [{'text': '1', 'x': 0.22, 'y': 0.12, 'confidence': 0.98}]
    after.ui_numbers = [{'text': '2', 'x': 0.22, 'y': 0.12, 'confidence': 0.98}]
    evidence, evidence_detail = agent.progress_evidence(before, after, 0.9, 0.9, 0.9)
    assert evidence > 0 and evidence_detail['candidate_information_gain'] > 0
    assert agent.state_signature(before) != agent.state_signature(after)
    index = agent.action_index['click']
    action_effect = {'kind': 'click', 'input_sent': True, 'finished': True, 'feedback_valid': True,
                     'spatial': True, 'start_x': 0.5, 'start_y': 0.5, 'requested_duration': 0.15}
    feedback = {'frame_deltas': [0.06, 0.07, 0.06], 'frame_times': [0.02, 0.09, 0.18], 'settled_change': 0.06,
                'frame_stability': 0.9, 'hud_stability': 0.9, 'post_action_drift': 0.005}
    learned_reward, measured_change = agent.reward_for(before, after, index, action_effect, feedback)
    assert engine.math.isfinite(learned_reward) and engine.math.isfinite(measured_change)
    if agent.reward_info['control_learning_verified']:
        assert 'click' in agent.game.feedback_latency_by_kind
        assert 0.035 <= agent.game.feedback_latency_by_kind['click'][0] <= 0.60
    agent.learn(before, index, after, learned_reward, measured_change, done=True, effect=action_effect)
    assert agent.step == 1
    initial_world_counts = sum(row[1] for row in agent.game.world.values())
    agent.game.passive_samples = 4
    agent.game.passive_change = 0.22
    passive_feedback = {'frame_deltas': [0.05, 0.06, 0.05], 'frame_times': [0.02, 0.08, 0.16],
                        'settled_change': 0.05, 'frame_stability': 0.85, 'hud_stability': 0.85,
                        'post_action_drift': 0.07}
    passive_reward, _ = agent.reward_for(before, after, index, action_effect, passive_feedback)
    assert engine.math.isfinite(passive_reward) and not agent.reward_info['control_learning_verified']
    assert agent.reward_info['causal_confidence'] < 0.10
    assert sum(row[1] for row in agent.game.world.values()) == initial_world_counts
    world_changes = [0.02] * engine.WORLD_FEATURE_COUNT
    for _ in range(35):
        loss = agent.train_world_network(agent.game, index, before.features, {'requested_duration': 0.15}, world_changes, 0.12, 0.9)
    assert loss is not None and engine.math.isfinite(loss)
    assert agent._predict_learned_world(agent.game, index, before.features) is not None
    assert all(name in agent.game.world_network for name in ('w1_alt', 'b1_alt', 'w2_alt', 'b2_alt'))
    world_weights = agent.game.world_network
    assert any(abs(float(world_weights['w1'][0][i]) - float(world_weights['w1_alt'][0][i])) > 1e-7
               for i in range(engine.WORLD_ACTION_FEATURES))
    assert len(agent.game.world_action_error_variance) == len(agent.actions)
    initial_validation = agent.game.world_validation_samples[index]
    predicted_before = agent._predict_learned_world(agent.game, index, before.features)
    assert predicted_before is not None
    verified_error = agent.validate_world_prediction(agent.game, index, before.features, after.features,
                                                     {'requested_duration': 0.15})
    assert verified_error is not None and engine.math.isfinite(verified_error)
    assert agent.game.world_validation_samples[index] == initial_validation + 1
    assert agent.game.diagnostics['world_holdout_evaluations'] >= 1
    assert not agent.plan_prediction_failed(agent.world_state(before), before)
    agent.game.world_effects['a:' + up_id] = [9.0, 2.0, 10]
    agent.game.control_profiles[up_id] = [0.04, -0.01, 0.52, 0.30, 0.42, 8]
    synthetic_context = agent.experiment_context(before)
    agent.game.spatial_context_stats[synthetic_context + ':click:3:4'] = [6, 0.31, 0.42, 0.0]
    agent.game.duration_context_stats[synthetic_context + ':click:0.15'] = [6, 0.24, 0.39, 0.0]
    agent.game.action_goal[index] = 0.31
    agent.game.action_goal_samples[index] = 3
    agent.game.goal_hypotheses['number:2:1'] = [4.0, 0.0, 0.0, 2.0]
    agent.game.repeat_effects['c:synthetic:' + up_id] = [5.0, 1.0, 3.0, 6]
    agent.game.inverse_dynamics['move_up'] = [12, [0.06] * len(engine.INVERSE_WORLD_INDICES), 0.025, 9]
    agent.game.world_condition_errors['k:key:medium'] = [9, 0.12, 0.005]
    event_context = agent.world_event_key(before, index)
    agent.game.world_events[event_context] = [7.0, 1.0, 4.0, 0.0, 2.0, 3.0, 1.0]
    assert agent.update_dual_values(agent.game, before, index, effect=1.0, control_confidence=0.90,
                                    objective=0.75, objective_confidence=0.90)
    agent.game.ui_history['synthetic_temporal_votes'] = ['READY', 4, agent.game.game_steps, 0.93,
                                                         [['READY', 0.88], ['READY', 0.93]]]
    agent.game.ui_history['synthetic_legacy_votes'] = ['BEGIN', 2, agent.game.game_steps, 0.84]
    agent.game.intent_values['i:primary_select'] = [7.0, 2.0, 1.8, 4.0]
    agent.game.goal_proposals['relation:contact'] = [3.0, 4.0, 2.5, 'c:123', 31]
    agent.save(force=True)
finally:
    agent.close()
assert (workspace / 'learning_state.json.gz').is_file()
restored = engine.Brain(workspace, stop_vk, numeric)
try:
    assert restored.step >= 1 and restored.checkpoint_verified
    assert restored.game.world_network_steps >= 35
    assert all(name in restored.game.world_network for name in ('w1_alt', 'b1_alt', 'w2_alt', 'b2_alt'))
    assert restored.game.control_posteriors[click_index][0] > 1.0
    assert restored.game.control_posteriors[click_index][1] > 1.0
    assert len(restored.decoder) == len(engine.RECONSTRUCTION_INDICES)
    assert len(restored.game.phase_votes) >= 1
    assert restored.game.passive_samples >= 4
    assert len(restored.game.world_action_error_variance) == len(restored.actions)
    assert restored.game.world_effects['a:' + up_id][0] == 9.0
    assert abs(restored.game.action_goal[index] - 0.31) < 1e-8
    assert restored.game.action_goal_samples[index] == 3
    assert restored.game.intent_values['i:primary_select'] == [7.0, 2.0, 1.8, 4.0]
    assert restored.game.goal_proposals['relation:contact'] == [3.0, 4.0, 2.5, 'c:123', 31]
    assert restored.game.goal_hypotheses['number:2:1'] == [4.0, 0.0, 0.0, 2.0]
    assert restored.game.hierarchical_controls
    assert restored.game.repeat_effects['c:synthetic:' + up_id] == [5.0, 1.0, 3.0, 6]
    assert restored.game.inverse_dynamics['move_up'][0] == 12
    assert len(restored.game.inverse_dynamics['move_up'][1]) == len(engine.INVERSE_WORLD_INDICES)
    assert restored.game.world_condition_errors['k:key:medium'][0] == 9
    assert restored.game.world_events[event_context][0] == 7.0
    assert len(restored.game.world_events[event_context]) == 12
    assert restored.game.control_head_samples[index] > 0
    assert restored.game.objective_head_samples[index] > 0
    assert abs(float(restored.game.control_head_bias[index])) > 0.00001
    assert abs(float(restored.game.objective_head_bias[index])) > 0.00001
    assert restored.game.world_validation_samples[index] >= 1
    assert restored.game.diagnostics['world_holdout_evaluations'] >= 1
    assert all(isinstance(entry, list) and len(entry) == 5 for entry in restored.game.ui_history.values())
    assert len(restored.game.ui_history['synthetic_temporal_votes'][4]) == 2
    assert restored.game.ui_history['synthetic_legacy_votes'][4] == []
    assert restored.game.control_profiles[up_id][5] == 8
    assert restored.game.spatial_context_stats[synthetic_context + ':click:3:4'][0] == 6
    assert restored.game.duration_context_stats[synthetic_context + ':click:0.15'][0] == 6
    assert sum(restored.game.action_attempts) >= 1
finally:
    restored.close()
inspection = engine.inspect_checkpoint_bundle(workspace)
assert inspection['restores_latest'] and inspection['base_step'] >= 1
class DesktopNative:
    def desktop(self):
        return workspace
archive_path = engine.blackbox(DesktopNative(), workspace, None, mode, stop_vk)
assert archive_path.stat().st_size <= 1000000
with engine.zipfile.ZipFile(archive_path) as archive:
    assert 'report.json' in archive.namelist()
    metadata = engine.json.loads(archive.read('report.json'))
    assert metadata['mode'] == mode
    assert 'pre_update_world_validation_samples' in metadata
    assert 'learning_evidence_diagnostics' in metadata
    assert 'dual_control_head_population' in metadata
    assert 'dual_objective_head_population' in metadata
archive_path.unlink()
probe = engine.Brain.__new__(engine.Brain)
probe.actions = [engine.Action('test', 'key')]
probe.spool_path = workspace / 'nonexistent' / 'experience_overflow.jsonl'
probe.spool_lock = engine.threading.Lock()
probe.persist_backlog = engine.deque()
probe.journal_unwritten = engine.OrderedDict()
probe.journal_failures = 0
probe.journaled_transitions = 0
probe.store_problem = None
probe.dropped_unpersisted = 0
probe.spilled_transitions = 0
vector = [0.1] * engine.FEATURE_COUNT
sample = ('desktop', 'test', 0.1, vector, vector, 0.0, False, 1, 0.2, 0.9, {'uid': 'offline_failover_uid_1'})
probe.persist_backlog = engine.deque([sample] * 12000)
probe.journal_unwritten[sample[10]['uid']] = sample
transition = ['desktop', vector, 0, 0.1, vector, 0.2, False, 1, 0.9, {'uid': 'offline_failover_uid_2'}]
probe._append_persist(transition)
assert len(probe.persist_backlog) == 12000 and probe.dropped_unpersisted == 1
assert probe.store_problem is not None
store = engine.ReplayStore(workspace)
try:
    assert store.total_transitions >= 1
finally:
    store.close()
'''
    command = [sys.executable, '-I', '-c', script, str(folder), str(pathlib.Path(__file__).resolve()),
               str(workspace), backend, str(stop_vk), mode, *installed_paths]
    try:
        run = subprocess.run(command, capture_output=True, stdin=subprocess.DEVNULL, timeout=120,
                             creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        if run.returncode != 0:
            message = run.stderr.decode('utf-8', errors='replace')[-700:]
            raise OSError('隔离网络后的离线重启与经验回读验证失败：' + message)
        return True
    finally:
        shutil.rmtree(workspace, ignore_errors=True)

def stop_options():
    names = {8: 'Backspace', 9: 'Tab', 13: 'Enter', 16: 'Shift', 17: 'Ctrl', 18: 'Alt', 19: 'Pause', 20: 'Caps Lock', 27: 'ESC', 32: 'Space', 33: 'Page Up', 34: 'Page Down', 35: 'End', 36: 'Home', 37: '←', 38: '↑', 39: '→', 40: '↓', 44: 'Print Screen', 45: 'Insert', 46: 'Delete', 91: 'Win Left', 92: 'Win Right', 93: 'Menu', 144: 'Num Lock', 145: 'Scroll Lock'}
    for vk in range(48, 58):
        names[vk] = chr(vk)
    for vk in range(65, 91):
        names[vk] = chr(vk)
    for vk in range(96, 106):
        names[vk] = f'Num {vk - 96}'
    for vk, label in ((106, 'Num *'), (107, 'Num +'), (109, 'Num -'), (110, 'Num .'), (111, 'Num /')):
        names[vk] = label
    for vk in range(112, 136):
        names[vk] = f'F{vk - 111}'
    for vk, label in ((160, 'L Shift'), (161, 'R Shift'), (162, 'L Ctrl'), (163, 'R Ctrl'), (164, 'L Alt'), (165, 'R Alt'), (166, 'Browser Back'), (167, 'Browser Forward'), (168, 'Browser Refresh'), (169, 'Browser Stop'), (170, 'Browser Search'), (171, 'Browser Favorites'), (172, 'Browser Home'), (173, 'Mute'), (174, 'Volume Down'), (175, 'Volume Up'), (176, 'Media Next'), (177, 'Media Previous'), (178, 'Media Stop'), (179, 'Media Play/Pause'), (180, 'Launch Mail'), (181, 'Launch Media'), (182, 'Launch App 1'), (183, 'Launch App 2'), (186, ';'), (187, '='), (188, ','), (189, '-'), (190, '.'), (191, '/'), (192, '`'), (219, '['), (220, '\\'), (221, ']'), (222, "'"), (226, 'OEM 102')):
        names[vk] = label
    ordered = [(names[v], v) for v in [27] + [v for v in sorted(names) if v != 27]]
    return ordered


def encode_png(raw):
    if len(raw) != W * H * 4:
        raise ValueError('无法将非基础分辨率的画面编码为 PNG')
    lines = bytearray()
    for y in range(H):
        lines.append(0)
        base = y * W * 4
        for x in range(W):
            idx = base + x * 4
            lines.extend((raw[idx + 2], raw[idx + 1], raw[idx]))
    def part(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xFFFFFFFF)
    return b'\x89PNG\r\n\x1a\n' + part(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 2, 0, 0, 0)) + part(b'IDAT', zlib.compress(bytes(lines), 7)) + part(b'IEND', b'')


def inspect_checkpoint_bundle(folder):
    primary = folder / 'learning_state.json.gz'
    backup = folder / 'learning_state.json.gz.bak'
    delta_path = folder / 'learning_delta.json.gz'
    result = {'files': [], 'restores_latest': False, 'delta_present': delta_path.exists(),
              'delta_valid': False, 'backup_used': False, 'error': None, 'base_step': None, 'latest_step': None}
    def inspect(path, compressed_limit, expanded_limit):
        if path.stat().st_size > compressed_limit:
            raise ValueError('学习检查点压缩容量超限')
        with gzip.open(path, 'rb') as stream:
            raw = stream.read(expanded_limit + 1)
        if len(raw) > expanded_limit:
            raise ValueError('学习检查点解压容量超限')
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError('学习检查点结构错误')
        actual_hash = data.pop('integrity_sha256', None)
        payload = json.dumps(data, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
        if not isinstance(actual_hash, str) or hashlib.sha256(payload).hexdigest() != actual_hash:
            raise ValueError('学习检查点摘要校验失败')
        return data, actual_hash
    errors = []
    base = None
    base_hash = None
    chosen = None
    for candidate in (primary, backup):
        if not candidate.exists():
            continue
        try:
            proposed, digest = inspect(candidate, 140_000_000, 260_000_000)
            if (proposed.get('format') not in (7, 8, 9, 10, 11, 12, 13, 14, 15, 16, MODEL_FORMAT)
                    or proposed.get('feature_count') not in (LEGACY_FEATURE_COUNT, FEATURE_COUNT)
                    or proposed.get('hidden_size') not in (96, MODEL_HIDDEN_SIZE)
                    or not isinstance(proposed.get('action_ids'), list)):
                raise ValueError('基础学习检查点版本不匹配')
            base, base_hash, chosen = proposed, digest, candidate
            break
        except (OSError, ValueError, TypeError, OverflowError, EOFError, gzip.BadGzipFile, json.JSONDecodeError) as exc:
            errors.append(f'{candidate.name}: {type(exc).__name__}: {str(exc)[:120]}')
    if base is None:
        result['error'] = '; '.join(errors)[:300] if errors else 'base_not_found'
        return result
    result['files'] = [chosen]
    result['backup_used'] = chosen == backup
    result['base_step'] = int(base.get('step', 0))
    result['latest_step'] = result['base_step']
    result['base_sha256'] = base_hash
    result['restores_latest'] = not delta_path.exists() and not result['backup_used']
    if delta_path.exists():
        try:
            delta, delta_hash = inspect(delta_path, 80_000_000, 150_000_000)
            if (delta.get('format') != 1 or delta.get('base_step') != result['base_step']
                    or delta.get('feature_count') != base.get('feature_count')
                    or delta.get('hidden_size') != base.get('hidden_size')
                    or delta.get('action_ids') != base.get('action_ids')
                    or not isinstance(delta.get('games'), dict)
                    or int(delta.get('step', -1)) < result['base_step']):
                raise ValueError('增量与基础学习检查点不匹配')
            result['files'].append(delta_path)
            result['latest_step'] = int(delta['step'])
            result['delta_valid'] = True
            result['delta_sha256'] = delta_hash
            result['restores_latest'] = not result['backup_used']
        except (OSError, ValueError, TypeError, OverflowError, EOFError, gzip.BadGzipFile, json.JSONDecodeError) as exc:
            errors.append(f'{delta_path.name}: {type(exc).__name__}: {str(exc)[:120]}')
            result['restores_latest'] = False
    if errors:
        result['error'] = '; '.join(errors)[:300]
    return result


def blackbox(native, folder, agent, mode, stop_vk):
    destination = native.desktop()
    destination.mkdir(parents=True, exist_ok=True)
    unique_name = f'游戏Agent黑匣子_{time.strftime("%Y%m%d_%H%M%S")}_{uuid.uuid4().hex[:8]}.zip'
    final = destination / unique_name
    temp = destination / (unique_name + '.tmp')
    brain = agent.brain if agent else None
    manifest = {
        'created': time.strftime('%Y-%m-%d %H:%M:%S'),
        'platform': sys.platform,
        'python': sys.version.split()[0],
        'mode': mode,
        'stop_virtual_key': stop_vk,
        'data_directory': str(folder),
        'started': agent.started if agent else None,
        'steps': brain.step if brain else 0,
        'total_proxy_reward': brain.total_reward if brain else 0.0,
        'game_identity': brain.game_key if brain else None,
        'tracked_screens': len(brain.visits) if brain else 0,
        'replay_in_memory': len(brain.memory) if brain else 0,
        'valid_transitions': brain.valid_transitions if brain else 0,
        'low_information_observations': brain.low_information_observations if brain else 0,
        'persisted_transitions_this_session': brain.persisted_transitions if brain else 0,
        'transitions_pending_write': len(brain.persist_backlog) if brain else 0,
        'unpersisted_transitions_dropped': brain.dropped_unpersisted if brain else 0,
        'overflow_records_spilled': brain.spilled_transitions if brain else 0,
        'overflow_records_recovered': brain.spool_recovered if brain else 0,
        'overflow_file_bytes': brain.spool_path.stat().st_size if brain and brain.spool_path.exists() else 0,
        'transitions_in_database': brain.store.total_transitions if brain and brain.store else brain.db_transitions_last_known if brain else None,
        'sqlite_reconnect_failures': brain.store_failures if brain else 0,
        'sqlite_connected': bool(brain.store is not None) if brain else False,
        'nstep_generated': brain.nstep_generated if brain else 0,
        'learning_updates': brain.updates if brain else 0,
        'training_failures': brain.training_failures if brain else 0,
        'training_retries': brain.training_retried if brain else 0,
        'training_queue_evictions': brain.training_queue_evictions if brain else 0,
        'terminal_credit_samples': brain.terminal_credit_samples if brain else 0,
        'checkpoint_verified': brain.checkpoint_verified if brain else False,
        'checkpoint_migrated': brain.checkpoint_migrated if brain else False,
        'screen_outcome_totals': dict(brain.game.screen_outcomes) if brain else {},
        'action_control_trials': sum(max(0.0, sum(pair) - 2.0) for pair in brain.game.control_posteriors) if brain else 0,
        'action_control_candidates': sum(pair[0] >= 2.0 for pair in brain.game.control_posteriors) if brain else 0,
        'action_attempts': sum(brain.game.action_attempts) if brain else 0,
        'valid_action_learning_samples': sum(brain.game.counts) if brain else 0,
        'world_action_effect_contexts': len(brain.game.world_effects) if brain else 0,
        'passive_world_contexts': len(brain.game.passive_world) if brain else 0,
        'goal_context_supports': len(brain.game.goal_context_support) if brain else 0,
        'latest_decision': agent.last_decision if agent else None,
        'world_action_effect_positive_evidence': round(sum(max(0.0, row[0] - 1.0) for row in brain.game.world_effects.values()), 2) if brain else 0,
        'world_action_effect_negative_evidence': round(sum(max(0.0, row[1] - 1.0) for row in brain.game.world_effects.values()), 2) if brain else 0,
        'learned_control_profiles': len(brain.game.control_profiles) if brain else 0,
        'spatial_action_contexts': len(brain.game.spatial_context_stats) if brain else 0,
        'duration_action_contexts': len(brain.game.duration_context_stats) if brain else 0,
        'world_prediction_error_mean': brain.game.prediction_error_mean if brain else None,
        'world_prediction_error_variance': brain.game.prediction_error_variance if brain else None,
        'pre_update_world_validation_samples': sum(brain.game.world_validation_samples) if brain else 0,
        'world_validation_action_coverage': sum(value > 0 for value in brain.game.world_validation_samples) if brain else 0,
        'learning_evidence_diagnostics': dict(brain.game.diagnostics) if brain else {},
        'dual_control_head_population': sum(value > 0 for value in brain.game.control_head_samples) if brain else 0,
        'dual_objective_head_population': sum(value > 0 for value in brain.game.objective_head_samples) if brain else 0,
        'dual_control_head_samples': sum(brain.game.control_head_samples) if brain else 0,
        'dual_objective_head_samples': sum(brain.game.objective_head_samples) if brain else 0,
        'world_event_contexts': len(brain.game.world_events) if brain else 0,
        'transfer_skill_tests': len(brain.game.transfer_skill_stats) if brain else 0,
        'latest_evidence_confidence': {field: brain.reward_info.get(field) for field in ('action_evidence_confidence', 'objective_evidence_confidence', 'reward_learning_confidence')} if brain else {},
        'replay_surprise_samples': len(brain.surprise_memory) if brain else 0,
        'replay_failure_samples': len(brain.failure_memory) if brain else 0,
        'feedback_latency_by_kind': dict(list(brain.game.feedback_latency_by_kind.items())[-24:]) if brain else {},
        'scene_phase_votes': len(brain.game.phase_votes) if brain else 0,
        'journaled_transitions': brain.journaled_transitions if brain else 0,
        'journal_failures': brain.journal_failures if brain else 0,
        'database_roundtrip_verified': brain.store_roundtrip_verified if brain else False,
        'database_preflight_verified': brain.db_preflight_verified if brain else False,
        'capture_valid': agent.last_capture_valid if agent else None,
        'last_capture_at': agent.last_capture_at if agent else None,
        'last_experience_at': agent.last_experience_at if agent else None,
        'completed_actions': agent.completed_actions if agent else 0,
        'partially_executed_actions': agent.partial_actions if agent else 0,
        'capture_failures': agent.capture_failures if agent else 0,
        'input_failures': agent.input_failures if agent else 0,
        'feedback_capture_batches': agent.feedback_captures if agent else 0,
        'visually_observed_input_effects': agent.visual_input_effects if agent else 0,
        'estimated_episode_boundaries': agent.episode_boundaries if agent else 0,
        'visual_game_switches': agent.visual_game_switches if agent else 0,
        'continuous_capture_frames': agent.sensor_frames_total if agent else 0,
        'sensor_restarts': agent.sensor_restarts if agent else 0,
        'bound_target_pid': agent.capture_target_pid if agent else None,
        'bound_target_hwnd': agent.capture_target_hwnd if agent else None,
        'actions_cut_short_by_visual_feedback': agent.monitor_breaks if agent else 0,
        'touch_injection_supported': agent.controller.touch_available if agent and agent.controller else None,
        'storage_problem': brain.storage_problem if brain else None,
        'storage_failures': brain.storage_failures if brain else 0,
        'pending_keyframes': len(brain.frame_backlog) if brain else 0,
        'skipped_keyframes': brain.keyframes_skipped if brain else 0,
        'capture_backend': agent.capture.backend if agent and agent.capture else None,
        'stop_input_channels': agent.listener.mode if agent and agent.listener else None,
        'stop_raw_events': agent.listener.raw_events if agent and agent.listener else 0,
        'stop_hook_events': agent.listener.hook_events if agent and agent.listener else 0,
        'stop_poll_events': agent.stop_gate.poll_stops if agent else 0,
        'stop_registered_channels': dict(agent.listener.registered_channels) if agent and agent.listener else {},
        'stop_registration_problem': agent.listener.registration_error if agent and agent.listener else None,
        'capture_backend_problem': agent.capture.backend_error if agent and agent.capture else None,
        'failures': agent.failure_count if agent else 0,
        'last_rectangle': agent.last_rect if agent else None,
        'learning_note': '代理奖励分离动作可控证据、任务进展证据和训练置信度；世界模型误差采用动作前预测与后续画面的对比。均非游戏服务端真实结果，不能仅凭画面判断胜率。',
        'win_verified': None,
        'model_excerpt_note': '若完整检查点超过容量上限，保存活动游戏的自建模型 FP16 诊断摘录；该摘录不是完整训练状态，不能直接替代检查点。',
    }
    events = list(agent.events) if agent else []
    errors = list(agent.errors) if agent else []
    state = folder / 'learning_state.json.gz'
    delta_state = folder / 'learning_delta.json.gz'
    checkpoint = inspect_checkpoint_bundle(folder)
    checkpoint_files = checkpoint['files']
    checkpoint_total = sum(file.stat().st_size for file in checkpoint_files)
    checkpoint_eligible = bool(checkpoint_files and checkpoint_total <= 920000)
    manifest['checkpoint_bundle'] = {key: value for key, value in checkpoint.items() if key != 'files'}
    runtime = folder / 'runtime_state.json'
    performance = folder / 'runtime_profile.json'
    error_file = folder / 'agent_errors.jsonl'
    manifest['learning_state_bytes'] = state.stat().st_size if state.exists() else 0
    manifest['learning_delta_bytes'] = delta_state.stat().st_size if delta_state.exists() else 0
    excerpt = None
    excerpt_meta = None
    if brain is not None:
        try:
            with brain.lock:
                active = brain.games.get(brain.game_key)
                if active is not None:
                    arrays = [('encoder', brain.encoder), ('encoder_bias', brain.encoder_bias),
                              ('head', active.q), ('head_bias', active.bias)]
                    if active.world_network is not None:
                        arrays.extend(('world_' + name, value) for name, value in active.world_network.items())
                    for kind, parameters in sorted(active.parameter_heads.items(), key=lambda item: item[1]['samples'], reverse=True)[:24]:
                        if parameters['samples'] > 0:
                            arrays.append(('parameter_' + kind + '_weights', parameters['w']))
                            arrays.append(('parameter_' + kind + '_bias', parameters['b']))
                    parts = []
                    layout = []
                    for name, matrix in arrays:
                        numeric = matrix.tolist() if hasattr(matrix, 'tolist') else matrix
                        flat = [float(number) for row in numeric for number in row] if numeric and isinstance(numeric[0], (tuple, list)) else [float(number) for number in numeric]
                        flat = [max(-4.0, min(4.0, value)) if math.isfinite(value) else 0.0 for value in flat]
                        parts.append(struct.pack('<' + 'e' * len(flat), *flat))
                        layout.append({'name': name, 'shape': [len(numeric), len(numeric[0])] if numeric and isinstance(numeric[0], (tuple, list)) else [len(flat)], 'values': len(flat)})
                    excerpt = b''.join(parts)
                    excerpt_meta = {'game': brain.game_key, 'encoding': 'IEEE754-binary16-le', 'layout': layout,
                                    'sha256': hashlib.sha256(excerpt).hexdigest(), 'bytes': len(excerpt),
                                    'checkpoint_step': brain.step, 'checkpoint_updates': brain.updates,
                                    'checkpoint_last_summary': brain.last_checkpoint_summary}
        except Exception as exc:
            manifest['model_excerpt_error'] = f'{type(exc).__name__}: {str(exc)[:140]}'
    def write(include_state, event_count, include_screen, include_log, include_excerpt):
        manifest['archive_contents'] = {
            'checkpoint_included': bool(include_state and checkpoint_eligible),
            'checkpoint_pair_included': bool(include_state and checkpoint_eligible and checkpoint['delta_valid']),
            'checkpoint_restores_latest': bool(include_state and checkpoint_eligible and checkpoint['restores_latest']),
            'learning_delta_included': bool(include_state and checkpoint_eligible and checkpoint['delta_valid']),
            'active_model_excerpt_included': bool(include_excerpt and excerpt is not None),
            'screen_included': bool(include_screen and brain and brain.last_frame),
            'error_log_included': bool(include_log and error_file.exists()),
            'events_included': min(len(events), event_count),
            'events_omitted': max(0, len(events) - event_count),
            'checkpoint_omission': 'invalid_or_missing' if not checkpoint_files else 'size_limit' if not checkpoint_eligible else 'size_budget' if not include_state else None,
            'learning_delta_omission': ('not_found' if not checkpoint['delta_present'] else
                                        'invalid_or_incompatible' if not checkpoint['delta_valid'] else
                                        'size_limit' if not checkpoint_eligible else
                                        'size_budget' if not include_state else None),
            'screen_omission': 'size_budget' if not include_screen and brain and brain.last_frame else 'not_available' if not brain or not brain.last_frame else None,
            'error_log_omission': 'size_budget' if not include_log and error_file.exists() else 'not_found' if not error_file.exists() else None,
            'error_log_tail_truncated': bool(include_log and error_file.exists() and error_file.stat().st_size > 32000),
            'runtime_state_omission': 'not_found' if not runtime.exists() else 'size_limit' if runtime.stat().st_size > 30000 else None,
            'runtime_profile_omission': 'not_found' if not performance.exists() else 'size_limit' if performance.stat().st_size > 30000 else None,
        }
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('report.json', json.dumps(manifest, ensure_ascii=False, indent=2))
            archive.writestr('recent_actions.json', json.dumps(events[-event_count:] if event_count else [], ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_errors.json', json.dumps(errors, ensure_ascii=False, separators=(',', ':')))
            if runtime.exists() and runtime.stat().st_size <= 30000:
                archive.write(runtime, 'runtime_state.json')
            if performance.exists() and performance.stat().st_size <= 30000:
                archive.write(performance, 'runtime_profile.json')
            if include_log and error_file.exists():
                with error_file.open('rb') as stream:
                    start = max(0, error_file.stat().st_size - 32000)
                    stream.seek(start)
                    lines = stream.read(32000)
                    if start:
                        boundary = lines.find(b'\n')
                        lines = lines[boundary + 1:] if boundary >= 0 else b''
                    if lines and not lines.endswith(b'\n'):
                        boundary = lines.rfind(b'\n')
                        lines = lines[:boundary + 1] if boundary >= 0 else b''
                    archive.writestr('error_log_tail.jsonl', lines)
            if include_screen and brain and brain.last_frame:
                archive.writestr('last_screen.png', encode_png(brain.last_frame))
            if include_state and checkpoint_eligible:
                for checkpoint_file in checkpoint_files:
                    archive.write(checkpoint_file, checkpoint_file.name)
            if include_excerpt and excerpt is not None:
                archive.writestr('active_model_fp16.bin', excerpt)
                archive.writestr('active_model_layout.json', json.dumps(excerpt_meta, ensure_ascii=False, separators=(',', ':')))
            if brain:
                with brain.lock:
                    diagnostics = {
                        'steps': brain.step,
                        'updates': brain.updates,
                        'valid_transitions': brain.valid_transitions,
                        'low_information_observations': brain.low_information_observations,
                        'database_pending': len(brain.persist_backlog),
                        'database_dropped': brain.dropped_unpersisted,
                        'pending_terminal_updates': len(brain.terminal_updates),
                        'pending_keyframes': len(brain.frame_backlog),
                        'last_reward': brain.reward_info,
                        'visual_game_routes': {name: [{'id': record.get('key'), 'samples': record.get('samples'), 'anchors': len(record.get('anchors', []))} for record in routes] for name, routes in list(brain.visual_routes.items())[-20:]},
                        'training_problem': brain.training_problem,
                        'database_problem': brain.store_problem,
                        'backend_recoveries': brain.backend_recoveries,
                        'checkpoint_summary': brain.last_checkpoint_summary,
                        'checkpoint_size_bytes': brain.checkpoint_compressed_bytes,
                        'confirmed_screen_results': {key: list(data.confirmed_results.items())[-16:] for key, data in list(brain.games.items())[-16:]},
                        'game_statistics': {key: {'steps': value.game_steps, 'tracked_screens': len(value.visits), 'world_states': len(value.world), 'target_regions': len(value.targets), 'possible_events': len(value.candidate_events), 'learned_hud_trends': len(value.hud_trends), 'calibrated_goal_hypotheses': len(value.goal_hypotheses), 'world_event_contexts': len(value.world_events), 'duration_stats': len(value.duration_stats), 'trained_parameter_heads': {kind: int(head['samples']) for kind, head in value.parameter_heads.items()}, 'spatial_stats': len(value.parameter_stats), 'learned_skills': len(value.skills), 'world_network_steps': value.world_network_steps, 'world_network_error': value.world_network_error, 'tracked_passive_scenes': len(value.passive_scenes), 'prediction_error_mean': value.prediction_error_mean, 'plan_success': value.plan_success, 'screen_outcomes': value.screen_outcomes} for key, value in list(brain.games.items())[-32:]},
                    }
                archive.writestr('learning_diagnostics.json', json.dumps(diagnostics, ensure_ascii=False, separators=(',', ':')))
    try:
        for keep_state, event_count, screen, keep_log, keep_excerpt in (
                (True, 350, True, True, True), (True, 150, False, True, True),
                (True, 35, False, False, False), (False, 350, True, True, True),
                (False, 150, True, True, False), (False, 120, True, False, False),
                (False, 35, False, True, True), (False, 35, False, False, False),
                (False, 0, False, False, False)):
            write(keep_state, event_count, screen, keep_log, keep_excerpt)
            if temp.stat().st_size <= 1_000_000:
                os.replace(temp, final)
                return final
        minimal = {
            'created': manifest['created'], 'mode': mode, 'stop_virtual_key': stop_vk,
            'data_directory': str(folder), 'steps': manifest['steps'],
            'completed_actions': manifest['completed_actions'], 'failures': manifest['failures'],
            'last_error': (errors[-1] if errors else None),
            'note': '压缩包已裁剪为最小诊断信息；学习数据未包含在这个精简黑匣子中，仍位于选定文件夹。',
            'checkpoint_bundle': manifest['checkpoint_bundle'],
        }
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('report.json', json.dumps(minimal, ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_errors.json', json.dumps(errors[-3:], ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_actions.json', json.dumps(events[-12:], ensure_ascii=False, separators=(',', ':')))
            if brain is not None and brain.last_frame is not None:
                archive.writestr('last_screen.png', encode_png(brain.last_frame))
        if temp.stat().st_size <= 1_000_000:
            os.replace(temp, final)
            return final
        with zipfile.ZipFile(temp, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            archive.writestr('report.json', json.dumps(minimal, ensure_ascii=False, separators=(',', ':')))
            archive.writestr('recent_errors.json', json.dumps(errors[-1:], ensure_ascii=False, separators=(',', ':')))
        if temp.stat().st_size <= 1_000_000:
            os.replace(temp, final)
            return final
        raise OSError('精简后的黑匣子仍超过 1 MB')
    finally:
        temp.unlink(missing_ok=True)


class App:
    def __init__(self):
        self.n = Native()
        self.instance = self.n.kernel.GetModuleHandleW(None)
        self.window_callback = WINPROC(self.window_proc)
        self.classname = 'OpenGameAgentSingleFileNativeWindow'
        wc = WNDCLASSW()
        wc.lpfnWndProc = self.window_callback
        wc.hInstance = self.instance
        wc.hCursor = self.n.user.LoadCursorW(None, ctypes.c_void_p(32512))
        wc.hbrBackground = HWND(16)
        wc.lpszClassName = self.classname
        if not self.n.user.RegisterClassW(ctypes.byref(wc)):
            raise OSError('无法注册程序窗口')
        self.hwnd = self.n.user.CreateWindowExW(0, self.classname, '通用游戏 Agent', 0x00CA0000, 180, 140, 650, 330, None, None, self.instance, None)
        if not self.hwnd:
            raise OSError('无法创建主窗口')
        self.folder = None
        self.selected_folder = None
        self.workspace_lease = None
        self.prepared_config = None
        self.preparing_config = None
        self.blackbox_busy = False
        self.pending_release_controller = None
        self.release_repair_active = False
        self.worker = None
        self.numpy = None
        self.runtime_profile = None
        self.preparing = False
        self.ready = False
        self.running = False
        self.agent = None
        self.message = '请选择数据文件夹。'
        self.options = stop_options()
        self.controls = {}
        self.create_controls()
        self.n.user.ShowWindow(self.hwnd, 5)
        self.n.user.UpdateWindow(self.hwnd)
        self.n.user.PostMessageW(self.hwnd, WM_APP_CHOOSE, 0, 0)

    def control(self, name, title, style, x, y, w, h, id):
        hwnd = self.n.user.CreateWindowExW(0, name, title, style | 0x40000000 | 0x10000000, x, y, w, h, self.hwnd, HWND(id), self.instance, None)
        font = self.n.gdi.GetStockObject(17)
        self.n.user.SendMessageW(hwnd, WM_SETFONT, font or 0, 1)
        self.controls[id] = hwnd
        return hwnd

    def add_item(self, hwnd, label):
        text = ctypes.c_wchar_p(label)
        self.n.user.SendMessageW(hwnd, 0x0143, 0, ctypes.cast(text, HWND).value)

    def create_controls(self):
        self.control('STATIC', '游戏 Agent · 本地自主探索与在线学习', 0, 22, 17, 530, 30, 101)
        self.control('BUTTON', '选择文件夹', 0x00010000, 22, 63, 130, 32, 201)
        self.control('STATIC', '尚未选择文件夹', 0, 163, 68, 460, 29, 102)
        self.control('STATIC', 'Agent 操作范围：', 0, 22, 115, 152, 28, 103)
        range_box = self.control('COMBOBOX', '', 0x0003 | 0x00200000 | 0x00010000, 178, 107, 142, 220, 202)
        self.add_item(range_box, '全屏')
        self.add_item(range_box, '窗口')
        self.n.user.SendMessageW(range_box, 0x014E, 0, 0)
        self.control('STATIC', '停止键：', 0, 347, 115, 88, 28, 104)
        stop_box = self.control('COMBOBOX', '', 0x0003 | 0x00200000 | 0x00010000, 440, 107, 162, 220, 203)
        for label, _ in self.options:
            self.add_item(stop_box, label)
        self.n.user.SendMessageW(stop_box, 0x014E, 0, 0)
        self.control('BUTTON', '启动', 0x00010000, 23, 160, 142, 41, 204)
        self.control('BUTTON', '黑匣子', 0x00010000, 187, 160, 142, 41, 205)
        self.control('STATIC', '状态：请选择文件夹，准备完成后启动。', 0, 23, 218, 591, 52, 106)
        self.n.user.EnableWindow(self.controls[204], 0)
        self.n.user.EnableWindow(self.controls[205], 0)

    def set_status(self, message):
        self.message = message
        self.n.user.PostMessageW(self.hwnd, WM_APP_STATUS, 0, 0)

    def chosen_mode(self):
        index = self.n.user.SendMessageW(self.controls[202], 0x0147, 0, 0)
        return '窗口' if index == 1 else '全屏'

    def chosen_stop_key(self):
        index = self.n.user.SendMessageW(self.controls[203], 0x0147, 0, 0)
        return self.options[index][1] if 0 <= index < len(self.options) else 27

    def choose_folder(self):
        if self.running or self.preparing or self.blackbox_busy:
            return
        selected = self.n.folder(self.hwnd)
        if selected is None:
            return
        if selected != self.selected_folder:
            try:
                lease = WorkspaceLease(selected)
            except OSError as exc:
                self.set_status(f'数据目录不可用：{str(exc)[:140]}')
                return
            previous = self.workspace_lease
            self.workspace_lease = lease
            self.selected_folder = selected
            self.folder = lease.folder
            if previous is not None:
                previous.close()
            self.agent = None
            self.numpy = None
            self.runtime_profile = None
        self.n.user.SetWindowTextW(self.controls[102], str(self.folder))
        self.start_prepare()

    def start_prepare(self):
        if self.running or self.preparing or self.blackbox_busy or self.folder is None:
            return
        self.ready = False
        self.prepared_config = None
        self.preparing_config = (self.chosen_mode(), self.chosen_stop_key())
        self.preparing = True
        for number in (201, 202, 203, 204, 205):
            self.n.user.EnableWindow(self.controls[number], 0)
        self.set_status('检查工作目录、运行配置与所需组件…')
        threading.Thread(target=self.prepare, args=(self.preparing_config,), name='Preparation', daemon=True).start()

    def prepare(self, configuration):
        mode, stop_vk = configuration
        try:
            self.folder.mkdir(parents=True, exist_ok=True)
            probe = self.folder / '_agent_write_probe.tmp'
            with probe.open('wb') as stream:
                stream.write(b'ok')
                stream.flush()
                os.fsync(stream.fileno())
            if probe.read_bytes() != b'ok':
                raise OSError('工作目录回读失败')
            probe.unlink()
            verify_local_storage(self.folder, self.n)
            self.numpy = acceleration_for(self.folder, self.set_status)
            self.set_status('正在验证本地推理与训练运算')
            validate_learning_backend(self.numpy)
            self.set_status('正在验证屏幕采集链路')
            capture = Capture(self.n, '全屏', self.hwnd)
            try:
                capture_started = time.perf_counter()
                frame, rect = capture.grab()
                if len(frame) != W * H * 4 or rect[2] < 80 or rect[3] < 80:
                    raise OSError('屏幕采集返回了无效的尺寸')
                detail_frame = capture.grab_detail(rect, 0.5, 0.5)
                if len(detail_frame) != DW * DH * 4:
                    raise OSError('局部高分辨率采集不完整')
                capture_ms = round((time.perf_counter() - capture_started) * 500, 3)
            finally:
                capture.close()
            if mode == '窗口':
                window_probe = Capture(self.n, '窗口', self.hwnd)
                try:
                    window_probe._candidates()
                finally:
                    window_probe.close()
            self.set_status('正在测量离线视觉处理与动作决策速度')
            try:
                self.runtime_profile = profile_runtime(self.folder, self.numpy, capture_ms, stop_vk)
            except Exception:
                fallback = None
                if self.numpy is not None:
                    try:
                        imported = importlib.import_module('numpy')
                        if validate_learning_backend(imported):
                            fallback = imported
                    except Exception:
                        pass
                self.numpy = fallback
                self.runtime_profile = profile_runtime(self.folder, self.numpy, capture_ms, stop_vk)
            self.set_status('正在验证停止键监听初始化')
            probe_listener = StopListener(self.n, stop_vk, threading.Event())
            try:
                probe_listener.start()
                if not probe_listener.healthy():
                    raise OSError('停止键监听和独立轮询的健康检查失败')
            finally:
                probe_listener.close()
            self.set_status('正在验证经验库事务写入、回读及回滚')
            try:
                store = ReplayStore(self.folder)
            except sqlite3.DatabaseError as exc:
                if not quarantine_corrupt_store(self.folder, exc):
                    raise
                store = ReplayStore(self.folder)
            try:
                if not store.verify_roundtrip():
                    raise sqlite3.DatabaseError('经验库回读验证失败')
            finally:
                store.close()
            self.set_status('正在禁用网络测试离线重启、训练、经验持久化及恢复')
            verify_offline_cold_start(self.folder, self.numpy, stop_vk, mode)
            self.runtime_profile['offline_network_blocked_preflight_passed'] = True
            self.runtime_profile['physical_airplane_mode_tested'] = False
            profile = self.folder / 'runtime_profile.json'
            temporary = self.folder / 'runtime_profile.json.tmp'
            with temporary.open('w', encoding='utf-8') as stream:
                json.dump(self.runtime_profile, stream, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, profile)
            estimated = self.runtime_profile['estimated_single_decision_milliseconds']
            self.set_status(f'一切就绪 · 本地离线运行 · 基准决策约 {estimated:.1f} 毫秒（不含采集、训练及游戏延迟）')
            self.prepared_config = configuration
            self.ready = True
        except BaseException as exc:
            self.ready = False
            self.set_status(f'准备失败：{str(exc)[:150]}')
        finally:
            self.preparing = False
            self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)

    def launch(self):
        if not self.ready or self.running or not self.folder or self.blackbox_busy or self.pending_release_controller is not None:
            return
        try:
            mode, stop_vk = self.chosen_mode(), self.chosen_stop_key()
            if (mode, stop_vk) != self.prepared_config:
                self.start_prepare()
                return
            agent = GameAgent(self.n, self.folder, mode, stop_vk, self.hwnd, self.numpy)
            if mode == '窗口':
                next_window = self.n.user.GetWindow(self.hwnd, 2)
                if next_window and next_window != self.hwnd and self.n.user.IsWindow(next_window):
                    agent.window_hint = next_window
            agent.on_input_released = lambda: self.n.user.PostMessageW(self.hwnd, WM_APP_RELEASED, 0, 0)
            agent.ensure_listener()
            if agent.check_stop_fallback():
                agent.listener.close()
                self.set_status('启动被停止键取消；界面保持显示。')
                return
            agent.stop_gate.on_stop = lambda: self.n.user.PostMessageW(self.hwnd, WM_APP_STOP_REQUESTED, 0, 0)
            worker = threading.Thread(target=self.agent_worker, name='GameAgent', daemon=False)
            self.worker = worker
            self.agent = agent
            self.running = True
            self.n.user.ShowWindow(self.hwnd, 0)
            worker.start()
        except Exception as exc:
            self.running = False
            if 'agent' in locals() and agent.listener is not None:
                agent.listener.close()
            self.n.user.ShowWindow(self.hwnd, 5)
            self.set_status(f'启动失败：{str(exc)[:150]}')

    def agent_worker(self):
        try:
            while self.agent is not None and not self.agent.stop_event.is_set():
                current = self.agent
                try:
                    current.run()
                except BaseException as exc:
                    current.error(exc)
                if current.stop_event.is_set():
                    break
                current.error(RuntimeError('运行循环异常退出，正在恢复 Agent'))
                while not current.check_stop_fallback() and not current.input_release_verified:
                    try:
                        if current.controller is None:
                            current.input_release_verified = True
                        else:
                            current.controller.release(retries=5)
                            current.input_release_verified = not (current.controller.down or current.controller.mouse_down or current.controller.touch_points)
                    except Exception as exc:
                        current.error(exc)
                        current.stop_event.wait(0.3)
                if current.stop_event.is_set():
                    break
                recovered = False
                while not current.check_stop_fallback() and not recovered:
                    try:
                        next_agent = GameAgent(self.n, self.folder, current.mode, current.stop_vk, self.hwnd, current.np)
                        next_agent.stop_event = current.stop_event
                        next_agent.stop_gate = current.stop_gate
                        next_agent.on_input_released = current.on_input_released
                        next_agent.window_hint = current.window_hint
                        next_agent.started = current.started
                        next_agent.events.extend(current.events)
                        next_agent.errors.extend(current.errors)
                        next_agent.completed_actions = current.completed_actions
                        next_agent.partial_actions = current.partial_actions
                        next_agent.feedback_captures = current.feedback_captures
                        next_agent.visual_game_switches = current.visual_game_switches
                        next_agent.sensor_frames_total = current.sensor_frames_total
                        next_agent.monitor_breaks = current.monitor_breaks
                        next_agent.capture_target_signature = current.capture_target_signature
                        next_agent.capture_target_pid = current.capture_target_pid
                        next_agent.capture_target_hwnd = current.capture_target_hwnd
                        next_agent.failure_count = current.failure_count
                        next_agent.last_error = current.last_error
                        next_agent.same_error_count = current.same_error_count
                        next_agent.last_capture_at = current.last_capture_at
                        next_agent.last_experience_at = current.last_experience_at
                        next_agent.visual_input_effects = current.visual_input_effects
                        next_agent.episode_boundaries = current.episode_boundaries
                        self.agent = next_agent
                        recovered = True
                    except BaseException as exc:
                        current.error(exc)
                        current.stop_event.wait(min(2.0, 0.1 + current.same_error_count * 0.02))
                if not recovered:
                    break
        finally:
            current = self.agent
            if current is not None and current.controller is not None and not current.input_release_verified:
                self.pending_release_controller = current.controller
            self.n.user.PostMessageW(self.hwnd, WM_APP_STOPPED, 0, 0)

    def repair_release(self, control):
        attempts = 0
        try:
            while self.pending_release_controller is control:
                attempts += 1
                try:
                    control.release(retries=5)
                    if not (control.down or control.mouse_down or control.touch_points):
                        if self.agent is not None:
                            self.agent.input_release_verified = True
                        self.pending_release_controller = None
                        self.n.user.PostMessageW(self.hwnd, WM_APP_RELEASED, 0, 0)
                        return
                except Exception as exc:
                    if self.agent is not None:
                        self.agent.error(exc)
                time.sleep(min(2.0, 0.18 + attempts * 0.06))
        finally:
            self.release_repair_active = False
            self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)

    def export_blackbox(self):
        if not self.folder or self.running or self.blackbox_busy or self.preparing:
            return
        self.blackbox_busy = True
        self.n.user.EnableWindow(self.controls[204], 0)
        self.n.user.EnableWindow(self.controls[205], 0)
        self.n.user.EnableWindow(self.controls[201], 0)
        self.set_status('正在创建黑匣子压缩包…')
        threading.Thread(target=self.export_blackbox_worker,
                         args=(self.folder, self.agent, self.chosen_mode(), self.chosen_stop_key()),
                         name='Blackbox', daemon=True).start()

    def export_blackbox_worker(self, folder, agent, mode, stop_vk):
        com_ready = self.n.ole.CoInitializeEx(None, 2) in (0, 1)
        try:
            path = blackbox(self.n, folder, agent, mode, stop_vk)
            self.set_status(f'黑匣子已保存到桌面：{path.name}（{path.stat().st_size} 字节）')
        except BaseException as exc:
            self.set_status(f'黑匣子创建失败：{str(exc)[:170]}')
        finally:
            if com_ready:
                self.n.ole.CoUninitialize()
            self.blackbox_busy = False
            self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)

    def window_proc(self, hwnd, msg, wp, lp):
        try:
            if msg == WM_COMMAND:
                number, notification = int(wp) & 0xFFFF, int(wp) >> 16
                if notification == 1 and number in (202, 203):
                    if not self.running and not self.preparing and self.folder is not None:
                        self.start_prepare()
                    return 0
                if notification == 0:
                    if number == 201:
                        self.choose_folder()
                    elif number == 204:
                        self.launch()
                    elif number == 205:
                        self.export_blackbox()
                    return 0
            if msg == WM_APP_CHOOSE:
                self.choose_folder()
                return 0
            if msg == WM_APP_STATUS:
                self.n.user.SetWindowTextW(self.controls[106], '状态：' + self.message)
                return 0
            if msg == WM_APP_READY:
                unlocked = not (self.running or self.preparing or self.blackbox_busy)
                for number in (201, 202, 203):
                    self.n.user.EnableWindow(self.controls[number], int(unlocked))
                can_start = unlocked and self.ready and self.pending_release_controller is None
                self.n.user.EnableWindow(self.controls[204], int(can_start))
                self.n.user.EnableWindow(self.controls[205], int(unlocked and self.ready))
                return 0
            if msg == WM_APP_STOP_REQUESTED:
                self.n.user.ShowWindow(self.hwnd, 5)
                self.n.user.UpdateWindow(self.hwnd)
                self.n.user.EnableWindow(self.controls[204], 0)
                self.n.user.EnableWindow(self.controls[205], 0)
                self.set_status('已收到停止键，正在释放输入与保存学习状态…')
                return 0
            if msg == WM_APP_RELEASED:
                self.n.user.ShowWindow(self.hwnd, 5)
                self.n.user.UpdateWindow(self.hwnd)
                if self.running:
                    self.n.user.EnableWindow(self.controls[204], 0)
                    self.n.user.EnableWindow(self.controls[205], 0)
                    self.set_status('输入释放已确认，正在保存学习状态…')
                else:
                    self.set_status('已确认 Agent 输入释放完成。')
                    self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)
                return 0
            if msg == WM_APP_STOPPED:
                self.running = False
                self.n.user.ShowWindow(self.hwnd, 5)
                self.n.user.UpdateWindow(self.hwnd)
                steps = self.agent.brain.step if self.agent and self.agent.brain else 0
                if self.pending_release_controller is not None:
                    self.set_status('已收到停止键；部分输入尚未确认释放，正在自动重试。')
                    if not self.release_repair_active:
                        self.release_repair_active = True
                        threading.Thread(target=self.repair_release,
                                         args=(self.pending_release_controller,), name='InputRelease', daemon=True).start()
                else:
                    self.set_status(f'Agent 已停止操作；累计学习 {steps} 步。')
                self.n.user.PostMessageW(self.hwnd, WM_APP_READY, 0, 0)
                return 0
            if msg == WM_CLOSE:
                if not self.running:
                    self.n.user.DestroyWindow(hwnd)
                return 0
            if msg == WM_DESTROY:
                self.n.user.PostQuitMessage(0)
                return 0
        except BaseException as exc:
            try:
                agent = getattr(self, 'agent', None)
                if agent is not None:
                    agent.error(exc)
                else:
                    folder = getattr(self, 'folder', None)
                    if folder is not None:
                        entry = {'at': time.time(), 'type': type(exc).__name__, 'error': str(exc)[:350],
                                 'phase': 'window_proc', 'message': int(msg), 'trace': traceback.format_exc(limit=8)[-2400:]}
                        with (folder / 'agent_errors.jsonl').open('a', encoding='utf-8') as stream:
                            stream.write(json.dumps(entry, ensure_ascii=False) + '\n')
            except Exception:
                pass
            return self.n.user.DefWindowProcW(hwnd, msg, wp, lp)
        return self.n.user.DefWindowProcW(hwnd, msg, wp, lp)

    def loop(self):
        message = MSG()
        try:
            while True:
                result = self.n.user.GetMessageW(ctypes.byref(message), None, 0, 0)
                if result <= 0:
                    return
                self.n.user.TranslateMessage(ctypes.byref(message))
                self.n.user.DispatchMessageW(ctypes.byref(message))
        finally:
            if self.workspace_lease is not None:
                self.workspace_lease.close()
            if self.n.com_initialized:
                self.n.ole.CoUninitialize()


def main():
    if os.name != 'nt':
        raise SystemExit('本程序需要 Windows 11。')
    try:
        ctypes.WinDLL('kernel32').FreeConsole()
    except Exception:
        pass
    App().loop()


if __name__ == '__main__':
    main()
