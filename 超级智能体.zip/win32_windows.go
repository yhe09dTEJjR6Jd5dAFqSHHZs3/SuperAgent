package main

import (
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"unsafe"
)

const (
	className = "LocalGameAgentMainWindowV2"
	appTitle  = "本地游戏智能体"

	WM_CREATE      = 0x0001
	WM_DESTROY     = 0x0002
	WM_PAINT       = 0x000F
	WM_CLOSE       = 0x0010
	WM_COMMAND     = 0x0111
	WM_SYSCOMMAND  = 0x0112
	WM_HOTKEY      = 0x0312
	WM_APP         = 0x8000
	WM_APP_UPDATE  = WM_APP + 1
	WM_APP_FINISH  = WM_APP + 2
	WM_APP_FRAME   = WM_APP + 3
	SC_CLOSE       = 0xF060
	MF_BYCOMMAND   = 0x00000000
	MF_GRAYED      = 0x00000001
	MF_ENABLED     = 0x00000000
	STOP_HOTKEY_ID = 0x6A31

	WS_OVERLAPPED    = 0x00000000
	WS_CAPTION       = 0x00C00000
	WS_SYSMENU       = 0x00080000
	WS_MINIMIZEBOX   = 0x00020000
	WS_CHILD         = 0x40000000
	WS_VISIBLE       = 0x10000000
	WS_TABSTOP       = 0x00010000
	WS_BORDER        = 0x00800000
	WS_VSCROLL       = 0x00200000
	ES_READONLY      = 0x00000800
	ES_AUTOHSCROLL   = 0x00000080
	CBS_DROPDOWNLIST = 0x0003
	BS_PUSHBUTTON    = 0x00000000

	CB_ADDSTRING    = 0x0143
	CB_RESETCONTENT = 0x014B
	CB_SETCURSEL    = 0x014E
	CB_GETCURSEL    = 0x0147
	CBN_SELCHANGE   = 1
	BN_CLICKED      = 0

	SW_RESTORE           = 9
	SW_SHOW              = 5
	SRCCOPY              = 0x00CC0020
	CAPTUREBLT           = 0x40000000
	DIB_RGB_COLORS       = 0
	BI_RGB               = 0
	PW_RENDERFULLCONTENT = 2
	HALFTONE             = 4
	GA_ROOT              = 2
	WH_KEYBOARD_LL       = 13
	WH_MOUSE_LL          = 14
	LLKHF_INJECTED       = 0x10
	LLMHF_INJECTED       = 0x1
	SM_XVIRTUALSCREEN    = 76
	SM_YVIRTUALSCREEN    = 77
	SM_CXVIRTUALSCREEN   = 78
	SM_CYVIRTUALSCREEN   = 79
	VREFRESH             = 116

	VK_ESCAPE = 0x1B
	VK_F1     = 0x70
	VK_F12    = 0x7B
	VK_PAUSE  = 0x13
	VK_SCROLL = 0x91
	VK_INSERT = 0x2D
	VK_DELETE = 0x2E
	VK_HOME   = 0x24
	VK_END    = 0x23
	VK_PRIOR  = 0x21
	VK_NEXT   = 0x22

	ID_FOLDER_EDIT  = 101
	ID_FOLDER_BTN   = 102
	ID_WINDOW_COMBO = 103
	ID_REFRESH_BTN  = 104
	ID_STOP_COMBO   = 105
	ID_PLAY_BTN     = 106
	ID_AGENT_BTN    = 107
	ID_TRAIN_BTN    = 108
	ID_BLACKBOX_BTN = 109
	ID_STATUS       = 110
	ID_HINT         = 111

	MAX_BLACKBOX_BYTES = 1000000
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")

	pRegisterClassExW              = user32.NewProc("RegisterClassExW")
	pCreateWindowExW               = user32.NewProc("CreateWindowExW")
	pDefWindowProcW                = user32.NewProc("DefWindowProcW")
	pShowWindow                    = user32.NewProc("ShowWindow")
	pDestroyWindow                 = user32.NewProc("DestroyWindow")
	pUpdateWindow                  = user32.NewProc("UpdateWindow")
	pGetMessageW                   = user32.NewProc("GetMessageW")
	pTranslateMessage              = user32.NewProc("TranslateMessage")
	pDispatchMessageW              = user32.NewProc("DispatchMessageW")
	pPostQuitMessage               = user32.NewProc("PostQuitMessage")
	pPostMessageW                  = user32.NewProc("PostMessageW")
	pSendMessageW                  = user32.NewProc("SendMessageW")
	pSetWindowTextW                = user32.NewProc("SetWindowTextW")
	pGetWindowTextW                = user32.NewProc("GetWindowTextW")
	pGetWindowTextLen              = user32.NewProc("GetWindowTextLengthW")
	pGetModuleHandleW              = kernel32.NewProc("GetModuleHandleW")
	pLoadCursorW                   = user32.NewProc("LoadCursorW")
	pGetStockObject                = gdi32.NewProc("GetStockObject")
	pEnableWindow                  = user32.NewProc("EnableWindow")
	pEnumWindows                   = user32.NewProc("EnumWindows")
	pIsWindow                      = user32.NewProc("IsWindow")
	pIsIconic                      = user32.NewProc("IsIconic")
	pIsWindowVisible               = user32.NewProc("IsWindowVisible")
	pGetWindowThreadProcessId      = user32.NewProc("GetWindowThreadProcessId")
	pGetWindowRect                 = user32.NewProc("GetWindowRect")
	pGetClientRect                 = user32.NewProc("GetClientRect")
	pClientToScreen                = user32.NewProc("ClientToScreen")
	pSetForegroundWindow           = user32.NewProc("SetForegroundWindow")
	pGetForegroundWindow           = user32.NewProc("GetForegroundWindow")
	pGetAncestor                   = user32.NewProc("GetAncestor")
	pSetWindowsHookExW             = user32.NewProc("SetWindowsHookExW")
	pUnhookWindowsHookEx           = user32.NewProc("UnhookWindowsHookEx")
	pCallNextHookEx                = user32.NewProc("CallNextHookEx")
	pGetSystemMetrics              = user32.NewProc("GetSystemMetrics")
	pGetDpiForSystem               = user32.NewProc("GetDpiForSystem")
	pSetProcessDpiAwarenessContext = user32.NewProc("SetProcessDpiAwarenessContext")
	pGetSystemMenu                 = user32.NewProc("GetSystemMenu")
	pEnableMenuItem                = user32.NewProc("EnableMenuItem")
	pDrawMenuBar                   = user32.NewProc("DrawMenuBar")
	pMessageBoxW                   = user32.NewProc("MessageBoxW")
	pInvalidateRect                = user32.NewProc("InvalidateRect")
	pBeginPaint                    = user32.NewProc("BeginPaint")
	pEndPaint                      = user32.NewProc("EndPaint")
	pDrawTextW                     = user32.NewProc("DrawTextW")
	pSetTextColor                  = gdi32.NewProc("SetTextColor")
	pSetBkMode                     = gdi32.NewProc("SetBkMode")
	pRectangle                     = gdi32.NewProc("Rectangle")
	pFillRect                      = user32.NewProc("FillRect")
	pStretchDIBits                 = gdi32.NewProc("StretchDIBits")
	pSetStretchBltMode             = gdi32.NewProc("SetStretchBltMode")
	pGetDeviceCaps                 = gdi32.NewProc("GetDeviceCaps")
	pGetDC                         = user32.NewProc("GetDC")
	pReleaseDC                     = user32.NewProc("ReleaseDC")
	pCreateCompatibleDC            = gdi32.NewProc("CreateCompatibleDC")
	pDeleteDC                      = gdi32.NewProc("DeleteDC")
	pCreateDIBSection              = gdi32.NewProc("CreateDIBSection")
	pSelectObject                  = gdi32.NewProc("SelectObject")
	pDeleteObject                  = gdi32.NewProc("DeleteObject")
	pRtlMoveMemory                 = kernel32.NewProc("RtlMoveMemory")
	pStretchBlt                    = gdi32.NewProc("StretchBlt")
	pPrintWindow                   = user32.NewProc("PrintWindow")
	pSendInput                     = user32.NewProc("SendInput")
	pSHBrowseForFolderW            = shell32.NewProc("SHBrowseForFolderW")
	pSHGetPathFromIDListEx         = shell32.NewProc("SHGetPathFromIDListEx")
	pSHGetKnownFolderPath          = shell32.NewProc("SHGetKnownFolderPath")
	pCoTaskMemFree                 = ole32.NewProc("CoTaskMemFree")
	pCoInitializeEx                = ole32.NewProc("CoInitializeEx")
	pCoUninitialize                = ole32.NewProc("CoUninitialize")
	pOpenProcess                   = kernel32.NewProc("OpenProcess")
	pQueryFullProcessImageNameW    = kernel32.NewProc("QueryFullProcessImageNameW")
	pCloseHandle                   = kernel32.NewProc("CloseHandle")
	pMoveFileExW                   = kernel32.NewProc("MoveFileExW")
)

type POINT struct{ X, Y int32 }
type GUID struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}
type KBDLLHOOKSTRUCT struct {
	VkCode    uint32
	ScanCode  uint32
	Flags     uint32
	Time      uint32
	ExtraInfo uintptr
}
type MSLLHOOKSTRUCT struct {
	Pt        POINT
	MouseData uint32
	Flags     uint32
	Time      uint32
	ExtraInfo uintptr
}
type RECT struct{ Left, Top, Right, Bottom int32 }
type MSG struct {
	Hwnd    uintptr
	Message uint32
	_       uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      POINT
	Private uint32
	_2      uint32
}
type WNDCLASSEX struct {
	CbSize     uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   syscall.Handle
	Icon       syscall.Handle
	Cursor     syscall.Handle
	Background syscall.Handle
	MenuName   *uint16
	ClassName  *uint16
	IconSm     syscall.Handle
}
type PAINTSTRUCT struct {
	Hdc       syscall.Handle
	Erase     int32
	Paint     RECT
	Restore   int32
	IncUpdate int32
	Reserved  [32]byte
}
type BITMAPINFOHEADER struct {
	Size          uint32
	Width         int32
	Height        int32
	Planes        uint16
	BitCount      uint16
	Compression   uint32
	SizeImage     uint32
	XPelsPerMeter int32
	YPelsPerMeter int32
	ClrUsed       uint32
	ClrImportant  uint32
}
type RGBQUAD struct{ Blue, Green, Red, Reserved byte }
type BITMAPINFO struct {
	Header BITMAPINFOHEADER
	Colors [1]RGBQUAD
}
type KEYBDINPUT struct {
	Vk        uint16
	Scan      uint16
	Flags     uint32
	Time      uint32
	ExtraInfo uintptr
}
type MOUSEINPUT struct {
	Dx        int32
	Dy        int32
	MouseData uint32
	Flags     uint32
	Time      uint32
	ExtraInfo uintptr
}
type INPUT struct {
	Type uint32
	Pad  uint32
	Data [32]byte
}
type BROWSEINFO struct {
	HwndOwner   uintptr
	PidlRoot    uintptr
	DisplayName *uint16
	Title       *uint16
	Flags       uint32
	Callback    uintptr
	LParam      uintptr
	Image       int32
}

func utf16(s string) *uint16 {
	p, _ := syscall.UTF16PtrFromString(s)
	return p
}

func scaleCoord(value int32) int32 {
	return int32(math.Round(float64(value) * uiScale))
}

func callCreate(class, title string, style uint32, x, y, w, h int32, parent uintptr, id uintptr) uintptr {
	cw := utf16(class)
	tw := utf16(title)
	r, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cw)), uintptr(unsafe.Pointer(tw)), uintptr(style), uintptr(scaleCoord(x)), uintptr(scaleCoord(y)), uintptr(scaleCoord(w)), uintptr(scaleCoord(h)), parent, id, uintptr(getInstance()), 0)
	runtime.KeepAlive(cw)
	runtime.KeepAlive(tw)
	return r
}

func getInstance() syscall.Handle {
	r, _, _ := pGetModuleHandleW.Call(0)
	return syscall.Handle(r)
}

func sendMsg(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	r, _, _ := pSendMessageW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func setText(hwnd uintptr, s string) {
	p := utf16(s)
	pSetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(p)))
	runtime.KeepAlive(p)
}

func addCombo(hwnd uintptr, s string) {
	p := utf16(s)
	sendMsg(hwnd, CB_ADDSTRING, 0, uintptr(unsafe.Pointer(p)))
	runtime.KeepAlive(p)
}

func messageBox(hwnd uintptr, text, caption string, flags uintptr) {
	t := utf16(text)
	c := utf16(caption)
	pMessageBoxW.Call(hwnd, uintptr(unsafe.Pointer(t)), uintptr(unsafe.Pointer(c)), flags)
	runtime.KeepAlive(t)
	runtime.KeepAlive(c)
}

func extendedWindowsPath(path string) string {
	abs, err := filepath.Abs(path)
	if err != nil {
		abs = path
	}
	if strings.HasPrefix(abs, `\\?\`) {
		return abs
	}
	if strings.HasPrefix(abs, `\\`) {
		return `\\?\UNC\` + strings.TrimPrefix(abs, `\\`)
	}
	return `\\?\` + abs
}

func atomicWriteFile(path string, data []byte, mode os.FileMode) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	tmp := path + ".tmp"
	f, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, mode)
	if err != nil {
		return err
	}
	if _, err = f.Write(data); err == nil {
		err = f.Sync()
	}
	closeErr := f.Close()
	if err != nil {
		_ = os.Remove(tmp)
		return err
	}
	if closeErr != nil {
		_ = os.Remove(tmp)
		return closeErr
	}
	if _, statErr := os.Stat(path); statErr == nil {
		if err := copyBackupAtomic(path, path+".bak"); err != nil {
			_ = os.Remove(tmp)
			return fmt.Errorf("更新上一版本备份失败：%w", err)
		}
	}
	from, _ := syscall.UTF16PtrFromString(extendedWindowsPath(tmp))
	to, _ := syscall.UTF16PtrFromString(extendedWindowsPath(path))
	ok, _, callErr := pMoveFileExW.Call(uintptr(unsafe.Pointer(from)), uintptr(unsafe.Pointer(to)), 0x1|0x8)
	runtime.KeepAlive(from)
	runtime.KeepAlive(to)
	if ok == 0 {
		_ = os.Remove(tmp)
		if callErr != syscall.Errno(0) {
			return callErr
		}
		return fmt.Errorf("MoveFileExW 替换文件失败")
	}
	return nil
}

func copyBackupAtomic(source, backup string) error {
	src, err := os.Open(source)
	if err != nil {
		return err
	}
	defer src.Close()
	tmp := backup + ".tmp"
	dst, err := os.OpenFile(tmp, os.O_CREATE|os.O_TRUNC|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	_, copyErr := io.Copy(dst, src)
	if copyErr == nil {
		copyErr = dst.Sync()
	}
	closeErr := dst.Close()
	if copyErr != nil {
		_ = os.Remove(tmp)
		return copyErr
	}
	if closeErr != nil {
		_ = os.Remove(tmp)
		return closeErr
	}
	from, _ := syscall.UTF16PtrFromString(extendedWindowsPath(tmp))
	to, _ := syscall.UTF16PtrFromString(extendedWindowsPath(backup))
	ok, _, callErr := pMoveFileExW.Call(uintptr(unsafe.Pointer(from)), uintptr(unsafe.Pointer(to)), 0x1|0x8)
	runtime.KeepAlive(from)
	runtime.KeepAlive(to)
	if ok == 0 {
		_ = os.Remove(tmp)
		if callErr != syscall.Errno(0) {
			return callErr
		}
		return fmt.Errorf("无法替换备份文件")
	}
	return nil
}

func processImagePath(pid uint32) string {
	const processQueryLimitedInformation = 0x1000
	h, _, _ := pOpenProcess.Call(processQueryLimitedInformation, 0, uintptr(pid))
	if h == 0 {
		return ""
	}
	defer pCloseHandle.Call(h)
	buf := make([]uint16, 32768)
	size := uint32(len(buf))
	ok, _, _ := pQueryFullProcessImageNameW.Call(h, 0, uintptr(unsafe.Pointer(&buf[0])), uintptr(unsafe.Pointer(&size)))
	if ok == 0 || size == 0 {
		return ""
	}
	return syscall.UTF16ToString(buf[:size])
}

func targetPID(hwnd uintptr) uint32 {
	var pid uint32
	pGetWindowThreadProcessId.Call(hwnd, uintptr(unsafe.Pointer(&pid)))
	return pid
}

func targetIsForeground(hwnd uintptr, pid uint32) bool {
	fg, _, _ := pGetForegroundWindow.Call()
	if fg == 0 {
		return false
	}
	root, _, _ := pGetAncestor.Call(fg, GA_ROOT)
	if root == 0 {
		root = fg
	}
	if root != hwnd {
		return false
	}
	return targetPID(root) == pid
}
