module local.gameagent/win11

go 1.22
