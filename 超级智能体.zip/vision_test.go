package main

import "testing"

func TestVisualFeatureAveragesAndTracksMotion(t *testing.T) {
	const w, h = 120, 90
	frame := make([]byte, w*h*4)
	for i := 0; i < w*h; i++ {
		frame[i*4+0] = 20
		frame[i*4+1] = 40
		frame[i*4+2] = 200
		frame[i*4+3] = 255
	}
	first, change := visualFeature(frame, w, h, nil)
	if len(first) == 0 {
		t.Fatal("feature vector should not be empty")
	}
	if change != 0 {
		t.Fatalf("first-frame change=%f", change)
	}
	secondFrame := append([]byte(nil), frame...)
	for i := 0; i < w*h/2; i++ {
		secondFrame[i*4+0] = 240
		secondFrame[i*4+1] = 240
		secondFrame[i*4+2] = 240
	}
	second, change := visualFeature(secondFrame, w, h, first)
	if change <= 0 {
		t.Fatal("expected nonzero motion/change metric")
	}
	if featureHash(first) == featureHash(second) {
		t.Fatal("different frames should have different feature hashes")
	}
}

func TestVisualFeatureHandlesInvalidFrame(t *testing.T) {
	feature, change := visualFeature(nil, 0, 0, nil)
	if len(feature) != 0 {
		t.Fatal("invalid frame should not produce a feature vector")
	}
	if change != 0 {
		t.Fatalf("change=%f", change)
	}
}
