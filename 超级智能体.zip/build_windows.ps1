$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$go = Get-Command go -ErrorAction SilentlyContinue
if (-not $go) {
    throw 'Go 1.22 or newer is required to rebuild this project.'
}
& go test ./...
if ($LASTEXITCODE -ne 0) { throw 'Tests failed.' }
& go vet -unsafeptr=false ./...
if ($LASTEXITCODE -ne 0) { throw 'Static analysis failed.' }
$env:GOOS = 'windows'
$env:GOARCH = 'amd64'
$env:CGO_ENABLED = '0'
& go build -trimpath -ldflags='-s -w -H=windowsgui' -o GameAgent.exe .
if ($LASTEXITCODE -ne 0) { throw 'Windows x64 build failed.' }
