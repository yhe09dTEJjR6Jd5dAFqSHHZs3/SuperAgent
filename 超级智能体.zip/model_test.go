package main

import (
	"encoding/json"
	"math"
	"math/rand"
	"path/filepath"
	"testing"
)

func TestModelStoresObservedActionAverage(t *testing.T) {
	m := newModel([]string{"idle", "left"})
	m.update(10, 1, 11, 1)
	m.update(10, 1, 12, 0.5)
	m.mu.Lock()
	value := m.Q[10][1]
	count := m.ActionVisits[10][1]
	m.mu.Unlock()
	if math.Abs(value-0.75) > 1e-9 {
		t.Fatalf("mean response=%f, want 0.75", value)
	}
	if count != 2 {
		t.Fatalf("action visits=%d, want 2", count)
	}
}

func TestModelChooseDoesNotAlwaysSelectFirstAction(t *testing.T) {
	m := newModel([]string{"idle", "left", "right"})
	rng := rand.New(rand.NewSource(42))
	seen := make(map[int]bool)
	for range 100 {
		seen[m.choose(1, false, rng)] = true
	}
	if len(seen) < 2 {
		t.Fatalf("tie-breaking did not explore alternatives: %v", seen)
	}
}

func TestTrainingPolicySelectsUntriedActions(t *testing.T) {
	m := newModel([]string{"idle", "left", "right"})
	rng := rand.New(rand.NewSource(7))
	m.update(1, 0, 2, 0.1)
	selected := m.choose(1, true, rng)
	if selected == 0 {
		t.Fatalf("training policy selected an already tried action: %d", selected)
	}
}

func TestDecodeLegacyModelMigratesToExpandedActionSet(t *testing.T) {
	legacy := ModelDisk{Version: 1, Q: map[uint64][]float64{42: {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}}, Visits: map[uint64]uint32{42: 3}}
	data, err := json.Marshal(legacy)
	if err != nil {
		t.Fatal(err)
	}
	current := actionNames(defaultActions())
	m, err := decodeModel(data, current)
	if err != nil {
		t.Fatal(err)
	}
	if len(m.Q[42]) != len(current) {
		t.Fatalf("migrated Q length=%d, want %d", len(m.Q[42]), len(current))
	}
	if m.Q[42][10] != 10 {
		t.Fatalf("legacy action value not preserved: %f", m.Q[42][10])
	}
	if m.Q[42][11] != 0 {
		t.Fatalf("new action should start at zero: %f", m.Q[42][11])
	}
	if m.Visits[42] != 3 {
		t.Fatalf("visit count = %d", m.Visits[42])
	}
}

func TestDecodeVersionTwoModelMigratesWithoutActionCounts(t *testing.T) {
	legacy := ModelDisk{Version: 2, Actions: []string{"idle", "left"}, Q: map[uint64][]float64{7: {0.2, 0.8}}}
	data, err := json.Marshal(legacy)
	if err != nil {
		t.Fatal(err)
	}
	m, err := decodeModel(data, []string{"idle", "left", "right"})
	if err != nil {
		t.Fatal(err)
	}
	if m.Q[7][1] != 0.8 || len(m.ActionVisits[7]) != 0 {
		t.Fatalf("unexpected migrated model: %#v %#v", m.Q[7], m.ActionVisits[7])
	}
}

func TestDecodeRejectsMalformedQTable(t *testing.T) {
	d := ModelDisk{Version: modelVersion, Actions: []string{"idle", "left"}, Q: map[uint64][]float64{1: {0}}}
	data, _ := json.Marshal(d)
	if _, err := decodeModel(data, []string{"idle", "left"}); err == nil {
		t.Fatal("expected malformed Q vector to be rejected")
	}
	data = []byte(`{"version":3,"actions":["idle","left"],"q":{"1":[0,NaN]}}`)
	if _, err := decodeModel(data, []string{"idle", "left"}); err == nil {
		t.Fatal("expected invalid JSON number to be rejected")
	}
}

func TestModelSaveLoadRoundTrip(t *testing.T) {
	path := filepath.Join(t.TempDir(), "agent_model.json")
	m := newModel([]string{"idle", "left"})
	m.update(1, 1, 2, 0.75)
	m.markVisited(1)
	if err := m.save(path); err != nil {
		t.Fatal(err)
	}
	loaded, err := loadModel(path, []string{"idle", "left", "right"})
	if err != nil {
		t.Fatal(err)
	}
	if len(loaded.Q[1]) != 3 {
		t.Fatalf("loaded Q length=%d", len(loaded.Q[1]))
	}
	if loaded.Q[1][1] != 0.75 {
		t.Fatalf("expected saved Q value, got %f", loaded.Q[1][1])
	}
	if loaded.ActionVisits[1][1] != 1 {
		t.Fatalf("action visit count=%d", loaded.ActionVisits[1][1])
	}
}
