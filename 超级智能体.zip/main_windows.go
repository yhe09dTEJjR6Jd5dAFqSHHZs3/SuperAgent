package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math/rand"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

type WindowInfo struct {
	Hwnd    uintptr
	Title   string
	PID     uint32
	ExePath string
}

type StopKeyOption struct {
	Name string
	VK   uint16
}

type App struct {
	hwnd              uintptr
	folder            string
	target            uintptr
	targetPID         uint32
	targetTitle       string
	targetExePath     string
	profileDir        string
	modelPath         string
	profileName       string
	windows           []WindowInfo
	actions           []Action
	model             *Model
	active            atomic.Bool
	stopRequested     atomic.Bool
	mode              string
	stopVK            uint16
	stopName          string
	mu                sync.Mutex
	frame             []byte
	frameW, frameH    int
	status            string
	events            []string
	steps             uint64
	lastAction        string
	lastReward        float64
	folderEdit        uintptr
	windowCombo       uintptr
	stopCombo         uintptr
	statusLabel       uintptr
	hintLabel         uintptr
	folderButton      uintptr
	refreshButton     uintptr
	playButton        uintptr
	agentButton       uintptr
	trainButton       uintptr
	blackboxButton    uintptr
	stopKeys          []StopKeyOption
	lastSaveError     string
	lastRecoveryError string
	eventsBytes       int
}

var app *App
var uiScale = 1.0

func recordEvent(s string) {
	if app == nil {
		return
	}
	event := time.Now().Format(time.RFC3339Nano) + " " + s
	app.mu.Lock()
	app.events = append(app.events, event)
	app.eventsBytes += len(event)
	for app.eventsBytes > MAX_BLACKBOX_BYTES && len(app.events) > 0 {
		app.eventsBytes -= len(app.events[0])
		app.events = app.events[1:]
	}
	app.mu.Unlock()
}

func postStatus(s string) {
	if app == nil {
		return
	}
	app.mu.Lock()
	app.status = s
	app.mu.Unlock()
	if app.hwnd != 0 {
		pPostMessageW.Call(app.hwnd, WM_APP_UPDATE, 0, 0)
	}
}

func postFrame(frame []byte, w, h int) {
	app.mu.Lock()
	app.frame = append(app.frame[:0], frame...)
	app.frameW, app.frameH = w, h
	app.mu.Unlock()
	if app.hwnd != 0 {
		pPostMessageW.Call(app.hwnd, WM_APP_FRAME, 0, 0)
	}
}

func updateStatusUI() {
	app.mu.Lock()
	s := app.status
	app.mu.Unlock()
	if app.statusLabel != 0 {
		setText(app.statusLabel, s)
	}
}

func updateHintUI() {
	if app.hintLabel == 0 {
		return
	}
	app.mu.Lock()
	steps, action, reward := app.steps, app.lastAction, app.lastReward
	app.mu.Unlock()
	states := 0
	if app.model != nil {
		states = app.model.stateCount()
	}
	setText(app.hintLabel, fmt.Sprintf("观察步数：%d  |  已学习状态：%d  |  最近动作：%s  |  视觉响应：%.3f", steps, states, action, reward))
}

func createControls(hwnd uintptr) {
	font, _, _ := pGetStockObject.Call(17)
	mk := func(class, title string, style uint32, x, y, w, h int32, id uintptr) uintptr {
		handle := callCreate(class, title, WS_CHILD|WS_VISIBLE|style, x, y, w, h, hwnd, id)
		if handle != 0 {
			sendMsg(handle, 0x0030, font, 1)
		}
		return handle
	}
	mk("STATIC", "纯本地游戏智能体 · 无云端服务 · 无第三方 AI 模型", 0, 20, 14, 900, 26, 0)
	mk("STATIC", "工作目录：", 0, 20, 50, 90, 24, 0)
	app.folderEdit = mk("EDIT", "", WS_BORDER|ES_READONLY|ES_AUTOHSCROLL, 112, 47, 650, 28, ID_FOLDER_EDIT)
	app.folderButton = mk("BUTTON", "选择文件夹…", BS_PUSHBUTTON|WS_TABSTOP, 775, 47, 155, 28, ID_FOLDER_BTN)
	mk("STATIC", "目标游戏窗口：", 0, 20, 91, 100, 24, 0)
	app.windowCombo = mk("COMBOBOX", "", CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP, 112, 87, 650, 240, ID_WINDOW_COMBO)
	app.refreshButton = mk("BUTTON", "刷新窗口", BS_PUSHBUTTON|WS_TABSTOP, 775, 87, 155, 28, ID_REFRESH_BTN)
	mk("STATIC", "停止键：", 0, 20, 132, 80, 24, 0)
	app.stopCombo = mk("COMBOBOX", "", CBS_DROPDOWNLIST|WS_VSCROLL|WS_TABSTOP, 112, 128, 180, 260, ID_STOP_COMBO)
	mk("STATIC", "运行期间全局生效；停止键不会发送给游戏。", 0, 310, 131, 590, 24, 0)
	app.playButton = mk("BUTTON", "用户玩游戏", BS_PUSHBUTTON|WS_TABSTOP, 20, 174, 200, 40, ID_PLAY_BTN)
	app.agentButton = mk("BUTTON", "Agent 玩游戏", BS_PUSHBUTTON|WS_TABSTOP, 236, 174, 200, 40, ID_AGENT_BTN)
	app.trainButton = mk("BUTTON", "Agent 自主训练", BS_PUSHBUTTON|WS_TABSTOP, 452, 174, 200, 40, ID_TRAIN_BTN)
	app.blackboxButton = mk("BUTTON", "生成桌面黑匣子", BS_PUSHBUTTON|WS_TABSTOP, 668, 174, 262, 40, ID_BLACKBOX_BTN)
	app.statusLabel = mk("STATIC", "先选择工作目录，再刷新并手动选择游戏窗口。", WS_BORDER, 20, 226, 910, 30, ID_STATUS)
	app.hintLabel = mk("STATIC", "观察步数：0 | 已学习状态：0 | 最近动作：无", 0, 20, 264, 910, 24, ID_HINT)
	mk("STATIC", "目标窗口实时画面", 0, 20, 299, 500, 20, 0)
	mk("STATIC", "Agent 运行期间会屏蔽物理键鼠输入；所选停止键始终可用。", 0, 20, 632, 910, 24, 0)

	app.stopKeys = buildStopKeyOptions()
	for _, k := range app.stopKeys {
		addCombo(app.stopCombo, k.Name)
	}
	sendMsg(app.stopCombo, CB_SETCURSEL, 0, 0)
	app.stopVK, app.stopName = VK_ESCAPE, "ESC"
}

func buildStopKeyOptions() []StopKeyOption {
	keys := []StopKeyOption{{"ESC（默认）", VK_ESCAPE}, {"BACKSPACE", 0x08}, {"CAPS LOCK", 0x14}, {"PRINT SCREEN", 0x2C}, {"NUM LOCK", 0x90}}
	for i := 1; i <= 24; i++ {
		keys = append(keys, StopKeyOption{fmt.Sprintf("F%d", i), uint16(0x6F + i)})
	}
	for c := 'A'; c <= 'Z'; c++ {
		keys = append(keys, StopKeyOption{string(c), uint16(c)})
	}
	for c := '0'; c <= '9'; c++ {
		keys = append(keys, StopKeyOption{string(c), uint16(c)})
	}
	keys = append(keys,
		StopKeyOption{"左方向键", 0x25}, StopKeyOption{"上方向键", 0x26}, StopKeyOption{"右方向键", 0x27}, StopKeyOption{"下方向键", 0x28},
		StopKeyOption{"空格", 0x20}, StopKeyOption{"回车", 0x0D}, StopKeyOption{"TAB", 0x09},
		StopKeyOption{"PAUSE", VK_PAUSE}, StopKeyOption{"SCROLL LOCK", VK_SCROLL}, StopKeyOption{"INSERT", VK_INSERT},
		StopKeyOption{"DELETE", VK_DELETE}, StopKeyOption{"HOME", VK_HOME}, StopKeyOption{"END", VK_END},
		StopKeyOption{"PAGE UP", VK_PRIOR}, StopKeyOption{"PAGE DOWN", VK_NEXT},
		StopKeyOption{"NUMPAD 0", 0x60}, StopKeyOption{"NUMPAD 1", 0x61}, StopKeyOption{"NUMPAD 2", 0x62},
		StopKeyOption{"NUMPAD 3", 0x63}, StopKeyOption{"NUMPAD 4", 0x64}, StopKeyOption{"NUMPAD 5", 0x65},
		StopKeyOption{"NUMPAD 6", 0x66}, StopKeyOption{"NUMPAD 7", 0x67}, StopKeyOption{"NUMPAD 8", 0x68},
		StopKeyOption{"NUMPAD 9", 0x69}, StopKeyOption{"NUMPAD *", 0x6A}, StopKeyOption{"NUMPAD +", 0x6B},
		StopKeyOption{"NUMPAD -", 0x6D}, StopKeyOption{"NUMPAD .", 0x6E}, StopKeyOption{"NUMPAD /", 0x6F}, StopKeyOption{"NUMPAD SEPARATOR", 0x6C},
		StopKeyOption{"OEM ;", 0xBA}, StopKeyOption{"OEM =", 0xBB}, StopKeyOption{"OEM ,", 0xBC},
		StopKeyOption{"OEM -", 0xBD}, StopKeyOption{"OEM .", 0xBE}, StopKeyOption{"OEM /", 0xBF},
		StopKeyOption{"OEM `", 0xC0}, StopKeyOption{"OEM [", 0xDB}, StopKeyOption{"OEM \\", 0xDC},
		StopKeyOption{"OEM ]", 0xDD}, StopKeyOption{"OEM '", 0xDE}, StopKeyOption{"OEM_8", 0xDF})
	return keys
}

func chooseFolder() {
	var display [32768]uint16
	title := utf16("请选择 Agent 数据存放目录（模型、配置和运行数据只写入此目录）")
	bi := BROWSEINFO{HwndOwner: app.hwnd, DisplayName: &display[0], Title: title, Flags: 0x0001 | 0x0040}
	pidl, _, _ := pSHBrowseForFolderW.Call(uintptr(unsafe.Pointer(&bi)))
	runtime.KeepAlive(title)
	runtime.KeepAlive(display)
	if pidl == 0 {
		return
	}
	path := make([]uint16, 32768)
	ok, _, _ := pSHGetPathFromIDListEx.Call(pidl, uintptr(unsafe.Pointer(&path[0])), uintptr(len(path)), 0)
	pCoTaskMemFree.Call(pidl)
	if ok == 0 {
		messageBox(app.hwnd, "无法读取所选目录。", appTitle, 0x10)
		return
	}
	folder := syscall.UTF16ToString(path)
	if folder == "" {
		return
	}
	if err := os.MkdirAll(folder, 0700); err != nil {
		messageBox(app.hwnd, "无法访问所选目录："+err.Error(), appTitle, 0x10)
		return
	}
	app.folder = folder
	app.model = nil
	setText(app.folderEdit, folder)
	postStatus("工作目录已就绪。模型、动作配置和运行数据将在此目录内按游戏分别保存。")
	recordEvent("选择工作目录")
}

func enumerateWindows() []WindowInfo {
	wins := make([]WindowInfo, 0, 32)
	cb := syscall.NewCallback(func(hwnd, lParam uintptr) uintptr {
		if hwnd == app.hwnd {
			return 1
		}
		visible, _, _ := pIsWindowVisible.Call(hwnd)
		if visible == 0 {
			return 1
		}
		length, _, _ := pGetWindowTextLen.Call(hwnd)
		if length == 0 || length > 500 {
			return 1
		}
		buf := make([]uint16, length+1)
		got, _, _ := pGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		if got == 0 {
			return 1
		}
		pid := targetPID(hwnd)
		title := syscall.UTF16ToString(buf)
		if strings.TrimSpace(title) == "" || title == appTitle {
			return 1
		}
		wins = append(wins, WindowInfo{Hwnd: hwnd, Title: title, PID: pid, ExePath: processImagePath(pid)})
		return 1
	})
	pEnumWindows.Call(cb, 0)
	runtime.KeepAlive(cb)
	return wins
}

func refreshWindows() {
	app.windows = enumerateWindows()
	sendMsg(app.windowCombo, CB_RESETCONTENT, 0, 0)
	for _, w := range app.windows {
		addCombo(app.windowCombo, fmt.Sprintf("[%d] %s", w.PID, w.Title))
	}
	sendMsg(app.windowCombo, CB_SETCURSEL, ^uintptr(0), 0)
	app.target, app.targetPID, app.targetTitle, app.targetExePath = 0, 0, "", ""
	if len(app.windows) > 0 {
		postStatus(fmt.Sprintf("发现 %d 个可见窗口；请从列表中手动选择目标游戏窗口。", len(app.windows)))
	} else {
		postStatus("未发现可见窗口。请先打开游戏，再刷新窗口列表。")
	}
}

func selectWindowFromCombo() {
	idx := int(sendMsg(app.windowCombo, CB_GETCURSEL, 0, 0))
	if idx < 0 || idx >= len(app.windows) {
		return
	}
	w := app.windows[idx]
	if !pIsWindowResult(w.Hwnd) || targetPID(w.Hwnd) != w.PID {
		postStatus("窗口已失效，请刷新窗口列表。")
		return
	}
	app.windows[idx] = w
	app.target, app.targetPID, app.targetTitle, app.targetExePath = w.Hwnd, w.PID, w.Title, w.ExePath
	if w.ExePath != "" {
		postStatus("目标已选择：" + w.Title + " | " + filepath.Base(w.ExePath))
	} else {
		postStatus("目标已选择：" + w.Title + " | 无法读取进程路径，将使用窗口标题建立档案")
	}
	recordEvent("选择目标窗口：" + w.Title)
}

func selectStopKey() {
	idx := int(sendMsg(app.stopCombo, CB_GETCURSEL, 0, 0))
	if idx >= 0 && idx < len(app.stopKeys) {
		app.stopVK, app.stopName = app.stopKeys[idx].VK, strings.TrimSuffix(app.stopKeys[idx].Name, "（默认）")
	}
}

func profileDirectory(folder, exePath, title string) (string, string) {
	identity := strings.ToLower(strings.TrimSpace(exePath))
	base := "game"
	if exePath != "" {
		base = strings.TrimSuffix(filepath.Base(exePath), filepath.Ext(exePath))
	} else {
		identity = "window-title:" + strings.ToLower(strings.TrimSpace(title))
		base = title
	}
	if identity == "" {
		identity = "unknown-game"
	}
	var safe strings.Builder
	for _, r := range strings.ToLower(base) {
		if r >= 'a' && r <= 'z' || r >= '0' && r <= '9' || r == '-' || r == '_' {
			safe.WriteRune(r)
		} else if r > 127 {
			safe.WriteByte('_')
		}
		if safe.Len() >= 24 {
			break
		}
	}
	name := strings.Trim(safe.String(), "_")
	if name == "" {
		name = "game"
	}
	sum := sha256.Sum256([]byte(identity))
	profile := name + "_" + hex.EncodeToString(sum[:6])
	return filepath.Join(folder, "models", profile), profile
}

func quarantineFile(path string) string {
	if _, err := os.Stat(path); err != nil {
		return ""
	}
	backup := path + ".corrupt_" + time.Now().Format("20060102_150405_000000000")
	if err := os.Rename(path, backup); err != nil {
		return ""
	}
	return backup
}

func loadProfileModel(profileDir, folder string, names []string) (*Model, string, error) {
	path := filepath.Join(profileDir, "agent_model.json")
	model, err := loadModel(path, names)
	if err == nil {
		return model, path, nil
	}
	var notes []string
	if !os.IsNotExist(err) {
		if moved := quarantineFile(path); moved != "" {
			notes = append(notes, "损坏模型已隔离备份")
		} else if _, statErr := os.Stat(path); statErr == nil {
			return nil, path, fmt.Errorf("模型文件损坏且无法隔离；为避免覆盖原文件，已取消启动")
		}
	}

	backupPath := path + ".bak"
	backupModel, backupErr := loadModel(backupPath, names)
	if backupErr == nil {
		restoreErr := backupModel.save(path)
		message := "已从 .bak 恢复模型"
		if restoreErr != nil {
			message += "，但恢复写入失败：" + restoreErr.Error()
		}
		if len(notes) > 0 {
			message += "；" + strings.Join(notes, "；")
		}
		return backupModel, path, fmt.Errorf("%s", message)
	}
	if _, statErr := os.Stat(backupPath); statErr == nil && backupErr != nil {
		if moved := quarantineFile(backupPath); moved != "" {
			notes = append(notes, "损坏备份已隔离")
		} else if _, stillExists := os.Stat(backupPath); stillExists == nil {
			return nil, path, fmt.Errorf("模型备份损坏且无法隔离；为避免覆盖原文件，已取消启动")
		}
	}

	legacyPath := filepath.Join(folder, "agent_model.json")
	if legacy, legacyErr := loadModel(legacyPath, names); legacyErr == nil {
		saveErr := legacy.save(path)
		message := "已将旧版共享模型迁移到当前游戏独立档案"
		if saveErr != nil {
			message += "，但迁移写入失败：" + saveErr.Error()
		}
		if len(notes) > 0 {
			message += "；" + strings.Join(notes, "；")
		}
		return legacy, path, fmt.Errorf("%s", message)
	} else if !os.IsNotExist(legacyErr) {
		if moved := quarantineFile(legacyPath); moved != "" {
			notes = append(notes, "旧版损坏模型已隔离")
		} else if _, stillExists := os.Stat(legacyPath); stillExists == nil {
			notes = append(notes, "旧版损坏模型无法隔离，已保留原文件")
		}
	}
	if len(notes) > 0 {
		return newModel(names), path, fmt.Errorf("%s；已初始化新模型", strings.Join(notes, "；"))
	}
	return newModel(names), path, nil
}

func startAgent(mode string) {
	if app.active.Load() {
		return
	}
	if app.folder == "" {
		messageBox(app.hwnd, "请先选择工作目录。", appTitle, 0x30)
		return
	}
	if app.target == 0 || !pIsWindowResult(app.target) || targetPID(app.target) != app.targetPID {
		messageBox(app.hwnd, "请先刷新并手动选择一个有效的游戏窗口。", appTitle, 0x30)
		return
	}
	selectStopKey()
	var actions []Action
	var model *Model
	var modelPath, profileDir, profileName, recoveryNote string
	if mode != "human" {
		profileDir, profileName = profileDirectory(app.folder, app.targetExePath, app.targetTitle)
		if err := os.MkdirAll(profileDir, 0700); err != nil {
			messageBox(app.hwnd, "无法创建游戏档案目录："+err.Error(), appTitle, 0x10)
			return
		}
		var created bool
		var actionErr error
		actions, created, actionErr = loadActions(actionConfigPath(profileDir), app.stopVK)
		if actionErr != nil {
			messageBox(app.hwnd, "动作配置无效，未启动 Agent：\n"+actionErr.Error()+"\n\n请更换停止键，或修复所选游戏档案中的动作配置。", appTitle, 0x10)
			return
		}
		var modelNote error
		model, modelPath, modelNote = loadProfileModel(profileDir, app.folder, actionNames(actions))
		if model == nil {
			messageBox(app.hwnd, "无法安全加载游戏模型：\n"+modelNote.Error(), appTitle, 0x10)
			return
		}
		if created {
			recordEvent("已生成当前游戏动作配置")
		}
		if modelNote != nil {
			recordEvent(modelNote.Error())
			recoveryNote = modelNote.Error()
		}
	}
	if err := installInputGuard(app.stopVK, mode != "human"); err != nil {
		messageBox(app.hwnd, "无法安装可靠的停止键保护，因此没有启动会话：\n"+err.Error(), appTitle, 0x10)
		return
	}
	app.profileDir, app.profileName, app.modelPath = profileDir, profileName, modelPath
	app.actions, app.model = actions, model
	app.stopRequested.Store(false)
	app.mode = mode
	app.steps = 0
	app.mu.Lock()
	app.lastAction, app.lastReward = "无", 0
	app.lastSaveError = ""
	app.lastRecoveryError = recoveryNote
	app.mu.Unlock()
	app.active.Store(true)
	setControlsEnabled(false)
	if mode == "human" {
		pSetForegroundWindow.Call(app.target)
		postStatus("用户控制模式已启动；游戏输入由用户操作，按 " + app.stopName + " 结束观察。")
		recordEvent("开始用户控制模式；停止键：" + app.stopName)
		go runHumanMode(app.target, app.targetPID)
		return
	}
	postStatus("Agent 已启动：" + modeName(mode) + "。物理键鼠输入已隔离；按 " + app.stopName + " 停止。")
	recordEvent("开始模式：" + mode + "；停止键：" + app.stopName + "；档案：" + profileName)
	go runAgent(mode, app.target, app.targetPID, app.modelPath)
}

func setControlsEnabled(enabled bool) {
	for _, h := range []uintptr{app.folderEdit, app.windowCombo, app.stopCombo, app.folderButton, app.refreshButton, app.playButton, app.agentButton, app.trainButton} {
		if h != 0 {
			pEnableWindow.Call(h, boolToUintptr(enabled))
		}
	}
	if app.blackboxButton != 0 {
		pEnableWindow.Call(app.blackboxButton, boolToUintptr(enabled))
	}
	menu, _, _ := pGetSystemMenu.Call(app.hwnd, 0)
	flag := uintptr(MF_ENABLED)
	if !enabled {
		flag = MF_GRAYED
	}
	pEnableMenuItem.Call(menu, SC_CLOSE, flag|MF_BYCOMMAND)
	pDrawMenuBar.Call(app.hwnd)
}

func boolToUintptr(v bool) uintptr {
	if v {
		return 1
	}
	return 0
}
func pIsWindowResult(hwnd uintptr) bool { r, _, _ := pIsWindow.Call(hwnd); return r != 0 }

func runHumanMode(target uintptr, pid uint32) {
	defer func() {
		if recovered := recover(); recovered != nil {
			recordEvent(fmt.Sprintf("用户控制观察异常：%v", recovered))
			postStatus("观察线程发生异常；按停止键结束本次会话。")
		}
		pPostMessageW.Call(app.hwnd, WM_APP_FINISH, 0, 0)
	}()
	for !app.stopRequested.Load() {
		if !pIsWindowResult(target) || targetPID(target) != pid {
			postStatus("目标窗口暂不可用；观察仍在运行，等待窗口恢复或按停止键结束。")
			_ = sleepWithStop(displayFrameInterval(target), &app.stopRequested)
			continue
		}
		frame, width, height, err := captureWindow(target)
		if err != nil {
			postStatus("读取游戏画面失败；观察仍在运行并持续重试。")
			_ = sleepWithStop(displayFrameInterval(target), &app.stopRequested)
			continue
		}
		postFrame(frame, width, height)
		app.mu.Lock()
		app.steps++
		step := app.steps
		app.lastAction = "用户控制"
		app.mu.Unlock()
		if step%30 == 0 {
			postStatus(fmt.Sprintf("用户控制中；已观察 %d 帧；按 %s 结束。", step, app.stopName))
		}
		if !sleepWithStop(displayFrameInterval(target), &app.stopRequested) {
			break
		}
	}
	recordEvent("用户结束控制模式")
}

func runAgent(mode string, target uintptr, pid uint32, modelPath string) {
	defer func() {
		releaseAllInputs()
		if recovered := recover(); recovered != nil {
			recordEvent(fmt.Sprintf("Agent 内部异常：%v", recovered))
			app.mu.Lock()
			app.lastRecoveryError = fmt.Sprint(recovered)
			app.mu.Unlock()
			saveModelSafely(modelPath)
			if !app.stopRequested.Load() {
				postStatus("Agent 遇到内部异常，已释放输入并保存模型，正在恢复运行。按 " + app.stopName + " 停止。")
				_ = sleepWithStop(displayFrameInterval(target), &app.stopRequested)
				if !app.stopRequested.Load() {
					go runAgent(mode, target, pid, modelPath)
					return
				}
			}
		}
		pPostMessageW.Call(app.hwnd, WM_APP_FINISH, 0, 0)
	}()
	rng := rand.New(rand.NewSource(time.Now().UnixNano()))
	var previousFeature []byte
	var pendingState uint64
	var pendingAction int
	pending := false
	lastSave := time.Now()
	for !app.stopRequested.Load() {
		if !pIsWindowResult(target) || targetPID(target) != pid {
			postStatus("目标窗口暂不可用或身份已变化；Agent 保持运行并等待恢复，不会向其他窗口发送输入。按 " + app.stopName + " 停止。")
			_ = sleepWithStop(displayFrameInterval(target), &app.stopRequested)
			continue
		}
		if iconic, _, _ := pIsIconic.Call(target); iconic != 0 {
			pShowWindow.Call(target, SW_RESTORE)
		}
		if !focusTarget(target, pid, &app.stopRequested) {
			if app.stopRequested.Load() {
				break
			}
			postStatus("正在重新取得目标窗口；Agent 不会因物理键鼠输入而暂停。按 " + app.stopName + " 停止。")
			continue
		}
		frame, fw, fh, err := captureWindow(target)
		if err != nil {
			postStatus("读取游戏画面失败；Agent 保持运行并持续重试，不会盲目发送按键。按 " + app.stopName + " 停止。")
			recordEvent("画面读取失败：" + err.Error())
			_ = sleepWithStop(displayFrameInterval(target), &app.stopRequested)
			continue
		}
		if app.stopRequested.Load() {
			break
		}
		feature, change := visualFeature(frame, fw, fh, previousFeature)
		state := featureHash(feature)
		if pending {
			reward := visualResponseReward(change)
			app.model.update(pendingState, pendingAction, state, reward)
			app.mu.Lock()
			app.lastReward = reward
			app.mu.Unlock()
			pending = false
		}
		actionIndex := app.model.choose(state, mode == "train", rng)
		if actionIndex < 0 || actionIndex >= len(app.actions) {
			actionIndex = 0
		}
		postFrame(frame, fw, fh)
		if err := performAction(target, pid, app.actions[actionIndex], &app.stopRequested); err != nil {
			if app.stopRequested.Load() {
				break
			}
			recordEvent("动作未执行：" + err.Error())
			postStatus(err.Error() + "；Agent 保持运行并重试。按 " + app.stopName + " 停止。")
			previousFeature = feature
			_ = sleepWithStop(displayFrameInterval(target), &app.stopRequested)
			continue
		}
		pendingState, pendingAction, pending = state, actionIndex, true
		app.model.markVisited(state)
		previousFeature = feature
		app.mu.Lock()
		app.steps++
		step := app.steps
		app.lastAction = app.actions[actionIndex].Name
		app.mu.Unlock()
		if step%10 == 0 {
			postStatus(fmt.Sprintf("运行中：%s | 步数 %d | 最近动作 %s | 视觉响应 %.3f | 按 %s 停止", modeName(mode), step, app.actions[actionIndex].Name, app.lastReward, app.stopName))
			pPostMessageW.Call(app.hwnd, WM_APP_UPDATE, 0, 0)
		}
		if step%25 == 0 || time.Since(lastSave) > 15*time.Second {
			saveModelSafely(modelPath)
			lastSave = time.Now()
		}
	}
	saveModelSafely(modelPath)
	recordEvent("用户停止模式：" + mode)
}

func saveModelSafely(path string) {
	if app == nil || app.model == nil {
		return
	}
	err := app.model.save(path)
	app.mu.Lock()
	if err != nil {
		app.lastSaveError = err.Error()
	} else {
		app.lastSaveError = ""
	}
	app.mu.Unlock()
	if err != nil {
		recordEvent("模型保存失败：" + err.Error())
	}
}

func modeName(mode string) string {
	switch mode {
	case "human":
		return "用户玩游戏"
	case "agent":
		return "Agent 玩游戏"
	case "train":
		return "Agent 自主训练"
	}
	return mode
}

func finishAgent() {
	releaseAllInputs()
	uninstallInputGuard()
	app.active.Store(false)
	setControlsEnabled(true)
	app.mu.Lock()
	saveErr := app.lastSaveError
	mode := app.mode
	app.mu.Unlock()
	if mode == "human" {
		postStatus("用户控制模式已结束。")
	} else if saveErr != "" {
		postStatus("已停止，但模型保存失败：" + saveErr)
	} else {
		postStatus("已停止。当前游戏模型已保存到所选工作目录的独立档案。")
	}
	updateHintUI()
}

func createBlackbox() {
	desktop := desktopPath()
	if desktop == "" {
		messageBox(app.hwnd, "无法定位 Windows 桌面目录；未在其他位置创建文件。", appTitle, 0x10)
		return
	}
	app.mu.Lock()
	events := append([]string(nil), app.events...)
	steps, action, status, reward := app.steps, app.lastAction, app.status, app.lastReward
	saveErr, runErr := app.lastSaveError, app.lastRecoveryError
	app.mu.Unlock()
	states := 0
	if app.model != nil {
		states = app.model.stateCount()
	}
	payload := map[string]any{
		"format": "LocalGameAgent-BlackBox-v3", "created_at": time.Now().Format(time.RFC3339Nano),
		"mode": modeName(app.mode), "target_window": app.targetTitle, "target_process": app.targetExePath,
		"game_profile": app.profileName, "steps": steps, "learned_states": states,
		"last_action": action, "last_visual_response": reward,
		"status": status, "last_save_error": saveErr, "last_recovery_error": runErr, "actions": actionNames(app.actions),
	}
	var data []byte
	low, high := 0, len(events)
	for low < high {
		mid := (low + high) / 2
		payload["events"] = events[mid:]
		candidate, _ := json.Marshal(payload)
		if len(candidate) <= MAX_BLACKBOX_BYTES {
			data = candidate
			high = mid
		} else {
			low = mid + 1
		}
	}
	if len(data) == 0 {
		payload["events"] = events[low:]
		data, _ = json.Marshal(payload)
	}
	if len(events) == 0 {
		payload["events"] = []string{}
		data, _ = json.Marshal(payload)
	}
	if len(data) > MAX_BLACKBOX_BYTES {
		payload = map[string]any{"format": "LocalGameAgent-BlackBox-v3", "created_at": time.Now().Format(time.RFC3339Nano), "steps": steps, "learned_states": states}
		data, _ = json.Marshal(payload)
	}
	if len(data) > MAX_BLACKBOX_BYTES {
		messageBox(app.hwnd, "黑匣子超过 1,000,000 字节限制，已取消写入。", appTitle, 0x10)
		return
	}
	name := "GameAgent_BlackBox_" + time.Now().Format("20060102_150405_000000000") + ".json"
	path := filepath.Join(desktop, name)
	if err := writeBlackboxFile(path, data); err != nil {
		messageBox(app.hwnd, "创建黑匣子失败："+err.Error(), appTitle, 0x10)
		return
	}
	info, err := os.Stat(path)
	if err != nil || info.Size() > MAX_BLACKBOX_BYTES {
		_ = os.Remove(path)
		messageBox(app.hwnd, "黑匣子大小校验失败，已撤销文件。", appTitle, 0x10)
		return
	}
	recordEvent("生成黑匣子：" + path)
	messageBox(app.hwnd, fmt.Sprintf("黑匣子已生成：\n%s\n大小：%d 字节（不超过 1,000,000 字节）", path, info.Size()), appTitle, 0x40)
}

func writeBlackboxFile(path string, data []byte) error {
	if len(data) > MAX_BLACKBOX_BYTES {
		return fmt.Errorf("黑匣子超过 1,000,000 字节限制")
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	n, writeErr := f.Write(data)
	if writeErr == nil {
		writeErr = f.Sync()
	}
	closeErr := f.Close()
	if writeErr != nil {
		_ = os.Remove(path)
		return writeErr
	}
	if closeErr != nil {
		_ = os.Remove(path)
		return closeErr
	}
	if n != len(data) {
		_ = os.Remove(path)
		return fmt.Errorf("黑匣子写入不完整")
	}
	info, err := os.Stat(path)
	if err != nil {
		_ = os.Remove(path)
		return err
	}
	if info.Size() > MAX_BLACKBOX_BYTES {
		_ = os.Remove(path)
		return fmt.Errorf("黑匣子大小超过限制")
	}
	return nil
}

func utf16PtrToString(ptr *uint16) string {
	if ptr == nil {
		return ""
	}
	return syscall.UTF16ToString(unsafe.Slice(ptr, 32768))
}

func desktopPath() string {
	id := GUID{Data1: 0xB4BFCC3A, Data2: 0xDB2C, Data3: 0x424C, Data4: [8]byte{0xB0, 0x29, 0x7F, 0xE9, 0x9A, 0x87, 0xC6, 0x41}}
	var path *uint16
	hr, _, _ := pSHGetKnownFolderPath.Call(uintptr(unsafe.Pointer(&id)), 0, 0, uintptr(unsafe.Pointer(&path)))
	if int32(hr) < 0 || path == nil {
		return ""
	}
	value := utf16PtrToString(path)
	pCoTaskMemFree.Call(uintptr(unsafe.Pointer(path)))
	return value
}

func drawPreview(hwnd uintptr) {
	var ps PAINTSTRUCT
	hdc, _, _ := pBeginPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	if hdc == 0 {
		return
	}
	defer pEndPaint.Call(hwnd, uintptr(unsafe.Pointer(&ps)))
	panel := RECT{Left: scaleCoord(20), Top: scaleCoord(371), Right: scaleCoord(930), Bottom: scaleCoord(620)}
	brush, _, _ := pGetStockObject.Call(1)
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&panel)), brush)
	pRectangle.Call(hdc, uintptr(panel.Left), uintptr(panel.Top), uintptr(panel.Right), uintptr(panel.Bottom))
	app.mu.Lock()
	frame := append([]byte(nil), app.frame...)
	fw, fh, mode := app.frameW, app.frameH, app.mode
	app.mu.Unlock()
	if mode != "" && len(frame) >= 4 && fw > 0 && fh > 0 {
		bmi := BITMAPINFO{Header: BITMAPINFOHEADER{Size: uint32(unsafe.Sizeof(BITMAPINFOHEADER{})), Width: int32(fw), Height: int32(-fh), Planes: 1, BitCount: 32, Compression: BI_RGB, SizeImage: uint32(fw * fh * 4)}}
		pSetStretchBltMode.Call(hdc, HALFTONE)
		pStretchDIBits.Call(hdc, uintptr(scaleCoord(22)), uintptr(scaleCoord(373)), uintptr(scaleCoord(906)), uintptr(scaleCoord(245)), 0, 0, uintptr(fw), uintptr(fh), uintptr(unsafe.Pointer(&frame[0])), uintptr(unsafe.Pointer(&bmi)), DIB_RGB_COLORS, SRCCOPY)
		runtime.KeepAlive(frame)
	} else {
		msg := "等待画面…\n选择运行模式后，这里会显示目标窗口画面。"
		pSetBkMode.Call(hdc, 1)
		pSetTextColor.Call(hdc, 0x505050)
		t := utf16(msg)
		textRect := RECT{Left: scaleCoord(35), Top: scaleCoord(450), Right: scaleCoord(915), Bottom: scaleCoord(540)}
		pDrawTextW.Call(hdc, uintptr(unsafe.Pointer(t)), ^uintptr(0), uintptr(unsafe.Pointer(&textRect)), 0x00000001|0x00000004)
		runtime.KeepAlive(t)
	}
}

func wndProc(hwnd uintptr, msg uint32, wp, lp uintptr) uintptr {
	switch msg {
	case WM_CREATE:
		app.hwnd = hwnd
		createControls(hwnd)
		refreshWindows()
		return 0
	case WM_COMMAND:
		id := int(wp & 0xFFFF)
		code := int((wp >> 16) & 0xFFFF)
		switch id {
		case ID_FOLDER_BTN:
			if code == BN_CLICKED {
				chooseFolder()
			}
		case ID_REFRESH_BTN:
			if code == BN_CLICKED {
				refreshWindows()
			}
		case ID_WINDOW_COMBO:
			if code == CBN_SELCHANGE {
				selectWindowFromCombo()
			}
		case ID_STOP_COMBO:
			if code == CBN_SELCHANGE {
				selectStopKey()
				postStatus("停止键已设置为 " + app.stopName + "。")
			}
		case ID_PLAY_BTN:
			if code == BN_CLICKED {
				startAgent("human")
			}
		case ID_AGENT_BTN:
			if code == BN_CLICKED {
				startAgent("agent")
			}
		case ID_TRAIN_BTN:
			if code == BN_CLICKED {
				startAgent("train")
			}
		case ID_BLACKBOX_BTN:
			if code == BN_CLICKED {
				createBlackbox()
			}
		}
		return 0
	case WM_HOTKEY:
		if app.active.Load() && wp == STOP_HOTKEY_ID {
			app.stopRequested.Store(true)
			postStatus("已收到 " + app.stopName + " 停止指令；正在释放输入并保存模型…")
			recordEvent("用户按下停止键：" + app.stopName)
		}
		return 0
	case WM_APP_UPDATE:
		updateStatusUI()
		updateHintUI()
		return 0
	case WM_APP_FRAME:
		var r RECT = RECT{Left: scaleCoord(20), Top: scaleCoord(371), Right: scaleCoord(930), Bottom: scaleCoord(620)}
		pInvalidateRect.Call(hwnd, uintptr(unsafe.Pointer(&r)), 0)
		return 0
	case WM_APP_FINISH:
		finishAgent()
		pInvalidateRect.Call(hwnd, 0, 0)
		return 0
	case WM_PAINT:
		drawPreview(hwnd)
		return 0
	case WM_SYSCOMMAND:
		if (wp&0xFFF0) == SC_CLOSE && app.active.Load() {
			postStatus("Agent 正在运行；请按 " + app.stopName + " 停止后再关闭窗口。")
			return 0
		}
	case WM_CLOSE:
		if app.active.Load() {
			postStatus("Agent 正在运行；请按 " + app.stopName + " 停止后再关闭窗口。")
			return 0
		}
		pDestroyWindow.Call(hwnd)
		return 0
	case WM_DESTROY:
		if app.active.Load() {
			return 0
		}
		uninstallInputGuard()
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, uintptr(msg), wp, lp)
	return r
}

func main() {
	pSetProcessDpiAwarenessContext.Call(^uintptr(1))
	if dpi, _, _ := pGetDpiForSystem.Call(); dpi > 0 {
		uiScale = float64(dpi) / 96
	}
	runtime.LockOSThread()
	coInit, _, _ := pCoInitializeEx.Call(0, 0x2)
	if coInit == 0 || coInit == 1 {
		defer pCoUninitialize.Call()
	}
	app = &App{stopVK: VK_ESCAPE, stopName: "ESC", status: "先选择工作目录，再刷新并手动选择游戏窗口。"}
	instance := getInstance()
	cn := utf16(className)
	cursor, _, _ := pLoadCursorW.Call(0, 32512)
	wc := WNDCLASSEX{CbSize: uint32(unsafe.Sizeof(WNDCLASSEX{})), Style: 0x0002 | 0x0001, WndProc: syscall.NewCallback(wndProc), Instance: instance, Cursor: syscall.Handle(cursor), Background: syscall.Handle(6), ClassName: cn}
	if r, _, _ := pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc))); r == 0 {
		messageBox(0, "窗口类注册失败。", appTitle, 0x10)
		return
	}
	caption := utf16(appTitle + " · Windows 11 x64")
	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cn)), uintptr(unsafe.Pointer(caption)), WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX, uintptr(scaleCoord(100)), uintptr(scaleCoord(60)), uintptr(scaleCoord(970)), uintptr(scaleCoord(710)), 0, 0, uintptr(instance), 0)
	runtime.KeepAlive(cn)
	runtime.KeepAlive(caption)
	runtime.KeepAlive(wc)
	if hwnd == 0 {
		messageBox(0, "主窗口创建失败。", appTitle, 0x10)
		return
	}
	pShowWindow.Call(hwnd, SW_SHOW)
	pUpdateWindow.Call(hwnd)
	var msg MSG
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&msg)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&msg)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&msg)))
	}
}
