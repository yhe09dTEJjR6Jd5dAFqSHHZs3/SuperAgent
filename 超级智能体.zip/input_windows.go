package main

import (
	"fmt"
	"runtime"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

const (
	inputKeyboard        = 1
	inputMouse           = 0
	keyUpFlag            = 0x0002
	mouseMove            = 0x0001
	mouseLeftDown        = 0x0002
	mouseLeftUp          = 0x0004
	mouseRightDown       = 0x0008
	mouseRightUp         = 0x0010
	mouseWheel           = 0x0800
	mouseAbsolute        = 0x8000
	mouseVirtualDesktop  = 0x4000
	keyboardHookInjected = 0x12
	mouseHookInjected    = 0x3
	wmKeyDown            = 0x0100
	wmKeyUp              = 0x0101
	wmSysKeyDown         = 0x0104
	wmSysKeyUp           = 0x0105
	wmLeftButtonUp       = 0x0202
	wmRightButtonUp      = 0x0205
	wmMiddleButtonUp     = 0x0208
	wmXButtonUp          = 0x020C
)

var inputState = struct {
	sync.Mutex
	keys  map[uint16]bool
	mouse map[uint32]bool
}{keys: make(map[uint16]bool), mouse: make(map[uint32]bool)}

var inputGuard = struct {
	sync.Mutex
	stopVK        atomic.Uint32
	blockPhysical atomic.Bool
	keyboard      uintptr
	mouse         uintptr
	keyboardProc  uintptr
	mouseProc     uintptr
}{}

func installInputGuard(stopVK uint16, blockPhysical bool) error {
	inputGuard.Lock()
	defer inputGuard.Unlock()
	if inputGuard.keyboard != 0 || inputGuard.mouse != 0 {
		return fmt.Errorf("输入保护已处于安装状态")
	}
	inputGuard.stopVK.Store(uint32(stopVK))
	inputGuard.blockPhysical.Store(blockPhysical)
	keyboardProc := syscall.NewCallback(func(nCode int, wParam, lParam uintptr) uintptr {
		if nCode >= 0 && lParam != 0 {
			var info KBDLLHOOKSTRUCT
			pRtlMoveMemory.Call(uintptr(unsafe.Pointer(&info)), lParam, unsafe.Sizeof(info))
			if info.Flags&keyboardHookInjected == 0 {
				if info.VkCode == inputGuard.stopVK.Load() {
					if wParam == wmKeyDown || wParam == wmSysKeyDown {
						app.stopRequested.Store(true)
						pPostMessageW.Call(app.hwnd, WM_HOTKEY, STOP_HOTKEY_ID, 0)
					}
					return 1
				}
				if inputGuard.blockPhysical.Load() && wParam != wmKeyUp && wParam != wmSysKeyUp {
					return 1
				}
			}
		}
		r, _, _ := pCallNextHookEx.Call(0, uintptr(nCode), wParam, lParam)
		return r
	})
	mouseProc := syscall.NewCallback(func(nCode int, wParam, lParam uintptr) uintptr {
		if nCode >= 0 && lParam != 0 {
			var info MSLLHOOKSTRUCT
			pRtlMoveMemory.Call(uintptr(unsafe.Pointer(&info)), lParam, unsafe.Sizeof(info))
			if info.Flags&mouseHookInjected == 0 && wParam != wmLeftButtonUp && wParam != wmRightButtonUp && wParam != wmMiddleButtonUp && wParam != wmXButtonUp {
				return 1
			}
		}
		r, _, _ := pCallNextHookEx.Call(0, uintptr(nCode), wParam, lParam)
		return r
	})
	module := getInstance()
	keyboard, _, keyboardErr := pSetWindowsHookExW.Call(WH_KEYBOARD_LL, keyboardProc, uintptr(module), 0)
	if keyboard == 0 {
		inputGuard.stopVK.Store(0)
		inputGuard.blockPhysical.Store(false)
		if keyboardErr != nil && keyboardErr != syscall.Errno(0) {
			return fmt.Errorf("无法隔离物理键盘输入：%w", keyboardErr)
		}
		return fmt.Errorf("无法隔离物理键盘输入")
	}
	var mouse uintptr
	if blockPhysical {
		var mouseErr error
		mouse, _, mouseErr = pSetWindowsHookExW.Call(WH_MOUSE_LL, mouseProc, uintptr(module), 0)
		if mouse == 0 {
			pUnhookWindowsHookEx.Call(keyboard)
			inputGuard.stopVK.Store(0)
			inputGuard.blockPhysical.Store(false)
			if mouseErr != nil && mouseErr != syscall.Errno(0) {
				return fmt.Errorf("无法隔离物理鼠标输入：%w", mouseErr)
			}
			return fmt.Errorf("无法隔离物理鼠标输入")
		}
	}
	inputGuard.keyboard = keyboard
	inputGuard.mouse = mouse
	inputGuard.keyboardProc = keyboardProc
	inputGuard.mouseProc = mouseProc
	return nil
}

func uninstallInputGuard() {
	inputGuard.Lock()
	keyboard, mouse := inputGuard.keyboard, inputGuard.mouse
	inputGuard.keyboard, inputGuard.mouse = 0, 0
	inputGuard.keyboardProc, inputGuard.mouseProc = 0, 0
	inputGuard.stopVK.Store(0)
	inputGuard.blockPhysical.Store(false)
	inputGuard.Unlock()
	if keyboard != 0 {
		pUnhookWindowsHookEx.Call(keyboard)
	}
	if mouse != 0 {
		pUnhookWindowsHookEx.Call(mouse)
	}
}

func sendKeyInput(vk uint16, up bool) error {
	flags := uint32(0)
	if up {
		flags = keyUpFlag
	}
	in := INPUT{Type: inputKeyboard}
	ki := KEYBDINPUT{Vk: vk, Flags: flags}
	*(*KEYBDINPUT)(unsafe.Pointer(&in.Data[0])) = ki
	count, _, callErr := pSendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
	runtime.KeepAlive(in)
	if count != 1 {
		if callErr != nil && callErr != syscall.Errno(0) {
			return callErr
		}
		return fmt.Errorf("SendInput 键盘输入失败（返回 %d）", count)
	}
	inputState.Lock()
	if up {
		delete(inputState.keys, vk)
	} else {
		inputState.keys[vk] = true
	}
	inputState.Unlock()
	return nil
}

func sendMouseInput(flags, data uint32) error {
	in := INPUT{Type: inputMouse}
	mi := MOUSEINPUT{MouseData: data, Flags: flags}
	*(*MOUSEINPUT)(unsafe.Pointer(&in.Data[0])) = mi
	count, _, callErr := pSendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
	runtime.KeepAlive(in)
	if count != 1 {
		if callErr != nil && callErr != syscall.Errno(0) {
			return callErr
		}
		return fmt.Errorf("SendInput 鼠标输入失败（返回 %d）", count)
	}
	inputState.Lock()
	switch flags {
	case mouseLeftDown:
		inputState.mouse[mouseLeftUp] = true
	case mouseLeftUp:
		delete(inputState.mouse, mouseLeftUp)
	case mouseRightDown:
		inputState.mouse[mouseRightUp] = true
	case mouseRightUp:
		delete(inputState.mouse, mouseRightUp)
	}
	inputState.Unlock()
	return nil
}

func sendMouseMove(x, y int32) error {
	left, _, _ := pGetSystemMetrics.Call(SM_XVIRTUALSCREEN)
	top, _, _ := pGetSystemMetrics.Call(SM_YVIRTUALSCREEN)
	width, _, _ := pGetSystemMetrics.Call(SM_CXVIRTUALSCREEN)
	height, _, _ := pGetSystemMetrics.Call(SM_CYVIRTUALSCREEN)
	if width <= 1 || height <= 1 {
		return fmt.Errorf("无法读取虚拟桌面尺寸")
	}
	dx := int64(x-int32(left)) * 65535 / int64(width-1)
	dy := int64(y-int32(top)) * 65535 / int64(height-1)
	if dx < 0 {
		dx = 0
	}
	if dx > 65535 {
		dx = 65535
	}
	if dy < 0 {
		dy = 0
	}
	if dy > 65535 {
		dy = 65535
	}
	in := INPUT{Type: inputMouse}
	mi := MOUSEINPUT{Dx: int32(dx), Dy: int32(dy), Flags: mouseMove | mouseAbsolute | mouseVirtualDesktop}
	*(*MOUSEINPUT)(unsafe.Pointer(&in.Data[0])) = mi
	count, _, callErr := pSendInput.Call(1, uintptr(unsafe.Pointer(&in)), unsafe.Sizeof(in))
	runtime.KeepAlive(in)
	if count != 1 {
		if callErr != nil && callErr != syscall.Errno(0) {
			return callErr
		}
		return fmt.Errorf("SendInput 鼠标移动失败（返回 %d）", count)
	}
	return nil
}

func releaseAllInputs() {
	inputState.Lock()
	keys := make([]uint16, 0, len(inputState.keys))
	for vk := range inputState.keys {
		keys = append(keys, vk)
	}
	buttons := make([]uint32, 0, len(inputState.mouse))
	for flag := range inputState.mouse {
		buttons = append(buttons, flag)
	}
	inputState.Unlock()
	for _, vk := range keys {
		_ = sendKeyInput(vk, true)
	}
	for _, flag := range buttons {
		_ = sendMouseInput(flag, 0)
	}
}

func displayFrameInterval(target uintptr) time.Duration {
	dc, _, _ := pGetDC.Call(target)
	if dc != 0 {
		refresh, _, _ := pGetDeviceCaps.Call(dc, VREFRESH)
		pReleaseDC.Call(target, dc)
		if refresh > 1 {
			return time.Second / time.Duration(refresh)
		}
	}
	return time.Second / 60
}

func focusTarget(target uintptr, pid uint32, stop atomicBool) bool {
	for !stop.Load() {
		if !pIsWindowResult(target) || targetPID(target) != pid {
			return false
		}
		if targetIsForeground(target, pid) {
			return true
		}
		pSetForegroundWindow.Call(target)
		if !sleepWithStop(displayFrameInterval(target), stop) {
			return false
		}
	}
	return false
}

type atomicBool interface{ Load() bool }

func actionDuration(target uintptr, action Action) time.Duration {
	if action.DurationMS > 0 {
		return time.Duration(action.DurationMS) * time.Millisecond
	}
	return displayFrameInterval(target)
}

func performAction(target uintptr, pid uint32, action Action, stop atomicBool) error {
	if stop.Load() {
		return nil
	}
	if !focusTarget(target, pid, stop) {
		if stop.Load() {
			return nil
		}
		return fmt.Errorf("目标窗口暂时无法获得前台焦点；未向其他窗口发送输入")
	}
	duration := actionDuration(target, action)
	if action.Mouse != "" {
		if err := performMouseAction(target, pid, action, duration, stop); err != nil {
			return err
		}
	}
	if len(action.Keys) > 0 {
		pressed := make([]uint16, 0, len(action.Keys))
		defer func() {
			for i := len(pressed) - 1; i >= 0; i-- {
				_ = sendKeyInput(pressed[i], true)
			}
		}()
		for _, vk := range action.Keys {
			if stop.Load() {
				return nil
			}
			if !targetIsForeground(target, pid) {
				return fmt.Errorf("输入期间游戏窗口失去焦点；已释放按键")
			}
			if err := sendKeyInput(vk, false); err != nil {
				return err
			}
			pressed = append(pressed, vk)
		}
		if !sleepWithTarget(duration, target, pid, stop) {
			if stop.Load() {
				return nil
			}
			return fmt.Errorf("输入期间游戏窗口失去焦点；已释放按键")
		}
	}
	if len(action.Keys) == 0 && action.Mouse == "" {
		_ = sleepWithStop(duration, stop)
	}
	return nil
}

func performMouseAction(target uintptr, pid uint32, action Action, duration time.Duration, stop atomicBool) error {
	var client RECT
	ok, _, _ := pGetClientRect.Call(target, uintptr(unsafe.Pointer(&client)))
	if ok == 0 {
		return fmt.Errorf("无法读取游戏客户区")
	}
	width, height := int(client.Right-client.Left), int(client.Bottom-client.Top)
	if width < 1 || height < 1 {
		return fmt.Errorf("游戏客户区尺寸无效")
	}
	pt := POINT{X: int32(float64(width-1) * action.X), Y: int32(float64(height-1) * action.Y)}
	ok, _, _ = pClientToScreen.Call(target, uintptr(unsafe.Pointer(&pt)))
	if ok == 0 {
		return fmt.Errorf("无法转换鼠标坐标")
	}
	if !targetIsForeground(target, pid) {
		return fmt.Errorf("游戏窗口失去焦点；未执行鼠标操作")
	}
	if action.Mouse == "move" || action.Mouse == "left" || action.Mouse == "right" || action.Mouse == "wheel_up" || action.Mouse == "wheel_down" {
		if err := sendMouseMove(pt.X, pt.Y); err != nil {
			return err
		}
	}
	if action.Mouse == "move" {
		return nil
	}
	if !targetIsForeground(target, pid) {
		return fmt.Errorf("鼠标操作前游戏窗口失去焦点")
	}
	switch action.Mouse {
	case "left":
		if err := sendMouseInput(mouseLeftDown, 0); err != nil {
			return err
		}
		defer func() { _ = sendMouseInput(mouseLeftUp, 0) }()
		if !sleepWithTarget(duration, target, pid, stop) && !stop.Load() {
			return fmt.Errorf("鼠标按住期间游戏窗口失去焦点；已释放鼠标键")
		}
	case "right":
		if err := sendMouseInput(mouseRightDown, 0); err != nil {
			return err
		}
		defer func() { _ = sendMouseInput(mouseRightUp, 0) }()
		if !sleepWithTarget(duration, target, pid, stop) && !stop.Load() {
			return fmt.Errorf("鼠标按住期间游戏窗口失去焦点；已释放鼠标键")
		}
	case "wheel_up":
		return sendMouseInput(mouseWheel, 120)
	case "wheel_down":
		return sendMouseInput(mouseWheel, 0xFFFFFF88)
	}
	return nil
}

func sleepWithStop(duration time.Duration, stop atomicBool) bool {
	deadline := time.Now().Add(duration)
	for time.Now().Before(deadline) {
		if stop.Load() {
			return false
		}
		remaining := time.Until(deadline)
		if remaining > time.Millisecond {
			remaining = time.Millisecond
		}
		time.Sleep(remaining)
	}
	return !stop.Load()
}

func sleepWithTarget(duration time.Duration, target uintptr, pid uint32, stop atomicBool) bool {
	deadline := time.Now().Add(duration)
	for time.Now().Before(deadline) {
		if stop.Load() || !targetIsForeground(target, pid) {
			return false
		}
		remaining := time.Until(deadline)
		if remaining > time.Millisecond {
			remaining = time.Millisecond
		}
		time.Sleep(remaining)
	}
	return !stop.Load() && targetIsForeground(target, pid)
}
