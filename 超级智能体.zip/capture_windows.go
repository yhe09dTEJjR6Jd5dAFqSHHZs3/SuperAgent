package main

import (
	"fmt"
	"math"
	"runtime"
	"unsafe"
)

func captureWindow(hwnd uintptr) ([]byte, int, int, error) {
	var r RECT
	ok, _, _ := pGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&r)))
	if ok == 0 {
		return nil, 0, 0, fmt.Errorf("GetWindowRect 失败")
	}
	sw, sh := int(r.Right-r.Left), int(r.Bottom-r.Top)
	if sw <= 0 || sh <= 0 {
		return nil, 0, 0, fmt.Errorf("窗口尺寸无效")
	}
	screenW, _, _ := pGetSystemMetrics.Call(SM_CXVIRTUALSCREEN)
	screenH, _, _ := pGetSystemMetrics.Call(SM_CYVIRTUALSCREEN)
	scale := 1.0
	if screenW > 0 && screenH > 0 {
		scale = math.Min(1, math.Min(float64(screenW)/float64(sw), float64(screenH)/float64(sh)))
	}
	w, h := int(math.Max(1, math.Round(float64(sw)*scale))), int(math.Max(1, math.Round(float64(sh)*scale)))
	maxInt := int(^uint(0) >> 1)
	if h == 0 || w > maxInt/h/4 {
		return nil, 0, 0, fmt.Errorf("窗口画面尺寸超出可分配范围")
	}
	pixelBytes := w * h * 4
	bmi := BITMAPINFO{Header: BITMAPINFOHEADER{Size: uint32(unsafe.Sizeof(BITMAPINFOHEADER{})), Width: int32(w), Height: int32(-h), Planes: 1, BitCount: 32, Compression: BI_RGB, SizeImage: uint32(pixelBytes)}}
	screenDC, _, _ := pGetDC.Call(0)
	if screenDC == 0 {
		return nil, 0, 0, fmt.Errorf("GetDC 失败")
	}
	defer pReleaseDC.Call(0, screenDC)
	memDC, _, _ := pCreateCompatibleDC.Call(screenDC)
	if memDC == 0 {
		return nil, 0, 0, fmt.Errorf("CreateCompatibleDC 失败")
	}
	defer pDeleteDC.Call(memDC)
	var bits uintptr
	bitmap, _, _ := pCreateDIBSection.Call(screenDC, uintptr(unsafe.Pointer(&bmi)), DIB_RGB_COLORS, uintptr(unsafe.Pointer(&bits)), 0, 0)
	if bitmap == 0 || bits == 0 {
		return nil, 0, 0, fmt.Errorf("CreateDIBSection 失败")
	}
	defer pDeleteObject.Call(bitmap)
	old, _, _ := pSelectObject.Call(memDC, bitmap)
	defer pSelectObject.Call(memDC, old)
	printed, _, _ := pPrintWindow.Call(hwnd, memDC, PW_RENDERFULLCONTENT)
	pix := make([]byte, pixelBytes)
	pRtlMoveMemory.Call(uintptr(unsafe.Pointer(&pix[0])), bits, uintptr(len(pix)))
	if printed == 0 {
		pSetStretchBltMode.Call(memDC, HALFTONE)
		pStretchBlt.Call(memDC, 0, 0, uintptr(w), uintptr(h), screenDC, uintptr(r.Left), uintptr(r.Top), uintptr(sw), uintptr(sh), SRCCOPY|CAPTUREBLT)
		pRtlMoveMemory.Call(uintptr(unsafe.Pointer(&pix[0])), bits, uintptr(len(pix)))
	}
	runtime.KeepAlive(pix)
	return pix, w, h, nil
}
