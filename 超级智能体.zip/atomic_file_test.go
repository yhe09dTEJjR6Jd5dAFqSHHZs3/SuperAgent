package main

import (
	"os"
	"path/filepath"
	"testing"
)

func TestAtomicWriteKeepsPreviousVersion(t *testing.T) {
	path := filepath.Join(t.TempDir(), "state.json")
	if err := atomicWriteFile(path, []byte("one"), 0600); err != nil {
		t.Fatal(err)
	}
	if err := atomicWriteFile(path, []byte("two"), 0600); err != nil {
		t.Fatal(err)
	}
	backup := path + ".bak"
	data, err := os.ReadFile(backup)
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != "one" {
		t.Fatalf("first backup=%q, want one", data)
	}
	if err := atomicWriteFile(path, []byte("three"), 0600); err != nil {
		t.Fatal(err)
	}
	data, err = os.ReadFile(backup)
	if err != nil {
		t.Fatal(err)
	}
	if string(data) != "two" {
		t.Fatalf("updated backup=%q, want two", data)
	}
}
