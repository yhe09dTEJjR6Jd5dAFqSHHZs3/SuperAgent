package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"sort"
	"sync"
)

const (
	modelVersion      = 3
	maxModelFileBytes = 64 * 1024 * 1024
	maxQValue         = 1e6
)

var legacyActionNames = []string{"不操作", "←", "→", "↑", "↓", "A", "D", "W", "S", "空格", "回车"}

type ModelDisk struct {
	Version      int                  `json:"version"`
	Actions      []string             `json:"actions,omitempty"`
	Q            map[uint64][]float64 `json:"q"`
	Visits       map[uint64]uint32    `json:"visits,omitempty"`
	ActionVisits map[uint64][]uint64  `json:"action_visits,omitempty"`
}

type Model struct {
	mu           sync.Mutex
	Q            map[uint64][]float64
	Visits       map[uint64]uint32
	ActionVisits map[uint64][]uint64
	ActionNames  []string
}

func modelStateLimit(actionCount int) int {
	perState := int64(128 + actionCount*40)
	limit := int(maxModelFileBytes / perState)
	if limit < 1 {
		return 1
	}
	return limit
}

func newModel(names []string) *Model {
	return &Model{
		Q:            make(map[uint64][]float64),
		Visits:       make(map[uint64]uint32),
		ActionVisits: make(map[uint64][]uint64),
		ActionNames:  append([]string(nil), names...),
	}
}

func (m *Model) ensureLocked(state uint64) []float64 {
	q := m.Q[state]
	if q == nil {
		q = make([]float64, len(m.ActionNames))
		m.Q[state] = q
	}
	return q
}

func (m *Model) ensureActionVisitsLocked(state uint64) []uint64 {
	visits := m.ActionVisits[state]
	if visits == nil {
		visits = make([]uint64, len(m.ActionNames))
		m.ActionVisits[state] = visits
	}
	return visits
}

func (m *Model) choose(state uint64, explore bool, rng interface {
	Float64() float64
	Intn(int) int
}) int {
	m.mu.Lock()
	defer m.mu.Unlock()
	if len(m.ActionNames) == 0 {
		return 0
	}
	q := m.ensureLocked(state)
	visits := m.ensureActionVisitsLocked(state)
	var total uint64
	for _, n := range visits {
		total += n
	}
	logTotal := math.Log(float64(total) + 1)
	bestScore := math.Inf(-1)
	best := make([]int, 0, len(q))
	for i, value := range q {
		score := value
		if explore {
			if visits[i] == 0 {
				score = math.Inf(1)
			} else if !math.IsInf(bestScore, 1) {
				score += math.Sqrt(2 * logTotal / float64(visits[i]))
			}
		}
		if score > bestScore {
			bestScore = score
			best = best[:0]
			best = append(best, i)
		} else if score == bestScore {
			best = append(best, i)
		}
	}
	if len(best) == 0 {
		return rng.Intn(len(q))
	}
	return best[rng.Intn(len(best))]
}

func (m *Model) update(state uint64, action int, next uint64, reward float64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if action < 0 || action >= len(m.ActionNames) {
		return
	}
	if math.IsNaN(reward) || math.IsInf(reward, 0) {
		return
	}
	q := m.ensureLocked(state)
	visits := m.ensureActionVisitsLocked(state)
	if visits[action] < ^uint64(0) {
		visits[action]++
	}
	q[action] += (reward - q[action]) / float64(visits[action])
	m.evictLocked(state, next)
}

func (m *Model) markVisited(state uint64) {
	m.mu.Lock()
	if m.Visits[state] < ^uint32(0) {
		m.Visits[state]++
	}
	m.evictLocked(state, state)
	m.mu.Unlock()
}

func (m *Model) evictLocked(keepA, keepB uint64) {
	limit := modelStateLimit(len(m.ActionNames))
	if len(m.Q) <= limit {
		return
	}
	type item struct {
		state  uint64
		visits uint32
	}
	items := make([]item, 0, len(m.Q))
	for state := range m.Q {
		if state == keepA || state == keepB {
			continue
		}
		items = append(items, item{state: state, visits: m.Visits[state]})
	}
	sort.Slice(items, func(i, j int) bool {
		if items[i].visits == items[j].visits {
			return items[i].state < items[j].state
		}
		return items[i].visits < items[j].visits
	})
	target := limit
	for _, it := range items {
		if len(m.Q) <= target {
			break
		}
		delete(m.Q, it.state)
		delete(m.Visits, it.state)
		delete(m.ActionVisits, it.state)
	}
}

func (m *Model) visitCount(state uint64) uint32 {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.Visits[state]
}

func (m *Model) stateCount() int {
	m.mu.Lock()
	defer m.mu.Unlock()
	return len(m.Q)
}

func (m *Model) save(path string) error {
	m.mu.Lock()
	d := ModelDisk{
		Version:      modelVersion,
		Actions:      append([]string(nil), m.ActionNames...),
		Q:            make(map[uint64][]float64, len(m.Q)),
		Visits:       make(map[uint64]uint32, len(m.Visits)),
		ActionVisits: make(map[uint64][]uint64, len(m.ActionVisits)),
	}
	for k, v := range m.Q {
		d.Q[k] = append([]float64(nil), v...)
	}
	for k, v := range m.Visits {
		d.Visits[k] = v
	}
	for k, v := range m.ActionVisits {
		d.ActionVisits[k] = append([]uint64(nil), v...)
	}
	m.mu.Unlock()
	data, err := json.Marshal(d)
	if err != nil {
		return err
	}
	if len(data) > maxModelFileBytes {
		return fmt.Errorf("模型文件超过安全容量")
	}
	return atomicWriteFile(path, data, 0600)
}

func loadModel(path string, currentActions []string) (*Model, error) {
	info, err := os.Stat(path)
	if err != nil {
		return nil, err
	}
	if info.Size() <= 0 || info.Size() > maxModelFileBytes {
		return nil, fmt.Errorf("模型文件大小无效：%d 字节", info.Size())
	}
	data, err := readBoundedFile(path, maxModelFileBytes)
	if err != nil {
		return nil, err
	}
	return decodeModel(data, currentActions)
}

func decodeModel(data []byte, currentActions []string) (*Model, error) {
	if len(data) == 0 || len(data) > maxModelFileBytes {
		return nil, fmt.Errorf("模型数据大小无效")
	}
	var d ModelDisk
	if err := json.Unmarshal(data, &d); err != nil {
		return nil, fmt.Errorf("模型 JSON 无效：%w", err)
	}
	if d.Q == nil {
		return nil, fmt.Errorf("模型缺少 Q 表")
	}
	if len(d.Q) > modelStateLimit(len(currentActions)) {
		return nil, fmt.Errorf("模型状态数超过当前动作集对应的文件容量")
	}
	var storedNames []string
	switch d.Version {
	case 1:
		storedNames = legacyActionNames
	case 2, modelVersion:
		storedNames = d.Actions
	default:
		return nil, fmt.Errorf("模型版本不受支持：%d", d.Version)
	}
	if len(storedNames) == 0 {
		return nil, fmt.Errorf("模型缺少动作名称")
	}
	if len(currentActions) == 0 {
		return nil, fmt.Errorf("当前动作集为空")
	}
	storedIndex := make(map[string]int, len(storedNames))
	for i, name := range storedNames {
		if name == "" {
			return nil, fmt.Errorf("模型包含空动作名称")
		}
		if _, exists := storedIndex[name]; exists {
			return nil, fmt.Errorf("模型包含重复动作名称")
		}
		storedIndex[name] = i
	}
	currentIndex := make([]int, len(currentActions))
	matched := 0
	for i, name := range currentActions {
		idx, ok := storedIndex[name]
		if ok {
			currentIndex[i] = idx
			matched++
		} else {
			currentIndex[i] = -1
		}
	}
	if matched == 0 {
		return nil, fmt.Errorf("模型与当前动作集没有可迁移的共同动作")
	}
	if len(d.Visits) > modelStateLimit(len(currentActions)) || len(d.ActionVisits) > modelStateLimit(len(currentActions)) {
		return nil, fmt.Errorf("模型访问计数超过安全容量")
	}
	m := newModel(currentActions)
	for state, values := range d.Q {
		if len(values) != len(storedNames) {
			return nil, fmt.Errorf("状态 %d 的 Q 值长度错误", state)
		}
		converted := make([]float64, len(currentActions))
		for _, value := range values {
			if math.IsNaN(value) || math.IsInf(value, 0) || math.Abs(value) > maxQValue {
				return nil, fmt.Errorf("状态 %d 包含非法 Q 值", state)
			}
		}
		for i, oldIdx := range currentIndex {
			if oldIdx >= 0 {
				converted[i] = values[oldIdx]
			}
		}
		m.Q[state] = converted
	}
	for state, count := range d.Visits {
		if _, exists := m.Q[state]; !exists {
			return nil, fmt.Errorf("访问计数引用了不存在的状态 %d", state)
		}
		m.Visits[state] = count
	}
	if d.Version >= modelVersion {
		for state, values := range d.ActionVisits {
			if _, exists := m.Q[state]; !exists {
				return nil, fmt.Errorf("动作访问计数引用了不存在的状态 %d", state)
			}
			if len(values) != len(storedNames) {
				return nil, fmt.Errorf("状态 %d 的动作访问计数长度错误", state)
			}
			converted := make([]uint64, len(currentActions))
			for i, oldIdx := range currentIndex {
				if oldIdx >= 0 {
					converted[i] = values[oldIdx]
				}
			}
			m.ActionVisits[state] = converted
		}
	}
	return m, nil
}

func visualResponseReward(visualChange float64) float64 {
	if math.IsNaN(visualChange) || math.IsInf(visualChange, 0) {
		return 0
	}
	return clamp(visualChange, 0, 1)
}

func clamp(v, minValue, maxValue float64) float64 {
	if v < minValue {
		return minValue
	}
	if v > maxValue {
		return maxValue
	}
	return v
}
