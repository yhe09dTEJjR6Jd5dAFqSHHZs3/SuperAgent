package main

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

const (
	maxActions       = 64
	maxActionCfgSize = 256 * 1024
)

type Action struct {
	Name       string
	Keys       []uint16
	Mouse      string
	X          float64
	Y          float64
	DurationMS int
}

type ActionConfig struct {
	Version int                 `json:"version"`
	Actions []ActionConfigEntry `json:"actions"`
}

type ActionConfigEntry struct {
	Name       string   `json:"name"`
	Keys       []string `json:"keys,omitempty"`
	Mouse      string   `json:"mouse,omitempty"`
	X          *float64 `json:"x,omitempty"`
	Y          *float64 `json:"y,omitempty"`
	DurationMS int      `json:"duration_ms,omitempty"`
}

func defaultActions(stopKeys ...uint16) []Action {
	acts := []Action{
		{Name: "不操作"},
		{Name: "←", Keys: []uint16{0x25}},
		{Name: "→", Keys: []uint16{0x27}},
		{Name: "↑", Keys: []uint16{0x26}},
		{Name: "↓", Keys: []uint16{0x28}},
		{Name: "A", Keys: []uint16{'A'}},
		{Name: "D", Keys: []uint16{'D'}},
		{Name: "W", Keys: []uint16{'W'}},
		{Name: "S", Keys: []uint16{'S'}},
		{Name: "空格", Keys: []uint16{0x20}},
		{Name: "回车", Keys: []uint16{0x0D}},
		{Name: "Shift+W", Keys: []uint16{0x10, 'W'}},
		{Name: "Shift+A", Keys: []uint16{0x10, 'A'}},
		{Name: "Shift+S", Keys: []uint16{0x10, 'S'}},
		{Name: "Shift+D", Keys: []uint16{0x10, 'D'}},
		{Name: "鼠标移至中心", Mouse: "move", X: 0.5, Y: 0.5},
		{Name: "鼠标移至左侧", Mouse: "move", X: 0.25, Y: 0.5},
		{Name: "鼠标移至右侧", Mouse: "move", X: 0.75, Y: 0.5},
		{Name: "鼠标移至上方", Mouse: "move", X: 0.5, Y: 0.25},
		{Name: "鼠标移至下方", Mouse: "move", X: 0.5, Y: 0.75},
		{Name: "鼠标左键", Mouse: "left", X: 0.5, Y: 0.5},
		{Name: "鼠标右键", Mouse: "right", X: 0.5, Y: 0.5},
		{Name: "滚轮向上", Mouse: "wheel_up", X: 0.5, Y: 0.5},
		{Name: "滚轮向下", Mouse: "wheel_down", X: 0.5, Y: 0.5},
	}
	if len(stopKeys) == 0 || stopKeys[0] == 0 {
		return acts
	}
	stopVK := stopKeys[0]
	filtered := make([]Action, 0, len(acts))
	for _, action := range acts {
		conflict := false
		for _, key := range action.Keys {
			if key == stopVK {
				conflict = true
				break
			}
		}
		if !conflict {
			filtered = append(filtered, action)
		}
	}
	return filtered
}

func actionNames(actions []Action) []string {
	names := make([]string, len(actions))
	for i := range actions {
		names[i] = actions[i].Name
	}
	return names
}

func defaultActionConfig(stopKeys ...uint16) ActionConfig {
	acts := defaultActions(stopKeys...)
	cfg := ActionConfig{Version: 1, Actions: make([]ActionConfigEntry, 0, len(acts))}
	for _, a := range acts {
		entry := ActionConfigEntry{Name: a.Name, Mouse: a.Mouse, DurationMS: a.DurationMS}
		for _, vk := range a.Keys {
			entry.Keys = append(entry.Keys, virtualKeyName(vk))
		}
		x, y := a.X, a.Y
		entry.X, entry.Y = &x, &y
		cfg.Actions = append(cfg.Actions, entry)
	}
	return cfg
}

func loadActions(path string, stopVK uint16) ([]Action, bool, error) {
	info, statErr := os.Stat(path)
	if os.IsNotExist(statErr) {
		cfg := defaultActionConfig(stopVK)
		data, marshalErr := json.MarshalIndent(cfg, "", "  ")
		if marshalErr != nil {
			return defaultActions(stopVK), false, marshalErr
		}
		if writeErr := atomicWriteFile(path, data, 0600); writeErr != nil {
			return defaultActions(stopVK), false, writeErr
		}
		acts, validateErr := validateActionConfig(cfg, stopVK)
		return acts, true, validateErr
	}
	if statErr != nil {
		return defaultActions(stopVK), false, statErr
	}
	if info.Size() <= 0 || info.Size() > maxActionCfgSize {
		return defaultActions(stopVK), false, fmt.Errorf("actions.json 大小无效")
	}
	b, err := readBoundedFile(path, maxActionCfgSize)
	if err != nil {
		return defaultActions(stopVK), false, err
	}
	var cfg ActionConfig
	if err := json.Unmarshal(b, &cfg); err != nil {
		return defaultActions(stopVK), false, fmt.Errorf("actions.json 格式错误：%w", err)
	}
	filtered, changed := filterStopKeyConflicts(cfg, stopVK)
	if changed {
		updatedData, marshalErr := json.MarshalIndent(filtered, "", "  ")
		if marshalErr != nil {
			return defaultActions(stopVK), false, marshalErr
		}
		if writeErr := atomicWriteFile(path, updatedData, 0600); writeErr != nil {
			return defaultActions(stopVK), false, writeErr
		}
		cfg = filtered
	}
	acts, err := validateActionConfig(cfg, stopVK)
	if err != nil {
		return defaultActions(stopVK), false, err
	}
	return acts, false, nil
}

func filterStopKeyConflicts(cfg ActionConfig, stopVK uint16) (ActionConfig, bool) {
	if stopVK == 0 {
		return cfg, false
	}
	filtered := make([]ActionConfigEntry, 0, len(cfg.Actions))
	changed := false
	for _, entry := range cfg.Actions {
		conflict := false
		for _, keyName := range entry.Keys {
			if vk, ok := parseVirtualKey(keyName); ok && vk == stopVK {
				conflict = true
				break
			}
		}
		if conflict {
			changed = true
			continue
		}
		filtered = append(filtered, entry)
	}
	cfg.Actions = filtered
	return cfg, changed
}

func validateActionConfig(cfg ActionConfig, stopVK uint16) ([]Action, error) {
	if cfg.Version != 1 {
		return nil, fmt.Errorf("actions.json 版本不受支持")
	}
	if len(cfg.Actions) < 1 || len(cfg.Actions) > maxActions {
		return nil, fmt.Errorf("动作数量必须在 1 到 %d 之间", maxActions)
	}
	out := make([]Action, 0, len(cfg.Actions))
	seen := make(map[string]bool)
	for i, entry := range cfg.Actions {
		name := strings.TrimSpace(entry.Name)
		if name == "" || len([]rune(name)) > 40 {
			return nil, fmt.Errorf("第 %d 个动作名称为空或过长", i+1)
		}
		if seen[name] {
			return nil, fmt.Errorf("动作名称重复：%s", name)
		}
		seen[name] = true
		a := Action{Name: name, Mouse: strings.ToLower(strings.TrimSpace(entry.Mouse)), DurationMS: entry.DurationMS}
		if a.DurationMS < 0 || int64(a.DurationMS) > int64(^uint64(0)>>1)/int64(1000000) {
			return nil, fmt.Errorf("动作 %q 的 duration_ms 超出系统可表示范围", name)
		}
		if entry.X != nil {
			a.X = *entry.X
		} else {
			a.X = 0.5
		}
		if entry.Y != nil {
			a.Y = *entry.Y
		} else {
			a.Y = 0.5
		}
		if a.X < 0 || a.X > 1 || a.Y < 0 || a.Y > 1 {
			return nil, fmt.Errorf("动作 %q 的鼠标坐标必须在 0 到 1 之间", name)
		}
		if len(entry.Keys) > 3 {
			return nil, fmt.Errorf("动作 %q 的组合键不能超过 3 个", name)
		}
		keySeen := make(map[uint16]bool)
		for _, keyName := range entry.Keys {
			vk, ok := parseVirtualKey(keyName)
			if !ok || !allowedActionKey(vk) {
				return nil, fmt.Errorf("动作 %q 包含不允许的按键：%s", name, keyName)
			}
			if vk == stopVK {
				return nil, fmt.Errorf("动作 %q 使用了当前停止键；请更换动作键或停止键", name)
			}
			if keySeen[vk] {
				return nil, fmt.Errorf("动作 %q 包含重复按键", name)
			}
			keySeen[vk] = true
			a.Keys = append(a.Keys, vk)
		}
		switch a.Mouse {
		case "", "move", "left", "right", "wheel_up", "wheel_down":
		default:
			return nil, fmt.Errorf("动作 %q 的 mouse 类型无效", name)
		}
		if len(a.Keys) == 0 && a.Mouse == "" && i != 0 {
			return nil, fmt.Errorf("动作 %q 没有键盘或鼠标操作", name)
		}
		if i == 0 && (len(a.Keys) != 0 || a.Mouse != "") {
			return nil, fmt.Errorf("第一个动作必须是不操作动作（无按键、无鼠标操作）")
		}
		out = append(out, a)
	}
	return out, nil
}

func allowedActionKey(vk uint16) bool {
	if vk >= 'A' && vk <= 'Z' || vk >= '0' && vk <= '9' {
		return true
	}
	switch vk {
	case 0x08, 0x09, 0x0D, 0x10, 0x11, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E:
		return true
	}
	return (vk >= 0x60 && vk <= 0x6F) || (vk >= 0x70 && vk <= 0x87) ||
		(vk >= 0xBA && vk <= 0xC0) || (vk >= 0xDB && vk <= 0xDF)
}

func parseVirtualKey(name string) (uint16, bool) {
	s := strings.ToUpper(strings.TrimSpace(name))
	if len(s) == 1 {
		if s[0] >= 'A' && s[0] <= 'Z' || s[0] >= '0' && s[0] <= '9' {
			return uint16(s[0]), true
		}
	}
	switch s {
	case "BACKSPACE":
		return 0x08, true
	case "TAB":
		return 0x09, true
	case "ENTER", "RETURN":
		return 0x0D, true
	case "SHIFT":
		return 0x10, true
	case "CTRL", "CONTROL":
		return 0x11, true
	case "SPACE":
		return 0x20, true
	case "PAGEUP", "PAGE UP":
		return 0x21, true
	case "PAGEDOWN", "PAGE DOWN":
		return 0x22, true
	case "END":
		return 0x23, true
	case "HOME":
		return 0x24, true
	case "LEFT":
		return 0x25, true
	case "UP":
		return 0x26, true
	case "RIGHT":
		return 0x27, true
	case "DOWN":
		return 0x28, true
	case "INSERT":
		return 0x2D, true
	case "DELETE":
		return 0x2E, true
	case "PRINTSCREEN", "PRINT SCREEN":
		return 0x2C, true
	case "NUMLOCK", "NUM LOCK":
		return 0x90, true
	case "NUMPAD0", "NUMPAD 0":
		return 0x60, true
	case "NUMPAD1", "NUMPAD 1":
		return 0x61, true
	case "NUMPAD2", "NUMPAD 2":
		return 0x62, true
	case "NUMPAD3", "NUMPAD 3":
		return 0x63, true
	case "NUMPAD4", "NUMPAD 4":
		return 0x64, true
	case "NUMPAD5", "NUMPAD 5":
		return 0x65, true
	case "NUMPAD6", "NUMPAD 6":
		return 0x66, true
	case "NUMPAD7", "NUMPAD 7":
		return 0x67, true
	case "NUMPAD8", "NUMPAD 8":
		return 0x68, true
	case "NUMPAD9", "NUMPAD 9":
		return 0x69, true
	case "NUMPAD_MULTIPLY":
		return 0x6A, true
	case "NUMPAD_ADD":
		return 0x6B, true
	case "NUMPAD_SEPARATOR":
		return 0x6C, true
	case "NUMPAD_SUBTRACT":
		return 0x6D, true
	case "NUMPAD_DECIMAL":
		return 0x6E, true
	case "NUMPAD_DIVIDE":
		return 0x6F, true
	case "OEM_1":
		return 0xBA, true
	case "OEM_PLUS":
		return 0xBB, true
	case "OEM_COMMA":
		return 0xBC, true
	case "OEM_MINUS":
		return 0xBD, true
	case "OEM_PERIOD":
		return 0xBE, true
	case "OEM_2":
		return 0xBF, true
	case "OEM_3":
		return 0xC0, true
	case "OEM_4":
		return 0xDB, true
	case "OEM_5":
		return 0xDC, true
	case "OEM_6":
		return 0xDD, true
	case "OEM_7":
		return 0xDE, true
	case "OEM_8":
		return 0xDF, true
	}
	if strings.HasPrefix(s, "F") {
		if n, err := strconv.Atoi(strings.TrimPrefix(s, "F")); err == nil && n >= 1 && n <= 24 {
			return uint16(0x6F + n), true
		}
	}
	return 0, false
}

func virtualKeyName(vk uint16) string {
	if vk >= 'A' && vk <= 'Z' || vk >= '0' && vk <= '9' {
		return string(rune(vk))
	}
	switch vk {
	case 0x08:
		return "BACKSPACE"
	case 0x09:
		return "TAB"
	case 0x0D:
		return "ENTER"
	case 0x10:
		return "SHIFT"
	case 0x11:
		return "CTRL"
	case 0x20:
		return "SPACE"
	case 0x21:
		return "PAGEUP"
	case 0x22:
		return "PAGEDOWN"
	case 0x23:
		return "END"
	case 0x24:
		return "HOME"
	case 0x25:
		return "LEFT"
	case 0x26:
		return "UP"
	case 0x27:
		return "RIGHT"
	case 0x28:
		return "DOWN"
	case 0x2D:
		return "INSERT"
	case 0x2E:
		return "DELETE"
	case 0x2C:
		return "PRINTSCREEN"
	case 0x90:
		return "NUMLOCK"
	case 0x6A:
		return "NUMPAD_MULTIPLY"
	case 0x6B:
		return "NUMPAD_ADD"
	case 0x6C:
		return "NUMPAD_SEPARATOR"
	case 0x6D:
		return "NUMPAD_SUBTRACT"
	case 0x6E:
		return "NUMPAD_DECIMAL"
	case 0x6F:
		return "NUMPAD_DIVIDE"
	case 0xBA:
		return "OEM_1"
	case 0xBB:
		return "OEM_PLUS"
	case 0xBC:
		return "OEM_COMMA"
	case 0xBD:
		return "OEM_MINUS"
	case 0xBE:
		return "OEM_PERIOD"
	case 0xBF:
		return "OEM_2"
	case 0xC0:
		return "OEM_3"
	case 0xDB:
		return "OEM_4"
	case 0xDC:
		return "OEM_5"
	case 0xDD:
		return "OEM_6"
	case 0xDE:
		return "OEM_7"
	case 0xDF:
		return "OEM_8"
	}
	if vk >= 0x60 && vk <= 0x69 {
		return fmt.Sprintf("NUMPAD%d", vk-0x60)
	}
	if vk >= 0x70 && vk <= 0x87 {
		return fmt.Sprintf("F%d", vk-0x6F)
	}
	return fmt.Sprintf("VK_%02X", vk)
}

func actionConfigPath(profileDir string) string {
	return filepath.Join(profileDir, "actions.json")
}
